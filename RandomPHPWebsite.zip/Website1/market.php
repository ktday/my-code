<?php

$conn = mysqli_connect("localhost","root","","database");
if(!$conn){
    echo("Invalid database connection.");exit();
}

echo"
<link rel='stylesheet' href='style.css' />
";

if(isset($_COOKIE["sessionID"])){
    $sessionID = mysqli_real_escape_string($conn, $_COOKIE["sessionID"]);

    $accq = mysqli_query($conn,"SELECT * FROM users WHERE `session` = '$sessionID'");
    if(mysqli_num_rows($accq) == 1){
        $acc = mysqli_fetch_array($accq);

        if(isset($_POST['buy'])){
            $itemid = mysqli_real_escape_string($conn, $_POST['buy']);
            $itemq = mysqli_query($conn,"SELECT * FROM items WHERE `id` = '$itemid'");
            if(mysqli_num_rows($itemq) == 1){
                $item = mysqli_fetch_array($itemq);

                if($acc['money'] >= $item['price']){

                    // Buy
                    $remaining = $acc['money'] - $item['price'];
                    mysqli_query($conn, "UPDATE users SET `money` = '$remaining' WHERE `id` = '$acc[id]'");

                    // Add item
                    $time = time();
                    mysqli_query($conn, "INSERT INTO owners VALUES(NULL, '$acc[id]', '$itemid', '$item[price]', '$time')");
                    echo"<center><title>You bought $item[name]</title>
                    <h1 style='color:green;'>Successfully bought \"$item[name]\"</h1>
                    <a class='button' href='/website/'>Back to home</a>   <a class='button' href='/website/market.php'>Buy something else</a>
                    </center>";exit();

                }else{
                    echo"<title>You're too poor 🤣</title><h1 style='color:red;'>You do not have enough money.</h1>";exit();
                }
            }
        }

        echo"<title>Market</title>";
        echo"<div class='box'><h1>Market</h1><p>Current balance \$<span style='color:#6ff'>$acc[money]</span></p><hr>";

        $items = mysqli_query($conn,"SELECT * FROM items WHERE `onsale` = '1' ORDER BY price ASC");

        if(mysqli_num_rows($items) == 0){
            echo"<h2>There are no items for sale.</h2>";
        }else{

            include("format.php");
            while(($item = mysqli_fetch_array($items))){
                $color = formatRarity($item["rarity"]);
                echo"<h2 style='color:$color;'>$item[name]</h2><p>Price: \$<span style='color:#6ff'>$item[price]</span></p><form method='post'><button name='buy' value='$item[id]'>Buy me</button></form><hr>";
            }

        }   

        echo"<br><a href='/website/' class='button'>Return</a><br><br></div>";

    }else{
        setcookie("sessionID", "", 1, "/website/");
        echo"<h1 style='color:red;'>Invalid account. Reload the page to log in again.</h1>";exit();
    }
}else{
    echo"<script>window.location='/website/'</script>";exit();
}