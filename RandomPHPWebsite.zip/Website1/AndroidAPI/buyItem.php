<?php

$conn = mysqli_connect("localhost","root","","database");
if(!$conn){
    echo("Invalid database connection.");exit();
}

if(isset($_GET["id"]) && isset($_GET["item"])){
    $id = mysqli_real_escape_string($conn,$_GET['id']);
    $item = mysqli_real_escape_string($conn,$_GET['item']);

    $user = mysqli_query($conn,"SELECT * FROM `users` WHERE `id` = '$id'");
    if(mysqli_num_rows($user) == 1){
        
        $u = mysqli_fetch_array($user);

        $itemq = mysqli_query($conn,"SELECT * FROM `items` WHERE `id` = '$item'");
        if(mysqli_num_rows($itemq) == 1){
            
            $i = mysqli_fetch_array($itemq);
            if($u["banned"] != "0"){
                exit("-1");
            }

            if($u["money"] < $i["price"]){
                exit("0");
            }

            $money = $u["money"] - $i["price"];
            $time = time();

            mysqli_query($conn,"UPDATE `users` SET `money` = '$money' WHERE `id` = '$id'");
            mysqli_query($conn,"INSERT INTO `owners` VALUES(NULL,'$id','$item','$i[price]','$time')");
            exit("1");

        }else{
            echo"-1";
        }

    }else{
        echo"-1";
    }
}else{
    echo"-1";
}

?>