<?php

$conn = mysqli_connect("localhost","root","","database");
if(!$conn){
    echo("Invalid database connection.");exit();
}

if(isset($_GET["id"])){
    $id = mysqli_real_escape_string($conn,$_GET['id']);

    $itemsq = mysqli_query($conn,"SELECT `name`, `money`, `created`, `banned` FROM `users` WHERE `id` = '$id'");
    if(mysqli_num_rows($itemsq) == 0){
        echo"0";
    }else{
        $item = mysqli_fetch_array($itemsq);
        echo(json_encode($item));
    }
}else{
    echo"-1";
}

?>