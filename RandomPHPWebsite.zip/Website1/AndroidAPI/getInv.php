<?php

$conn = mysqli_connect("localhost","root","","database");
if(!$conn){
    echo("Invalid database connection.");exit();
}

if(isset($_GET["id"])){
    $id = mysqli_real_escape_string($conn,$_GET['id']);

    $itemsq = mysqli_query($conn,"SELECT owners.*, items.* FROM `owners` INNER JOIN items ON items.id = owners.item WHERE owners.user = '$id'");
    if(mysqli_num_rows($itemsq) == 0){
        echo"0";
    }else{
        $arr = [];
        while(($item = mysqli_fetch_array($itemsq))){
            array_push($arr, [
                "name" => $item["name"],
                "price" => $item["price"],
                "rarity" => $item["rarity"]
            ]);
        }
        echo(json_encode($arr));
    }
}else{
    echo"-1";
}