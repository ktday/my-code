<?php

$conn = mysqli_connect("localhost","root","","database");
if(!$conn){
    echo("Invalid database connection.");exit();
}

$items = mysqli_query($conn,"SELECT * FROM items WHERE `onsale` = '1' ORDER BY price ASC");

if(mysqli_num_rows($items) == 0){
    echo"[]";exit();
}else{

    $arr = [];

    while(($item = mysqli_fetch_array($items))){
        array_push($arr, [
            "id" => $item["id"],
            "name" => $item["name"],
            "price" => $item["price"],
            "rarity" => $item["rarity"]
        ]);
    }

    echo(json_encode($arr));

}

?>