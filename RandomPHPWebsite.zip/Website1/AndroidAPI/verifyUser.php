<?php

$conn = mysqli_connect("localhost","root","","database");
if(!$conn){
    echo("Invalid database connection.");exit();
}

if(isset($_GET["username"]) && isset($_GET['password'])){
    $username = mysqli_real_escape_string($conn,$_GET['username']);
    $password = mysqli_real_escape_string($conn,$_GET['password']);

    // totally didnt steal code from login page
    $accq = mysqli_query($conn,"SELECT * FROM users WHERE `name` = '$username'");
    if(mysqli_num_rows($accq) == 1){
        $acc = mysqli_fetch_array($accq);
        $verify = password_verify($password, $acc['password']);
        if($verify){
            $time = time();
            mysqli_query($conn,"UPDATE `users` SET `loggedin` = '$time' WHERE `name` = '$username'");
            echo(json_encode($acc));
        }else{
            echo"1";
        }
    }else{
        echo"0";
    }
}else{
    echo"-1";
}

?>