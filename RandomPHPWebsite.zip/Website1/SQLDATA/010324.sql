-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 01, 2024 at 02:41 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `database`
--

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`id`, `name`, `price`, `rarity`, `onsale`) VALUES
(1, '🍎 Apple', 2, 'common', 1),
(2, '🎁 Surprise gift', 15, 'common', 1),
(3, '💎 Diamond', 50, 'common', 1),
(4, '📐🏠', 250, 'epic', 0),
(5, '🎫 Ticket to North Korea', 425, 'rare', 1),
(6, '💤 +1 hour of sleep per night', 560, 'rare', 1),
(7, '🚗 New Bugatti', 5000000, 'epic', 0),
(8, '🇫🇷 France', 2958000000000, 'epic', 1),
(9, '😃 1 Month subscription to: Life', 1000, 'rare', 1),
(10, '👑 Crown', 2500, 'rare', 1),
(11, '🥖 Хлеб', 10, 'common', 1),
(12, '👨 Борис Джонсон', 67000000, 'epic', 1);

--
-- Dumping data for table `owners`
--

INSERT INTO `owners` (`id`, `user`, `item`, `boughtprice`, `time`) VALUES
(1, 1, 1, 10, 6326232),
(2, 1, 8, 2958000000000, 1709299524),
(3, 1, 5, 425, 1709300048),
(4, 1, 4, 250, 1709300057),
(5, 1, 12, 67000000, 1709300434);

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `password`, `session`, `money`, `created`, `loggedin`, `moneytime`) VALUES
(1, 'John', '$2y$10$4T6hNAM4wkEa9fGl38pwH.RV1VdhGP8E0MEvo80frXueMpsHIqbVy', 'abc', 277481493928, 0, 1709299462, 1709300532),
(3, 'User2', '$2y$10$bjwUHrcqTQaWUgAqFgbh..zwPttgqqu5WGt6zHFvDSmuFmC9vTBl.', '85vkhLx2Olb4RyHsQCyP6EfOD9ULGL0xl4GDZM1sD9RT3fHF4kd1EAWEJ3MBE708ODpvV2hczbUaREhWzzLEtAx5P0dFO9Z6NakIjC8j6ESwNuHtBMy1U9U2fAbllL7Q', 100, 1709114143, 1709298838, 0),
(4, 'Mr Fantastic', '$2y$10$jCCxqNeGJ.b45BZ0RhT2J.FeKGkH0CCVmf9y18ywxiPxvA5pZGw.O', 'xhsDigbiYgvl4LqYYrMugtgvYxLsw1GdtSoyimsGKdHq1lxg1obudjmss1OQYxnjjSAhvFW55DFHCrk2My8pItsGXgGlsuWeWv4PhzXZWzjY3nYAVhcw7M7txcHiAB7S', 100, 1709116659, 1709116659, 0),
(5, 'User3', '$2y$10$oqWh36UGg3MTp60K4AX8iucvTjwcNPRwibqhC9jHj9X0ktdNa.4am', 'BQjUS4l2UkFNR02qt9ZM3lMLWpsvN4Fz7lOncWQBJqNSIEA8ibaMDAZZXJIPbrg0mw9aL91FhD6oGTWsDLqgtlDYKtxgnRdpFeQkwDuN6TbQKgvLMDTTFElxn8RFoucM', 101, 1709116777, 1709116785, 101);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
