-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 29, 2024 at 11:00 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `database`
--

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`id`, `name`, `price`, `rarity`, `onsale`) VALUES
(1, '🍎 Apple', 2, 'common', 1),
(2, '🎁 Surprise gift', 15, 'common', 1),
(3, '💎 Diamond', 50, 'common', 1),
(4, '📐🏠', 250, 'rare', 0),
(5, '🎫 Ticket to North Korea', 425, 'rare', 1),
(6, '💤 +1 hour of sleep per night', 560, 'rare', 1),
(7, '🚗 New Bugatti', 5000000, 'epic', 1),
(8, '🇫🇷 France', 2958000000000, 'epic', 1),
(9, '😃 1 Month subscription to: Life', 1000, 'rare', 1),
(10, '👑 Crown', 2500, 'rare', 1);

--
-- Dumping data for table `owners`
--

INSERT INTO `owners` (`id`, `user`, `item`, `boughtprice`, `time`) VALUES
(1, 1, 1, 2, 1709198413),
(2, 1, 1, 2, 1709198448),
(3, 1, 4, 250, 1709199827),
(4, 1, 10, 2500, 1709199843),
(5, 1, 7, 5000000, 1709199847),
(6, 1, 8, 2958000000000, 1709199891),
(7, 1, 1, 2, 1709200000),
(8, 1, 8, 2958000000000, 1709200006),
(9, 1, 8, 2958000000000, 1709200011);

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `password`, `session`, `money`, `created`, `loggedin`) VALUES
(1, 'User2', '$2y$10$HAi5WwUTF8DoOv36XHDu3OltNfuadMwY66FPUeyeqiJt7gt9TrRqq', 'CzwgvtloFQjBep9MzoyhxoaL3HlA2lfs2oI9fZOzGZHHL0jh0pJw49OWkhFynW6HnNEZZJMzKclrIhxXVYhfOVaPHMDrMZN4umKmOOdQI7xyigQNJEref4OIQLnEFnAV', 725999999998, 1709198150, 1709198150);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
