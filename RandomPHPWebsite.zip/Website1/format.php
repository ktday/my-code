<?php
function formatRarity($rarity) {
    if($rarity == 'common'){
        return "#fff";
    }elseif($rarity == 'rare'){
        return "#0ff";
    }elseif($rarity == 'epic'){
        return "#f55";
    }else{
        return "#999";
    }
}
?>