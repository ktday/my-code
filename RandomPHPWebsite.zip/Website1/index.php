<?php

$conn = mysqli_connect("localhost","root","","database");
if(!$conn){
    echo("Invalid database connection.");exit();
}

echo"
<link rel='stylesheet' href='style.css' />
";

if(isset($_COOKIE["sessionID"])){

    $sessionID = mysqli_real_escape_string($conn, $_COOKIE["sessionID"]);

    $accq = mysqli_query($conn,"SELECT * FROM users WHERE `session` = '$sessionID'");
    if(mysqli_num_rows($accq) == 1){
        $acc = mysqli_fetch_array($accq);
        $date = gmdate('H:i:s, j F Y', $acc['created']);
        $login = gmdate('H:i:s, j F Y', $acc['loggedin']);

        $money = 0; $next = 0;
        if($acc['moneytime'] <= time()){
            $money = $acc["money"] + 10;
            $next = time() + 300;
            mysqli_query($conn, "UPDATE users SET `money` = '$money', `moneytime` = '$next' WHERE `id` = '$acc[0]'");
        }else{
            $money = $acc["money"];
            $next = $acc["moneytime"];
        }

        if(isset($_POST['logout'])){
            setcookie("sessionID", "", 1, "/website/");
            echo"<script>window.location='/website/'</script>";exit();
        }
        $moneytime = gmdate('H:i:s', $next);

        echo"<center>
        <div class='box'>
        <h1>Hello, $acc[name]!</h1>
        <title>Hello, $acc[name]!</title>
        <p>Current balance \$<span style='color:#6ff'>$money</span><br>
        <span class='small'>Reload the page every 5 minutes to gain money</span></p>
        <p>You created your account at $date</p>
        <p>You last logged in at $login</p>
        <p>You will gain money at $moneytime</p>
        <p>Your user ID is $acc[id]</p>
        <form method='post'><button name='logout'>Log out</button></form>
        </div>
        <br>
        <div class='box'>
        <h1>Your items</h1>
        ";
        $itemsq = mysqli_query($conn,"SELECT owners.*, items.* FROM `owners` INNER JOIN items ON items.id = owners.item WHERE owners.user = '$acc[id]'");
        if(mysqli_num_rows($itemsq) == 0){
            echo"<p>You have no items.</p>";
        }else{
            include("format.php");
            while(($item = mysqli_fetch_array($itemsq))){
                $color = formatRarity($item["rarity"]);
                echo"<h2 style='color:$color;'>$item[name]</h2><p>Bought for \$<span style='color:#6ff'>$item[boughtprice]</span></p><hr>";
            }
        }
        echo"
        <br><a class='button' href='market.php'>To Market</a><br><br>
        </div>
        </center>";

    }else{
        setcookie("sessionID", "", 1, "/website/");
        echo"<h1 style='color:red;'>Invalid account. Reload the page to log in again.</h1>";
    }

}else{

    if(isset($_POST['login-name']) && isset($_POST['login-pass'])){
        $username = mysqli_real_escape_string($conn, $_POST['login-name']);
        $password = mysqli_real_escape_string($conn, $_POST['login-pass']);
        $accq = mysqli_query($conn,"SELECT * FROM users WHERE `name` = '$username'");
        if(mysqli_num_rows($accq) == 1){
            $acc = mysqli_fetch_array($accq);
            $verify = password_verify($password, $acc['password']);
            if($verify){
                $time = time();
                mysqli_query($conn,"UPDATE `users` SET `loggedin` = '$time' WHERE `name` = '$username'");
                setcookie("sessionID", $acc["session"], time() + 86400, "/website/");
                echo"<script>window.location='/website/'</script>";exit();
            }else{
                echo"<h1 style='color:red;'>Incorrect password</h1>";
            }
        }else{
            echo"<h1 style='color:red;'>No account found with that username</h1>";
        }
    }

    if(isset($_POST['reg-name']) && isset($_POST['reg-pass']) && isset($_POST['reg-pass2'])){
        $username = mysqli_real_escape_string($conn, $_POST['reg-name']);
        $password = mysqli_real_escape_string($conn, $_POST['reg-pass']);
        $password2 = mysqli_real_escape_string($conn, $_POST['reg-pass2']);
        if($password == $password2){
            $accq = mysqli_query($conn,"SELECT * FROM users WHERE `name` = '$username'");
            if(mysqli_num_rows($accq) == 0){
                $hash = password_hash($password, PASSWORD_DEFAULT);
                include("randomstring.php");
                $session = janix(128);
                $time = time();
                mysqli_query($conn,"
                INSERT INTO `users` VALUES(NULL, '$username', '$hash', '$session', '100', '$time', '$time','$time','0')
                ");
                setcookie("sessionID", $session, time() + 86400, "/website/");
                echo"<script>window.location='/website/'</script>";exit();
            }else{
                echo"<h1 style='color:red;'>That username is already taken</h1>";
            }
        }else{
            echo"<h1 style='color:red;'>Passwords do not match</h1>";
        }
    }

    echo"

    <title>Log in or register</title>

    <center><h1>You are not logged in.</h1></center>

    <div class='box1 box'>
        <h1>Login</h1>
        <form method='post'>
            <p>Enter Username:</p>
            <input name='login-name' required><br>
            <p>Enter Password:</p>
            <input type='password' name='login-pass' required><br>
            <button>Login</button>
        </form>
    </div>
    <div class='box2 box'>
        <h1>Register</h1>
        <form method='post'>
            <p>Enter Username:</p>
            <input name='reg-name' maxlength='32' required><br>
            <p>Enter Password:</p>
            <input type='password' name='reg-pass' required><br>
            <p>Repeat Password:</p>
            <input type='password' name='reg-pass2' required><br>
            <button>Register</button>
        </form>
    </div>
    
    ";
}

?>