<title>Kabrick.tk Beta</title>

<link rel='icon' href='/Misc/IMGS/favicon.png' type='image/x-icon'/>

<link rel='stylesheet' href='//cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css' />
<link rel='stylesheet' type='text/css' href='/Misc/gamma.css' />

<ul class='nav'>
    
    <li class='navL nav'>
        <a href='/' class='hovers'>
            <i class='fa fa-home'></i> Home
        </a>
    </li>
    
    <li class='navL nav'>
        <a href='/Market/' class='hovers'>
            <i class='fa fa-shopping-cart'></i> Market
        </a>
    </li>
    
    <li class='navL nav'>
        <a href='/Users/' class='hovers'>
            <i class='fa fa-users'></i> Users
        </a>
    </li>
    
    <li class='navL nav'>
        <a href='/Forums/' class='hovers'>
            <i class='fa fa-comments'></i> Forums
        </a>
    </li>
    
    <li class='navL nav'>
        <a href='/Clans/' class='hovers'>
            <i class='fa fa-users'></i> Clans
        </a>
    </li>
    
    <li class='dropdown'>
		<a class='dropbtn hovers navL nav' href=''>
		<i class='fa fa-chevron-down'></i>
		    More
		</a>
		<div class='dropdown-content'>
		    <a href='/News/' class='hovers'>
		        <i class='fa fa-newspaper'></i>
		        News
		    </a>
		    <a href='/Search/' class='hovers'>
		        <i class='fa fa-search'></i>
		        Search
		    </a>
		    <a href='/badges.php' class='hovers'>
		        <i class='fa fa-medal'></i>
		        Badges
		    </a>
		    <a href='/help.php' class='hovers'>
		        <i class='fa fa-question-circle'></i>
		        Help
		    </a>
		    <a href='//discord.gg/S4MePHa' class='hovers'>
		        <i class='fab fa-discord'></i>
		        Discord Server
		    </a>
		</div>
	</li>
	
	
    
</ul>

<div class='mc'>
    
    <div class='noticebar'>
        
        <b>The database is currently down. It may come back online soon. Click "Home" to check if it is okay again. If not, you will be redirected back here.</b>
        
    </div>
    
    <div class='ws'></div>
  


<div class='platform'>
    <h2>Welcome To The Kabrick.tk Beta Site!</h2>
    <p>Join the other users on the site!</p>
    <p>Kabrick.tk is currently in beta, so there may be some bugs. You will need a regcode to be able to sign up.</p>
    
</div>

<br><br>

<div class='indexcard signincard'>
    <div class='indexcardtop'>
        <b>Log in</b>
    </div>
    <div class='indexcardbody'>
        <form method='post'>
            <input class='form' placeholder='Username' name='l-username' required>
            <div class='formpad'></div>
            <input class='form' placeholder='Password' type='password' name='l-password' required>
            <div class='formpad'></div>
            <button class='formbtn'>Login!</button>
        </form>
    </div>
</div>

<div class='indexcard signupcard'>
    <div class='indexcardtop'>
        <b>Register</b>
    </div>
    <div class='indexcardbody'>
        <form method='post'>
            <input class='form' placeholder='Username (A-Z,a-z,0-9)' name='username' required>
            <div class='formpad'></div>
            <input class='form' placeholder='Password' type='password' name='password' required>
            <div class='formpad'></div>
            <input class='form' placeholder='Confirm Password' type='password' name='password2' required>
            <div class='formpad'></div>
            <br>
            <input class='form' placeholder='Regcode' name='code' required>
            <div class='formpad'></div>
            <button class='formbtn'>Register!</button>
            <p class='small1'>By registering, you agree to our <a class='ud small1' href='/help.php'>terms of service</a></p>
        </form>
    </div>
</div>

</div>