<?php

if(isset($_COOKIE['KABRICK_U']) || isset($_COOKIE['KABRICK_P'])){
    echo"<script>window.location='/Home/'</script>";exit();
}else{
    
    #echo"<script>window.location='../'</script>";
    
    $reg_alert = "none";
    
    include( $_SERVER['DOCUMENT_ROOT'] . '/Misc/connect.php' );
    
    
    if(isset($_POST['username']) && isset($_POST['password']) && isset($_POST['password2']) && isset($_POST['gender']) && isset($_POST['code'])) {
        $set_username = mysqli_real_escape_string($conn,$_POST['username']);
	    $set_password = mysqli_real_escape_string($conn,$_POST['password']);
	    $set_password2 = mysqli_real_escape_string($conn,$_POST['password2']);
	    $set_gender = mysqli_real_escape_string($conn,$_POST['gender']);
	    $set_code = mysqli_real_escape_string($conn,$_POST['code']);
	    
	    if ($set_password !== $set_password2){
	        $reg_alert = "Passwords Are Not Identical!";
	    }else{
	        #$re = '/\\A[a-z\\d]+(?:[.-][a-z\\d]+)*\\z/i';
	        $re = '/^[A-Za-z0-9]*$/';
		    if(!preg_match_all($re, $set_username)){
		        $reg_alert = "Incorrect Username Syntax!";
		    }else{
		        $UsernameL = strlen($set_username);
			    if ($UsernameL < 2 || $UsernameL > 20){
			        $reg_alert = "Username Needs To Be Bigger Than 2 Characters And Smaller Than 20!";
			    }else{
			        $AccountQ = mysqli_query($conn,"SELECT * FROM `USERS` WHERE `USERNAME` = '$set_username'");
			        $Account = mysqli_num_rows($AccountQ);
			        if($Account >= 1){
			            $reg_alert = "Username Already Exists!";
			        }else{
			            //regcode
			            $RegCodeQ = mysqli_query($conn,"SELECT * FROM `REG_CODES` WHERE `CODE` = '$set_code'");
			            $RegCode = mysqli_fetch_array($RegCodeQ);
			            if(mysqli_num_rows($RegCodeQ)>0){
			                //regcode exists
			                $ip = $_SERVER['REMOTE_ADDR'];
			                $time = time();
			                if($RegCode['TYPE']=='PERMENANT'){
			                    //perm
			                    if($RegCode['ENABLED']=='YES'){
                                  
                                  function generateRandomString($length = 5) {
                                        $characters = '0123456789abcdefghijklmnopqrstuvwxyz';
                                        $charactersLength = strlen($characters);
                                        $randomString = '';
                                        for ($i = 0; $i < $length; $i++) {
                                            $randomString .= $characters[rand(0, $charactersLength - 1)];
                                        }
                                        return $randomString;
                                    }
                                  
                                  	$uid = generateRandomString() . "-" . generateRandomString() . "-" . generateRandomString() . "-" . generateRandomString() . "-" . generateRandomString();
                                  
                                  
			                        //enabled + perm
			                        $gosted = hash('gost',$set_password);
                                    $password = hash('whirlpool',$gosted);
                                    $gostedIP = hash('gost',$ip);
                                    $newIP = hash('whirlpool',$gostedIP);
			                        $sqlii = mysqli_query($conn, "INSERT INTO `USERS` VALUES(
        			                NULL,
        			                '$set_username','$password','$set_code','$set_gender',
        			                '/Misc/IMGS/avatar.png',
        			                '0','20','0',
        			                'MEMBER','NONE','0','UNVERIFIED','0','NAME',
        			                '0','0','0','0','0','0',
        			                'UNSET',
        			                '$newIP',
        			                'Hi, I am new here!',
        			                '$time','$time','$time',
        			                'LIGHT','EN',
        			                'FALSE','FALSE','FALSE','FALSE','$uid')");
                                    $sqliq = mysqli_query($conn, "SELECT * FROM `USERS` WHERE `USERNAME` = '$set_username'");
                                    $sqlin = mysqli_num_rows($sqliq);
        			                if($sqlin>0){
        					            echo"<script>window.alert('Success!')</script>";
                                        $sqlia = mysqli_fetch_array($sqliq);
        					            mysqli_query($conn,"INSERT INTO `AVATAR` VALUES('$sqlia[0]','0','0','0','0','0','0','0','0','0')");
        			                }else{
        					            echo"<script>window.alert('Account Creation Failed! Error 2:1')</script>";
        			                }
			                    }elseif($RegCode['ENABLED']=='NO'){
			                        echo"<script>window.alert('The Code You Used Doesn\'t Exist! Error 2:3')</script>";
			                        echo"<script>window.location='/register'</script>";exit();
			                    }else{
			                        echo"<script>window.alert('Error 2:2')</script>";
			                        echo"<script>window.location='/register'</script>";exit();
			                    }
			                }elseif($RegCode['TYPE']=='ONE-TIME'){
			                    //single use plastic
			                    if($RegCode['ENABLED']=='YES'){
			                        //enabled + OT
                                  
                                  
                                  
                                  function generateRandomString($length = 5) {
                                        $characters = '0123456789abcdefghijklmnopqrstuvwxyz';
                                        $charactersLength = strlen($characters);
                                        $randomString = '';
                                        for ($i = 0; $i < $length; $i++) {
                                            $randomString .= $characters[rand(0, $charactersLength - 1)];
                                        }
                                        return $randomString;
                                    }
                                  
                                  	$uid = generateRandomString() . "-" . generateRandomString() . "-" . generateRandomString() . "-" . generateRandomString() . "-" . generateRandomString();
                                  
                                  
                                
			                        $gosted = hash('gost',$set_password);
                                    $password = hash('whirlpool',$gosted);
			                        $sqliq = mysqli_query($conn, "INSERT INTO `USERS` VALUES(
        			                NULL,
        			                '$set_username','$password','$set_code','$set_gender','/Misc/IMGS/avatar.png',
        			                '20','0','0',
        			                'MEMBER','NONE','0','UNVERIFIED','NAME',
        			                '0','0','0','0','0','0',
        			                'UNSET',
        			                '$ip',
        			                'Hi, I am new here!',
        			                '$time','$time','$time',
        			                'LIGHT','EN',
        			                'FALSE','FALSE','FALSE','FALSE','$uid')");
                                    $sqliq = mysqli_query($conn, "SELECT * FROM `USERS` WHERE `USERNAME` = '$set_username'");
                                    $sqlia = mysqli_fetch_array($sqliq);
                                    $sqlin = mysqli_num_rows($sqliq);
        			                if($sqlin>0){
        					            echo"<script>window.alert('Success!')</script>";
                                        $sqlia = mysqli_fetch_array($sqliq);
        					            mysqli_query($conn,"INSERT INTO `AVATAR` VALUES('$sqlia[0]','0','0','0','0','0','0','0','0','0')");
        			                    echo"<script>window.location='/login.php'</script>";
        			                    mysqli_query($conn,"UPDATE `REG_CODES` SET `USED_BY` = '$sqlia[ID]' WHERE `CODE` = '$set_code'");
        			                    mysqli_query($conn,"UPDATE `REG_CODES` SET `ENABLED` = 'EXPIRED' WHERE `CODE` = '$set_code'");exit();
        			                }else{
        					            echo"<script>window.alert('Account Creation Failed! Error 2:1')</script>";
        			                    echo"<script>window.location='/register.php'</script>";exit();
        			                }
			                    }elseif($RegCode['ENABLED']=='NO'){
			                        echo"<script>window.alert('The Code You Used Doesn\'t Exist! Error 2:3')</script>";
			                        echo"<script>window.location='/register.php'</script>";exit();
			                    }else{
			                        echo"<script>window.alert('This Reg Code Has Been Used By Someone Else Already!')</script>";
			                        echo"<script>window.location='/register.php'</script>";exit();
			                    }
			                }
			            }else{
			                echo"<script>window.alert('This Reg Code Does Not Exist!')</script>";
	                        echo"<script>window.location='/register.php'</script>";exit();
			            }
			        }
			    }
		    }
	    }
    }
    include( $_SERVER['DOCUMENT_ROOT'] . '/Misc/navbar.php' );
    echo"
<script>function makeid(length) {
   var result           = '';
   var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789`¬¦!£$%^&*()|\-_=+[]{};:@#~<>,./?';
   var charactersLength = characters.length;
   for ( var i = 0; i < length; i++ ) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
      pass = 'Randomly Generated Password: ' + result
   }
   return pass;
};</script>
    <title>Kabrick.tk - Register</title>

    <center>
    
        <h1><i style='color:white;' class='fa fa-user-plus'></i> <u><b>Register</b></u></h1>
        
        <div class='box middle'>
        
            <br>
            
            <form method='post' action='register.php'>
			    <input id='username' class='Ginput' name='username' placeholder='Desired Username' minlength='3' maxlength='20' required/><br>
				<input class='Ginput' name='password' type='password' placeholder='Password' required /><br>
				<input class='Ginput' name='password2' type='password' placeholder='Retype Password' required /><br><br>
				<input class='Ginput' name='code' placeholder='Reg Code' required maxlength='20' /><br><br>
				<div style='font-size:15px;white-space: nowrap;'>
					<input name='gender' type='radio' value='MALE' checked>MALE</input>
					<input name='gender' type='radio' value='FEMALE'>FEMALE</input>
					<input name='gender' type='radio' value='OTHER'>OTHER</input>
				</div><br>
				<button class='buttonF'> Submit! </button>
			</form>
				
			";
			
			if($reg_alert !== "none"){
			    echo"<p style='color:red;'>$reg_alert</p>";
			}
			
			
			echo"
			
			<p>By registering, you agree to our <a href='/help.php#tos'>TOS</a>.</p>
			
			<p>Already have an account? <a href='/login.php'>Login!</a></p>
			
			<button class='button' onclick='window.alert(makeid(15))'>Randomly Generate a Password</button>
			
		</div>
			
	</center>

</body>

</html>
    
    ";
}
?>