<?php

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/embed.php');

embed(
  "Badges",
  "List of the awards available in kabrick",
  "Badges/"
);

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');

echo"<title>Badges | $meta_name</title>";

if(isset($_GET['id'])){
  
  $id = mysqli_real_escape_string($conn,$_GET['id']);
  $bQ = mysqli_query($conn,"SELECT * FROM `BADGES` WHERE `ID` = '$id'");
  if(mysqli_num_rows($bQ)==1){
    
    $b = mysqli_fetch_array($bQ);
    $o = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM `USER_BADGES` WHERE `BADGE` = '$id'"));
    
    echo"
    
    <div class='platform'>
    	<div class='platformtitle'>
        	<p><u><b>$b[NAME]</b></u></p>
        </div>
        
        <img src='$b[IMAGE]'>
        <p>$b[DESCRIPTION]</p>
        <p>$o Owners</p>
        
    </div>
    
    ";
    
    exit();
  }
  
}

echo"

<div class='platform'>
	<div class='platformtitle'>
    	<p><u><b>Badges</b></u></p>
    </div>
    
    <br>
    ";
    
    $badges = mysqli_query($conn,"SELECT * FROM `BADGES` WHERE `ACTIVE` = '1'");
    while(($b=mysqli_fetch_array($badges))){
        echo"<a href='/Badges/?id=$b[ID]'>
        <img src='$b[IMAGE]'>
        <p>$b[NAME]</p></a>
        <p>$b[DESCRIPTION]</p>
        <br>";
    }
    
    echo"
    <br>
</div>

</div>

";

?>