<?php

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/connect.php');
include($_SERVER['DOCUMENT_ROOT'] . '/Misc/vars.php');

if(!isset($_COOKIE['KABRICK_U']) || !isset($_COOKIE['KABRICK_P'])){
    $e = 0;
}else{$e=1;}

if(!isset($_GET['id'])){
  exit();
}else{
  $id = mysqli_real_escape_string($conn,$_GET['id']);
}

echo"<h1>Clan Wall</h1>";

$memberQ = mysqli_query($conn,"SELECT * FROM `WALL` WHERE `CLAN` = '$id' ORDER BY `ID`");
$memberN = mysqli_num_rows($memberQ);

$clan = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `CLANS` WHERE `ID` = '$id'"));

if($ar > 3) { #   EXECUTIVE +
  echo"
  
  <form method='post' action='/Clans/cmd.php'>
  	<input class='form form1l' name='cmd_bar' placeholder='Command Bar'>
    <button class='button3 btn-blue nd' name='id' value='$id'>Commit</button>
  </form>
  
  ";
}

if($clan['WALL'] == '0'){
  
  echo"<p>This clan has its wall disabled</p>";

}else{
  
  if($e==1){echo"
  
  <form method='post'>
  	<textarea class='form form1l' name='wall' placeholder='Your message!'></textarea>
    <button class='button3 btn-blue nd'>Post!</button>
  </form>
  
  ";}
  
  if($memberN<1){
    echo"<p>This clan has no wall posts</p>";
  }else{


      echo"
              <script>
  
  var clan = '$clan[0]'
  id = 0;
  function next() {
	id ++;
	jQuery.ajax({
		data:{
			pageIndex:id,
			clan:clan
		},
		url:'/Clans/pages.php',
		type:'POST',
		success:function(results) {
		    jQuery('.wall').html(results);
		}
	});
  }

  function back() {
	if(id > 1){
		id = id - 1;
		jQuery.ajax({
			data:{
				pageIndex:id,
				clan:clan
			},
			url:'/Clans/pages.php',
			type:'POST',
			success:function(results) {
 			   jQuery('.wall').html(results);
			}
		});
  }} 
  
  next();
  
  </script>
  
  <div class='wall'>
  
  </div>
  
  <button class='button3 btn-blue nd' onclick='back()'>Previous Page</button>
  <button class='button3 btn-blue nd' onclick='next()'>Next Page</button>
              ";
  }
}

?>