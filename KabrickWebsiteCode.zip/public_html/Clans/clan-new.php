<?php

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');
include($_SERVER['DOCUMENT_ROOT'] . '/bbcode.php');

#include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();


echo"<title>Clans | $meta_name</title>";

if(!isset($_COOKIE['KABRICK_U']) || !isset($_COOKIE['KABRICK_P'])){
    $e = 0;
}else{$e=1;}

if(!isset($_GET['id'])&&!isset($_GET['join'])&&!isset($_GET['exit'])&&!isset($_GET['boost'])&&!isset($_GET['prim'])){
    include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
}

if(isset($_GET['id'])){

$id = mysqli_real_escape_string($conn,$_GET['id']);

$clan = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `CLANS` WHERE `ID` = '$id'"));

if(mysqli_num_rows(mysqli_query($conn,"SELECT * FROM `CLANS` WHERE `ID` = '$id'"))!=1){
    include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
}
if($clan['STATUS']=='BANNED'){
    include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
}
if($clan['STATUS']=='DISABLED'){
    #if($clan['OWNER']!=$account[0]){
        include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
    #}
}
if($clan['STATUS']=='MODERATED'){
    $clname = "[ MODERATED ]";
    $clicon = "/Misc/IMGS/unknown_clan.png";
}else{
  $clname = $clan[1];
  $clicon = $clan[3];
}

$owner = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$clan[OWNER]'"));                              #  FIND OWNER
$members = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM `MEMBERS_IN_CLANS` WHERE `CLAN_ID` = '$id'"));                        # FIND MEMBER COUNT

if($members!=$clan['MEMBERS']){
  mysqli_query($conn,"UPDATE `CLANS` SET `MEMBERS` = '$members' WHERE `ID` = '$id'");
}

if($e==0){
  $in = 500;
}else{
  $inq = mysqli_query($conn,"SELECT * FROM `MEMBERS_IN_CLANS` WHERE `CLAN_ID` = '$id' AND `USER_ID` = '$account[0]'"); # CHECK IF USER IS IN CLAN
  $in = mysqli_num_rows($inq);
  $m = mysqli_fetch_array($inq);
}

if($e==1){
if($owner[0]==$account[0]){ 
	$joined = 2; # IS OWNER
    $role = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `CLAN_ROLES` WHERE `ID` = '$m[ROLE]'"));
    $perms = [1,1,1,1];
}else{
 	if($in==1){
      $joined = 1; # IS JOINED
      $role = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `CLAN_ROLES` WHERE `ID` = '$m[ROLE]'"));
      $perms = explode(':',$role[2]);
    }elseif($in==500){
      $joined = 3; # NOT LOGGED IN
    }else{
      $joined = 0; # IS NOT JOINED
    }
}}else{$joined=3;}


//leaderboard pos

$x = 0;$lbid = "0";
$lbrq = mysqli_query($conn,"SELECT * FROM `CLANS` WHERE 1 ORDER BY `MEMBERS` DESC LIMIT 10");

while(($f = mysqli_fetch_array($lbrq))){
    $x = $x + 1;
    if($f[0] == $id){
        $lbid = "#$x in top";
    }
}
if($lbid=="0"){
    $lbid = "Not in top";
}
if($lbid=="#1 in top"){
    $color = 'gold';
}elseif($lbid=="#2 in top"){
    $color = 'silver';
}elseif($lbid=="#3 in top"){
    $color = 'bronze';
}else{
    $color = 'white';
}

if($clan['STATUS']=='PARTNER'){
    $icon = "<partner></partner>";
}else{
    if($clan['BOOSTS']>0&&$clan['BOOSTS']<5){
        $icon = "<boost1></boost1>";
    }elseif($clan['BOOSTS']>4&&$clan['BOOSTS']<10){
        $icon = "<boost2></boost2>";
    }elseif($clan['BOOSTS']>9&&$clan['BOOSTS']<15){
        $icon = "<boost3></boost3>";
    }elseif($clan['BOOSTS']>14&&$clan['BOOSTS']<30){
        $icon = "<boost4></boost4>";
    }elseif($clan['BOOSTS']>29){
        $icon = "<boost5></boost5>";
    }else{
        $icon = "";
    }
}

//boost price

if($e!=0){
  if($account['VIP']=="NONE"){
    $boostPrice = 20;
  }elseif($account['VIP']=="VIP"){
    $boostPrice = 10;
  }elseif($account['VIP']=="MEGA"){
    $boostPrice = 5;
  }elseif($account['VIP']=="ULTRA"){
    $boostPrice = 0;
  }else{
   $boostPrice = 20; 
  }
}else{$boostPrice=5000000000;}

if($e==1 && isset($_POST['wall'])){
  $p = mysqli_real_escape_string($conn,$_POST['wall']);
  mysqli_query($conn,"INSERT INTO `WALL` VALUES(NULL,'$clan[0]','$account[0]','$p')");
  update($account[0], "Wall");
  #echo"<script>location.reload()</script>";
}

echo"

<script>
$(document).ready(function(){
  info();
});

function mbrs() {
  $('#load').load('/Clans/members.php?id=$id');
}

function wall() {
  $('#load').load('/Clans/wall.php?id=$id');
}

function info() {
  $('#load').load('/Clans/info.php?id=$id');
}

function assets() {
  $('#load').load('/Clans/assets.php?id=$id');
}


</script>

";

echo"

<div class='doublebox box1'>
    <div class='platformtitle'>
        <h1>$icon $clname</h1>
    </div>
    <br>
    <img src='$clicon' style='
    width: 10rem;
    height: 10rem;
'><br>
    <p>Members: $members</p>
    <p><a href='/Profile/$owner[1]'>Owner: $owner[1]</a></p>
    <p class='txtcol-purple'>$clan[BOOSTS] Boosts</p>
    <p class='txtcol-$color'>$lbid</p>
    ";if($joined==1){   /*  WHEN USER IS IN CLAN  */ echo"
    <p class='txtcol-green'><i class='fa fa-check-circle'></i> You have joined this clan</p>
    <p>Role: $role[1]</p>
    <a href='/Clans/cl.php?exit=$id' class='button btn-red nd hover'>Leave</a><br>
    <a href='/Clans/cl.php?boost=$id' class='button btn-purple nd hover'>Boost (<i class='fa fa-money-bill'></i>$boostPrice)</a>
    ";
    
    if(intval($perms[2])==1){
      echo"<a href='/Clans/edit.php?id=$id' class='button btn-red nd hover'>Clan Settings</a>";
    }
                    
                    }elseif($joined==2){   /*  WHEN USER IS OWNER  */ echo"
    <p class='txtcol-gold'>You own this clan</p>
    <a href='/Clans/cl.php?boost=$id' class='button btn-purple nd hover'>Boost (<i class='fa fa-money-bill'></i>$boostPrice)</a>
    <a href='/Clans/edit.php?id=$id' class='button btn-red nd hover'>Clan Settings</a>
    ";}elseif($joined==0){if($clan['STATUS']!='UNVERIFIED'){   /*  WHEN USER IS NOT IN CLAN  */ echo"
    <a href='/Clans/cl.php?join=$id' class='button btn-blue nd hover'>Join this Clan</a>
    ";}}

	if($ar>=5){
      echo"<a href='/Clans/manage.php?id=$id' class='button btn-red nd hover'>Admin</a>";
      echo"<a href='/cx/$clan[INVITE]' class='button btn-red nd hover'>Info</a>";
    }

echo"
    
</div>

<div class='doublebox box2'>
    
    <button class='button2 btn-blue nd' onclick='wall()'>Wall</button>
    <button class='button2 btn-blue nd' onclick='info()'>Info</button>
    <button class='button2 btn-blue nd' onclick='mbrs()'>Members</button>
    <button class='button2 btn-blue nd' onclick='assets()'>Clothing</button>
    
    <div id='load'>
    
    </div>
    
</div>

</div>

";
  
}elseif(isset($_GET['join'])){
  $id = mysqli_real_escape_string($conn,$_GET['join']);

$clan = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `CLANS` WHERE `ID` = '$id'"));

if(mysqli_num_rows(mysqli_query($conn,"SELECT * FROM `CLANS` WHERE `ID` = '$id'"))!=1){
    include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
}
if($clan['STATUS']=='BANNED'){
    include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
}
if($clan['STATUS']=='DISABLED'){
    #if($clan['OWNER']!=$account[0]){
        include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
    #}
}
if($clan['STATUS']=='UNVERIFIED'){
    include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
}
  
  
$inq = mysqli_query($conn,"SELECT * FROM `MEMBERS_IN_CLANS` WHERE `CLAN_ID` = '$id' AND `USER_ID` = '$account[0]'"); # CHECK IF USER IS IN CLAN
  $in = mysqli_num_rows($inq);
  
  if($in!=0){
    include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
  }else{
    
    mysqli_query($conn,"INSERT INTO `MEMBERS_IN_CLANS` VALUES(NULL,'$id','$account[0]','$clan[DEF_ROLE]')");
  }
  
  echo"<script>window.location='/Clan/$id'</script>";exit();
  
  
}

?>