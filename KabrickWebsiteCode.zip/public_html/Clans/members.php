<?php

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/connect.php');

if(!isset($_GET['id'])){
  exit();
}else{
  $id = mysqli_real_escape_string($conn,$_GET['id']);
}

echo"<h1>Members</h1>";

$memberQ = mysqli_query($conn,"SELECT * FROM `MEMBERS_IN_CLANS` WHERE `CLAN_ID` = '$id' ORDER BY `ID`");
$memberN = mysqli_num_rows($memberQ);

if($memberN<1){
  echo"<p>This clan has no members</p>";
}else{
  while(($member = mysqli_fetch_array($memberQ))){

    $u = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$member[USER_ID]'"));
    $role = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `CLAN_ROLES` WHERE `ID` = '$member[ROLE]'"));

    echo"
            <a href='/Profile/$u[1]' class='nd dib'>
                <div class='forum-av'>
        			<img src='$u[AVATAR_IMG_URL]'><br>
        			<p>$u[1]<br><span class='small1'>$role[1]</span></p>
                    <br><br>
            	</div>
            </a>
            ";
  }
}

?>