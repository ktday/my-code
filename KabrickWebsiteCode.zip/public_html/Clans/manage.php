<?php

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');
#include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();

if(!isset($_COOKIE['KABRICK_U']) || !isset($_COOKIE['KABRICK_P'])){
    include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
}

/*if(!isset($_GET['id'])){
    include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
}*/

if($ar<5){
  include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
}

echo"<title>Manage Clan | $meta_name</title>";

if(isset($_GET['id'])){

$id = mysqli_real_escape_string($conn,$_GET['id']);

$clan = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `CLANS` WHERE `ID` = '$id'"));

if(mysqli_num_rows(mysqli_query($conn,"SELECT * FROM `CLANS` WHERE `ID` = '$id'"))!=1){
    include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
}
if($clan['STATUS']=='BANNED'){
    include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
}
if($clan['STATUS']=='DISABLED'){
    #if($clan['OWNER']!=$account[0]){
        include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
    #}
}
  
  $inq = mysqli_query($conn,"SELECT * FROM `MEMBERS_IN_CLANS` WHERE `CLAN_ID` = '$id' AND `USER_ID` = '$account[0]'"); # CHECK IF USER IS IN CLAN
  $in = mysqli_num_rows($inq);
  $m = mysqli_fetch_array($inq);
  
  if($in!=1){include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();}
  
  $role = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `CLAN_ROLES` WHERE `ID` = '$m[ROLE]'"));
  $perms = explode(':',$role[2]);
  
  if($perms[2]!=1&&$perms[3]!=1){include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();}


if($clan['LOCKED']==1){$locked="Invite-Only";}elseif($clan['LOCKED']==0){$locked="Anyone can join";}

if(isset($_POST['description'])){//desc
        $d = mysqli_real_escape_string($conn,$_POST['description']);
        mysqli_query($conn,"UPDATE `CLANS` SET `DESCRIPTION` = '$d' WHERE `ID` = '$id'");
        echo"<script>window.alert('Success!');window.location='/Clans/edit.php?id=$id'</script>";exit();
}
if(isset($_POST['lock'])){//lock
        if($clan['LOCKED']==1){$d = 0;}else{$d=1;}
        mysqli_query($conn,"UPDATE `CLANS` SET `LOCKED` = '$d' WHERE `ID` = '$id'");
        echo"<script>window.alert('Success!');window.location='/Clans/edit.php?id=$id'</script>";exit();
}
/*if(isset($_POST['userid'])){//rank
    if($s[0]!=$account[0]){echo"<script>window.location='/Clans/'</script>";}else{
        $uid = mysqli_real_escape_string($conn,$_POST['userid']);
        $fuQ = mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$uid'");
        if(mysqli_num_rows($fuQ)!=1){echo"<script>window.alert('This User Does Not Exist!');window.location='/Clans/edit.php?id=$id'</script>";exit();}else{
        $fuigQ = mysqli_query($conn,"SELECT * FROM `MEMBERS_IN_CLANS` WHERE `USER_ID` = '$uid' AND `CLAN_ID` = '$id'");
        if(mysqli_num_rows($fuigQ)!=1){echo"<script>window.alert('This User Is Not In This Clan!');window.location='/Clans/edit.php?id=$id'</script>";exit();}else{
        //change
        if($_POST['rank']=="MEMBER"){$d = "MEMBER";}elseif($_POST['rank']=="VIP"){$d = "VIP";}else{$d="ADMIN";}
        mysqli_query($conn,"UPDATE `MEMBERS_IN_CLANS` SET `RANK` = '$d' WHERE `USER_ID` = '$uid' AND `CLAN_ID` = '$id'");
        echo"<script>window.alert('Success!');window.location='/Clans/edit.php?id=$id'</script>";exit();
    }}}
}*/

if(isset($_POST['newownerid'])){//owner
        $un = mysqli_real_escape_string($conn,$_POST['newownerid']);
        $fuQ = mysqli_query($conn,"SELECT * FROM `USERS` WHERE `USERNAME` = '$un'");
        if(mysqli_num_rows($fuQ)!=1){
          echo"<script>window.alert('This User Does Not Exist!');window.location='/Clans/edit.php?id=$id'</script>";exit();
        }else{
          $u = mysqli_fetch_array($fuQ);
          $fuigQ = mysqli_query($conn,"SELECT * FROM `MEMBERS_IN_CLANS` WHERE `USER_ID` = '$u[0]' AND `CLAN_ID` = '$id'");
          if(mysqli_num_rows($fuigQ)!=1){
            echo"<script>window.alert('This User Is Not In This Clan!');window.location='/Clans/edit.php?id=$id'</script>";exit();
          }else{
        	//change
          	mysqli_query($conn,"UPDATE `MEMBERS_IN_CLANS` SET `ROLE` = '$m[ROLE]' WHERE `USER_ID` = '$u[0]' AND `CLAN_ID` = '$id'");
          	mysqli_query($conn,"UPDATE `MEMBERS_IN_CLANS` SET `ROLE` = '$clan[DEF_ROLE]' WHERE `USER_ID` = '$account[0]' AND `CLAN_ID` = '$id'");
          	mysqli_query($conn,"UPDATE `CLANS` SET `OWNER` = '$u[0]' WHERE `ID` = '$id'");
          	echo"<script>window.alert('Success!');window.location='/Clan/$id'</script>";exit();
    	  }
        }
}

if(isset($_POST['delete'])){//delete
    if($s[0]!=$account[0]){echo"<script>window.location='/Clans/'</script>";}else{
        $fuigQ = mysqli_query($conn,"SELECT * FROM `MEMBERS_IN_CLANS` WHERE `CLAN_ID` = '$id'");
        while(($fuig=mysqli_fetch_array($fuigQ))){
            mysqli_query($conn,"DELETE FROM `MEMBERS_IN_CLANS` WHERE `ID` = '$fuig[0]'");
        }
        mysqli_query($conn,"UPDATE `CLANS` SET `OWNER` = '0' WHERE `ID` = '$id'");
        mysqli_query($conn,"UPDATE `CLANS` SET `STATUS` = 'DELETED' WHERE `ID` = '$id'");
        echo"<script>window.alert('Successfully DELETED Clan!');window.location='/Clans/edit.php?id=$id'</script>";exit();
    }
}

echo"

<div class='platform'>
	<div class='platformtitle'>
    	<h1>Manage Clan \"$clan[1]\"</h1>
    </div>
    
    <br><a href='/Clan/$id' class='button2 btn-blue nd hover'>Return to Clan</a><br><br>
    
    <span class='txtcol-red'>Ban/Moderate</span>
    <form method='post'>
        <button name='delete' style='border:1px solid red' class='button3 btn-red'>Request Delete</button>
    </form>
    
</div>
</div>";}

elseif(isset($_GET['ban'])){
    $id = mysqli_real_escape_string($conn,$_GET['ban']);
    $cQ = mysqli_query($conn,"SELECT * FROM `CLANS` WHERE `ID` = '$id'");
    $cN = mysqli_num_rows($cQ);if($cN==0){echo"<script>window.location='/Clans/'</script>";exit();}
    mysqli_query($conn,"UPDATE `CLANS` SET `STATUS` = 'BANNED' WHERE `ID` = '$id'");
    echo"<script>window.alert('Successfully BANNED Clan!');window.location='/Clans/clan.php?id=$id'</script>";exit();
}

elseif(isset($_GET['mod'])){
    $id = mysqli_real_escape_string($conn,$_GET['mod']);
    $cQ = mysqli_query($conn,"SELECT * FROM `CLANS` WHERE `ID` = '$id'");
    $cN = mysqli_num_rows($cQ);if($cN==0){echo"<script>window.location='/Clans/'</script>";exit();}
    mysqli_query($conn,"UPDATE `CLANS` SET `STATUS` = 'MODERATED' WHERE `ID` = '$id'");
    echo"<script>window.alert('Successfully MODERATED Clan!');window.location='/Clans/clan.php?id=$id'</script>";exit();
}

elseif(isset($_GET['ret'])){
    $id = mysqli_real_escape_string($conn,$_GET['ret']);
    $cQ = mysqli_query($conn,"SELECT * FROM `CLANS` WHERE `ID` = '$id'");
    $cN = mysqli_num_rows($cQ);if($cN==0){echo"<script>window.location='/Clans/'</script>";exit();}
    mysqli_query($conn,"UPDATE `CLANS` SET `STATUS` = 'OK' WHERE `ID` = '$id'");
    echo"<script>window.alert('Successfully RETURNED Clan!');window.location='/Clans/clan.php?id=$id'</script>";exit();
}

elseif(isset($_GET['par'])){
    if($account[0]!='2'){echo"<script>window.location='/Clans/clan.php?id=$id'</script>";exit();}
    $id = mysqli_real_escape_string($conn,$_GET['par']);
    $cQ = mysqli_query($conn,"SELECT * FROM `CLANS` WHERE `ID` = '$id'");
    $cN = mysqli_num_rows($cQ);if($cN==0){echo"<script>window.location='/Clans/'</script>";exit();}
    mysqli_query($conn,"UPDATE `CLANS` SET `STATUS` = 'PARTNER' WHERE `ID` = '$id'");
    echo"<script>window.alert('Successfully PARTNERED Clan!');window.location='/Clans/clan.php?id=$id'</script>";exit();
}

?>