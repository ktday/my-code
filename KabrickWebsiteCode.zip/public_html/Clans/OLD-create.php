<?php

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/navbar.php');

if(isset($_COOKIE['KABRICK_U']) || isset($_COOKIE['KABRICK_P'])){}else{
    echo"<script>window.location='/'</script>";
}

if(isset($_POST['name'])&&isset($_POST['desc'])){
    $data_t = mysqli_real_escape_string($conn,$_POST['name']);
    $data_b = mysqli_real_escape_string($conn,$_POST['desc']);
    if(strlen($data_t)>3){
        if($account['BUCKS']<30){
            //cannot afford
            echo"<script>window.alert('You do not have enough bucks!');window.location='/Clans/'</script>";
        }else{
            //can afford
            //buy
            $selectAllClans = mysqli_query($conn,"SELECT * FROM `MEMBERS_IN_CLANS` WHERE `USER_ID` = '$account[0]'");
            $sacN = mysqli_num_rows($selectAllClans);
            if($sacN>2){echo"<script>window.alert('You have reached the clan limit of 3 clans! You cannot join any more!');window.location='/Clans/clan.php?id=$id'</script>";}
            else{
            $remainingBucks = $account['BUCKS'] - 30;
            mysqli_query($conn,"UPDATE `USERS` SET `BUCKS` = '$remainingBucks' WHERE `ID` = '$account[0]'");
            $time=time();
            $cat2 = mysqli_query($conn,"INSERT INTO `MEMBERS_IN_CLANS` VALUES(NULL,'$id','$account[0]','OWNER')");
            $cat = mysqli_query($conn,"INSERT INTO `CLANS` VALUES(NULL,'$data_t','$data_b','$account[0]','$time','OK','0','NO')");
            $catQ = mysqli_query($conn,"SELECT * FROM `CLANS` WHERE `NAME` = '$data_t' AND `DESCRIPTION` = '$data_b' AND `TIME` = '$time'");
            $catQQ = mysqli_fetch_array($catQ);
            //query devs
            $ADM_Q = mysqli_query($conn,"SELECT * FROM `CURRENT_ECONOMY` WHERE `ID` = '1'");
            $ADM_A = mysqli_fetch_array($ADM_Q);
            //ammount to pay devs
            $ADMINSCOINSQ = 30;
            $ADMINSCOINS = $ADM_A['BUCKS'] + $ADMINSCOINSQ;
            //pay devs
            mysqli_query($conn,"UPDATE `CURRENT_ECONOMY` SET `BUCKS` = '$ADMINSCOINS' WHERE `ID` = '1'");
            //done
            echo"<script>window.alert('Clan Created!');window.location='/Clans/clan.php?id=$catQQ[ID]'</script>";
        }}
    }else{
        echo"<script>window.alert('The name needs to be over 3 characters long!');window.location='/Clans/'</script>";
    }
}

echo"
<title>Kabrick.tk - Create A Clan</title>
<center>
<h1><i style='color:$col8;' class='fa fa-plus'></i> <u><b>Create a clan</b></u></h1>
<div class='box middle' style='background-color:$col12;border-color:$col13;'>
    <br>
    <p><a href='/Clans/'><i class='fa fa-times'></i> Cancel</a></p>
    <form method='post'>
        <input style='border:1px solid black;border-radius:5px;width:300px;padding:5px;margin-bottom:5px;' placeholder='Name' name='name' minlength='4' maxlength='20' required><br>
        <textarea style='border:1px solid black;border-radius:5px;padding:5px;margin-bottom:5px;width:400px;height:100px' name='desc' placeholder='Description (200 Character Limit)' maxlength='200' required></textarea><br>
        <button style='border:1px solid black;padding:5px;width:120px;margin:5px;margin-left: 5px;margin-right: 5px;border-radius: 5px;'>Create for 30 Bucks!</button>
    </form>
    <br>
</div>
</center>
</body>
</html>";

?>