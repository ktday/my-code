<?php

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');

function e(){include('../404-raw.php');exit();}
function alert($i){echo"<script>window.alert('$i')</script>";}
function clan($id){echo"<script>window.location = '/Clan/$id'</script>";}

if($ar < 4){
  e();
}

if(isset($_POST['id'])){
  $id = mysqli_real_escape_string($conn,$_POST['id']);
  $query = $conn->prepare("SELECT * FROM `CLANS` WHERE `ID` = ?");
  $query->bind_param("i",$id);
  $query->execute();
  $clanQ = $query->get_result();
  
  if(mysqli_num_rows($clanQ) != 1){e();}
  
  $clan = mysqli_fetch_array($clanQ);
  
  if(isset($_POST['cmd_bar'])){
    $cmdF = mysqli_real_escape_string($conn,$_POST['cmd_bar']);
    $cmd = explode(' ', $cmdF);
    
    if($cmd[0] == "!help" || $cmd[0] == "?" || $cmd[0] == '!?'){
      alert("[ !wall ] [ !partner ] [ !mod ] [ !ban ]");
    }elseif($cmd[0] == "!wall"){
      if($clan['WALL'] == 1){$q = "0";}
      else{$q = "1";}
      mysqli_query($conn,"UPDATE `CLANS` SET `WALL` = '$q' WHERE `ID` = '$id'");
    }elseif($cmd[0] == "!partner"){
      if($clan['STATUS'] == 'PARTNER'){$q = "OK";}
      else{$q = "PARTNER";}
      mysqli_query($conn,"UPDATE `CLANS` SET `STATUS` = '$q' WHERE `ID` = '$id'");
    }elseif($cmd[0] == "!mod"){
      if($clan['STATUS'] == 'MODERATED'){$q = "OK";}
      else{$q = "MODERATED";}
      mysqli_query($conn,"UPDATE `CLANS` SET `STATUS` = '$q' WHERE `ID` = '$id'");
    }elseif($cmd[0] == "!ban"){
      if($clan['STATUS'] == 'BANNED'){$q = "OK";}
      else{$q = "BANNED";}
      mysqli_query($conn,"UPDATE `CLANS` SET `STATUS` = '$q' WHERE `ID` = '$id'");
    }
    clan($id);

  }else{
    e();
  }
}else{
  e();
}

?>