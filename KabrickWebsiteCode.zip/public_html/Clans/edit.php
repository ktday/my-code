<?php

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');
#include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();


echo"<title>Edit Clan | $meta_name</title>";

if(!isset($_COOKIE['KABRICK_U']) || !isset($_COOKIE['KABRICK_P'])){
    include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
}

if(!isset($_GET['id'])){
    include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
}

if(isset($_GET['id'])){

$id = mysqli_real_escape_string($conn,$_GET['id']);

$clan = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `CLANS` WHERE `ID` = '$id'"));

if(mysqli_num_rows(mysqli_query($conn,"SELECT * FROM `CLANS` WHERE `ID` = '$id'"))!=1){
    include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
}
if($clan['STATUS']=='BANNED'){
    include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
}
if($clan['STATUS']=='DISABLED'){
    #if($clan['OWNER']!=$account[0]){
        include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
    #}
}
  
  $inq = mysqli_query($conn,"SELECT * FROM `MEMBERS_IN_CLANS` WHERE `CLAN_ID` = '$id' AND `USER_ID` = '$account[0]'"); # CHECK IF USER IS IN CLAN
  $in = mysqli_num_rows($inq);
  $m = mysqli_fetch_array($inq);
  
  if($in!=1){include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();}
  
  $role = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `CLAN_ROLES` WHERE `ID` = '$m[ROLE]'"));
  $perms = explode(':',$role[2]);
  
  if($perms[2]!=1&&$perms[3]!=1){include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();}


if($clan['LOCKED']==1){$locked="Invite-Only";}elseif($clan['LOCKED']==0){$locked="Anyone can join";}

if(isset($_POST['description'])){//desc
        $d = mysqli_real_escape_string($conn,$_POST['description']);
        if(strlen($d) > 500){echo"<script>window.alert('Please use less than 500 characters');window.location='/Clans/edit.php?id=$id'</script>";exit();}else{
        mysqli_query($conn,"UPDATE `CLANS` SET `DESCRIPTION` = '$d' WHERE `ID` = '$id'");
        echo"<script>window.alert('Success!');window.location='/Clans/edit.php?id=$id'</script>";exit();}
}
/*if(isset($_POST['lock'])){//lock
        if($clan['LOCKED']==1){$d = 0;}else{$d=1;}
        mysqli_query($conn,"UPDATE `CLANS` SET `LOCKED` = '$d' WHERE `ID` = '$id'");
        echo"<script>window.alert('Success!');window.location='/Clans/edit.php?id=$id'</script>";exit();
}
/*if(isset($_POST['userid'])){//rank
    if($s[0]!=$account[0]){echo"<script>window.location='/Clans/'</script>";}else{
        $uid = mysqli_real_escape_string($conn,$_POST['userid']);
        $fuQ = mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$uid'");
        if(mysqli_num_rows($fuQ)!=1){echo"<script>window.alert('This User Does Not Exist!');window.location='/Clans/edit.php?id=$id'</script>";exit();}else{
        $fuigQ = mysqli_query($conn,"SELECT * FROM `MEMBERS_IN_CLANS` WHERE `USER_ID` = '$uid' AND `CLAN_ID` = '$id'");
        if(mysqli_num_rows($fuigQ)!=1){echo"<script>window.alert('This User Is Not In This Clan!');window.location='/Clans/edit.php?id=$id'</script>";exit();}else{
        //change
        if($_POST['rank']=="MEMBER"){$d = "MEMBER";}elseif($_POST['rank']=="VIP"){$d = "VIP";}else{$d="ADMIN";}
        mysqli_query($conn,"UPDATE `MEMBERS_IN_CLANS` SET `RANK` = '$d' WHERE `USER_ID` = '$uid' AND `CLAN_ID` = '$id'");
        echo"<script>window.alert('Success!');window.location='/Clans/edit.php?id=$id'</script>";exit();
    }}}
}*//*

if(isset($_POST['newownerid'])){//owner
        $un = mysqli_real_escape_string($conn,$_POST['newownerid']);
        $fuQ = mysqli_query($conn,"SELECT * FROM `USERS` WHERE `USERNAME` = '$un'");
        if(mysqli_num_rows($fuQ)!=1){
          echo"<script>window.alert('This User Does Not Exist!');window.location='/Clans/edit.php?id=$id'</script>";exit();
        }else{
          $u = mysqli_fetch_array($fuQ);
          $fuigQ = mysqli_query($conn,"SELECT * FROM `MEMBERS_IN_CLANS` WHERE `USER_ID` = '$u[0]' AND `CLAN_ID` = '$id'");
          if(mysqli_num_rows($fuigQ)!=1){
            echo"<script>window.alert('This User Is Not In This Clan!');window.location='/Clans/edit.php?id=$id'</script>";exit();
          }else{
        	//change
          	mysqli_query($conn,"UPDATE `MEMBERS_IN_CLANS` SET `ROLE` = '$m[ROLE]' WHERE `USER_ID` = '$u[0]' AND `CLAN_ID` = '$id'");
          	mysqli_query($conn,"UPDATE `MEMBERS_IN_CLANS` SET `ROLE` = '$clan[DEF_ROLE]' WHERE `USER_ID` = '$account[0]' AND `CLAN_ID` = '$id'");
          	mysqli_query($conn,"UPDATE `CLANS` SET `OWNER` = '$u[0]' WHERE `ID` = '$id'");
          	echo"<script>window.alert('Success!');window.location='/Clan/$id'</script>";exit();
    	  }
        }
}

if(isset($_POST['delete'])){//delete
    if($s[0]!=$account[0]){echo"<script>window.location='/Clans/'</script>";}else{
        $fuigQ = mysqli_query($conn,"SELECT * FROM `MEMBERS_IN_CLANS` WHERE `CLAN_ID` = '$id'");
        while(($fuig=mysqli_fetch_array($fuigQ))){
            mysqli_query($conn,"DELETE FROM `MEMBERS_IN_CLANS` WHERE `ID` = '$fuig[0]'");
        }
        mysqli_query($conn,"UPDATE `CLANS` SET `OWNER` = '0' WHERE `ID` = '$id'");
        mysqli_query($conn,"UPDATE `CLANS` SET `STATUS` = 'DELETED' WHERE `ID` = '$id'");
        echo"<script>window.alert('Successfully DELETED Clan!');window.location='/Clans/edit.php?id=$id'</script>";exit();
    }
}*/
  
  if(isset($_POST['changeRankUn'])){
    $username = mysqli_real_escape_string($conn,$_POST['changeRankUn']);
    $rank = mysqli_real_escape_string($conn,$_POST['rankRank']);
    
    //find user
    $uq = mysqli_query($conn,"SELECT * FROM `USERS` WHERE `USERNAME` = '$username' ORDER BY `ID` ASC LIMIT 1");
    if(mysqli_num_rows($uq)!=1){echo"<script>window.alert('User does not exist');window.location='/Clans/edit.php?id=$id'</script>";exit();}
    $u = mysqli_fetch_array($uq);
    
    //is user in clan
    $cq = mysqli_query($conn,"SELECT * FROM `MEMBERS_IN_CLANS` WHERE `CLAN_ID` = '$id' AND `USER_ID` = '$u[0]'");
    if(mysqli_num_rows($cq)!=1){echo"<script>window.alert('User is not in clan');window.location='/Clans/edit.php?id=$id'</script>";exit();}
    $c = mysqli_fetch_array($cq);
    
    //find role
    $rq = mysqli_query($conn,"SELECT * FROM `CLAN_ROLES` WHERE `CLAN` = '$id' AND `LISTID` = '$rank'");
    if(mysqli_num_rows($rq)!=1){echo"<script>window.alert('Invalid role');window.location='/Clans/edit.php?id=$id'</script>";exit();}
    $r = mysqli_fetch_array($rq);
    
    if($c['ROLE']==$r[0]){echo"<script>window.alert('User already has role');window.location='/Clans/edit.php?id=$id'</script>";exit();}
    
    $p = explode(':',$r[2]);
    if($p[3] == 1){echo"<script>window.alert('Cannot assign owner role to other users');window.location='/Clans/edit.php?id=$id'</script>";exit();}
    
    //all good :)
    mysqli_query($conn,"UPDATE `MEMBERS_IN_CLANS` SET `ROLE` = '$r[0]' WHERE `ID` = '$c[0]'");
    echo"<script>window.alert('Successfully changed $username role to $r[NAME]');window.location='/Clans/edit.php?id=$id'</script>";exit();
  }
  
  if(isset($_POST['changeQuickURL'])){
    $newinv = mysqli_real_escape_string($conn,$_POST['changeQuickURL']);
    if($newinv == $clan['INVITE']){echo"<script>window.alert('Invite already in use');window.location='/Clans/edit.php?id=$id'</script>";exit();}
    
    if(!preg_match_all("/^[A-Za-z0-9]*$/",$newinv)){echo"<script>window.location='/Clans/edit.php?id=$id'</script>";exit();}
    
    $q = mysqli_query($conn,"SELECT * FROM `CLANS` WHERE `INVITE` = '$newinv'");
    if(mysqli_num_rows($q)!=0){echo"<script>window.alert('Invite already in use');window.location='/Clans/edit.php?id=$id'</script>";exit();}
    
    mysqli_query($conn,"UPDATE `CLANS` SET `INVITE` = '$newinv' WHERE `ID` = '$clan[0]'");
    echo"<script>window.alert('Successfully updated quick url');window.location='/Clans/edit.php?id=$id'</script>";exit();
  }
    

echo"

<div class='platform'>
	<div class='platformtitle'>
    	<h1>Edit Clan \"$clan[1]\"</h1>
    </div>
    
    <br><a href='/Clan/$id' class='button2 btn-blue nd hover'>Return to Clan</a><br><br>
    
    Description:
    <form method='post'>
        <textarea class='form form1l' name='description' placeholder='$clan[2]' maxlength='200' required>$clan[2]</textarea><br>
        <button class='button3 btn-blue hover'>Update!</button>
    </form><br>
    
    Quick URL: <a href='/c/$clan[INVITE]'>/c/$clan[INVITE] <i class='fas fa-external-link-alt'></i> </a><br><br>
    <form method='post'>
        <input class='form form2l' title='New quick url link' placeholder='$clan[INVITE] (a-zA-z0-9)' name='changeQuickURL'>
    </form><br>
    
    Change User Rank:
    <form method='post'>
        <input class='form form2l' title='The Users ID' placeholder='Username' name='changeRankUn'>
        <select name='rankRank' class='form form2l'>
        
        ";
  
  
  		$q = mysqli_query($conn,"SELECT * FROM `CLAN_ROLES` WHERE `CLAN` = '$id' ORDER BY `LISTID` ASC");
  		
  		while(($r = mysqli_fetch_array($q))){
          echo"<option value='$r[LISTID]'>$r[NAME]</option>";
        }
  
  echo"
        
        </select>
        <button class='button3 btn-blue hover'>Update!</button>
    </form><br>
    
    
    <table>
    
    <tr>
    	<th>Rank (0-7)</th>
    	<th>Name</th>
    	<th>Wall Post</th>
    	<th>Wall View</th>
    	<th>Edit</th>
    	<th>Owner</th>
    </tr>
    ";
  
  $ranks = mysqli_query($conn,"SELECT * FROM `CLAN_ROLES` WHERE `CLAN` = '$id' ORDER BY `LISTID` ASC");
  
  while(($r = mysqli_fetch_array($ranks))){
    $perms = explode(':',$r[2]);
    echo"<tr>
    	<td>$r[LISTID]</td>
    	<td>$r[NAME]</td>
    	<td>$perms[0]</td>
    	<td>$perms[1]</td>
    	<td>$perms[2]</td>
    	<td>$perms[3]</td>
    </tr>";
  }
  
  echo"</table><br><br>";
  
  /*if($clan['OWNER']==$account[0]){
  
  echo"
  
  
    
    <span style='color:red'>Change owner</span>
    <form method='post'>
        <input class='form form1l' title='The user ID of the new owner' name='newownerid'>
        <button class='button3 btn-red'>Change!</button>
    </form><br>
    
    <span class='txtcol-red'>DELETE CLAN</span>
    <form method='post'>
        <button name='delete' style='border:1px solid red' class='button3 btn-red'>Request Delete</button>
    </form>
    
    ";}*/echo"
    
</div>
</div>";}

?>