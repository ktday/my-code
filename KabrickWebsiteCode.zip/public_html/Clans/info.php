<?php

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/connect.php');
include($_SERVER['DOCUMENT_ROOT'] . '/Misc/vars.php');
include($_SERVER['DOCUMENT_ROOT'] . '/bbcode.php');

if(!isset($_GET['id'])){
    exit();
}

$id = mysqli_real_escape_string($conn,$_GET['id']);

$clan = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `CLANS` WHERE `ID` = '$id'"));

echo"

<h1>Clan Info</h1>

<p>".bbcode_to_html(nl2br(htmlentities($clan['DESCRIPTION'])))."</p>

";

?>