<?php

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/connect.php');
include($_SERVER['DOCUMENT_ROOT'] . '/bbcode.php');


if(isset($_COOKIE['KABRICK_U'])&&isset($_COOKIE['KABRICK_P'])){
    include($_SERVER['DOCUMENT_ROOT'] . '/Misc/connect.php');
    $username = mysqli_real_escape_string($conn, $_COOKIE['KABRICK_U']);
    $password = mysqli_real_escape_string($conn, $_COOKIE['KABRICK_P']);
    
    $accountQ = $conn->prepare("SELECT * FROM `USERS` WHERE `USERNAME`=? AND `PASSWORD`=?");
    $accountQ->bind_param("ss", $username, $password);
    $accountQ->execute();
    $result = $accountQ->get_result();
	$account_R = mysqli_num_rows($result);
	$account = mysqli_fetch_array($result);
	
	if($account_R!=1){
	    echo"<script>window.location='/User/logout.php'</script>";exit();
	}
  
}else{exit();}




$var = intval(mysqli_real_escape_string($conn,$_POST['pageIndex']));
$clanid = mysqli_real_escape_string($conn,$_POST['clan']);
$pageIDsq = ($var-1) * 8;
if($var<1){
  $var = 1;
  $pageIDsq = 0;
}


				$clan = mysqli_query($conn,"SELECT * FROM `WALL` WHERE `CLAN` = '$clanid' ORDER BY ID DESC LIMIT $pageIDsq, 8");
          		if(mysqli_num_rows($clan)>0){
          		while(($c = mysqli_fetch_array($clan))){
                  $u = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$c[USER]'"));
                  $body=bbcode_to_html(nl2br(htmlentities($c['BODY'])));
                  
                    #FIND RANK
                  $rank = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `ROLES` WHERE `NAME` = '$u[RANK]'"));
                  if($rank['ICON']==""){$ur = "";}else{$ur = "<i class='$rank[ICON]'></i>";}
                  
                    
            
                    echo"
                    
                      <div class='forum-body'>

                        <div class='forum-av'>
                            <a href='/Profile/$u[1]'>
                                <img src='$u[AVATAR_IMG_URL]'>
                                <br>
                                <br>
                                <b style='color:$rank[COLOR];'>$u[1] $ur</b>
                            </a>
                        </div>

                        <div class='forum-st'>
                            $body
                        </div>

                    </div>
                    
                    ";
                  
                }}

?>