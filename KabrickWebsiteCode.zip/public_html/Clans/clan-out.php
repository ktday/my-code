<?php

#include($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');
#include($_SERVER['DOCUMENT_ROOT'] . '/bbcode.php');

echo"<title>Clans | $meta_name</title>";

if(!isset($_COOKIE['KABRICK_U']) || !isset($_COOKIE['KABRICK_P'])){
	}else{exit();
}

if(!isset($_GET['id'])){
    include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
}

$id = mysqli_real_escape_string($conn,$_GET['id']);

$clan = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `CLANS` WHERE `ID` = '$id'"));

if(mysqli_num_rows(mysqli_query($conn,"SELECT * FROM `CLANS` WHERE `ID` = '$id'"))!=1){
    include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
}
if($clan['STATUS']=='BANNED'){
    include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
}
if($clan['STATUS']=='DISABLED'){
    include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
}

$owner = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$clan[OWNER]'"));
$members = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM `MEMBERS_IN_CLANS` WHERE `CLAN_ID` = '$id'"));

//members
$memberQ = mysqli_query($conn,"SELECT * FROM `MEMBERS_IN_CLANS` WHERE `CLAN_ID` = '$id' ORDER BY `ID` DESC LIMIT 5");
$memberN = mysqli_num_rows($memberQ);

$member1Q = mysqli_query($conn,"SELECT * FROM `MEMBERS_IN_CLANS` WHERE `CLAN_ID` = '$id' AND `RANK` = 'MEMBER' ORDER BY `ID` DESC LIMIT 5");
$member1N = mysqli_num_rows($member1Q);

$member2Q = mysqli_query($conn,"SELECT * FROM `MEMBERS_IN_CLANS` WHERE `CLAN_ID` = '$id' AND `RANK` = 'VIP' ORDER BY `ID` DESC LIMIT 5");
$member2N = mysqli_num_rows($member2Q);

$member3Q = mysqli_query($conn,"SELECT * FROM `MEMBERS_IN_CLANS` WHERE `CLAN_ID` = '$id' AND `RANK` = 'ADMIN' ORDER BY `ID` DESC LIMIT 5");
$member3N = mysqli_num_rows($member3Q);

$member4Q = mysqli_query($conn,"SELECT * FROM `MEMBERS_IN_CLANS` WHERE `CLAN_ID` = '$id' AND `RANK` = 'OWNER' ORDER BY `ID` ASC LIMIT 1");
$member4N = mysqli_num_rows($member4Q);

//leaderboard pos

$x = 0;$lbid = "0";
$lbrq = mysqli_query($conn,"SELECT * FROM `CLANS` WHERE 1 ORDER BY `BOOSTS` DESC LIMIT 10");

while(($e = mysqli_fetch_array($lbrq))){
    $x = $x + 1;
    if($e[0] == $id){
        $lbid = "#$x in top";
    }
}
if($lbid=="0"){
    $lbid = "Not in top";
}
if($lbid=="#1 in top"){
    $color = 'gold';
}elseif($lbid=="#2 in top"){
    $color = 'silver';
}elseif($lbid=="#3 in top"){
    $color = 'bronze';
}else{
    $color = 'white';
}

if($clan['STATUS']=='PARTNER'){
    $icon = "<partner></partner>";
}else{
    if($clan['BOOSTS']>0&&$clan['BOOSTS']<5){
        $icon = "<boost1></boost1>";
    }elseif($clan['BOOSTS']>4&&$clan['BOOSTS']<10){
        $icon = "<boost2></boost2>";
    }elseif($clan['BOOSTS']>9&&$clan['BOOSTS']<15){
        $icon = "<boost3></boost3>";
    }elseif($clan['BOOSTS']>14&&$clan['BOOSTS']<30){
        $icon = "<boost4></boost4>";
    }elseif($clan['BOOSTS']>29){
        $icon = "<boost5></boost5>";
    }else{
        $icon = "";
    }
}

echo"

<div class='doublebox box1'>
    <div class='platformtitle'>
        <h1>$icon $clan[1]</h1>
    </div>
    <br>
    <img src='$clan[ICON_URL]'><br>
    <p>$members Members</p>
    <p><a href='/Profile/$owner[1]'>Owned by $owner[1]</a></p>
    <p class='txtcol-purple'>$clan[BOOSTS] Boosts</p>
    <p class='txtcol-$color'>$lbid</p>
    <a href='?join=$id' class='button btn-blue nd hover'>Login to Join this Clan</a>
    
</div>

<div class='doublebox box2'>
    <div style='display:block;width:100%;height:200px;border-radius:5px;overflow:hidden;background-image:url($clan[BANNER_URL]);background-size:cover;'>
        <p>".bbcode_to_html(nl2br(htmlentities($clan['DESCRIPTION'])))."</p>
    </div>
    
    <br>
    
    <h2>Members ($memberN)</h2>
    
    ";

	if($memberN<1){
        echo"<p>This clan has no members</p>";
    }else{
        while(($member = mysqli_fetch_array($memberQ))){
            
            $u = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$member[USER_ID]'"));
            
            echo"
            <a href='/Profile/$u[1]' class='nd dib'>
                <div class='forum-av'>
        			<img src='$u[AVATAR_IMG_URL]'><br>
        			<p>$u[1]</p><br><br>
            	</div>
            </a>
            ";
        }
    }

echo"

<hr>

<h2>Clan Wall</h2>

Login to view clan wall!
    
</div>

</div>

";

?>