<?php

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/navbar.php');

include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();

if(isset($_COOKIE['KABRICK_U']) || isset($_COOKIE['KABRICK_P'])){}else{
    echo"<script>window.location='/'</script>";exit();
}

if($account['RANK']!='OWNER'){echo"<script>window.location='/'</script>";exit();}

if(isset($_GET['id'])){if(!is_numeric($_GET['id'])){echo"<script>window.location='/'</script>";exit();}

$id=mysqli_real_escape_string($conn,$_GET['id']);
$cQ = mysqli_query($conn,"SELECT * FROM `CLANS` WHERE `ID` = '$id'");
$cN = mysqli_num_rows($cQ);if($cN==0){echo"<script>window.location='/Clans/'</script>";}
$c=mysqli_fetch_array($cQ);
if($c['STATUS']=='OK'){$name=$c[1];}
elseif($c['STATUS']=='MODERATED'){$name="[ MODERATED ]";}
elseif($c['STATUS']=='DELETED'){echo"<script>window.location='/Clans/'</script>";}
elseif($c['STATUS']=='BANNED'){$name="[ BANNED ]";}

echo"
<title>Kabrick.tk - Clan Moderation Actions</title>
<center>
<h1><i style='color:$col8;' class='fa fa-user-secret'></i> <u><b>Moderation Actions on clan: $c[1]</b></u></h1>
<div class='box middle' style='background-color:$col12;border-color:$col13;'>
    <br>
    <a class='button' href='?ban=$id'>Ban Clan</a>
    <a class='button' href='?mod=$id'>Moderate Clan</a>
    <a class='button' href='?ret=$id'>Return Clan To Normal Status</a>
    ";
    if($account[0]=='2'){echo"<a class='button' style='color:blue;' href='?par=$id'>Partner Clan</a>";}
    echo"<br><br>
    <a href='/Clans/clan.php?id=$id'>Return To Clan</a>
    <br>
</div>
</center>
</body>
</html>";
    
}

elseif(isset($_GET['ban'])){
    $id = mysqli_real_escape_string($conn,$_GET['ban']);
    $cQ = mysqli_query($conn,"SELECT * FROM `CLANS` WHERE `ID` = '$id'");
    $cN = mysqli_num_rows($cQ);if($cN==0){echo"<script>window.location='/Clans/'</script>";exit();}
    mysqli_query($conn,"UPDATE `CLANS` SET `STATUS` = 'BANNED' WHERE `ID` = '$id'");
    echo"<script>window.alert('Successfully BANNED Clan!');window.location='/Clans/clan.php?id=$id'</script>";exit();
}

elseif(isset($_GET['mod'])){
    $id = mysqli_real_escape_string($conn,$_GET['mod']);
    $cQ = mysqli_query($conn,"SELECT * FROM `CLANS` WHERE `ID` = '$id'");
    $cN = mysqli_num_rows($cQ);if($cN==0){echo"<script>window.location='/Clans/'</script>";exit();}
    mysqli_query($conn,"UPDATE `CLANS` SET `STATUS` = 'MODERATED' WHERE `ID` = '$id'");
    echo"<script>window.alert('Successfully MODERATED Clan!');window.location='/Clans/clan.php?id=$id'</script>";exit();
}

elseif(isset($_GET['ret'])){
    $id = mysqli_real_escape_string($conn,$_GET['ret']);
    $cQ = mysqli_query($conn,"SELECT * FROM `CLANS` WHERE `ID` = '$id'");
    $cN = mysqli_num_rows($cQ);if($cN==0){echo"<script>window.location='/Clans/'</script>";exit();}
    mysqli_query($conn,"UPDATE `CLANS` SET `STATUS` = 'OK' WHERE `ID` = '$id'");
    echo"<script>window.alert('Successfully RETURNED Clan!');window.location='/Clans/clan.php?id=$id'</script>";exit();
}

elseif(isset($_GET['par'])){
    if($account[0]!='2'){echo"<script>window.location='/Clans/clan.php?id=$id'</script>";exit();}
    $id = mysqli_real_escape_string($conn,$_GET['par']);
    $cQ = mysqli_query($conn,"SELECT * FROM `CLANS` WHERE `ID` = '$id'");
    $cN = mysqli_num_rows($cQ);if($cN==0){echo"<script>window.location='/Clans/'</script>";exit();}
    mysqli_query($conn,"UPDATE `CLANS` SET `STATUS` = 'PARTNER' WHERE `ID` = '$id'");
    echo"<script>window.alert('Successfully PARTNERED Clan!');window.location='/Clans/clan.php?id=$id'</script>";exit();
}

?>