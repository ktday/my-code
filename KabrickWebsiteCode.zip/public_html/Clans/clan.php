<?php

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');
include($_SERVER['DOCUMENT_ROOT'] . '/bbcode.php');

#include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();


echo"<title>Clans | $meta_name</title>";

if(!isset($_COOKIE['KABRICK_U']) || !isset($_COOKIE['KABRICK_P'])){
    include($_SERVER['DOCUMENT_ROOT'] . '/Clans/clan-out.php');exit();
}

if(!isset($_GET['id'])){
    include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
}

$id = mysqli_real_escape_string($conn,$_GET['id']);

$clan = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `CLANS` WHERE `ID` = '$id'"));

if(mysqli_num_rows(mysqli_query($conn,"SELECT * FROM `CLANS` WHERE `ID` = '$id'"))!=1){
    include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
}
if($clan['STATUS']=='BANNED'){
    include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
}
if($clan['STATUS']=='DISABLED'){
    if($clan['OWNER']!=$account[0]){
        include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
    }
}

$owner = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$clan[OWNER]'"));                              #  FIND OWNER
$members = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM `MEMBERS_IN_CLANS` WHERE `CLAN_ID` = '$id'"));                        # FIND MEMBER COUNT
$in = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM `MEMBERS_IN_CLANS` WHERE `CLAN_ID` = '$id' AND `USER_ID` = '$account[0]'")); # CHECK IF USER IS IN CLAN

if($owner[0]==$account[0]){ 
	$joined = 2; # IS OWNER
}else{
 	if($in==1){
      $joined = 1; # IS JOINED
    }else{
      $joined = 0; # IS NOT JOINED
    }
}

//members
$memberQ = mysqli_query($conn,"SELECT * FROM `MEMBERS_IN_CLANS` WHERE `CLAN_ID` = '$id' ORDER BY `ID` DESC LIMIT 5");
$memberN = mysqli_num_rows($memberQ);

$member1Q = mysqli_query($conn,"SELECT * FROM `MEMBERS_IN_CLANS` WHERE `CLAN_ID` = '$id' AND `RANK` = 'MEMBER' ORDER BY `ID` DESC LIMIT 5");
$member1N = mysqli_num_rows($member1Q);

$member2Q = mysqli_query($conn,"SELECT * FROM `MEMBERS_IN_CLANS` WHERE `CLAN_ID` = '$id' AND `RANK` = 'VIP' ORDER BY `ID` DESC LIMIT 5");
$member2N = mysqli_num_rows($member2Q);

$member3Q = mysqli_query($conn,"SELECT * FROM `MEMBERS_IN_CLANS` WHERE `CLAN_ID` = '$id' AND `RANK` = 'ADMIN' ORDER BY `ID` DESC LIMIT 5");
$member3N = mysqli_num_rows($member3Q);

$member4Q = mysqli_query($conn,"SELECT * FROM `MEMBERS_IN_CLANS` WHERE `CLAN_ID` = '$id' AND `RANK` = 'OWNER' ORDER BY `ID` ASC LIMIT 1");
$member4N = mysqli_num_rows($member4Q);

//leaderboard pos

$x = 0;$lbid = "0";
$lbrq = mysqli_query($conn,"SELECT * FROM `CLANS` WHERE 1 ORDER BY `BOOSTS` DESC LIMIT 10");

while(($e = mysqli_fetch_array($lbrq))){
    $x = $x + 1;
    if($e[0] == $id){
        $lbid = "#$x in top";
    }
}
if($lbid=="0"){
    $lbid = "Not in top";
}
if($lbid=="#1 in top"){
    $color = 'gold';
}elseif($lbid=="#2 in top"){
    $color = 'silver';
}elseif($lbid=="#3 in top"){
    $color = 'bronze';
}else{
    $color = 'white';
}

if($clan['STATUS']=='PARTNER'){
    $icon = "<partner></partner>";
}else{
    if($clan['BOOSTS']>0&&$clan['BOOSTS']<5){
        $icon = "<boost1></boost1>";
    }elseif($clan['BOOSTS']>4&&$clan['BOOSTS']<10){
        $icon = "<boost2></boost2>";
    }elseif($clan['BOOSTS']>9&&$clan['BOOSTS']<15){
        $icon = "<boost3></boost3>";
    }elseif($clan['BOOSTS']>14&&$clan['BOOSTS']<30){
        $icon = "<boost4></boost4>";
    }elseif($clan['BOOSTS']>29){
        $icon = "<boost5></boost5>";
    }else{
        $icon = "";
    }
}

//boost price

if($account['VIP']=="NONE"){
  $boostPrice = 20;
}elseif($account['VIP']=="VIP"){
  $boostPrice = 10;
}elseif($account['VIP']=="MEGA"){
  $boostPrice = 5;
}elseif($account['VIP']=="ULTRA"){
  $boostPrice = 0;
}else{
 $boostPrice = 20; 
}

if(isset($_POST['wall'])){
  $p = mysqli_real_escape_string($conn,$_POST['wall']);
  mysqli_query($conn,"INSERT INTO `WALL` VALUES(NULL,'$clan[0]','$account[0]','$p')");
  #echo"<script>location.reload()</script>";
}

echo"

<script>
$(document).ready(function(){
  wall();
});

function mbrs() {
  $('#load').load('/Clans/members.php?id=$id');
}

function wall() {
  $('#load').load('/Clans/wall.php?id=$id');
}


</script>

";

echo"

<div class='doublebox box1'>
    <div class='platformtitle'>
        <h1>$icon $clan[1]</h1>
    </div>
    <br>
    <img src='$clan[ICON_URL]'><br>
    <p>$members Members</p>
    <p><a href='/Profile/$owner[1]'>Owned by $owner[1]</a></p>
    <p class='txtcol-purple'>$clan[BOOSTS] Boosts</p>
    <p class='txtcol-$color'>$lbid</p>
    ";if($joined==1){   /*  WHEN USER IS IN CLAN  */ echo"
    <p class='txtcol-green'><i class='fa fa-check-circle'></i> You have joined this clan</p>
    <p>My role is </p>
    <a href='?quit=$id' class='button btn-red nd hover'>Leave this Clan</a><br>
    <a href='?boost=$id' class='button btn-purple nd hover'>Boost this Clan (<i class='fa fa-money-bill'></i>$boostPrice)</a>
    ";}elseif($joined==2){   /*  WHEN USER IS OWNER  */ echo"
    <p class='txtcol-gold'>You own this clan</p>
    <a href='?boost=$id' class='button btn-purple nd hover'>Boost this Clan (<i class='fa fa-money-bill'></i>$boostPrice)</a>
    ";}else{   /*  WHEN USER IS NOT IN CLAN  */ echo"
    <a href='?join=$id' class='button btn-blue nd hover'>Join this Clan</a>
    ";}echo"
    
</div>

<div class='doublebox box2'>
    <p>".bbcode_to_html(nl2br(htmlentities($clan['DESCRIPTION'])))."</p>
    
    <br><hr><br>
    
    <button class='button2 btn-blue nd' onclick='wall()'>Wall</button>
    <button class='button2 btn-blue nd' onclick='mbrs()'>Members</button>
    
    <div id='load'>
    
    </div>
    

<hr>

<h2>Clan Wall</h2>

";

if($clan['WALL']=='NO'){
  echo"
  
  <textarea class='form form1l' readonly=''>This clans wall has been locked.</textarea><br><br>
  
  ";
}else{
  echo"
  
  <form method='post'>
  	<textarea class='form form1l' name='wall'></textarea>
    <button class='button3 btn-blue nd'>Post!</button>
  </form>
  
  <script>
  
  var clan = '$clan[0]'
  id = 0;
  function next() {
	id ++;
	jQuery.ajax({
		data:{
			pageIndex:id,
			clan:clan
		},
		url:'pages.php',
		type:'POST',
		success:function(results) {
		    jQuery('.wall').html(results);
		}
	});
  }

  function back() {
	if(id > 1){
		id = id - 1;
		jQuery.ajax({
			data:{
				pageIndex:id,
				clan:clan
			},
			url:'pages.php',
			type:'POST',
			success:function(results) {
 			   jQuery('.wall').html(results);
			}
		});
  }} 
  
  next();
  
  </script>
  
  <div class='wall'>
  
  </div>
  
  <button class='button3 btn-blue nd' onclick='back()'>Previous Page</button>
  <button class='button3 btn-blue nd' onclick='next()'>Next Page</button>
  
  ";
}

echo"
    
</div>

</div>

";

?>