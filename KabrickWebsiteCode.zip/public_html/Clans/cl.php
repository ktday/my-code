<?php

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');

if(!isset($_COOKIE['KABRICK_U']) || !isset($_COOKIE['KABRICK_P'])){
    exit();
}


if(isset($_GET['join'])){
  $id = mysqli_real_escape_string($conn,$_GET['join']);

$cl = mysqli_query($conn,"SELECT * FROM `CLANS` WHERE `ID` = '$id'");
$clan = mysqli_fetch_array($cl);
  
if(mysqli_num_rows($cl)!=1){
    include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
}
if($clan['STATUS']=='BANNED'){
    include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
}
if($clan['STATUS']=='DISABLED'){
    #if($clan['OWNER']!=$account[0]){
        include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
    #}
}
  
if(mysqli_num_rows(mysqli_query($conn,"SELECT * FROM `MEMBERS_IN_CLANS` WHERE `USER_ID` = '$account[0]'")) >= 3){echo"<script>window.alert('You are already in 3 clans!');window.location='/Clan/$id'</script>";exit();}
  
  
$inq = mysqli_query($conn,"SELECT * FROM `MEMBERS_IN_CLANS` WHERE `CLAN_ID` = '$id' AND `USER_ID` = '$account[0]'"); # CHECK IF USER IS IN CLAN
  $in = mysqli_num_rows($inq);
  
  if($in!=0){
    include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
  }else{
    mysqli_query($conn,"INSERT INTO `MEMBERS_IN_CLANS` VALUES(NULL,'$id','$account[0]','$clan[DEF_ROLE]')");
  }
  
  echo"<script>window.location='/Clan/$id'</script>";exit();
  
  
}



if(isset($_GET['exit'])){
  $id = mysqli_real_escape_string($conn,$_GET['exit']);

$clan = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `CLANS` WHERE `ID` = '$id'"));

if(mysqli_num_rows(mysqli_query($conn,"SELECT * FROM `CLANS` WHERE `ID` = '$id'"))!=1){
    include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
}
  
  
$inq = mysqli_query($conn,"SELECT * FROM `MEMBERS_IN_CLANS` WHERE `CLAN_ID` = '$id' AND `USER_ID` = '$account[0]'"); # CHECK IF USER IS IN CLAN
  $in = mysqli_num_rows($inq);
  $m = mysqli_fetch_array($inq);
  
  if($in==0){
    include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
  }else{
    mysqli_query($conn,"DELETE FROM `MEMBERS_IN_CLANS` WHERE `ID` = '$m[0]'");
  }
  
  echo"<script>window.location='/Clan/$id'</script>";exit();
  
  
}