<?php

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');

#include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();

echo"<title>Clans | $meta_name</title>";

if(isset($_COOKIE['KABRICK_U']) || isset($_COOKIE['KABRICK_P'])){
    $loggedin = true;
}else{
  $loggedin = false;
}

$cQ = mysqli_query($conn,"SELECT * FROM `CLANS` WHERE `STATUS` = 'OK' OR `STATUS` = 'MODERATED' OR `STATUS` = 'PARTNER' ORDER BY `CLANS`.`MEMBERS` DESC");
$cN = mysqli_num_rows($cQ);

echo"

<div class='platform'>
    <div class='platformtitle'>
        <h2>Clans</h2>
    </div>
</div>

<br><br>

";

if($loggedin == true){
  $cIQ = mysqli_query($conn,"SELECT CLANS.* FROM MEMBERS_IN_CLANS JOIN CLANS ON CLANS.ID = MEMBERS_IN_CLANS.CLAN_ID
     WHERE MEMBERS_IN_CLANS.USER_ID = '$account[0]' ORDER BY CLANS.ID ASC");
  $cI = mysqli_num_rows($cIQ);
  
  echo"

<div class='doublebox box5'>
    <div class='platformtitle'>
        <h2>My Clans ($cI)</h2>
    </div>
    ";
    
    while(($clan = mysqli_fetch_array($cIQ))){
        
        #purple = #c09
	    $sQ = mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$clan[OWNER]'");
        $s = mysqli_fetch_array($sQ);
        
        if($clan['STATUS']=='MODERATED'){
            $name = "[ DELETED ]";
        }elseif($clan['STATUS']=='PARTNER'){
            $name = "<partner></partner>  " . $clan[1];
        }else{
            $name = $clan[1];
        }
        
        echo"
        
        <div id='my-clan'>
            <hr><br>
            <a class='big1' href='/Clan/$clan[0]'>$name</a> <big class='txtcol-white'>Members: $clan[MEMBERS]</big>
            <p><a class='small1' href='/Profile/$s[1]'>Owned by: $s[1]</a></p>
        </div>
        
        ";
    }echo"
    
    <hr><br>
    Create your own clan here<br><br>
    <a "; if($cI >= 3){echo"style='cursor:not-allowed;' class='button3 btn-red nd hover'";}else{echo"href='/Clans/create.php' class='button3 btn-blue nd hover'";} echo">Create</a><br><br>
    
    </div>";}else{
  
  echo"
  
  <div class='doublebox box5'>
    <div class='platformtitle'>
        <h2>My Clans</h2>
    </div>
    
    <h1>Login to see your clans!</h1>
    
  </div>
  
  ";}
    
    echo"

<div class='doublebox box6'>
    <div class='platformtitle'>
        <h2>Most Popular ($cN)</h2>
    </div>
    ";
    
    $x = 1;
    
    while(($tc = mysqli_fetch_array($cQ))){
        
	    $sQ = mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$tc[OWNER]'");
        $s = mysqli_fetch_array($sQ);
        
        if($tc['STATUS']=='MODERATED'){
            $name = "#$x [ DELETED ]";
        }elseif($tc['STATUS']=='PARTNER'){
            $name = "<partner></partner> #$x " . $tc[1];
        }else{
            $name = "#$x " . $tc[1];
        }
        
        if($x==1){
            $col = "txtcol-gold";
        }elseif($x==2){
            $col = "txtcol-silver";
        }elseif($x==3){
            $col = "txtcol-bronze";
        }else{
            $col = "txtcol-white";
        }
        
        echo"
        
        <div id='my-clan'>
            <hr><br>
            <a class='big1 $col' href='/Clan/$tc[0]'>$name</a> <big class='txtcol-white'>Members: $tc[MEMBERS]</big>
            <p><a class='small1' href='/Profile/$s[1]'>Owned by: $s[1]</a></p>
        </div>
        
        ";
        
        $x = $x + 1;
    }
  
    
    echo"
</div>

</div>

";

?>