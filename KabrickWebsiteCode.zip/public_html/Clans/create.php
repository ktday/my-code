<?php

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');
include($_SERVER['DOCUMENT_ROOT'] . '/bbcode.php');

#include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();


echo"<title>Create Clan | $meta_name</title>";

if(!isset($_COOKIE['KABRICK_U']) || !isset($_COOKIE['KABRICK_P'])){
    exit();
}

$price = $config['clanPrice'];

if(isset($_POST['clanName'])){
  $clanName = mysqli_real_escape_string($conn,$_POST['clanName']);
  
  if(!preg_match_all("/^[^<>]*$/",$clanName)){echo"<script>window.alert('Invalid characters in name');window.location='/Clans/create.php'</script>";exit();}
  
  if(strlen($clanName) > 20 || strlen($clanName) < 4){echo"<script>window.alert('Modifying lengths in inspect is bad for your brain. Go get some rest.');window.location='/Clans/create.php'</script>";exit();}
  
  $q = $conn->prepare("SELECT * FROM `CLANS` WHERE `NAME` = ?");
  $q->bind_param("s",$clanName);
  $q->execute();
  $nr = $q->num_rows;
  if($nr != 0){ echo"<script>window.alert('Name already taken');window.location='/Clans/create.php'</script>";exit(); }
  $q->close();
  
  //lets see, are they poor enough?
  if($account['BUCKS'] < $price){echo"<script>window.alert('Cannot afford clan');window.location='/Clans/'</script>";exit();}
  
  //now for the image shit
  
  if(isset($_FILES['clanImage'])){
    $img = $_FILES['clanImage'];
    if ($img["error"] > 0){
      echo "<script>window.alert('Error: " . $img["error"] . "')</script>";echo"<script>window.location='/Clans/create.php'</script>";exit();
    }
    $info = getimagesize($img['tmp_name']);
    if($info === FALSE){echo"<script>window.alert('info false');window.location='/Clans/'</script>";exit();}
    if (($info[2] !== IMAGETYPE_PNG)) {
      echo"<script>window.alert('Not A Valid Image file!')</script>";
      echo"<script>window.location='/Clans/create.php'</script>";exit();
    }
    
    //generate str
    $string = generateRandomString(15);
    
    $img_dir_pre = "/home/lord7302/domains/$meta_blank_url/public_html";
    $img_dir_suf = "/Misc/IMGS/CLANS/$string.png";
    $image_dir = $img_dir_pre.$img_dir_suf;
    move_uploaded_file($img['tmp_name'], $image_dir);
    
    //create
    
    $time = time();
    $clanDesc = $config["defaultClanDesc"];
    $nl = 0;
    $cq = $conn->prepare("INSERT INTO `CLANS` (`ID`,`NAME`,`DESCRIPTION`,`ICON_URL`,`OWNER`,`TIME`,`DEF_ROLE`,`INVITE`) VALUES (NULL,?,?,?,?,?,?,?)");
    #var_dump( $conn->error_list );
    $cq->bind_param("sssiiis",$clanName,$clanDesc,$img_dir_suf,$account[0],$time,$nl,$string);
    $cq->execute();
    $cq->close();
    
    //that reminds me, i need to add roles
    
    $findClan = mysqli_query($conn,"SELECT * FROM `CLANS` WHERE `INVITE` = '$string'");
    $cl = mysqli_fetch_array($findClan);
    
    $addroles = mysqli_query($conn,"INSERT INTO `CLAN_ROLES` VALUES
    (NULL,'Owner','1:1:1:1','$cl[0]','7'),
    (NULL,'Admin','1:1:1:0','$cl[0]','5'),
    (NULL,'Member','1:1:0:0','$cl[0]','1')");
    
    //bro how the fuck could i miss this part
    
    $owRole = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `CLAN_ROLES` WHERE `LISTID` = '7' AND `CLAN` = '$cl[0]'"));
    $mbRole = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `CLAN_ROLES` WHERE `LISTID` = '1' AND `CLAN` = '$cl[0]'"));
    
    mysqli_query($conn,"INSERT INTO `MEMBERS_IN_CLANS` VALUES (NULL,'$cl[0]','$account[0]','$owRole[0]')");
    mysqli_query($conn,"UPDATE `CLANS` SET `DEF_ROLE` = '$mbRole[0]' WHERE `ID` = '$cl[0]'");
    
    //take money
    $np = $account['BUCKS'] - $price;
    mysqli_query($conn,"UPDATE `USERS` SET `BUCKS` = '$np' WHERE `ID` = '$account[0]'");
    
    echo"<script>window.alert('Successfully Created Clan!');window.location='/Clan/$cl[0]'</script>";exit();
    
    
  }else{
    echo"<script>window.alert('No image set');window.location='/Clans/create.php'</script>";exit();
  }
}

echo"<div class='platform'>

<div class='platformtitle'>
	<p><u><b>Create a clan</b></u></p>
</div>

<form method='post' enctype='multipart/form-data'><br>

	Clan Name <i class='fas fa-key txtcol-silver'></i><br>
    <input name='clanName' minlength='4' maxlength='20' placeholder='Clan Name Here' class='form form2l'><br><br>
    Image Icon (Must be square)<br>
    <input type='file' id='clanImage' name='clanImage' accept='.png'><br><br>
    
    <b>Clan creation will cost <i class='fas fa-money-bill-alt'></i> $price</b><br><br>
    
    <button class='button3 btn-blue nd hover'>Create clan</button>

</form>

";