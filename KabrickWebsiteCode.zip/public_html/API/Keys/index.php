<?php

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');
echo"<title>API Keys | $meta_name</title>";

echo"

<div class='platform doublebox box5'>
    <div class='platformtitle'>
        <h2>Your API Keys</h2>
    </div>

    <div class='giftbox'>
        Scope XYZ<br>
        <span class='small1'>Ends on: , Uses: </span>
    </div>
</div>

<div class='platform doublebox box6'>
    <div class='platformtitle'>
        <h2>Create API Key</h2>
    </div>
</div>

";

?>