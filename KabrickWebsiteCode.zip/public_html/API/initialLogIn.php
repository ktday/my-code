<?php
header("Content-type: json");
include($_SERVER['DOCUMENT_ROOT'] . '/Misc/connect.php');
include($_SERVER['DOCUMENT_ROOT'] . '/Misc/funct.php');
if(isset($_POST['u']) && isset($_POST['p'])){
    $p = mysqli_real_escape_string($conn,$_POST['p']);
    $u = mysqli_real_escape_string($conn,$_POST['u']);

    $password = hashPW($p);

    $getInfo = $conn->prepare("SELECT * FROM `USERS` WHERE `USERNAME`=? AND `PASSWORD`=?");
    $getInfo->bind_param("ss", $u, $password);
    $getInfo->execute();
    $uI = $getInfo->get_result();

    if($uI->num_rows == 0){
        $info = ["response" => '0'];
    }else{
        $u = $uI->fetch_assoc();
        $info = [
            "response" => '1',
            "password" => $password,
            "userid" => $u['ID']
        ];
    }
}else{
    $info = ["response" => '0'];
}
echo json_encode($info);
?>