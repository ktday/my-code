<?php

header("Content-type: json");
include($_SERVER['DOCUMENT_ROOT'] . '/Misc/connect.php');
include($_SERVER['DOCUMENT_ROOT'] . '/Misc/funct.php');
include($_SERVER['DOCUMENT_ROOT'] . '/Misc/vars.php');

if(isset($_POST['uid']) && isset($_POST['pass']) && isset($_POST['changelog']) && isset($_POST['version'])){
    $p = mysqli_real_escape_string($conn,$_GET['pass']);
    $u = mysqli_real_escape_string($conn,$_GET['uid']);

    $getInfo = $conn->prepare("SELECT * FROM `USERS` WHERE `ID`=? AND `PASSWORD`=?");
    $getInfo->bind_param("is", $u, $p);
    $getInfo->execute();
    $uI = $getInfo->get_result();

    if($uI->num_rows == 0){
        echo(json_encode(["response" => '0']));
    }else{
        if($u["RANK"] == "OWNER"){
            include($_SERVER['DOCUMENT_ROOT'] . '/Admin/FUNCT.php');

            $changelog = mysqli_real_escape_string($conn,$_GET['changelog']);
            $v = mysqli_real_escape_string($conn,$_GET['version']);

            try {
                $r = appUpdate(json_decode($changelog), $v);
                echo(json_encode(["response" => $res . '']));
            } catch(Exception $e) {
                echo(json_encode(["response" => '0', 'error' => $e->getMessage()]));
            }
        }else{
            echo(json_encode(["response" => '0']));
        }
    }
}else{
    echo(json_encode(["response" => '0']));
}