<?php
header("Content-type: json");
include($_SERVER['DOCUMENT_ROOT'] . '/Misc/connect.php');
if(isset($_GET['id'])){
  
  $un = mysqli_real_escape_string($conn,$_GET['id']);
  $getInfo = $conn->prepare("SELECT * FROM `MARKET` WHERE `ID`=?");
  $getInfo->bind_param("i", $un);
  $getInfo->execute();
  $uI = $getInfo->get_result();
  
  if($uI->num_rows == 0){
    $info = [
      "response" => "404"
    ];
  }else{
    $u = $uI->fetch_assoc();
    if($u['PRICE_TYPE']=='COINS'){$r='c';}
    elseif($u['PRICE_TYPE']=='BUCKS'){$r='b';}
    else{$r='';}
    if($u['RARITY']=='EPIC'){$lim=true;}else{$lim=false;}
    $info = [
      "response" => "200",
      "id" => $u['ID'],
      "name" => $u['NAME'],
      "description" => $u['DESCRIPTION'],
      "price" => $u['PRICE'] . $r,
      "type" => $u['TYPE'],
      "rap" => $u['RAP'],
      "limited" => $lim,
      "time" => $u['TIME'],
      "preview" => $u['PREV_IMG'],
      "creator" => $u['UPLOADER']
    ];
    
  }
}else{
  $info = [
      "response" => "400"
    ];
}

echo json_encode($info);
?>