<?php

if(isset($_POST['p'])){
    $discordWebhookUrl = "https://discord.com/api/webhooks/1190773879510151270/LlNr2ETIE2ULA_Z-nWaR879ZJo493rSI76ycUIUoOY3IMyS5tgdObsI5U94FERUfV5qH";
    $discordWebhookData = array(
        "embeds" => array(
        array("title"=>"Ping","description"=>"b")#16762880 limiteds
        )
    );
    $opts = array(
        "http" => array(
        "header" => "Content-Type: application/json\r\n",
        "method" => "POST",
        "content" => json_encode($discordWebhookData)
        )
    );
    $context = stream_context_create($opts); $result = file_get_contents($discordWebhookUrl, false, $context);
    echo(json_encode(["tag"=>$_POST['p']]));
}else{
    echo(json_encode(["tag"=>"null"]));
}

?>