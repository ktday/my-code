<?php
header("Content-type: json");
include($_SERVER['DOCUMENT_ROOT'] . '/Misc/connect.php');
if(isset($_GET['u'])){
  
  if(!isset($_GET['token'])){exit();}
  else{$token = mysqli_real_escape_string($conn,$_GET['token']);
      if($token!="x2023aug4"){exit();}}
  
  $un = mysqli_real_escape_string($conn,$_GET['u']);
  $getInfo = $conn->prepare("SELECT * FROM `USERS` WHERE `USERNAME`=?");
  $getInfo->bind_param("s", $un);
  $getInfo->execute();
  $uI = $getInfo->get_result();
  
  if($uI->num_rows == 0){
    $info = [
      "response" => "404"
    ];
  }else{
    $u = $uI->fetch_assoc();
    $info = [
      "response" => "200",
      "id" => $u['ID'],
      "username" => $u['USERNAME'],
      "bucks" => $u['BUCKS'],
      "coins" => $u['COINS']
    ];
  }
}else{
  $info = [
      "response" => "400"
    ];
}

echo json_encode($info);
?>