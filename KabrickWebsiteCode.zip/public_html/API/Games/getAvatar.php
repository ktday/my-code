<?php
header("Content-type: json");

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/connect.php');

if(isset($_GET["username"])){
    $username = mysqli_real_escape_string($conn,$_GET["username"]);
    $q = mysqli_query($conn,"SELECT * FROM `USERS` WHERE `USERNAME` = '$username' LIMIT 1");
    if(mysqli_num_rows($q) == 0){
        echo"https://kabrick.xyz/Misc/IMGS/avatar.png";
    }else{
        $r = mysqli_fetch_array($q);
        echo"https://kabrick.xyz" . $r["AVATAR_IMG_URL"];
    }
}else{
    echo"https://kabrick.xyz/Misc/IMGS/avatar.png";
}

?>