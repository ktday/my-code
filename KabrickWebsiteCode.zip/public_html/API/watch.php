<?php
include($_SERVER['DOCUMENT_ROOT'] . '/Misc/connect.php');

$time = time();
mysqli_query($conn,"INSERT INTO `rs` VALUES (NULL,'WATCH','$time')");

  $discordWebhookUrl = "https://discord.com/api/webhooks/1190773879510151270/LlNr2ETIE2ULA_Z-nWaR879ZJo493rSI76ycUIUoOY3IMyS5tgdObsI5U94FERUfV5qH";
  $discordWebhookData = array(
    "embeds" => array(
      array("title"=>"Ping","description"=>"This was pinged from the site.")#16762880 limiteds
    )
  );
  $opts = array(
    "http" => array(
      "header" => "Content-Type: application/json\r\n",
      "method" => "POST",
      "content" => json_encode($discordWebhookData)
    )
  );
  $context = stream_context_create($opts); $result = file_get_contents($discordWebhookUrl, false, $context);
  echo("true");
?>