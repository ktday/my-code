<?php
header("Content-type: json");
include($_SERVER['DOCUMENT_ROOT'] . '/Misc/vars.php');
include("info/changelog.php");

$info = ["app_min_version" => 3,
        "app_active" => true,
        "site_version" => $siteVerRaw,
        "latest_app_version" => "Test 8",
        "changelog" => $changelog];

echo json_encode($info);

?>