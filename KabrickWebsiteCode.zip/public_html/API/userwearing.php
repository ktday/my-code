<?php
header("Content-type: json");
include($_SERVER['DOCUMENT_ROOT'] . '/Misc/connect.php');
if(isset($_GET['u'])){
  
  $un = mysqli_real_escape_string($conn,$_GET['u']);
  $getInfo = $conn->prepare("SELECT * FROM `USERS` WHERE `USERNAME`=?");
  $getInfo->bind_param("s", $un);
  $getInfo->execute();
  $uI = $getInfo->get_result();
  
  if($uI->num_rows == 0){
    $info = [
      "response" => "404"
    ];
  }else{
    $u = $uI->fetch_assoc();
    
    $getInfo = $conn->prepare("SELECT * FROM `AVATAR` WHERE `UID`=?");
    $getInfo->bind_param("i", $u['ID']);
    $getInfo->execute();
    $aI = $getInfo->get_result();
    $a = $aI->fetch_assoc();
    
    $info = [
      "response" => "200",
      "hat" => $a['HAT'],
      "hat2" => $a['HAT2'],
      "hat3" => $a['HAT3'],
      "hair" => $a['HAIR'],
      "face" => $a['FACE'],
      "gear" => $a['GEAR'],
      "shoulder" => $a['SHOULDER'],
      "mask" => $a['MASK'],
      "shirt" => $a['SHIRT'],
      "pants" => $a['PANTS'],
      "back" => $a['BACK'],
      "body" => $a['BODY']
    ];
    
  }
}else{
  $info = [
      "response" => "400"
    ];
}

echo json_encode($info);
?>