<?php
header("Content-type: json");
include($_SERVER['DOCUMENT_ROOT'] . '/Misc/connect.php');
if(isset($_POST['id']) && isset($_POST['pass'])){
  
  $id = mysqli_real_escape_string($conn,$_POST['id']);
  $pass = mysqli_real_escape_string($conn,$_POST['pass']);

  $getInfo = $conn->prepare("SELECT * FROM `MESSAGES` WHERE `RECIEVER` = ? ORDER BY `ID` DESC LIMIT 7");
  $getInfo->bind_param("i", $id);
  $getInfo->execute();
  $uI = $getInfo->get_result();

  if($uI->num_rows == 0){
    $info = [
      "response" => "0"
    ];
  }else{
    $users = [];
    while(($u = mysqli_fetch_array($uI))){
        $s = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$u[SENDER]'"));
        if($u['IMPORTANT'] == '1'){$i = true;}else{$i = false;}
        if($u['VIEWED'] == 'YES'){$b = true;}else{$b = false;}
        $in = [
            "id" => intval($u['ID']),
            "sender" => $s['USERNAME'],
            "title" => $u['TITLE'],
            "body" => $u['MESSAGE'],
            "sent" => intval($u['TIME']),
            "important" => $i,
            "read" => $b
        ];
        array_push($users, $in);
    }
    
    $info = [
        "response" => "1",
        "data" => $users
    ];
  }
}else{
  $info = [
      "response" => "400"
    ];
}

echo json_encode($info);
?>