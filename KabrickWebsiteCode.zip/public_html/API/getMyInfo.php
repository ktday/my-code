<?php
header("Content-type: json");
include($_SERVER['DOCUMENT_ROOT'] . '/Misc/connect.php');
include($_SERVER['DOCUMENT_ROOT'] . '/Misc/funct.php');
include($_SERVER['DOCUMENT_ROOT'] . '/Misc/vars.php');
if(isset($_GET['u']) && isset($_GET['p'])){
    $p = mysqli_real_escape_string($conn,$_GET['p']);
    $u = mysqli_real_escape_string($conn,$_GET['u']);

    $getInfo = $conn->prepare("SELECT * FROM `USERS` WHERE `ID`=? AND `PASSWORD`=?");
    $getInfo->bind_param("is", $u, $p);
    $getInfo->execute();
    $uI = $getInfo->get_result();

    if($uI->num_rows == 0){
        $info = ["response" => '0'];
    }else{
        $time = time() + 18000;
        $stmt = $conn->prepare("UPDATE `USERS` SET `LAST_ONLINE` = ?, `LAST_DEVICE`='1' WHERE `ID`=?");
        $stmt->bind_param("ii", $time, $u);
        $stmt->execute();

        $u = $uI->fetch_assoc();
        $info = [
            "response" => '1',
            "username" => $u['USERNAME'],
            "coins" => $u["COINS"],
            "bucks" => $u["BUCKS"],
            "avatar" => $meta_url . $u["AVATAR_IMG_URL"],
            "vip" => $u["VIP"],
            "ad" => $u["RANK"],
            "bio" => $u["BIO"]
        ];
    }
}else{
    $info = ["response" => "0"];
}
echo json_encode($info);
?>