<?php

$changelog = [
    "Test 7" => [
        "Added Changelog",
        "Added security to messages",
        "Added Inventory page",
        "Added button to open kabrick in browser"
    ],
    "Test 8" => [
        "Added button icons"
    ]
];

?>