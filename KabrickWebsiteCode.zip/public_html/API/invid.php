<?php
include($_SERVER['DOCUMENT_ROOT'] . '/Misc/connect.php');
header("Content-type: json");

if(isset($_GET['id']) && is_numeric($_GET['id'])){$id = mysqli_real_escape_string($conn,$_GET['id']);}else{ echo( json_encode(["response" => "400"]) ); exit(); }

$invid = mysqli_query($conn,"SELECT * FROM `INV` WHERE `ID` = '$id'");

if(mysqli_num_rows($invid) == 0){ echo( json_encode(["response" => "404"]) ); exit(); }

$i = mysqli_fetch_array($invid);
$json = ["response" => "200",
         "id" => "$id",
         "item" => "$i[ITEM]",
         "owner" => "$i[USER]",
         "serial" => "$i[SERIAL]"
        ];
$encode = json_encode($json);
echo $encode;
?>