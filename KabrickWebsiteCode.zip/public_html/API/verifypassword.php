<?php
header("Content-type: json");
include($_SERVER['DOCUMENT_ROOT'] . '/Misc/connect.php');
if(isset($_GET['u'])){
  
  $un = mysqli_real_escape_string($conn,$_GET['u']);
  $pw = mysqli_real_escape_string($conn,$_GET['p']);
  $getInfo = $conn->prepare("SELECT * FROM `USERS` WHERE `USERNAME`=?");
  $getInfo->bind_param("s", $un);
  $getInfo->execute();
  $uI = $getInfo->get_result();
  
  if($uI->num_rows == 0){
    $info = [
      "response" => false
    ];
  }else{
    $u = $uI->fetch_assoc();
    $passHash = hash('whirlpool',hash('gost',$pw));
    if($passHash == $u['PASSWORD']){
      $info = ["response"=>true];
    }else{
      $info = ["response"=>false];
    }
    
  }
}else{
  $info = ["response" => false];
}

echo json_encode($info);
?>