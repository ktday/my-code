<?php
include($_SERVER['DOCUMENT_ROOT'] . '/Misc/connect.php');
header("Content-type: json");
$count = $conn->query("SELECT * FROM `USERS`")->num_rows;
$json = ["users" => "$count"];
$encode = json_encode($json);
echo $encode;
?>