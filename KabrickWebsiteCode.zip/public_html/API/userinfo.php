<?php
header("Content-type: json");
include($_SERVER['DOCUMENT_ROOT'] . '/Misc/connect.php');
if(isset($_GET['u'])){
  
  $un = mysqli_real_escape_string($conn,$_GET['u']);
  $getInfo = $conn->prepare("SELECT * FROM `USERS` WHERE `USERNAME`=?");
  $getInfo->bind_param("s", $un);
  $getInfo->execute();
  $uI = $getInfo->get_result();
  
  if($uI->num_rows == 0){
    $info = [
      "response" => "404"
    ];
  }else{
    $u = $uI->fetch_assoc();
    $info = [
      "response" => "200",
      "id" => $u['ID'],
      "username" => $u['USERNAME'],
      "bio" => $u['BIO'],
      "avatar" => $u['AVATAR_IMG_URL'],
      "forum_posts" => $u['FORUM_POSTS'],
      "vip" => $u['VIP'],
      "join_date" => $u['JOINED'],
      "last_online" => $u['LAST_ONLINE']
    ];
    
  }
}else{
  $info = [
      "response" => "400"
    ];
}

echo json_encode($info);
?>