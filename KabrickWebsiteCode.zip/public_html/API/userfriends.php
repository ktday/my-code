<?php
header("Content-type: json");
include($_SERVER['DOCUMENT_ROOT'] . '/Misc/connect.php');
if(isset($_GET['u'])){
  
  $un = mysqli_real_escape_string($conn,$_GET['u']);
  $getInfo = $conn->prepare("SELECT * FROM `FRIENDS` WHERE `U1`=? OR `U2`=?");
  $getInfo->bind_param("ii", $un, $un);
  $getInfo->execute();
  $uI = $getInfo->get_result();

  if($uI->num_rows == 0){
    $info = [
      "response" => "0"
    ];
  }else{
    $users = [];
    while(($f = mysqli_fetch_array($uI))){
        if($f['U1'] == $un){$ouid = $f['U2'];}else{$ouid = $f['U1'];}
        $u = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$ouid'"));
        $in = [
            "id" => intval($u['ID']),
            "username" => $u['USERNAME'],
            "bio" => $u['BIO'],
            "avatar" => "https://kabrick.xyz" . $u['AVATAR_IMG_URL'],
            "forum_posts" => intval($u['FORUM_POSTS']),
            "vip" => $u['VIP'],
            "admin" => $u['RANK'],
            "join_date" => intval($u['JOINED']),
            "last_online" => intval($u['LAST_ONLINE'])
        ];
        array_push($users, $in);
    }
    
    $info = [
        "response" => "1",
        "data" => $users
    ];
  }
}else{
  $info = [
      "response" => "400"
    ];
}

echo json_encode($info);
?>