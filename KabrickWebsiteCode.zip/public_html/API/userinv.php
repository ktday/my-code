<?php
header("Content-type: json");
include($_SERVER['DOCUMENT_ROOT'] . '/Misc/connect.php');
if(isset($_GET['u'])){
  
  $un = mysqli_real_escape_string($conn,$_GET['u']);
  $getInfo = $conn->prepare("SELECT * FROM `INV` WHERE `USER`=? ORDER BY `ID` DESC");
  $getInfo->bind_param("i", $un);
  $getInfo->execute();
  $uI = $getInfo->get_result();

  if($uI->num_rows == 0){
    $info = [
      "response" => "0"
    ];
  }else{
    $users = [];
    while(($inv = mysqli_fetch_array($uI))){
        
        $i = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$inv[ITEM]'"));
        $in = [
            "id" => ($i['ID']),
            "serial" => ($inv["SERIAL"]),
            "name" => $i["NAME"],
            "desc" => $i["DESCRIPTION"],
            "rarity" => $i["RARITY"],
            "av_img" => "https://kabrick.xyz" . $i["AV_IMG"]
        ];
        array_push($users, $in);
    }
    
    $info = [
        "response" => "1",
        "data" => $users
    ];
  }
}else{
  $info = [
      "response" => "400"
    ];
}

echo json_encode($info);
?>