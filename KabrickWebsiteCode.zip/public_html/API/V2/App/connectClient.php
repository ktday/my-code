<?php

header("Content-type: json");
include("../Handshake/create-handshake.php");

/* Login */
if(
    isset($_POST['key']) &&
    isset($_POST['name']) &&
    isset($_POST['pass'])
    ){
        $username = mysqli_real_escape_string($conn,$_POST['name']);
        $password = mysqli_real_escape_string($conn,$_POST['pass']);
        $key = mysqli_real_escape_string($conn,$_POST['key']);

        $pwHashed = hash('whirlpool',hash('gost',$password));

        $q = $conn->prepare("SELECT * FROM USERS WHERE `USERNAME` = ? AND `PASSWORD` = ?");
        $q->bind_param("ss", $username, $pwHashed);
        $q->execute();
        $res = $q->get_result();

        if($res->num_rows == 1){
            $user = $res->fetch_assoc();
            // Create handshake
            $handshake = createHandshake($key);

            if($handshake[0] == false){
                echo(json_encode(["response"=>"handshakeError", "message"=>$handshakeErrors[$handshake[1]]]));exit();
            }else{
                $hasScope = hasScope($handshake[1], "APP");
                if($hasScope){
                    addUse($key);

                    // Done :)
                    // Update user device info
                    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
                    $charactersLength = strlen($characters);
                    $randomString = '';
                    for ($i = 0; $i < 64; $i++) {
                        $randomString .= $characters[random_int(0, $charactersLength - 1)];
                    }

                    if(isset($_POST['info_sdk'])){$sdk = intval(mysqli_real_escape_string($conn,$_POST['info_sdk']));}else{$sdk = 1001;}
                    if(isset($_POST['info_dvc'])){$dvc = mysqli_real_escape_string($conn,$_POST['info_dvc']);}else{$dvc = "None";}
                    if(isset($_POST['info_pdc'])){$pdc = mysqli_real_escape_string($conn,$_POST['info_pdc']);}else{$pdc = "None";}
                    if(isset($_POST['info_mdl'])){$mdl = mysqli_real_escape_string($conn,$_POST['info_mdl']);}else{$mdl = "None";}
                    if(isset($_POST['info_man'])){$man = mysqli_real_escape_string($conn,$_POST['info_man']);}else{$man = "None";}

                    #$q = mysqli_query($conn,"SELECT * FROM `APP_HANDSHAKE_IDS` WHERE `USER` = '$user[0]' ORDER BY AI DESC LIMIT 1");
                    #if(mysqli_num_rows($q) >= 1){
                        mysqli_query($conn,"
                        INSERT INTO `APP_HANDSHAKE_IDS`
                        VALUES(NULL, '$randomString', '$user[ID]', '$key', 
                        '$sdk', '$dvc', '$mdl', '$pdc', '$man')");
                    echo(json_encode(["response"=>"success", "userid"=>intval($user["ID"])]));
                    #}else{

                    #}
                }else{
                    echo(json_encode(["response"=>"handshakeError", "message"=>$invalidScopeError]));exit();
                }
            }
        }else{
            echo(json_encode(["response"=>"fail", "message"=>"Incorrect username or password"]));
        }
    }else{
        echo(json_encode(["response"=>"fail", "message"=>"Invalid paramaters set"]));
    }

?>