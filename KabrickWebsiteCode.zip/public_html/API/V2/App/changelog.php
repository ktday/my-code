<?php

$changelog = [
    "Test 7" => [
        "Added Changelog",
        "Added security to messages",
        "Added Inventory page",
        "Added button to open kabrick in browser"
    ],
    "Test 8" => [
        "Added button icons"
    ],
    "ALT 0.01" => [
        "New Layout",
        "API V2",
        "API key system",
        "Secure App"
    ]
];

?>