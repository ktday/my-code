<?php
header("Content-type: json");
include($_SERVER['DOCUMENT_ROOT'] . '/Misc/vars.php');
include("changelog.php");

$info = ["app_min_version" => 3,
        "app_format" => "ALT",
        "app_active" => true,
        "site_version" => $siteVerRaw,
        "latest_app_version" => "0.01",
        "changelog" => $changelog];

echo json_encode($info);

?>