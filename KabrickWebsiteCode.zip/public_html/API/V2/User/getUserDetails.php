<?php

header("Content-type: json");
include("../Handshake/create-handshake.php");

if(isset($_GET['key']) && isset($_GET['userid'])){
    $key = mysqli_real_escape_string($conn,$_GET["key"]);
    $handshake = createHandshake($key);

    if($handshake[0] == false){
        echo(json_encode(["response"=>"handshakeError", "message"=>$handshakeErrors[$handshake[1]]]));exit();
    }else{
        $hasScope = hasScope($handshake[1], "USR");
        if($hasScope){
            addUse($key);

            $id = mysqli_real_escape_string($conn,$_GET["userid"]);

            $q = $conn->prepare("SELECT * FROM USERS WHERE `ID` = ?");
            $q->bind_param("i", $id);
            $q->execute();
            $res = $q->get_result();
            $item = $res->fetch_assoc();

            $array = [
                "id" => $item["ID"],
                "username" => $item["USERNAME"],
                "bio" => $item["BIO"],
                "avatar_img_url" => $item["AVATAR_IMG_URL"],

                "vip" => $item["VIP"],
                "rank" => $item["RANK"],

                "joined" => intval($item["JOINED"]),
                "last_online" => intval($item["LAST_ONLINE"]),
                "forum_posts" => intval($item["FORUM_POSTS"])
            ];

            echo(json_encode(["response"=>"success", "data"=>$array]));
        }else{
            echo(json_encode(["response"=>"handshakeError", "message"=>$invalidScopeError]));exit();
        }
    }
}elseif(isset($_GET['key']) && isset($_GET['username'])){
    $key = mysqli_real_escape_string($conn,$_GET["key"]);
    $handshake = createHandshake($key);

    if($handshake[0] == false){
        echo(json_encode(["response"=>"handshakeError", "message"=>$handshakeErrors[$handshake[1]]]));exit();
    }else{
        $hasScope = hasScope($handshake[1], "USR");
        if($hasScope){
            addUse($key);

            $id = mysqli_real_escape_string($conn,$_GET["username"]);

            $q = $conn->prepare("SELECT * FROM USERS WHERE `USERNAME` = ?");
            $q->bind_param("s", $id);
            $q->execute();
            $res = $q->get_result();
            $item = $res->fetch_assoc();

            $array = [
                "id" => $item["ID"],
                "username" => $item["USERNAME"],
                "bio" => $item["BIO"],
                "avatar_img_url" => $item["AVATAR_IMG_URL"],

                "vip" => $item["VIP"],
                "rank" => $item["RANK"],

                "joined" => intval($item["JOINED"]),
                "last_online" => intval($item["LAST_ONLINE"]),
                "forum_posts" => intval($item["FORUM_POSTS"])
            ];

            echo(json_encode(["response"=>"success", "data"=>$array]));
        }else{
            echo(json_encode(["response"=>"handshakeError", "message"=>$invalidScopeError]));exit();
        }
    }
}else{
    echo(json_encode(["response"=>"fail"]));exit();
}

?>