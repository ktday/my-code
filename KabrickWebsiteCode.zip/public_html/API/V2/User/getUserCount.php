<?php

include("../Handshake/create-handshake.php");

if(isset($_GET['key'])){
    $key = mysqli_real_escape_string($conn,$_GET["key"]);
    $handshake = createHandshake($key);

    if($handshake[0] == false){
        echo(json_encode(["response"=>"handshakeError", "message"=>$handshakeErrors[$handshake[1]]]));exit();
    }else{
        $hasScope = hasScope($handshake[1], "UCT");
        if($hasScope){
            addUse($key);

            $ucq = $conn->prepare("SELECT COUNT(*) FROM USERS WHERE `STATUS` != 'DISABLED'");
            $ucq->execute();
            $res = $ucq->get_result();
            $count = $res->fetch_assoc()["COUNT(*)"];
            echo(json_encode(["response"=>"success", "count"=>$count]));
        }else{
            echo(json_encode(["response"=>"handshakeError", "message"=>$invalidScopeError]));exit();
        }
    }
}else{
    echo(json_encode(["response"=>"fail"]));exit();
}

?>