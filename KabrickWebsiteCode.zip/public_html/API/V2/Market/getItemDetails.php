<?php

header("Content-type: json");
include("../Handshake/create-handshake.php");

if(isset($_GET['key']) && isset($_GET['itemid'])){
    $key = mysqli_real_escape_string($conn,$_GET["key"]);
    $handshake = createHandshake($key);

    if($handshake[0] == false){
        echo(json_encode(["response"=>"handshakeError", "message"=>$handshakeErrors[$handshake[1]]]));exit();
    }else{
        $hasScope = hasScope($handshake[1], "ITM");
        if($hasScope){
            addUse($key);

            $id = mysqli_real_escape_string($conn,$_GET["itemid"]);

            $q = $conn->prepare("SELECT * FROM MARKET WHERE `ID` = ? LIMIT 1");
            $q->bind_param("i", $id);
            $q->execute();
            $res = $q->get_result();
            $item = $res->fetch_assoc();

            $array = [
                "id" => $item["ID"],
                "name" => $item["NAME"],
                "description" => $item["DESCRIPTION"],
                "img_url" => $item["PREV_IMG"],
                "rarity" => $item["RARITY"],
                "type" => $item["TYPE"],

                "price" => $item["PRICE"],
                "pricetype" => $item["PRICE_TYPE"],
                
                "stock" => $item["STOCK"],
                "stock_remaining" => $item["STOCK_REMAINING"],
                "onsale_time" => $item["ONSALE_TIME"],

                "creator" => intval($item["UPLOADER"]),
                "created" => intval($item["TIME"]),
                "edited" => intval($item["UPDATE_TIME"])
            ];

            echo(json_encode(["response"=>"success", "data"=>$array]));
        }else{
            echo(json_encode(["response"=>"handshakeError", "message"=>$invalidScopeError]));exit();
        }
    }
}else{
    echo(json_encode(["response"=>"fail"]));exit();
}

?>