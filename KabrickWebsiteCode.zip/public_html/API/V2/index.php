<?php

echo(json_encode(

    [

        "status" => "enabled"

    ]

));

?>