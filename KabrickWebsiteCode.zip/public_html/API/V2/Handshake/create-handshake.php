<?php

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/connect.php');

/*

Scopes:

1    = UCT Usercount
2    = USR Users
4    = ITM Items
8    = ISL Item Sales -- half byte
16   = ICM Item Comments
32   = UFR User Friends
64   = UIN User Inventory
128  = UCL User Clans -- byte
256  = CLA Clans
512  = FRM Forums
1024 = APP Application
2048 = ADM Administration -- 1.5 byte (12)

*/

function decodeScope($scope){
    $scopes = [];
    $string = strval(decbin($scope));
    $string = str_pad($string, 12, 0, STR_PAD_LEFT);
    foreach(str_split(strrev($string)) as $char){
        if ($char == "1"){
            array_push($scopes,true);
        }else{
            array_push($scopes,false);
        }
    }
    return $scopes;
}

function hasScope($scope, $target){
    $scopes = decodeScope($scope);

    $scopePos = [
        "UCT" => 0,
        "USR" => 1,
        "ITM" => 2,
        "ISL" => 3,
        "ICM" => 4,
        "UFR" => 5,
        "UIN" => 6,
        "UCL" => 7,
        "CLA" => 8,
        "FRM" => 9,
        "APP" => 10,
        "ADM" => 11
    ];

    if(array_key_exists($target, $scopePos)){
        if($scopes[$scopePos[$target]] == true){
            return true;
        }
    }
    return false;
}

function createHandshake($token){
    global $conn;
    $q = mysqli_query($conn,"SELECT * FROM `APIACCESS_KEYS` WHERE `KEY` = '$token' ORDER BY `ID` DESC LIMIT 1");
    if(mysqli_num_rows($q) == 1){
        $key = mysqli_fetch_array($q);
        $time = time();
        if($key["TIME"] > $time + 7776000){
            return [false, 1]; // outta time
        }else{
            if($key["USES"] >= $key["MAXUSES"]){
                return [false, 2]; // max uses reached
            }else{
                if($key["ENABLED"] == 1){
                    return [true, $key["SCOPES"]];
                }else{
                    return [false, 3]; // key disabled
                }
            }
        }
    }else{
        return [false, 0];
    }
}

function addUse($token){
    global $conn;
    mysqli_query($conn, "UPDATE `APIACCESS_KEYS` SET `USES` = `USES` + 1 WHERE `KEY` = '$token'");
}

$handshakeErrors = [
    0 => "Key not found",
    1 => "Key has expired",
    2 => "Key has reached its max uses",
    3 => "Key is disabled"
];
$invalidScopeError = "Key does not have the correct scope";

$androidVersion = "Alpha Layout Test 1";
$minApiVersion = 1;
$recentApiVersion = 1;

?>