<?php

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');

echo"<title>Dashboard | $meta_name</title>";

if(!isset($_COOKIE['KABRICK_U']) || !isset($_COOKIE['KABRICK_P'])){
    echo"<script>window.location='/'</script>";exit();
}
/*switch($account['RANK']){
        case OWNER:
        $rank = 'Owner';
        break;
        case MANAGER:
        $rank = 'Manager';
        break;
        case EXECUTIVE:
        $rank = 'Executive';
        break;
        case ADMIN:
        $rank = 'Administrator';
        break;
        case MODERATOR:
        $rank = 'Moderator';
        break;
        case ASSET_UPLOADER:
        $rank = 'Asset Dev';
        break;
        case FORUM_MOD:
        $rank = 'Forum Moderator';
        break;
        case MEMBER:
        $rank = 'Member';
        break;
        default:
           $rank = '???'; 
           break;*/
/*if($account['RANK']=='OWNER'){
    $rank = 'Owner';
}elseif($account['RANK']=='MANAGER'){
    $rank = 'Manager';
}elseif($account['RANK']=='EXECUTIVE'){
    $rank = 'Executive';
}elseif($account['RANK']=='ADMIN'){
    $rank = 'Administrator';
}elseif($account['RANK']=='MODERATOR'){
    $rank = 'Moderator';
}elseif($account['RANK']=='ASSET_UPLOADER'){
    $rank = 'Artist';
}elseif($account['RANK']=='FORUMS_MOD'){
    $rank = 'Forum Moderator';
}elseif($account['RANK']=='MEMBER'){
    $rank = 'Member';
}else{
    $rank = '???';
}*/

$rnk = $rank['ALIAS'];

if($account['VIP']=='ULTRA'){
    $vip = 'Ultra VIP';
}elseif($account['VIP']=='MEGA'){
    $vip = 'Mega VIP';
}elseif($account['VIP']=='VIP'){
    $vip = 'VIP';
}elseif($account['VIP']=='NONE'){
    $vip = 'None';
}else{
    $vip = '???';
}

$randomnumber = rand(1,1000);
if(isset($_GET['e'])){$randomnumber=369;}
if($randomnumber == 369){
  $title = 'Read Messages';
  echo"<style>body{cursor:wait;}</style>";
}else{
  $title = 'Unread Messages';
}
echo"<script>console.log($randomnumber)</script>";

echo"

<div class='doublebox box1'>
    
    <p><u><b>$account[1]</b></u></p>
    
    <img src='$account[AVATAR_IMG_URL]' class='avatar'>
    
    <br><br>
    
    <hr>
    
    <h3>Stats:</h3>
    
    <p>ID: $account[0]</p>
    
    <p>Admin Level: $rnk</p>
    
    <p>Membership: $vip</p>
    
    <hr>
    
    <p><a href='/Profile/$account[1]' class='btn-blue nd hover button'>My Profile</a></p>
    
    <p><a href='/User/settings.php' class='btn-blue nd hover button'>Settings</a></p>
    
    <p><a href='/User/Avatar/' class='btn-blue nd hover button'>Edit Avatar</a></p>
    
</div>

<div class='doublebox box2'>
    
    <h2>$title</h2>
    
    ";
    
    $query = $conn->prepare("SELECT MESSAGES.*, USERS.USERNAME FROM MESSAGES
                            JOIN USERS ON USERS.ID = MESSAGES.SENDER
                            WHERE MESSAGES.RECIEVER = ? AND MESSAGES.VIEWED = 'NO' ORDER BY MESSAGES.ID DESC LIMIT 3");
    $query->bind_param("i", $account[0]);
    $query->execute();
    $s = $query->get_result();
    
    if(mysqli_num_rows($s) < 1){
        echo"<p>No Recent Messages!</p>";
    }else{
    
    while(($m = mysqli_fetch_array($s))){
    
    if($m['IMPORTANT'] == 1){$ttl = "<a href='/Msg/$m[ID]' class='txtcol-red'><i class='fas fa-exclamation-triangle'></i> " . lgt($m['TITLE']) . "</a>";}
    else{$ttl = "<a href='/Msg/$m[ID]'>" . lgt($m['TITLE']) . "</a>";}
    
    echo"
    
    $ttl "; if($m['VIEWED']=='YES'){echo"<i class='fa fa-eye'></i>";} echo"<br>
    By <a href='/Profile/$m[USERNAME]'>$m[USERNAME]</a>
    
    <br><br>";
	
    }}
	
	echo"
	
	<a href='/User/messages.php' class='btn-blue nd hover button'>All Messages</a><br>
    
    <h2>Friend Requests</h2>
    
    ";
    
    $query = $conn->prepare("SELECT USERS.USERNAME FROM FRIEND_REQ JOIN USERS ON USERS.ID = FRIEND_REQ.SENDER WHERE FRIEND_REQ.RECIEVER = ? ORDER BY FRIEND_REQ.ID DESC LIMIT 3");
    $query->bind_param("i", $account[0]);
    $query->execute();
    $s = $query->get_result();
    
    if(mysqli_num_rows($s) < 1){
        echo"<p>No Friend Requests!</p>";
    }else{
    
    while(($u = mysqli_fetch_array($s))){
    
    echo"
    
    <a href='/Profile/$u[0]'>$u[0]</a>
    
    <br><br>";
	
    }}
	
	echo"
	
	<a href='/Friends/' class='btn-blue nd hover button'>Manage Friend Requests</a><br>
    
</div><br>
</div>

";

?>