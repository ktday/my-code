<?php

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/navbar.php');
include($_SERVER['DOCUMENT_ROOT'] . '/bbcode.php');

if(isset($_COOKIE['KABRICK_U']) || isset($_COOKIE['KABRICK_P'])){}else{
    echo"<script>window.location='/'</script>";
}
//393b3d
//stats loading

if($account['RANK']=='OWNER'){
    $rank = "Owner!";
}elseif($account['RANK']=='KABRICK'){
    $rank = "Kabrick.tk Bot!";
}elseif($account['RANK']=='ADMIN'){
    $rank = "Administrator!";
}elseif($account['RANK']=='MANAGER'){
    $rank = "Manager!";
}elseif($account['RANK']=='EXECUTIVE'){
    $rank = "Executive!";
}elseif($account['RANK']=='MODERATOR'){
    $rank = "Moderator!";
}elseif($account['RANK']=='FORUMS_MOD'){
    $rank = "Forum Moderator!";
}elseif($account['RANK']=='ASSET_UPLOADER'){
    $rank = "A person who is able to upload assets (Asset Developer)!";
}elseif($account['RANK']=='ASSET_MOD'){
    $rank = "Asset Moderator!";
}else{
    $rank = "Member!";
}

if($account['VIP']=='VIP'){
    $membership = "VIP!";
}elseif($account['VIP']=='MEGA'){
    $membership = "Mega VIP!";
}elseif($account['VIP']=='ULTRA'){
    $membership = "Ultra VIP!";
}else{
    $membership = "None!";
}

if($account['STATUS']=='UNVERIFIED'){
    $status = "Unverified!";
}else{
    $status = "Verified!";
}

if($account['GENDER']=='MALE'){
    $gender="<i style='color:$col8;' class='fa fa-male'></i> Male";
}elseif($account['GENDER']=='EON'){
    $gender="<i style='color:$col8;' class='fa fa-question'></i> Eon";
}elseif($account['GENDER']=='OTHER'){
    $gender="<i style='color:$col8;' class='fa fa-question'></i> Other";
}else{
    $gender="<i style='color:$col8;' class='fa fa-female'></i> Female";
}

echo"
<style>
div.db{border:1px solid;position:fixed;width:550px;border-radius:10px;border-color:$col8;}
div.w150{width:10.5%;}
div.w725{width:49.5%;}
div.w875{width:900px;}
div.p100{left:19%;}
div.p150{left:31%;}
</style>
<script>function eon() {window.location='/mr-eon.html'}</script>
<script>function avatar() {window.alert('You look bad');window.alert('jk');}</script>
<title>Kabrick.tk - Home</title>
<center>
<h1><i style='color:$col8;' class='fa fa-user'></i> <u><b>Welcome To Kabrick.tk, $account[USERNAME]</b></u></h1>
<div class='box middle' style='background-color:$col12;border-color:$col13;'>
    <div style='height:280px'>
    <div class='db w150 p100'>
        <br><u title='Your Username!'>$account[1]</u><br>
        <img onclick='avatar()' title='What you look like at the moment on Kabrick.tk!' src='$account[AVATAR_IMG_URL]'><br><br>
        <a href='/User/settings.php'><i style='color:$col8;' class='fa fa-cog'></i> Settings</a><br>
        <a href='/User/Avatar/'><i style='color:$col8;' class='fa fa-paint-brush'></i> Edit Avatar</a><br><br>
    </div>
    <div class='db w725 p150'>
        <h2>My Stats:</h2>
        <p title='Your user id is the order in which you joined Kabrick.tk eg ID 100 would be the 100th person to join Kabrick.tk!'><i style='color:$col8;' onclick='eon()' class='fa fa-user'></i> User Id: $account[ID]</p>
        <p title='A breif description of yourself, shown on your user profile. This can be changed in the settings!'><i style='color:$col8;' class='fa fa-comment'></i> Bio: ".bbcode_to_html(nl2br(htmlentities($account['BIO'])))."</p>
        <p title='Your rank in the community eg Admins have a higher rank than Members!'><i style='color:$col8;' class='fa fa-user-secret'></i> Authority: $rank</p>
        <p title='Your VIP Status. See more in the settings!'><i style='color:$col8;' class='fa fa-star'></i> Membership: $membership</p>
        <p title='Verified or Unverified.'><i style='color:$col8;' class='fa fa-user'></i> Status: $status</p>
        <p>Gender: $gender</p>
    </div></div>
    <br>
</div>
</center>
</body>
</html>";

?>