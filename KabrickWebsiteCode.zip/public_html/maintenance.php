<head>
<title>Maintenance | Kabrick.tk</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Montserrat&family=Tinos&display=swap" rel="stylesheet">
</head>
<h1 class="big">Kabrick.tk is under maintenance!</h1>
<h2>Check back later.</h2>
<style>
  html {
    background-color:#eee;
    padding-top:10%;
    margin:auto;
    text-align:center;
    font-family: 'Montserrat', sans-serif;
  }
  
  .big {
   font-size:50px;
  } 
</style>