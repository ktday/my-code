<?php

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');
include_once('../Admin/FUNCT.php');

echo"<title>Upload an item | $meta_name</title>";

if(!isset($_COOKIE['KABRICK_U']) || !isset($_COOKIE['KABRICK_P'])){
    exit();
}

if(isset($_POST['upl_name'])){
    $name = mysqli_real_escape_string($conn,$_POST['upl_name']);
    $desc = mysqli_real_escape_string($conn,$_POST['upl_desc']);
    $price = mysqli_real_escape_string($conn,$_POST['upl_price']);
    $pt = mysqli_real_escape_string($conn,$_POST['upl_pt']);
    $type = mysqli_real_escape_string($conn,$_POST['upl_type']);
    $img = $_FILES['upl_img'];
  
  if(!preg_match_all("/^[^<>]*$/",$name)){echo"<script>window.alert('Invalid characters in name');window.location='/Market/create.php'</script>";exit();}
    
    if($pt=="Price Type"){echo"<script>window.alert('PT')</script>";echo"<script>window.location='/Market/create.php'</script>";exit();}if($type=="Item Type"){echo"<script>window.alert('IT')</script>";echo"<script>window.location='/Market/create.php'</script>";exit();}
    
  	if($type!='SHIRT' && $type!='PANTS'){echo"<script>window.alert('Only SHIRT and PANTS are allowed');window.location='/Market/create.php'</script>";exit();}
  
    if(isset($img)){
      if ($img["error"] > 0){
        echo "<script>window.alert('Error: " . $img["error"] . "')</script>";echo"<script>window.location='/Market/create.php'</script>";exit();
      }else{
        $info = getimagesize($img['tmp_name']);
        if($info === FALSE){echo"<script>window.alert('info false');window.location='/Market/create.php'</script>";exit();}
        if (($info[2] !== IMAGETYPE_PNG)) {
          echo"<script>window.alert('Not A Valid Image file!')</script>";
          echo"<script>window.location='/Market/create.php'</script>";exit();
        }
        $ammOfItemQ = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE 1");
        $ammOfItem = mysqli_num_rows($ammOfItemQ) + 1;
        $img_dir_pre = "/home/lord7302/domains/$meta_blank_url/public_html";
        $img_dir_suf = "/Misc/IMGS/SHOP/U/$ammOfItem.png";
        $image_dir = $img_dir_pre.$img_dir_suf;
        move_uploaded_file($img['tmp_name'], $image_dir);
        $image_av = $img_dir_suf;

        
          $palette_img = imagecreatefrompng($img_dir_pre."/Misc/IMGS/avatar.png");
          $av_img = imagecreatefrompng($img_dir_pre.$img_dir_suf);
          imagesavealpha($palette_img, true);
          imagecopy($palette_img,$av_img,0,0,0,0,121,181);

        imagepng($palette_img,$img_dir_pre."/Misc/IMGS/SHOP/P/".$ammOfItem.".png");
        $image_pre = "/Misc/IMGS/SHOP/P/".$ammOfItem.".png";

        $time = time();

        mysqli_query($conn,"INSERT INTO `MARKET` VALUES(NULL,'$name','$desc','$price','$pt','$type','0','0','0','DEF','0','$account[0]','$time','$time','$image_pre','$image_av','UAP')");
        mysqli_query($conn,"INSERT INTO `INV` VALUES(NULL,'$ammOfItem','$account[0]','$pt','1')");
        logAction(3,0,"[$ammOfItem] $name (USER UPLOADED)");
        echo"<script>window.alert('Item Uploaded! Awaiting approval');window.location='/Market/item.php?id=$ammOfItem'</script>";exit();
      }
    }else{echo"<script>window.alert('No images selected');window.location='/Market/create.php'</script>";exit();}
}

#echo"Coming soon.";exit();

echo"

<div class='platform'>
<div class='platformtitle'><p class='pub'>Upload Item</p></div><br>

<form method='post' enctype='multipart/form-data'>
    <label for='upl_name'>Item name:</label> <input class='form form1l' placeholder='Item Name' name='upl_name' minlength='4' maxlength='25' required><br><br>
    
    <textarea class='form form1l' name='upl_desc' placeholder='Description' minlength='5' maxlength='100' required></textarea><br><br>
    
    <label for='upl_price'>Price:</label> <input class='form form1l' type='number' value='0' name='upl_price' max='100000' min='0' required><br><br>
    
    <select class='form form1l w10p' name='upl_pt'><option selected disabled>Price Type</option><option>COINS</option><option>BUCKS</option><option>OFFSALE</option><option>FREE</option></select><br><br>
    
    <label for='upl_type'>Type:</label> <select class='form form1l w10p' name='upl_type'><option selected disabled>Item Type</option><option>SHIRT</option><option>PANTS</option></select><br><br>
    <input id='itemimg' type='file' name='upl_img' accept='.png'><br><br>
    
    <button class='button3 btn-blue nd hover'>Submit!</button>
</form>

<h2>Templates</h2>

<table>
	<tr>
    	<td><img src='/Misc/IMGS/shirt.png'></td>
    	<td><img src='/Misc/IMGS/pants.png'></td>
	</tr>
    <tr>
    	<td>Shirt</td>
    	<td>Pants</td>
    </tr>
</table>

</div>
</div>

";
