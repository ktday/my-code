<?php

//include("../Misc/connect.php");
include("../Misc/vars.php");
include("../Misc/funct.php");

if(!isset($_COOKIE['KABRICK_U']) || !isset($_COOKIE['KABRICK_P'])){
    include("../404.php");exit();
}

if(!isset($_POST['serialid']) || !isset($_POST['price']) || !isset($_POST['id'])){
  include("../404.php");exit();
}

$id = mysqli_real_escape_string($conn,$_POST['id']);
$serial = mysqli_real_escape_string($conn,$_POST['serialid']);
$price = mysqli_real_escape_string($conn,$_POST['price']);

$item = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$id'"));

if($item['STATUS']!='AP'){include("../404.php");exit();}
if($item['RARITY']!='EPIC'){include("../404.php");exit();}

$invQ = mysqli_query($conn,"SELECT * FROM `INV` WHERE `ITEM` = '$id' AND `USER` = '$account[0]' AND `ID` = '$serial'"); # check user owns it
if(mysqli_num_rows($invQ)!=1){include("../404.php");exit();}

$inv = mysqli_fetch_array($invQ);

if($price<10){  echo"<script>window.alert('Price too low');window.location='/Market/item.php?id=$id'</script>";exit();}
if($price>5000){echo"<script>window.alert('Price too high');window.location='/Market/item.php?id=$id'</script>";exit();}

#$time = time();

mysqli_query($conn,"INSERT INTO `RESELLERS` VALUES(NULL,'$id','$account[0]','$price','0','$inv[0]')");

$url = "https://discord.com/api/webhooks/1222510659598553198/FkFeYaDhvxB0mq3TVM7Y7T8CHmNTAX6-L4xWXBi2sHjkT0KPck8qoJl-xdQPsYTctNqK";
$data = array(
  "embeds" => array(
    array(
      "title"=>"New item for sale!",
      "description"=>"Item: $item[NAME]\nUser: $account[USERNAME]\nPrice: $price Bucks",
      "color"=>$dcols["epic"],
      "url"=>$meta_url . "/Market/Item/" . $id
    )
  ),
  "content" => "<@&1222514522833817682>"
);
discord($url, $data);

echo"<script>window.location='/Market/Item/$id'</script>";exit();

?>