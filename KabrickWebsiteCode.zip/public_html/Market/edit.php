<?php
include_once($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');
include_once($_SERVER['DOCUMENT_ROOT'] . '/Admin/FUNCT.php');

if(!isset($_GET['id'])){exit();}

$id = mysqli_real_escape_string($conn,$_GET['id']);
$item = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$id'");

if(mysqli_num_rows($item)!=1){
  exit("Invalid item");
}

$i = mysqli_fetch_array($item);

if($ar<5 && $account[0]!=$i['UPLOADER']){include_once($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();}



if(isset($_POST['upd-desc'])){
  $desc = mysqli_real_escape_string($conn,$_POST['upd-desc']);
  mysqli_query($conn,"UPDATE `MARKET` SET `DESCRIPTION` = '$desc' WHERE `ID` = '$id'");
  mysqli_query($conn,"UPDATE `MARKET` SET `UPDATE_TIME` = '$time' WHERE `ID` = '$id'");
  if($account[0]!=$i['UPLOADER']){
    logAction(150,$i[0],"New -> `$desc`");
  }
  echo"<script>window.location='/Market/Item/$id'</script>";exit();
}

if(isset($_POST['upd-price'])){
  $p = mysqli_real_escape_string($conn,$_POST['upd-price']);
  $t = mysqli_real_escape_string($conn,$_POST['upd-priceT']);
  mysqli_query($conn,"UPDATE `MARKET` SET `PRICE` = '$p', `PRICE_TYPE` = '$t' WHERE `ID` = '$id'");
  mysqli_query($conn,"UPDATE `MARKET` SET `UPDATE_TIME` = '$time' WHERE `ID` = '$id'");
  if($account[0]!=$i['UPLOADER']){
    logAction(151,$i[0],"New -> `$p $t`");
  }
  echo"<script>window.location='/Market/Item/$id'</script>";exit();
}

if(isset($_POST['ad-del'])){
  if($ar<4){exit();}
  mysqli_query($conn,"UPDATE `MARKET` SET `STATUS` = 'BAN' WHERE `ID` = '$id'");
  mysqli_query($conn,"UPDATE `MARKET` SET `UPDATE_TIME` = '$time' WHERE `ID` = '$id'");
  #if($account[0]!=$i['UPLOADER']){
    logAction(152,0,"ID: $id");
  #}
  echo"<script>window.location='/Market/Item/$id'</script>";exit();
}

if(isset($_POST['ad-rarity'])){
  if($ar<6){exit();}
  $upd = mysqli_real_escape_string($conn,$_POST['ad-rarity']);
  mysqli_query($conn,"UPDATE `MARKET` SET `RARITY` = '$upd' WHERE `ID` = '$id'");
  mysqli_query($conn,"UPDATE `MARKET` SET `UPDATE_TIME` = '$time' WHERE `ID` = '$id'");

  echo"<script>window.location='/Market/Item/$id'</script>";exit();
}

if(isset($_POST['ad-status'])){
  if($ar<6){exit();}
  $upd = mysqli_real_escape_string($conn,$_POST['ad-status']);
  mysqli_query($conn,"UPDATE `MARKET` SET `STATUS` = '$upd' WHERE `ID` = '$id'");
  mysqli_query($conn,"UPDATE `MARKET` SET `UPDATE_TIME` = '$time' WHERE `ID` = '$id'");

  echo"<script>window.location='/Market/Item/$id'</script>";exit();
}

if(isset($_POST['ad-stock'])){
  if($ar<6){exit();}
  $upd = mysqli_real_escape_string($conn,$_POST['ad-stock']);
  mysqli_query($conn,"UPDATE `MARKET` SET `STOCK` = '". strval($upd + $i['STOCK']) . "' WHERE `ID` = '$id'");
  mysqli_query($conn,"UPDATE `MARKET` SET `STOCK_REMAINING` = '". strval($upd + $i['STOCK_REMAINING']) . "' WHERE `ID` = '$id'");
  mysqli_query($conn,"UPDATE `MARKET` SET `UPDATE_TIME` = '$time' WHERE `ID` = '$id'");

  echo"<script>window.location='/Market/Item/$id'</script>";exit();
}

if(isset($_POST['ad-timer'])){
  if($ar<6){exit();}
  $upd = mysqli_real_escape_string($conn,$_POST['ad-timer']);
  if($i['ONSALE_TIME']==0){$t = time() + ($upd * 3600);}else{$t = $i['ONSALE_TIME'] + ($upd * 3600);}
  mysqli_query($conn,"UPDATE `MARKET` SET `ONSALE_TIME` = '$t' WHERE `ID` = '$id'");
  mysqli_query($conn,"UPDATE `MARKET` SET `UPDATE_TIME` = '$time' WHERE `ID` = '$id'");

  echo"<script>window.location='/Market/Item/$id'</script>";exit();
}



#### SCRIPTS ####

echo"

<script>

function page1() {
    document.getElementById('page1').style.display = 'block';
    document.getElementById('page2').style.display = 'none';
    document.getElementById('page3').style.display = 'none';
    document.getElementById('page4').style.display = 'none';
}

function page2() {
    document.getElementById('page1').style.display = 'none';
    document.getElementById('page2').style.display = 'block';
    document.getElementById('page3').style.display = 'none';
    document.getElementById('page4').style.display = 'none';
}

function page3() {
    document.getElementById('page1').style.display = 'none';
    document.getElementById('page2').style.display = 'none';
    document.getElementById('page3').style.display = 'block';
    document.getElementById('page4').style.display = 'none';
}

function page4() {
    document.getElementById('page1').style.display = 'none';
    document.getElementById('page2').style.display = 'none';
    document.getElementById('page3').style.display = 'none';
    document.getElementById('page4').style.display = 'block';
}

</script>

";

#PAGES

# ID    # PAGE NAME
#####################
# 1     # Description
# 2     # Price
# 3     # Req - Request deletion
# 4     # Admin -> Delete

echo"

<title>Edit item | $meta_name</title>

<div class='doublebox box1'>

	<div class='platformtitle'>
      <p>$i[1]</p>
    </div>
    
    <br>
    
    <button class='button btn-blue nd hover' onclick='page1()'>Description</button>
    <button class='button btn-blue nd hover' onclick='page2()'>Price</button>
    <button class='button btn-blue nd hover' onclick='page3()'>Req</button>
    ";if($ar>4){echo"<button class='button btn-red nd hover' onclick='page4()'>Admin</button>";}echo"
    <a class='button btn-green nd hover' href='/Market/Item/$id'>Back</a>
    
    <br><hr><br>

</div>

<div class='doublebox box2'>

	<div id='page1' style='display:none;'>
    	
        <div class='platformtitle'>
        	<p>Description</p>
        </div><br>
        
        <form method='post'><textarea class='form form1l' minlength='5' maxlength='200' name='upd-desc' required>$i[DESCRIPTION]</textarea><button class='button3 hover'>Update</button></form>
        
    </div>

	<div id='page2' style='display:none;'>
    
    	<div class='platformtitle'>
        	<p>Price</p>
        </div><br>
        
        <form method='post'><select name='upd-priceT' required class='form form1l'><option>OFFSALE</option><option>FREE</option><option>COINS</option><option>BUCKS</option></select>
        <input class='form form1l' type='number' name='upd-price' placeholder='$i[PRICE]' required>
        <button class='button3 hover'>Submit</button></form>
        
        <p class='small1'>(30% Tax)</p>
    
    </div>

	<div id='page3' style='display:none;'>
    
    	<div class='platformtitle'>
        	<p>Request Deletion</p>
        </div><br>
        
        <form method='post'><button class='button3 hover btn-red' name='req-del'>Request Deletion</button></form>
        <p class='small1'>Requesting deletion will send an alert to admins to delete this item.<br>
        You will not be able to trade, sell or wear this item after its deleted.</p>
    
    </div>

	<div id='page4' style='display:none;'>
    
    	<div class='platformtitle'>
        	<p>Admin</p>
        </div><br>
        
        <form method='post'><button class='button3 hover btn-red' name='ad-del'>Delete</button></form>
        
        ";

		if($ar==6){
          
          echo"
          Rarity ($i[RARITY])
          
          <form method='post'><select name='ad-rarity' required class='form form1l'><option>DEF</option><option>RARE</option><option>EPIC</option><option>EVENT</option><option>CUSTOM</option><option>VIP</option></select>
        <button class='button3 hover'>Submit</button></form>
        
        <br>Status ($i[STATUS])
        
        <form method='post'><select name='ad-status' required class='form form1l'><option>AP</option><option>UAP</option><option>SECRET</option><option>BAN</option></select>
        <button class='button3 hover'>Submit</button></form>
        
        <form method='post'><input class='form form1l' type='number' name='ad-stock' placeholder='Add Stock ($i[STOCK])' required>
        <button class='button3 hover'>Submit</button></form>
        
        <form method='post'><input class='form form1l' type='number' name='ad-timer' placeholder='Add Time' required>
        <button class='button3 hover'>Submit</button></form>
        ";
          
        }

echo"
    
    </div>
    
</div>
</div>

";

?>