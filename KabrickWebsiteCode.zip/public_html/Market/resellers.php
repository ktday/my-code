<?php
include("../Misc/connect.php");
include("../bbcode.php");

if(!isset($_COOKIE['KABRICK_U']) || !isset($_COOKIE['KABRICK_P'])){
    $e = false;
}else{
  $e = true;
}

if(!isset($_GET['id'])){
  exit();
}

$id = mysqli_real_escape_string($conn,$_GET['id']);
$comments = mysqli_query($conn,"SELECT * FROM `RESELLERS` WHERE `ITEM` = '$id' AND `BOUGHT` = '0' ORDER BY `PRICE` ASC");
$item = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$id'"));

if($e==true){
  $rank = $account['RANK'];
  if($rank=='OWNER'||$rank=='MANAGER'||$rank=='EXECUTIVE'||$rank=='ADMIN'){
    $adminABUSE = true;
  }else{
    $adminABUSE = false;
  }
}else{
  $adminABUSE = false;
}

echo"

<div class='platformtitle'>
	<p>Resellers (". mysqli_num_rows($comments) .")</p>
</div>

<button onclick='Comments()' class='button2 nd btn-blue'>Comments</button>
"; if($item['RARITY'] == 'EPIC'){echo"<button onclick='Auction()' class='button2 nd btn-blue'>Auction</button>
    <button onclick='Resellers()' class='button2 nd btn-blue'>Resellers</button>";} echo"
"; if($adminABUSE == true){echo"<button onclick='Owners()' class='button2 nd btn-red'>Owners</button>";} 

if($item['RARITY']!='EPIC'){
echo"<br><br>You are only able to resell <u>Limited</u> items.";exit();
}

$invQ = mysqli_query($conn,"SELECT * FROM `INV` WHERE `ITEM` = '$id' AND `USER` = '$account[0]'");
$invcheck = mysqli_num_rows($invQ);
if($invcheck==0){echo"<br><br>You do not have this item.";}else{

echo"

<br><br>

<form method='post' action='/Market/resell-item.php'>
  
  Serial: <select class='form form1l' name='serialid'>
  	";
  
  	while(($s = mysqli_fetch_array($invQ))){
      echo"<option value='$s[ID]'>#$s[SERIAL]</option>";
    }
  
  echo"
  </select><br><br>
  
  <input type='number' max='1000' min='10' class='form form1l' name='price' placeholder='Price (in bucks)'><br><br>
  
  <button class='button btn-blue nd hover' value='$id' name='id'>Sell!</button>
  
</form>

";}

echo"<hr>";



if(mysqli_num_rows($comments)==0){
  echo"This item has no resellers :(";
}else{
  while(($i=mysqli_fetch_array($comments))){
    
    $getUser = mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$i[SELLER]'");
    $u = mysqli_fetch_array($getUser);
    $inv = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `INV` WHERE `ID` = '$i[INVID]'"));
    
    echo"
    
    <div style='width:80%;margin:auto;'>
    
      <img src='$u[AVATAR_IMG_URL]' class='fl' style='left:1rem;'>
      
      <br><br>
      <a class='button2 btn-green nd hover' href='/Market/BuyResell/$i[0]'>Buy for $i[PRICE] Bucks</a>
      <p class='small1'>Serial #$inv[SERIAL]</p>
      
      <span style='bottom:1rem;'><a href='/Profile/$u[1]'>For sale by $u[1]</a></span>
    
    </div>
    
    <br><br><br><br><br><br> <hr> <br>
    
    ";
  }
}

?>