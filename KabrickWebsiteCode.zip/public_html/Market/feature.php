<?php
include($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');

if(!isset($_COOKIE['KABRICK_U']) || !isset($_COOKIE['KABRICK_P'])){
    exit();
}

if($ar<5){exit();}

if(isset($_GET['id'])){
$id = mysqli_real_escape_string($conn,$_GET['id']);
$itemQ = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$id'");

if(mysqli_num_rows($itemQ)!=1){
    echo"<script>window.location='/Market/'</script>";exit();
}
  
$i = mysqli_fetch_array($itemQ);

if($i['TYPE']!='SHIRT'  &&  $i['TYPE']!='PANTS'){exit();}
  

  if($i['RARITY'] == 'DEF'){
    mysqli_query($conn,"UPDATE `MARKET` SET `RARITY` = 'FEATURED' WHERE `ID` = '$id'");
  }else{
    mysqli_query($conn,"UPDATE `MARKET` SET `RARITY` = 'DEF' WHERE `ID` = '$id'");
  }
  
  echo"<script>window.location='/Market/Item/$id'</script>";exit();
    
}