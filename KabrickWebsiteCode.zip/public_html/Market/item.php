<?php

##############################################################################################
# Rarity       # Stock?  # Limited Time?   # Who?           # Color       # Can have timer?  #
##############################################################################################
# DEF          # No      # No              # All            # White       # Yes              #
# RARE         # No      # No              # All            # Purple      # Yes              #
# EPIC         # Yes     # No              # All            # Gold        # Yes              #
# EVENT        # No      # No              # All            # Green       # Yes              #
# VIP          # No      # No              # VIP Users      # White       # No               #
# CUSTOM       # No      # No              # Custom Owner   # Blue        # No               #
# DEF + Timer  # No      # Yes             # All            # Red         #                  #
# RARE + Timer # No      # Yes             # All            # Purple      #                  #
# EPIC + Timer # No      # Yes             # All            # Gold        #                  #
# EVENT + Timer# No      # Yes             # All            # Green       #                  #
##############################################################################################

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');

if(!isset($_COOKIE['KABRICK_U']) || !isset($_COOKIE['KABRICK_P'])){
    $e = false;
}else{
  $e = true;
}

if(isset($_GET['id'])){
$id = mysqli_real_escape_string($conn,$_GET['id']);
$itemQ = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$id'");

if(mysqli_num_rows($itemQ)!=1){
    echo"<script>window.location='/Market/'</script>";exit();
}

$i = mysqli_fetch_array($itemQ);
$uQ = mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$i[UPLOADER]'");
$u = mysqli_fetch_array($uQ);

$t1 = date("H:i", $i['TIME']);
$t2 = gmdate("j F Y", $i['TIME']);

$t3 = date("H:i", $i['UPDATE_TIME']);
$t4 = gmdate("j F Y", $i['UPDATE_TIME']);

if(strlen($i['NAME'])>10){
    $name = substr($i['NAME'], 0, 10)."..";
}else{
    $name = $i['NAME'];
}

if($i['STATUS']=='BAN'&&$account[0]!=2){echo"<script>window.location='/Market/'</script>";exit();}

$bought = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM `INV` WHERE `ITEM` = '$id'"));
$favourites = 'N/A';

if($e==true){
$isowned = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM `INV` WHERE `ITEM` = '$id' AND `USER` = '$account[0]'"));
if($isowned==0&&$i['UPLOADER']==$account[0]){
    mysqli_query($conn,"INSERT INTO `INV` VALUES(NULL,'$id','$account[0]','$i[TYPE]','1')");
    echo"<script>window.location='/Market/Item/$id'</script>";exit();
}}else{
  $isowned = 0;
}
    
if(isset($_POST['COMMENT'])){
  $comment = mysqli_real_escape_string($conn,$_POST['COMMENT']);
    if(strlen($comment)>255){
    echo"<script>window.alert('Too L O N G');window.location='/Market/Item/$id'</script>";exit();
  }
  mysqli_query($conn,"INSERT INTO `COMMENTS` VALUES(NULL,'$account[0]','$id','$comment','0')");
  echo"<script>window.location='/Market/Item/$id'</script>";exit();
}
  
  $ttl = lgt($i[1]);

echo"<title>$ttl | $meta_name</title>";

/*if($i['STATUS']=='SECRET'&&$isowned==0){echo"<script>window.location='/Market/'</script>";exit();}*/

if($i['PRICE_TYPE']=='COINS'&&$i['PRICE']!=0){
    $price = "<i class='fa fa-coins'></i> $i[PRICE]";
}elseif($i['PRICE_TYPE']=='BUCKS'&&$i['PRICE']!=0){
    $price = "<i class='fa fa-money-bill-alt'></i> $i[PRICE]";
}elseif($i['PRICE_TYPE']=='FREE'){
    $price = "Free!";
}else{
    $price = "Offsale!";
}

//rarity

if($i['RARITY']=='DEF'){
  if($i['ONSALE_TIME']==0){
    $color = 'txtcol-white';
  }else{
    $color = 'txtcol-red';
  }
}elseif($i['RARITY']=='RARE'){
  $color = 'txtcol-purple';
}elseif($i['RARITY']=='WAR'){
  $color = 'txtcol-war';
}elseif($i['RARITY']=='EPIC'){
  $color = 'txtcol-gold';
}elseif($i['RARITY']=='EVENT'){
  $color = 'txtcol-green';
}elseif($i['RARITY']=='CUSTOM'){
  $color = 'txtcol-blue';
}else{
  $color = 'txtcol-white';
}
  
if($i['RARITY']=='EPIC'){
  if($i['ONSALE_TIME']==0){
  $v = "/Misc/IMGS/LimitedTag.png";
  }else{
  $v = "/Misc/IMGS/LimitedTimerTag.png";
  }
}elseif($i['RARITY']=='RARE'){
  if($i['ONSALE_TIME']==0){
  $v = "/Misc/IMGS/RareTag.png";
  }else{
  $v = "/Misc/IMGS/RareTimerTag.png";
  }
}elseif($i['RARITY']=='EVENT'){
  if($i['ONSALE_TIME']==0){
  $v = "/Misc/IMGS/EventTag.png";
  }else{
  $v = "/Misc/IMGS/EventTimerTag.png";
  }
}elseif($i['RARITY']=='CUSTOM'){
  $v = "/Misc/IMGS/CustomTag.png";
}elseif($i['RARITY']=='VIP'){
  $v = "/Misc/IMGS/VipTag.png";
}elseif($i['RARITY']=='FEATURED'){ // FEATURED
  $v = "/Misc/IMGS/FeaturedTag.png";
}else{
  if($i['ONSALE_TIME']==0){
    $img = "<img src='$i[PREV_IMG]' class='avatar'>";
  }else{
    $v = "/Misc/IMGS/TimerTag.png";
  }
}
  
if($i['RARITY']=='DEF'&&$i['ONSALE_TIME']==0){}
else{$img = "<img src='$v' class='avatar' style='background-image:url(\"$i[PREV_IMG]\");background-repeat: no-repeat;background-size: cover;'>";}
  
if($i['STATUS']=='SECRET'){
    /*$color = "txtcol-red";*/
    $iota = " <i class='fa fa-lock'></i>";
}else{
    $iota = "";
}

//type

if($i['TYPE']=='HAT'){
    $type = 'Hat';
}elseif($i['TYPE']=='FACE'){
    $type = 'Face';
}elseif($i['TYPE']=='MASK'){
    $type = 'Face Accessory';
}elseif($i['TYPE']=='GEAR'){
    $type = 'Tool';
}elseif($i['TYPE']=='SHOULDER'){
    $type = 'Shoulder Item';
}elseif($i['TYPE']=='BACK'){
    $type = 'Back Item';
}elseif($i['TYPE']=='BODY'){
    $type = 'Body';
}elseif($i['TYPE']=='SHIRT'){
    $type = 'Shirt';
}elseif($i['TYPE']=='PANTS'){
    $type = 'Pants';
}elseif($i['TYPE']=='PET'){
    $type = 'Pet';
}else{
    $type = '???';
}
  
if($i['ONSALE_TIME']!=0){
  if($i['ONSALE_TIME']>time()){
    $tL = $i['ONSALE_TIME']-time();
    #$tL = (time() + (1 * 90)) - time();
    if($tL<=86400){
      if($tL<=3600){
        $timeLeft = floor($tL / 60) . ' Minutes Left.';
      }else{
        $timeLeft = floor($tL / 3600) . ' Hours Left.';
      }
    }else{
      $timeLeft = floor($tL / 86400) . ' Days Left.';
    }
  }else{
  	$timeLeft = 'Out of time!';
  }
}else{
  $timeLeft = '';
}
  
if($e==true){
  $rank = $account['RANK'];
  if($rank=='OWNER'||$rank=='MANAGER'||$rank=='EXECUTIVE'||$rank=='ADMIN'){
    $adminABUSE = true;
  }else{
    $adminABUSE = false;
  }
}else{
  $adminABUSE = false;
}
  
if($e==true){
  if($isowned==1){
    $btn = "<a class='button2 btn-blue hover nd w2r'>Item Owned!</a>";
  }else{
    if($price == 'Offsale!'){
      $btn = "<a class='button2 btn-red hover nd w2r'>Offsale</a>";
    }else{
      $btn = "<a class='button2 btn-green hover nd w2r' href='/Market/Buy/$id'>Buy for $price</a>";
    }
  }
}else{
  $btn = "<a class='button2 btn-red hover nd w2r'>Log in to buy items</a>";
}
  
if($i['STATUS']=='AP'){$st = "Approved";}
elseif($i['STATUS']=='BAN'){$st = "Deleted";}
elseif($i['STATUS']=='UAP'){$st = "Pending Approval";}
else{$s = "Secret (oooohhhhhhhh...)";}
  
### SCRIPTS ###
  
if($e==true){
  
  echo"

<script>

function Comments(){
   $('#69420').load('/Market/comments.php?id=$id');
}

function Resellers(){
   $('#69420').load('/Market/resellers.php?id=$id');
}

function Auction(){
   $('#69420').load('/Market/auction.php?id=$id');
}

$(document).ready(function(){
  Comments();
});

";}
  
if($adminABUSE == true){
  echo"
  
  function Owners(){
   	$('#69420').load('/Market/owners.php?id=$id');
  }
  
  ";
}

echo"

</script>

<div class='platform'>
    
    <br>
    
    <div class='itemcard shadow'>
        <div class='absolute w20'></div>
        
        <div class='itemcard-info absolute'>
            <h2><span class='$color'>$ttl ($type)$iota</span><br>
            <a href='/Profile/$u[1]' class='small1 nd'>By $u[1]</a></h2>
            $btn &nbsp;&nbsp;<a class='button2 btn-gold hover nd'>Favourite</a>&nbsp;&nbsp;<a class='button2 btn-red hover nd' href='?report=$id'>Report</a>
            <p class='wb'>\"$i[DESCRIPTION]\"</p>
        </div>
        <div class='itemcard-img'>
            $img<br><br>
        </div>
    </div>
    
    <br>
    
</div>

<br><br><br>

<div class='doublebox box1'>
	<div class='platformtitle'>
    	<p>Item Info</p>
    </div>
    
    <p>Sold: $bought</p>
    <p>Item ID: $i[0]</p>
    "; if($i['RARITY']=='EPIC'&&$i['STOCK_REMAINING']!=0&&$i['ONSALE_TIME']==0){echo"<p class='txtcol-red'>($i[STOCK_REMAINING] left of $i[STOCK])</p>";}
  	elseif($i['RARITY']=='EPIC'&&$i['STOCK_REMAINING']==0&&$i['ONSALE_TIME']==0){echo"<p class='txtcol-red'>Sold out with $i[STOCK] stock</p>";} echo"
    "; if($i['ONSALE_TIME']!=0){echo"<p class='txtcol-red'>$timeLeft</p>";} 
       if($i['RARITY']=='EPIC'){echo"<p class='txtcol-gold'>RAP: $i[RAP]</p>";} echo"
    <p>Created: $t1, $t2</p>
    <p>Last updated: $t3, $t4</p>
    
    ";
  
  if($e){if($u[0] == $account[0] || $ar >= 5){
    
    echo"
    
    <hr>
    
    <p>Price: $price</p>
    <p>Status: $st</p>
    
    <a class='button btn-blue hover nd' href='/Market/edit.php?id=$i[0]'>Edit Item</a>
    
    ";
    
    if( $i['RARITY'] == 'EPIC' ){
      echo"<a class='button btn-blue hover nd' href='/Market/regenRAP.php?id=$i[0]'>Regenerate RAP</a>";
    }
    
    if($ar > 4 && ($i['TYPE'] == 'SHIRT' || $i['TYPE'] == 'PANTS')){
      echo"<a href='/Market/feature.php?id=$i[0]' class='button nd btn-gold hover'>Feature</a>";
    }
    
  }}
  
  if($e==true){
  
  echo"
    
</div>

<div class='doublebox box2' id='69420'>
	<div class='platformtitle'>
    	<p>Comments</p>
    </div>
    
    <button onclick='Comments()' class='button2 nd btn-blue'>Comments</button>
    "; if($i['RARITY'] == 'EPIC'){echo"<button onclick='Auction()' class='button2 nd btn-blue'>Auction</button>
    <button onclick='Resellers()' class='button2 nd btn-blue'>Resellers</button>";} echo"
    "; if($adminABUSE == true){echo"<button onclick='Owners()' class='button2 nd btn-red'>Owners</button>";} 
    
    
    
    echo"
</div>

";}else{
   
   echo"
    
</div>

<div class='doublebox box2' id='69420'>
	<div class='platformtitle'>
    	<p>Comments</p>
    </div>
    
    Log in to view Comments!
</div>

";}

/*if($i['RARITY'] == 'EPIC'){
        
    #$value = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `VALUES` WHERE `ITEM` = '$id'"))['VALUE'];
    
    #$query = mysqli_query($conn,"SELECT * FROM `RESELLERS` WHERE `ITEM` = '$id'");
    
    echo"
    
    <br><br>
    
    <div class='platform'>
    
        <h2>Resellers (Value: $value)</h2>
        
        <a class='button btn-blue hover nd' href='#'>Sell</a><br>
        
        ";
        
        /*while(($r = mysqli_fetch_array($query))){
            
            $u = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$r[SELLER]'"));
            $invid = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `INV` WHERE `ID` = '$r[INVID]'"));
            
            echo"
        
            <p><a href='/Profile/$u[1]'>$u[1]</a> is selling <b>#$invid[SERIAL]</b> for <b><i class='fa fa-money-bill-alt'></i> $r[PRICE]</b> <a class='button2 btn-green hover nd' href='?bri=$r[0]'>Buy now!</a></p>
            
            ";
            
        }*
        
        echo"
            
    </div>
    
    ";

}*/

echo"

</div>

";

}elseif(isset($_GET['report'])){
    
    #$id = mysqli_real_escape_string($conn,$_GET['rpt']);

    #mysqli_query($conn,"INSERT INTO `REPORTS` VALUES(NULL,'ITEM','$id','$account[0]')");
    echo"<script>window.alert('Unable to report item');window.location='/Market/Item/$id'</script>";exit();
    
}elseif(isset($_GET['buy'])){
    
    $id = mysqli_real_escape_string($conn,$_GET['buy']);
    
    $itemQ = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$id'");
    $item = mysqli_fetch_array($itemQ);
  
  	if($e==false){
      echo"<script>window.alert('Login to buy items!');window.location='/Market/Item/$item[0]'</script>";exit();
    }
  
  	if($item['ONSALE_TIME']!=0){
      $timer = true;
    }else{
      $timer = false;
    }
  
  	if($item['ONSALE_TIME']<time()){
      $onsale = false;
    }else{
      $onsale = true;
    }
    
    if($item['STATUS']!="AP"){echo"<script>window.location='/Market/'</script>";exit();}
    #echo"<script>window.alert('Soontm');window.location='/Market/item.php?id=$id'</script>";
    
    if(mysqli_num_rows($itemQ)!=1){
        echo"<script>window.location='/Market/Item/$id'</script>";exit();
    }else{
        
        $ioQ = mysqli_query($conn,"SELECT * FROM `INV` WHERE `USER`='$account[0]' AND `ITEM`='$id'");
        if(mysqli_num_rows($ioQ)>0){
            //already owned
            echo"<script>window.alert('You Already Own This Item!');window.location='/Market/Item/$id'</script>";exit();
        }else{
            if($item['PRICE_TYPE']=='OFFSALE'){
                echo"<script>window.location='/Market/Item/$id'</script>";exit();
            }else{
              
              	if($timer == true){
                  if($onsale == false){
                    echo"<script>window.alert('Out of time!');window.location='/Market/Item/$id'</script>";exit();
                  }
                }
              
              	if($item['RARITY']=='CUSTOM'){
                  echo"<script>window.alert('You cannot buy someone elses custom!');window.location='/Market/Item/$id'</script>";exit();
                }
              
              	if($item['RARITY']=='VIP'){
                  if($account['VIP']=='NONE'){
                    echo"<script>window.alert('You need vip to buy this item!');window.location='/Market/Item/$id'</script>";exit();
                  }
                }
              
              	$CHANGESTOCK = false;
                
                if($item['RARITY']=='EPIC'&&$timer==false){
                    
                    //is limited; check stock
                  
                    if($item['STOCK_REMAINING']<1){
                        
                        echo"<script>window.alert('Out of stock!');window.location='/Market/Item/$id'</script>";exit();
                        
                    }else{
                        
                      	$CHANGESTOCK = true;
                        
                    }
                    
                }
              
              $pt = $item['PRICE_TYPE'];
                    
              if($pt == "COINS" || $pt == "BUCKS"){
                    //is coins; check amount
                    if($account[$pt]<$item['PRICE']){
                        
                        //not enough
                        echo"<script>window.alert('Not enough $pt!');window.location='/Market/Item/$id'</script>";exit();
                        
                    }else{
                        
                        //take coins
                        $rc = $account[$pt] - $item['PRICE'];
                        mysqli_query($conn,"UPDATE `USERS` SET `$pt` = '$rc' WHERE `ID` = '$account[0]'");
                        
                    }
                
                    //query devs
                    $DEV_Q = mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$item[UPLOADER]'");
                    $DEV_A = mysqli_fetch_array($DEV_Q);
                    $ADM_Q = mysqli_query($conn,"SELECT * FROM `CURRENT_ECONOMY` WHERE `ID` = '1'");
                    $ADM_A = mysqli_fetch_array($ADM_Q);
                    
                    //ammount to pay devs
                    $DEVSCOINSQ = ($item['PRICE']/10)*7;
                    $ADMINSCOINSQ = ($item['PRICE']/10)*3;
                    $DEVSCOINS = $DEV_A[$pt] + $DEVSCOINSQ;
                    $ADMINSCOINS = $ADM_A[$pt] + $ADMINSCOINSQ;
                    
                    //pay devs
                    mysqli_query($conn,"UPDATE `USERS` SET `$pt` = '$DEVSCOINS' WHERE `ID` = '$DEV_A[0]'");
                    mysqli_query($conn,"UPDATE `CURRENT_ECONOMY` SET `$pt` = '$ADMINSCOINS' WHERE `ID` = '1'");
              }
                
                //buy
                
              	if($CHANGESTOCK == true){
                        $SR = $item['STOCK_REMAINING'] - 1;
                        mysqli_query($conn,"UPDATE `MARKET` SET `STOCK_REMAINING` = '$SR' WHERE `ID` = '$id'");
                }
                
                //find serial
                $findS = mysqli_query($conn,"SELECT * FROM `INV` WHERE `ITEM` = '$id'");
                $serial = mysqli_num_rows($findS) + 1;
                
                //insert item
                mysqli_query($conn,"INSERT INTO `INV` VALUES(NULL,'$item[0]','$account[0]','$item[TYPE]','$serial')");
                
                /*if($item['PRICE_TYPE']!='FREE'){
                    
                    
                    
                }*/

                //egg hunt 2024
                if($item["RARITY"] == "DEF"){update($account[0], "Buy");}
                
                //done
                echo"<script>window.alert('Successfully bought item!');window.location='/Market/Item/$id'</script>";exit();
                
                
            }
        }
    }
    
}elseif(isset($_GET['bri'])){//bri = "buy resold item"
}elseif(isset($_GET['buyFromReseller'])){
    
    $id = mysqli_real_escape_string($conn,$_GET['buyFromReseller']);
    
    $itemQ = mysqli_query($conn,"SELECT * FROM `RESELLERS` WHERE `ID` = '$id'");
    $item = mysqli_fetch_array($itemQ);
  
  	if($e==false){
      echo"<script>window.alert('Login to buy items!');window.location='/Market/Item/$i[0]'</script>";exit();
    }
  
  if($item['BOUGHT'] != '0'){echo"<script>window.location='/Market/Item/$i[0]'</script>";exit();}
    
    $invidQ = mysqli_query($conn,"SELECT * FROM `INV` WHERE `ID` = '$item[INVID]'");
    $invid = mysqli_fetch_array($invidQ);
    
    if($invid['USER']==$account[0] || $item['SELLER']==$account[0]){
        echo"<script>window.location='/Market/item.php?id=$invid[ITEM]'</script>";exit();
    }
    
    //check amount
    
    if($account['BUCKS']<$item['PRICE']){
        
        //not enough
        echo"<script>window.alert('Not enough bucks!');window.location='/Market/Item/$invid[ITEM]'</script>";exit();
        
    }else{
        
        //take bucks
        $rc = $account['BUCKS'] - $item['PRICE'];
        mysqli_query($conn,"UPDATE `USERS` SET `BUCKS` = '$rc' WHERE `ID` = '$account[ID]'");
        
    }
    
    //query devs
    $DEV_Q = mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$item[SELLER]'"); // seller
    $DEV_A = mysqli_fetch_array($DEV_Q);
    $ADM_Q = mysqli_query($conn,"SELECT * FROM `CURRENT_ECONOMY` WHERE `ID` = '1'");
    $ADM_A = mysqli_fetch_array($ADM_Q);
    
    //ammount to pay devs
    $DEVSCOINSQ = ($item['PRICE']/10)*7;
    $ADMINSCOINSQ = ($item['PRICE']/10)*3;
    $DEVSCOINS = $DEV_A['BUCKS'] + $DEVSCOINSQ;
    $ADMINSCOINS = $ADM_A['BUCKS'] + $ADMINSCOINSQ;
    
    //pay devs
    mysqli_query($conn,"UPDATE `USERS` SET `BUCKS` = '$DEVSCOINS' WHERE `ID` = '$DEV_A[0]'");
    mysqli_query($conn,"UPDATE `CURRENT_ECONOMY` SET `BUCKS` = '$ADMINSCOINS' WHERE `ID` = '1'");
    
    //update invid
    mysqli_query($conn,"UPDATE `INV` SET `USER` = '$account[0]' WHERE `ID` = '$invid[0]'");
    mysqli_query($conn,"UPDATE `RESELLERS` SET `BOUGHT` = '1' WHERE `ID` = '$id'");
  
    //add invid log (17/10/23)
  	mysqli_query($conn,"INSERT INTO `INVID`(`ID`, `INVID`, `OLD`, `NEW`, `TYPE`, `INT2`, `ITEM`) VALUES (NULL,$item[INVID],$DEV_A[0],$account[0],'SALE','$item[PRICE]','$invid[ITEM]')");
  
    //send message to seller
    $time = time();
    mysqli_query($conn,"INSERT INTO `MESSAGES` VALUES(NULL,'1','$item[SELLER]','Your item, $item[1] #$invid[SERIAL] has been sold to $account[1] for $item[PRICE] Bucks!','NO','$time','Item Sold!')");
  
    //send RESELLERS => SALES
    mysqli_query($conn,"INSERT INTO `SALES` VALUES(NULL,'$item[ITEM]','$item[PRICE]','$invid[0]','$item[SELLER]','$account[0]')");

    //discord embed (27/03/2024)
    $i = mysqli_fetch_array(mysqli_query($conn,"SELECT `NAME`, `RAP` FROM `MARKET` WHERE `ID` = '$item[ITEM]'"));
    $u = mysqli_fetch_array(mysqli_query($conn,"SELECT `USERNAME` FROM `USERS` WHERE `ID` = '$item[SELLER]'"));
    $url = "https://discord.com/api/webhooks/1222510659598553198/FkFeYaDhvxB0mq3TVM7Y7T8CHmNTAX6-L4xWXBi2sHjkT0KPck8qoJl-xdQPsYTctNqK";
    $data = array(
      "embeds" => array(
        array(
          "title"=>"Item has been sold!",
          "description"=>"Item: $i[NAME]\nSold by: $u[USERNAME]\nBought by: $account[USERNAME]\nPrice: $item[PRICE] Bucks",
          "color"=>$dcols["event"],
          "url"=>$meta_url . "/Market/Item/" . $item['ITEM']
        )
      )
    );
    discord($url, $data);
  
    // UPDATE RAP
  
    $rsales = mysqli_query($conn,"SELECT * FROM `SALES` WHERE `ITEM` = '$item[ITEM]' LIMIT 5");
    if(mysqli_num_rows($rsales)==0){$rap = 0;}else{
      if(mysqli_num_rows($rsales)==1){$rap = mysqli_fetch_array($rsales)['PRICE'];}else{
      $sp = array();

      while(($s = mysqli_fetch_array($rsales))){
        if($s['PRICE']>($i['RAP'] - 25) && $s['PRICE']<($i['RAP'] + 50)){ array_push($sp,$s['PRICE']); } // cancel adding if: rap - 25 < price < rap + 50
      }

      $rap = 0;

      foreach($sp as $x){
        $rap+=$x;
      }

      $rap /= count($sp);

    }}

    //update rap
    $frap = floor($rap);
    mysqli_query($conn,"UPDATE `MARKET` SET `RAP` = '$frap' WHERE `ID` = '$item[ITEM]'");
    
    //done
    //echo"<script>window.alert('Successfully bought item!');window.location='/Market/Item/$invid[ITEM]'</script>";exit();
    exit();


}else{

  
}

?>