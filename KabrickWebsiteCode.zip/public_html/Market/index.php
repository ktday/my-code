<?php

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');

echo"<title>Market | $meta_name</title>";

if(!isset($_COOKIE['KABRICK_U']) || !isset($_COOKIE['KABRICK_P'])){
    $e = false;
}else{$e=true;}

$CURRENT_ECONOMY = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `CURRENT_ECONOMY` WHERE `ID` = '1'"));
$timegmt = time() - 18000;

$pageID = null;
if(!isset($_GET['sort'])){
    echo"<script>window.location='/Market/?sort=all'</script>";exit();
}else{
    
    if(isset($_GET['page'])&&is_numeric($_GET['page'])){
        $pageID = intval(mysqli_real_escape_string($conn,$_GET['page']));
        $pageIDsq = ($pageID-1) * 15;
        if($pageID<1){
            $pageID = 1;
            $pageIDsq = 0;
        }
    }else{
        $pageID = 1;
        $pageIDsq = 0;
    }
    
    $sort = mysqli_real_escape_string($conn,$_GET['sort']);
  
    switch($sort){
      case 'all':
        $req = "`TYPE` != 'SHIRT' AND `TYPE` != 'PANTS' AND `STATUS` = 'AP'";break;
      case 'community':
        $req = "(`TYPE` = 'SHIRT' OR `TYPE` = 'PANTS') AND `STATUS` = 'AP'";break;
      case 'hat':
        $req = "`TYPE` = 'HAT' AND `STATUS` = 'AP'";break;
      case 'face':
        $req = "`TYPE` = 'FACE' AND `STATUS` = 'AP'";break;
      case 'mask':
        $req = "`TYPE` = 'MASK' AND `STATUS` = 'AP'";break;
      case 'tool':
        $req = "`TYPE` = 'GEAR' AND `STATUS` = 'AP'";break;
      case 'shoulder':
        $req = "`TYPE` = 'SHOULDER' AND `STATUS` = 'AP'";break;
      case 'shirt':
        $req = "`TYPE` = 'SHIRT' AND `STATUS` = 'AP'";break;
      case 'pants':
        $req = "`TYPE` = 'PANTS' AND `STATUS` = 'AP'";break;
      case 'featured':
        $req = "`RARITY` = 'FEATURED' AND `STATUS` = 'AP'";break;
      case 'limited':
        $req = "`RARITY` = 'EPIC' AND `STATUS` = 'AP'";break;
      case 'rare':
        $req = "`RARITY` = 'RARE' AND `STATUS` = 'AP'";break;
      case 'vip':
        $req = "`RARITY` = 'VIP' AND `STATUS` = 'AP'";break;
      default:
        echo"<script>window.location='/Market/?sort=all'</script>";exit();
    }
  
  	$q = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE $req ORDER BY `UPDATE_TIME` DESC LIMIT $pageIDsq, 15");
}

$btns = [
  
  ['All','all','nbg','blue'],
  ['Community Made','community','nbg','blue'],
  ['Featured','featured','nbg','blue'],
  [false],
  ['Hats','hat','nbg','blue'],
  ['Faces','face','nbg','blue'],
  ['Face Accessories','mask','nbg','blue'],
  ['Tools','tool','nbg','blue'],
  ['Shoulder Items','shoulder','nbg','blue'],
  ['Shirts','shirt','nbg','blue'],
  ['Pants','pants','nbg','blue'],
  [false],
  ['Limited Items','limited','gold','blue'],
  ['Rare Items','rare','purple','blue'],
  ['VIP Exclusives','vip','bronze','blue']
  
  ];

echo"

<div class='doublebox box4'>
    
    <div class='platformtitle'>
        <p><u><b>Sort</b></u></p>
    </div>
    
    <br>
    
    ";

	foreach($btns as $btn){
      if($btn[0] == false){echo"<br>";}
      else{
        echo"<a class='button btn-"; if($sort==$btn[1]){ echo($btn[3]); }else{ echo($btn[2]); } echo" hover nd' href='?sort=$btn[1]'>$btn[0]</a><br>";
      }
    }

if($e==true){echo"
    
    <a class='button btn-blue hover nd' href='/Market/create.php'>Create!</a>
    
    <div id='popupdivo' class='logdiv wallet-overlay' style='display:none;'></div>

    <div id='popupdiv' class='logdiv wallet-alert-overlay' style='display:none;top:2.5%;'>
        
        <div class='wallet-alert'>
            
            <div class='platformtitle border-radius-5px'>
                <p><u><b>Create an asset!</b></u></p>
            </div>
            
            <form method='post' enctype='multipart/form-data'>
                <label for='itemname'>Item name:</label> <input class='form form1l' placeholder='Item Name' name='itemname' minlength='4' maxlength='25' required><br><br><br>
                <textarea class='form form1l' name='itemdesc' placeholder='Description' minlength='5' maxlength='100' required></textarea><br><br><br>
                <label for='itemprice'>Price:</label> <input class='form form1l' type='number' value='0' name='itemprice' max='100000' min='0' required><br><br><br>
                <select class='form form1l' name='itempricetype'><option selected disabled>Price Type</option><option>COINS</option><option>BUCKS</option><option>OFFSALE</option><option>FREE</option></select><br><br><br>
                <label for='itemtype'>Type:</label> <select class='form form1l' name='itemtype'><option selected disabled>Item Type</option><option>PANTS</option><option>SHIRT</option></select><br><br><br>
                <input id='itemimg' type='file' name='itemimg' accept='.png'><br><br><br>
                <button class='button3 btn-blue nd hover'>Submit!</button>
            </form>
            
            <br><button onclick='close()' class='button3 btn-blue nd hover'>Close</button>
    
        </div>
    </div>
    
    <script>
    
    function create() {
        document.getElementById('popupdiv').style.display = 'block';
        document.getElementById('popupdivo').style.display = 'block';
    }
    
    function close() {
        document.getElementById('popupdiv').style.display = 'none';
        document.getElementById('popupdivo').style.display = 'none';
    }
    
    </script>";}echo"
    
    <br><br>
    
</div>

<div class='doublebox box3'>
    
    <div class='platformtitle shadow'>
        <p><u><b>Market</b></u></p>
    </div>
    
    <br><br>
    
    ";
    
    while(($i = mysqli_fetch_array($q))){
        
        //price
        
      if($i['RARITY'] == 'EPIC' && ( ($i['ONSALE_TIME']<time() && $i['ONSALE_TIME'] != 0) || ($i['STOCK_REMAINING']==0 && $i['STOCK'] != 0) )){
        $hrs = mysqli_query($conn,"SELECT * FROM `RESELLERS` WHERE `ITEM` = '$i[0]' AND `BOUGHT` = '0' ORDER BY `PRICE` ASC LIMIT 1");
        if(mysqli_num_rows($hrs) == 0){$price = "No-one is reselling";}else{$price = "Resale: <i class='fa fa-money-bill-alt'></i> " . mysqli_fetch_array($hrs)['PRICE'];}
      }else{
        if($i['PRICE_TYPE']=='COINS'&&$i['PRICE']!=0){
            $price = "<i class='fa fa-coins'></i> $i[PRICE]";
        }elseif($i['PRICE_TYPE']=='BUCKS'&&$i['PRICE']!=0){
            $price = "<i class='fa fa-money-bill-alt'></i> $i[PRICE]";
        }elseif($i['PRICE_TYPE']=='FREE'){
            $price = "Free!";
        }else{
            $price = "Offsale!";
        }}
        
        //rarity
        
        if($i['RARITY']=='DEF'){
          	if($i['ONSALE_TIME']==0){
            	$color = 'txtcol-white';
            }else{
              	$color = 'txtcol-red';
            }
        }elseif($i['RARITY']=='RARE'){
            $color = 'txtcol-purple';
        }elseif($i['RARITY']=='WAR'){
            $color = 'txtcol-war';
        }elseif($i['RARITY']=='EPIC'){
            $color = 'txtcol-gold';
        }elseif($i['RARITY']=='EVENT'){
            $color = 'txtcol-green';
        }elseif($i['RARITY']=='CUSTOM'){
            $color = 'txtcol-blue';
        }else{
            $color = 'txtcol-white';
        }
        
        //type
        
        if($i['ONSALE_TIME']==0){
          if($i['RARITY']=='EPIC'){
            if($i['STOCK_REMAINING']==0){
              $type = 'Sold Out!';
            }else{
              $type = "<span class='txtcol-red'>$i[STOCK_REMAINING] Left!</span>";
            }
          }else{
            $sales = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM `INV` WHERE `ITEM` = '$i[0]'"));
            $type = "$sales Sales";
          }
              
        }else{
          if($i['ONSALE_TIME']<time()){
            $type = 'Ran out of time!';
          }else{
           	$tL = $i['ONSALE_TIME']-time();
            #$tL = (time() + (1 * 90)) - time();
            if($tL<=86400){
              if($tL<=3600){
                $timeLeft = floor($tL / 60) . ' Minutes Left.';
              }else{
                $timeLeft = floor($tL / 3600) . ' Hours Left.';
              }
            }else{
              $timeLeft = floor($tL / 86400) . ' Days Left.';
            }
            $type = "<span class='txtcol-red'>$timeLeft</span>";
          }
        }
    
        echo"
    
        <a href='/Market/Item/$i[0]' class='nd asset'>
            <div class='marketcard'>
                <div class='marketcard-img'>
                    ";
      				
      				if($i['RARITY']=='EPIC'){
                      if($i['ONSALE_TIME']==0){
                        $v = "/Misc/IMGS/LimitedTag.png";
                      	#echo"<img src='/Misc/IMGS/LimitedTag.png' class='avatar' style='background-image:url(\"$i[PREV_IMG]\");background-repeat: no-repeat;'>";
                      }else{
                        $v = "/Misc/IMGS/LimitedTimerTag.png";
                        #echo"<img src='/Misc/IMGS/LimitedTimerTag.png' class='avatar' style='background-image:url(\"$i[PREV_IMG]\");background-repeat: no-repeat;'>";
                      }
                    }elseif($i['RARITY']=='RARE'){
                      if($i['ONSALE_TIME']==0){
                        $v = "/Misc/IMGS/RareTag.png";
                      	#echo"<img src='/Misc/IMGS/RareTag.png' class='avatar' style='background-image:url(\"$i[PREV_IMG]\");'>";
                      }else{
                        $v = "/Misc/IMGS/RareTimerTag.png";
                        #echo"<img src='/Misc/IMGS/RareTimerTag.png' class='avatar' style='background-image:url(\"$i[PREV_IMG]\");'>";
                      }
                    }elseif($i['RARITY']=='EVENT'){
                      if($i['ONSALE_TIME']==0){
                        $v = "/Misc/IMGS/EventTag.png";
                      	#echo"<img src='/Misc/IMGS/EventTag.png' class='avatar' style='background-image:url(\"$i[PREV_IMG]\");'>";
                      }else{
                        $v = "/Misc/IMGS/EventTimerTag.png";
                        #echo"<img src='/Misc/IMGS/EventTimerTag.png' class='avatar' style='background-image:url(\"$i[PREV_IMG]\");'>";
                      }
                    }elseif($i['RARITY']=='CUSTOM'){
                        $v = "/Misc/IMGS/CustomTag.png";
                      #echo"<img src='/Misc/IMGS/CustomTag.png' class='avatar' style='background-image:url(\"$i[PREV_IMG]\");'>";
                    }elseif($i['RARITY']=='VIP'){
                        $v = "/Misc/IMGS/VipTag.png";
                      #echo"<img src='/Misc/IMGS/VipTag.png' class='avatar' style='background-image:url(\"$i[PREV_IMG]\");'>";
                    }elseif($i['RARITY']=='FEATURED'){
                        $v = "/Misc/IMGS/FeaturedTag.png";
                    }
      
      				if($i['RARITY']=='DEF'){
                      if($i['ONSALE_TIME']==0){
                      	echo"<img src='$i[PREV_IMG]' class='avatar'>";
                      }else{
                        echo"<img src='/Misc/IMGS/TimerTag.png' class='avatar' style='background-image:url(\"$i[PREV_IMG]\");background-repeat: no-repeat;background-size: cover;'>";
                      }
                    }else{
                      echo"<img src='$v' class='avatar' style='background-image:url(\"$i[PREV_IMG]\");background-repeat: no-repeat;background-size: cover;'>";
                    }
      
      $ttl = lgt($i[1]);
      
      				echo"
                </div>
                <div class='$color'>
                    <p>$ttl</p>
                    <p>$price</p>
                    <p>$type</p>
                </div>
            </div>&nbsp;&nbsp;
        </a>
        
        ";
    
    }
    
    echo"
    
    <br><br>
    
    ";
    
    if(intval($pageID)!=1){
        echo "<a class='button3 btn-blue nd hover' href='?sort=$sort&page=". strval(intval($pageID) - 1) ."'><i class='fa fa-arrow-left'></i> Previous</a>";
    }else{

        echo "<a class='button3 btn-nbg nd hover'><i class='fa fa-arrow-left'></i> Previous</a>";
    }
    
    echo"
    
    &nbsp;&nbsp; Page $pageID &nbsp;&nbsp;
    
    ";

	if(mysqli_num_rows($q) < 15){
      echo "<a class='button3 btn-nbg nd hover'><i class='fa fa-arrow-right'></i> Next</a>";
    }else{
      echo"<a class='button3 btn-blue nd hover' href='?sort=$sort&page=". strval(intval($pageID) + 1) ."'><i class='fa fa-arrow-right'></i> Next</a>";
    }
    
    echo"
      
    <br><br>
    
</div>

</div>

";
/*
echo(time() + (3 * 86400));
echo"<br>";
echo(time() + (12 * 3600));
echo"<br>";
echo(time() + (30 * 60));*/

?>