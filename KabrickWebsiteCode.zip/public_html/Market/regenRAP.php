<?php
include($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');

if(!isset($_COOKIE['KABRICK_U']) || !isset($_COOKIE['KABRICK_P'])){
    exit();
}

if($ar<3){exit();}

if(isset($_GET['id'])){
$id = mysqli_real_escape_string($conn,$_GET['id']);
$itemQ = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$id'");

if(mysqli_num_rows($itemQ)!=1){
    echo"<script>window.location='/Market/'</script>";exit();
}
  
$i = mysqli_fetch_array($itemQ);

if($i['RARITY']!='EPIC'){exit();}
  
#gen rap
$rsales = mysqli_query($conn,"SELECT * FROM `SALES` WHERE `ITEM` = '$id' LIMIT 5");
if(mysqli_num_rows($rsales)==0){$rap = 0;}else{
  if(mysqli_num_rows($rsales)==1){$rap = mysqli_fetch_array($rsales)['PRICE'];}else{
  $sp = array();
  
  while(($s = mysqli_fetch_array($rsales))){
    if($s['PRICE']>($i['RAP'] - 25) && $s['PRICE']<($i['RAP'] + 50)){ array_push($sp,$s['PRICE']); } // cancel adding if: rap - 25 < price < rap + 50
  }
  
  $rap = 0;
  
  foreach($sp as $x){
    $rap+=$x;
  }
    
  $rap /= count($sp);
 
}}
  
//update rap
$frap = floor($rap);
mysqli_query($conn,"UPDATE `MARKET` SET `RAP` = '$frap' WHERE `ID` = '$id'");
  
  echo"<script>window.location='/Market/Item/$id'</script>";exit();
    
}