<?php
include("../Misc/connect.php");
include("../bbcode.php");

if(!isset($_GET['id'])){
  exit();
}

$id = mysqli_real_escape_string($conn,$_GET['id']);
$owners = mysqli_query($conn,"SELECT * FROM `INV` WHERE `ITEM` = '$id'");

$viewINVID = true;
$rank = $account['RANK'];
if($rank=='OWNER'||$rank=='MANAGER'||$rank=='EXECUTIVE'){
  /*if($rank=='OWNER'||$rank=='MANAGER'){
    $viewINVID = true;
  }*/
}else{
  echo"You do not have the permissions to view this page!";
}

echo"

<div class='platformtitle'>
	<p>Owners (". mysqli_num_rows($owners) .")</p>
</div>

<button onclick='Comments()' class='button2 nd btn-blue'>Comments</button>
<button onclick='Resellers()' class='button2 nd btn-blue'>Resellers</button>
<button onclick='Owners()' class='button2 nd btn-red'>Owners</button>

<br><br>

";

if(mysqli_num_rows($owners)==0){
  echo"This item has no owners :(";
}else{
  echo"<table>";
  if($viewINVID==true){echo"<tr><th>INVID</th><th>USER</th><th>SERIAL</th></tr>";}
  else{echo"<tr><th>USER</th><th>SERIAL</th></tr>";}
  while(($i=mysqli_fetch_array($owners))){
    
    $getUser = mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$i[USER]'");
    $u = mysqli_fetch_array($getUser);
    
    
	if($viewINVID == true){
      echo"<tr><td><a href='/Admin/Trace/?id=$i[ID]'>$i[ID]</a></td><td><a href='/Profile/$u[1]'>$u[1]</a></td><td>$i[SERIAL]</td></tr>";
    }else{
      echo"<tr><td><a href='/Profile/$u[1]'>$u[1]</a></td><td>$i[SERIAL]</td></tr>";
    }
  }
}

?>