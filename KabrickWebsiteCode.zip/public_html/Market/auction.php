<?php
include("../Misc/connect.php");

if(!isset($_COOKIE['KABRICK_U']) || !isset($_COOKIE['KABRICK_P'])){
    exit();
}else{
  $e = true;
}

if(!isset($_GET['id'])){
  exit();
}

$id = mysqli_real_escape_string($conn,$_GET['id']);
$item = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$id'"));

if($e==true){
  $rank = $account['RANK'];
  if($rank=='OWNER'||$rank=='MANAGER'||$rank=='EXECUTIVE'||$rank=='ADMIN'){
    $adminABUSE = true;
  }else{
    $adminABUSE = false;
  }
}else{
  exit();
}

echo"

<div class='platformtitle'>
	<p>Auction Item</p>
</div>

<button onclick='Comments()' class='button2 nd btn-blue'>Comments</button>
"; if($item['RARITY'] == 'EPIC'){echo"<button onclick='Auction()' class='button2 nd btn-blue'>Auction</button>
    <button onclick='Resellers()' class='button2 nd btn-blue'>Resellers</button>";} echo"
"; if($adminABUSE == true){echo"<button onclick='Owners()' class='button2 nd btn-red'>Owners</button>";} 

if($item['RARITY']!='EPIC'){
echo"<br><br>You are only able to auction <u>Limited</u> items.";exit();
}

$invQ = mysqli_query($conn,"SELECT * FROM `INV` WHERE `ITEM` = '$id' AND `USER` = '$account[0]'");
$invcheck = mysqli_num_rows($invQ);
if($invcheck==0){echo"<br><br>You do not have this item.";}else{

echo"

<br><br>

<form method='post' action='/Auction/create.php'>
  
  Serial: <select class='form form1l' name='serialid'>
  	";
  
  	while(($s = mysqli_fetch_array($invQ))){
      echo"<option>$s[SERIAL]</option>";
    }
  
  echo"
  </select><br><br>
  
  <input type='number' max='250' min='10' class='form form1l' name='startingbid' placeholder='Starting Bid'><br><br>
  
  <button class='button btn-blue nd hover' value='$id' name='id'>Sell!</button>
  
</form>

";}

?>