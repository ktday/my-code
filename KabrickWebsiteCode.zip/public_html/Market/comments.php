<?php
include("../Misc/connect.php");
include("../bbcode.php");

if(!isset($_COOKIE['KABRICK_U']) || !isset($_COOKIE['KABRICK_P'])){
    $e = false;
}else{
  $e = true;
}

if(!isset($_GET['id'])){
  exit();
}

$id = mysqli_real_escape_string($conn,$_GET['id']);
$comments = mysqli_query($conn,"SELECT * FROM `COMMENTS` WHERE `ITEM` = '$id' ORDER BY `ID` DESC");
$item = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$id'"));

if($e==true){
  $rank = $account['RANK'];
  if($rank=='OWNER'||$rank=='MANAGER'||$rank=='EXECUTIVE'||$rank=='ADMIN'){
    $adminABUSE = true;
  }else{
    $adminABUSE = false;
  }
}else{
  $adminABUSE = false;
}

echo"

<div class='platformtitle'>
	<p>Comments (". mysqli_num_rows($comments) .")</p>
</div>

<button onclick='Comments()' class='button2 nd btn-blue'>Comments</button>
"; if($item['RARITY'] == 'EPIC'){echo"<button onclick='Auction()' class='button2 nd btn-blue'>Auction</button>
<button onclick='Resellers()' class='button2 nd btn-blue'>Resellers</button>";} echo"
"; if($adminABUSE == true){echo"<button onclick='Owners()' class='button2 nd btn-red'>Owners</button>";} echo"

<br><br>

<form method='post'>
  Post a comment!<br>
  <textarea class='form form1l' name='COMMENT' placeholder='Comment' minlength='2' maxlength='255' required=''></textarea><br>
  <button class='button3 btn-blue nd hover' name='itemid' value='$id'>Post!</button>
</form>

";

if(mysqli_num_rows($comments)==0){
  echo"This item has no comments :(";
}else{
  while(($i=mysqli_fetch_array($comments))){
    
    $getUser = mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$i[USER]'");
    $u = mysqli_fetch_array($getUser);
    
    if($i['CENSORED']==1){
      if($adminABUSE==true){
        $c = "[CENSORED]<br>".bbcode_to_html($i['COMMENT']);
      }else{
        $c = "[CENSORED]";
      }
    }else{
      $c = bbcode_to_html($i['COMMENT']);
    }
    
    echo"
    
    <div style='width:80%;margin:auto;'>
    
      <img src='$u[AVATAR_IMG_URL]' class='fl' style='left:1rem;'>
      
      <br><br>
      $c<br><br>
      
      <span style='bottom:1rem;'>Posted By <a href='/Profile/$u[1]'>$u[1]</a></span>
    
    </div>
    
    <br><br><br><br><br><br> <hr> <br>
    
    ";
  }
}

?>