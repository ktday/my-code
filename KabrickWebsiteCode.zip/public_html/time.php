<?php
echo"<style>body{background:#000;color:#fff;}</style>";
echo(time());
if(isset($_GET['a'])){
  echo"<br>";
  echo(time() + $_GET['a']);
}
if(isset($_GET['m'])){
  echo"<br>";
  echo(time() + ($_GET['m']) * 60);
}
if(isset($_GET['h'])){
  echo"<br>";
  echo(time() + ($_GET['h']) * 3600);
}
if(isset($_GET['d'])){
  echo"<br>";
  echo(time() + ($_GET['d']) * 86400);
}

$string = '24h';
  echo"<br>";
echo(substr($string,-1));
  echo"<br>";
echo(rtrim($string, "h"));

?>