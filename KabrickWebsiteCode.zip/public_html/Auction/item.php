<?php

##############################################################################################
# Rarity       # Stock?  # Limited Time?   # Who?           # Color       # Can have timer?  #
##############################################################################################
# DEF          # No      # No              # All            # White       # Yes              #
# RARE         # No      # No              # All            # Purple      # Yes              #
# EPIC         # Yes     # No              # All            # Gold        # Yes              #
# EVENT        # No      # No              # All            # Green       # Yes              #
# VIP          # No      # No              # VIP Users      # White       # No               #
# CUSTOM       # No      # No              # Custom Owner   # Blue        # No               #
# DEF + Timer  # No      # Yes             # All            # Red         #                  #
# RARE + Timer # No      # Yes             # All            # Purple      #                  #
# EPIC + Timer # No      # Yes             # All            # Gold        #                  #
# EVENT + Timer# No      # Yes             # All            # Green       #                  #
##############################################################################################

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');

if(!isset($_COOKIE['KABRICK_U']) || !isset($_COOKIE['KABRICK_P'])){
    $e = false;
}else{
  $e = true;
}

if(isset($_GET['id'])){
$id = mysqli_real_escape_string($conn,$_GET['id']);
$aQ = mysqli_query($conn,"SELECT * FROM `AUCTION` WHERE `ID` = '$id'");

if(mysqli_num_rows($aQ)!=1){
    echo"<script>window.location='/Auction/'</script>";exit();
}

$a = mysqli_fetch_array($aQ);
$uQ = mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$a[USER]'");
$u = mysqli_fetch_array($uQ);
  
if($a['WINNER']!=0){echo"<script>window.location='/Auction/'</script>";exit();}
  
$i = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$a[ITEM]'"));
$inv = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `INV` WHERE `ID` = '$a[INVID]'"));
$bidsQ = mysqli_query($conn,"SELECT * FROM `BIDS` WHERE `AUCTION` = '$a[0]' ORDER BY `ID` DESC");
$bids = mysqli_num_rows($bidsQ);

$t1 = date("H:i", $a['TIME']);
$t2 = gmdate("j F Y", $a['TIME']);

/*if(strlen($i['NAME'])>10){
    $name = substr($i['NAME'], 0, 10)."..";
}else{
    $name = $i['NAME'];
}*/

if($i['STATUS']=='BAN'&&$account[0]!=2){echo"<script>window.location='/Market/'</script>";exit();
                                       
                                       
                                       
                                       }



echo"<title>Auction House ($i[1]) | $meta_name</title>";

/*if($i['STATUS']=='SECRET'&&$isowned==0){echo"<script>window.location='/Market/'</script>";exit();}*/

if($bids==0){
  $price = "Starting bid: <i class='fa fa-money-bill-alt'></i> $a[STARTINGBID]";
}else{
  $hbid = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `BIDS` WHERE `AUCTION` = '$a[0]' ORDER BY `ID` DESC LIMIT 1"));
  $price = "Highest Bid: <i class='fa fa-money-bill-alt'></i> $hbid[PRICE]";
  $a1 = $hbid['PRICE'] + 1;
}

//rarity

$color = 'txtcol-gold';
  
if($i['RARITY']=='EPIC'){
  if($i['ONSALE_TIME']==0){
  $v = "/Misc/IMGS/LimitedTag.png";
  }else{
  $v = "/Misc/IMGS/LimitedTimerTag.png";
  }
}
  
$img = "<img src='$v' class='avatar' style='background-image:url(\"$i[PREV_IMG]\");background-repeat: no-repeat;background-size: cover;'>";
  
if($i['STATUS']=='SECRET'){
    /*$color = "txtcol-red";*/
    $iota = " <i class='fa fa-lock'></i>";
}else{
    $iota = "";
}

//type

if($i['TYPE']=='HAT'){
    $type = 'Hat';
}elseif($i['TYPE']=='FACE'){
    $type = 'Face';
}elseif($i['TYPE']=='MASK'){
    $type = 'Face Accessory';
}elseif($i['TYPE']=='GEAR'){
    $type = 'Tool';
}elseif($i['TYPE']=='SHOULDER'){
    $type = 'Shoulder Item';
}elseif($i['TYPE']=='BACK'){
    $type = 'Back Item';
}elseif($i['TYPE']=='BODY'){
    $type = 'Body';
}elseif($i['TYPE']=='SHIRT'){
    $type = 'Shirt';
}elseif($i['TYPE']=='PANTS'){
    $type = 'Pants';
}else{
    $type = '???';
}
  
$bidtime = $a['TIME'] + 86400;
  
  if($bidtime>time()){
    $tL = $bidtime-time();
    #$tL = (time() + (1 * 90)) - time();
    if($tL<=86400){
      if($tL<=3600){
        $timeLeft = floor($tL / 60) . ' Minutes Left.';
      }else{
        $timeLeft = floor($tL / 3600) . ' Hours Left.';
      }
    }else{
      $timeLeft = floor($tL / 86400) . ' Days Left.';
    }
  }else{
  	$timeLeft = 'Out of time!';
    
    // BID ENDS FUNCTION
    
    if($bids == 0){
    
      mysqli_query($conn,"INSERT INTO `MESSAGES` VALUES(NULL,'1','$a[USER]','Your bid on #$inv[SERIAL] $i[1] has ended with no bids! The item will remain in your inventory.','NO','$time','Bid has ended!')");
      
      mysqli_query($conn,"UPDATE `AUCTION` SET `WINNER` = '1' WHERE `ID` = '$a[0]'");
      echo"<script>window.location='/Auction/'</script>";exit();
    
    }else{
    
      $hbid = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `BIDS` WHERE `AUCTION` = '$a[0]' ORDER BY `ID` DESC LIMIT 1"));
      
      $bidder = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$hbid[USER]'"));
      if($bidder['BUCKS']<$hbid['PRICE']){
        mysqli_query($conn,"INSERT INTO `MESSAGES` VALUES(NULL,'1','2','[Bid id $a[0] in item $i[1] #$inv[SERIAL]] $bidder[1] ($bidder[0]) Bid $hbid[PRICE] but did not have enough.','NO','$time','Bid error report')");
      	if($bids > 1){
          $sbid = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `BIDS` WHERE `AUCTION` = '$a[0]' AND `ID` < '$hbid[0]' ORDER BY `ID` DESC LIMIT 1"));
          $sbidder = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$sbid[USER]'"));
          if($sidder['BUCKS']<$sbid['PRICE']){
            mysqli_query($conn,"INSERT INTO `MESSAGES` VALUES(NULL,'1','2','[Bid id $a[0] in item $i[1] #$inv[SERIAL]] $bidder[1] ($bidder[0]) Bid $hbid[PRICE] but did not have enough. (2nd bidder)','NO','$time','Bid error report #2')");
            mysqli_query($conn,"INSERT INTO `MESSAGES` VALUES(NULL,'1','$a[USER]','Your bid on #$inv[SERIAL] $i[1] has ended, but both bidders ($bidder[0] & $sbidder[1]) did not have enough bucks; The item will remain in your inventory.','NO','$time','Bid has ended!')");
          }else{
            // Bidder #2 had enough
        
            $DEV_Q = mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$a[USER]'");
            $DEV_A = mysqli_fetch_array($DEV_Q);
            $ADM_Q = mysqli_query($conn,"SELECT * FROM `CURRENT_ECONOMY` WHERE `ID` = '1'");
            $ADM_A = mysqli_fetch_array($ADM_Q);

            //ammount to pay devs
            $DEVSCOINSQ = ($sbid['PRICE']/10)*7;
            $ADMINSCOINSQ = ($sbid['PRICE']/10)*3;
            $DEVSCOINS = $DEV_A['BUCKS'] + $DEVSCOINSQ;
            $ADMINSCOINS = $ADM_A['BUCKS'] + $ADMINSCOINSQ;

            $USERCOINS = $sbidder['BUCKS'] - $sbid['PRICE'];

            //pay devs
            mysqli_query($conn,"UPDATE `USERS` SET `BUCKS` = '$USERCOINS' WHERE `ID` = '$sbid[USER]'");
            mysqli_query($conn,"UPDATE `USERS` SET `BUCKS` = '$DEVSCOINS' WHERE `ID` = '$DEV_A[0]'");
            mysqli_query($conn,"UPDATE `CURRENT_ECONOMY` SET `BUCKS` = '$ADMINSCOINS' WHERE `ID` = '1'");

            //transfer item
            mysqli_query($conn,"UPDATE `INV` SET `USER` = '$sbidder[0]' WHERE `ID` = '$inv[0]'");
            mysqli_query($conn,"INSERT INTO `MESSAGES` VALUES(NULL,'1','$a[USER]','Your bid on #$inv[SERIAL] $i[1] has ended! The second bidder ($sbidder[1]) won the bid for $sbid[PRICE]!','NO','$time','Bid has ended!')");
            mysqli_query($conn,"INSERT INTO `MESSAGES` VALUES(NULL,'1','$sbid[USER]','You won the bid on #$inv[SERIAL] $i[1] for $sbid[PRICE]! The item has been transferred to your inventory!','NO','$time','Bid has ended!')");


            mysqli_query($conn,"UPDATE `AUCTION` SET `WINNER` = '$sbid[USER]' WHERE `ID` = '$a[0]'");
            echo"<script>window.location='/Auction/'</script>";exit();
          }
        }else{
          mysqli_query($conn,"INSERT INTO `MESSAGES` VALUES(NULL,'1','$a[USER]','Your bid on #$inv[SERIAL] $i[1] has ended, but the only bidder ($bidder[0]) did not have enough bucks (Bid: $hbid[PRICE]); The item will remain in your inventory.','NO','$time','Bid has ended!')"); 
        }
      }else{
        // Bidder #1 has enough
        
        $DEV_Q = mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$a[USER]'");
        $DEV_A = mysqli_fetch_array($DEV_Q);
        $ADM_Q = mysqli_query($conn,"SELECT * FROM `CURRENT_ECONOMY` WHERE `ID` = '1'");
        $ADM_A = mysqli_fetch_array($ADM_Q);

        //ammount to pay devs
        $DEVSCOINSQ = ($hbid['PRICE']/10)*7;
        $ADMINSCOINSQ = ($hbid['PRICE']/10)*3;
        $DEVSCOINS = $DEV_A['BUCKS'] + $DEVSCOINSQ;
        $ADMINSCOINS = $ADM_A['BUCKS'] + $ADMINSCOINSQ;
        
        $USERCOINS = $bidder['BUCKS'] - $hbid['PRICE'];

        //pay devs
        mysqli_query($conn,"UPDATE `USERS` SET `BUCKS` = '$USERCOINS' WHERE `ID` = '$hbid[USER]'");
        mysqli_query($conn,"UPDATE `USERS` SET `BUCKS` = '$DEVSCOINS' WHERE `ID` = '$DEV_A[0]'");
        mysqli_query($conn,"UPDATE `CURRENT_ECONOMY` SET `BUCKS` = '$ADMINSCOINS' WHERE `ID` = '1'");
        
        //transfer item
        mysqli_query($conn,"UPDATE `INV` SET `USER` = '$bidder[0]' WHERE `ID` = '$inv[0]'");
        mysqli_query($conn,"INSERT INTO `MESSAGES` VALUES(NULL,'1','$a[USER]','Your bid on #$inv[SERIAL] $i[1] has ended! $bidder[1] won the bid for $hbid[PRICE]!','NO','$time','Bid has ended!')");
        mysqli_query($conn,"INSERT INTO `MESSAGES` VALUES(NULL,'1','$hbid[USER]','You won the bid on #$inv[SERIAL] $i[1] for $hbid[PRICE]! The item has been transferred to your inventory!','NO','$time','Bid has ended!')");
        
        mysqli_query($conn,"UPDATE `AUCTION` SET `WINNER` = '$hbid[USER]' WHERE `ID` = '$a[0]'");
        echo"<script>window.location='/Auction/'</script>";exit();
        
      }
    
    }
      
  }
  
if($e==true){
  $rank = $account['RANK'];
  if($rank=='OWNER'||$rank=='MANAGER'||$rank=='EXECUTIVE'||$rank=='ADMIN'){
    $adminABUSE = true;
  }else{
    $adminABUSE = false;
  }
}else{
  $adminABUSE = false;
}
  
if($e==true){
  if($bids==0){
    $btn = "<a class='button2 btn-green hover nd w2r' href='?bid=$id'>Place First Bid!</a>";
  }else{
    $btn = "
    
    <form>
    
    <input class='form form1l' name='price' type='number' min='$a1' value='$a1'>
    
    <button name='bid' value='$id' class='button2 btn-green hover nd w2r'>Bid!</button>
    
    </form>
    
    ";
  }
      
}else{
  $btn = "<a class='button2 btn-red hover nd w2r'>Log in to buy items</a>";
}
  
if($i['STATUS']=='AP'){$st = "Approved";}
elseif($i['STATUS']=='BAN'){$st = "Deleted";}
elseif($i['STATUS']=='UAP'){$st = "Pending Approval";}
else{$s = "Secret (oooohhhhhhhh...)";}
  
### SCRIPTS ###
  
echo"

<div class='platform'>
    
    <br>
    
    <div class='itemcard shadow'>
        <div class='absolute w20'></div>
        
        <div class='itemcard-info absolute'>
            <h2><span class='$color'>$i[1] ($type)$iota</span><br>
            <a href='/Profile/$u[1]' class='small1 nd'>By $u[1]</a></h2>
            $btn &nbsp;&nbsp;
        </div>
        <div class='itemcard-img'>
            $img<br><br>
        </div>
    </div>
    
    <br>
    
</div>

<br><br><br>

<div class='doublebox box1'>
	<div class='platformtitle'>
    	<p>Item Info</p>
    </div>
    
    <p class='txtcol-green'>$price</p>
    <p class='txtcol-gold'>Serial: #$inv[SERIAL]</p>
    <p>Bids: $bids</p>
    "; if($i['RARITY']=='EPIC'&&$i['STOCK_REMAINING']!=0&&$i['ONSALE_TIME']==0){echo"<p class='txtcol-red'>($i[STOCK_REMAINING] left of $i[STOCK])</p>";}
  	elseif($i['RARITY']=='EPIC'&&$i['STOCK_REMAINING']==0&&$i['ONSALE_TIME']==0){echo"<p class='txtcol-red'>Sold out with $i[STOCK] stock</p>";} echo"
    <p>Bid Started: $t1, $t2</p>
    <p>Bid Ends: $timeLeft</p>
    
    <p>Starting Price: $a[STARTINGBID]</p>

</div>

<div class='doublebox box2'>

	<div class='platformtitle'>
    	<p>Highest Bids</p>
    </div>
    
    ";
  
  	$x = 1;
  
  	while(($b = mysqli_fetch_array($bidsQ))){
      if($x <= 3){
        $x++;
      	$getUser = mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$b[USER]'");
      	$u = mysqli_fetch_array($getUser);
        echo"
    
        <div style='width:80%;margin:auto;'>

          <img src='$u[AVATAR_IMG_URL]' class='fl' style='left:1rem;'>

          <br><br>
          <i class='fa fa-money-bill-alt'></i> $b[PRICE]<br><br>

          <span style='bottom:1rem;'>Bidder: <a href='/Profile/$u[1]'>$u[1]</a></span>

        </div>

        <br><br><br><br><br><br> <hr> <br>

        ";
      }
    }
  
  	if($bids==0){
      echo"There are no bids!";
    }
  
  echo"

</div>

";

}elseif(isset($_GET['bid'])){
    
    $id = mysqli_real_escape_string($conn,$_GET['bid']);
    $aQ = mysqli_query($conn,"SELECT * FROM `AUCTION` WHERE `ID` = '$id'");

    if(mysqli_num_rows($aQ)!=1){
        echo"<script>window.location='/Auction/'</script>";exit();
    }

    $a = mysqli_fetch_array($aQ);
  
  	if($a['USER'] == $account[0]){echo"<script>window.alert('Nice try...');window.location='/Auction/item.php?id=$id'</script>";exit();}
  
  	if($a['TIME'] + 86400 <= time()){echo"<script>window.alert('Time ran out!');window.location='/Auction/item.php?id=$id'</script>";exit();}

    $i = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$a[ITEM]'"));
    $inv = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `INV` WHERE `ID` = '$a[INVID]'"));
    $bids = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM `BIDS` WHERE `AUCTION` = '$a[0]'"));
    $hbidQ = mysqli_query($conn,"SELECT * FROM `BIDS` WHERE `AUCTION` = '$a[0]' ORDER BY `ID` DESC LIMIT 1");
  
  	if($inv['USER'] != $a['USER']){echo"<script>window.alert('Invalid Bid!');window.location='/Auction/'</script>";
                                   mysqli_query($conn,"INSERT INTO `MESSAGES` VALUES(NULL,'1','$a[USER]','Your bid on #$inv[SERIAL] $i[1] has ended due to the item being removed from your inventory!','NO','$time','Error with bid')");
                                   mysqli_query($conn,"DELETE FROM `AUCTION` WHERE `ID` = '$id'");
                                   mysqli_query($conn,"DELETE FROM `BIDS` WHERE `AUCTION` = '$id'");
                                  exit();}
  
  	if($bids==0){
      $price = $a['STARTINGBID'];
      if($account['BUCKS']<$price){
        echo"<script>window.alert('Not enough bucks!');window.location='/Auction/item.php?id=$id'</script>";exit();
      }else{
        mysqli_query($conn,"INSERT INTO `BIDS` VALUES(NULL,'$id','$account[0]','$price')");
      }
    }else{
      if( !isset($_GET['price']) || !is_numeric($_GET['price']) ){
        echo"<script>window.alert('Invalid price set!');window.location='/Auction/item.php?id=$id'</script>";exit();
      }else{
        $price = mysqli_real_escape_string($conn,$_GET['price']);
        if($account['BUCKS']<$price){
          echo"<script>window.alert('Not enough bucks!');window.location='/Auction/item.php?id=$id'</script>";exit();
        }else{
          mysqli_query($conn,"INSERT INTO `BIDS` VALUES(NULL,'$id','$account[0]','$price')");
        }
      }
    }

    echo"<script>window.alert('Successfully set bid on $i[1] for $price Bucks!');window.location='/Auction/item.php?id=$id'</script>";exit();
    
}else{

  
}

?>