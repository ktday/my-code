<?php

include_once($_SERVER['DOCUMENT_ROOT'] . '/Misc/connect.php');
include_once($_SERVER['DOCUMENT_ROOT'] . '/Misc/vars.php');

function sendEmbed($id){
  global $conn;
  global $meta_blank_url;
  $infoQ = mysqli_query($conn, "SELECT * FROM `AUCTION` WHERE `ID`='$id'");
  $info = mysqli_fetch_array($infoQ);
  $u = mysqli_fetch_array(mysqli_query($conn, "SELECT * FROM `USER` WHERE `ID`='$info[USER]'"));
  $discordWebhookUrl = "https://discord.com/api/webhooks/1169238627813953616/nk9-R7q4k3hziVc0ah64-Pv0puQyvzdy1asC-kNbrP7dpMM7HeOsUP24Npmt06cXbgRk";
  $discordWebhookData = array(
    "embeds" => array(
      array("title"=>"An Auction has started!","description"=>"An Auction has started by $u[USERNAME]","url"=>"http://$meta_blank_url/Auction/item.php?id=$id")#16762880 limiteds
    ),
    "content" => $cont
  );
  $opts = array(
    "http" => array(
      "header" => "Content-Type: application/json\r\n",
      "method" => "POST",
      "content" => json_encode($discordWebhookData)
    )
  );
  $context = stream_context_create($opts); $result = file_get_contents($discordWebhookUrl, false, $context);
  return 1;
}