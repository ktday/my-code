<?php
include($_SERVER['DOCUMENT_ROOT'] . '/Misc/embed.php');

embed(
  "Auction",
  "The auction house is were you can auction off limited items for 24 hours!",
  "Auction/"
);

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');

echo"<title>Auction | $meta_name</title>";

if(!isset($_COOKIE['KABRICK_U']) || !isset($_COOKIE['KABRICK_P'])){
    $e = false;
}else{$e=true;}

$CURRENT_ECONOMY = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `CURRENT_ECONOMY` WHERE `ID` = '1'"));
$timegmt = time() - 18000;

$pageID = null;
if(!isset($_GET['sort'])){
    echo"<script>window.location='/Auction/?sort=all'</script>";exit();
}else{
    
    if(isset($_GET['page'])&&is_numeric($_GET['page'])){
        $pageID = intval(mysqli_real_escape_string($conn,$_GET['page']));
        $pageIDsq = ($pageID-1) * 15;
        if($pageID<1){
            $pageID = 1;
            $pageIDsq = 0;
        }
    }else{
        $pageID = 1;
        $pageIDsq = 0;
    }
    
    $sort = mysqli_real_escape_string($conn,$_GET['sort']);
    if($sort == 'all'){
        $q = mysqli_query($conn,"SELECT * FROM `AUCTION` WHERE `TYPE` != 'SHIRT' AND `TYPE` != 'PANTS' AND `WINNER` = '0' ORDER BY `TIME` DESC LIMIT $pageIDsq, 15");
    }elseif($sort == 'community'){
        $q = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `TYPE` = 'SHIRT' AND `WINNER` = '0' AND `ID` >= $pageIDsq OR `TYPE` = 'PANTS' AND `WINNER` = '0' AND `ID` >= $pageIDsq ORDER BY `UPDATE_TIME` DESC LIMIT 15");
    }elseif($sort == 'hat'){
        $q = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `TYPE` = 'HAT' AND `WINNER` = '0' AND `ID` >= $pageIDsq ORDER BY `UPDATE_TIME` DESC LIMIT 15");
    }elseif($sort == 'face'){
        $q = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `TYPE` = 'FACE' AND `WINNER` = '0' AND `ID` >= $pageIDsq ORDER BY `UPDATE_TIME` DESC LIMIT 15");
    }elseif($sort == 'mask'){
        $q = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `TYPE` = 'MASK' AND `WINNER` = '0' AND `ID` >= $pageIDsq ORDER BY `UPDATE_TIME` DESC LIMIT 15");
    }elseif($sort == 'tool'){
        $q = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `TYPE` = 'GEAR' AND `WINNER` = '0' AND `ID` >= $pageIDsq ORDER BY `UPDATE_TIME` DESC LIMIT 15");
    }elseif($sort == 'shoulder'){
        $q = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `TYPE` = 'SHOULDER' AND `WINNER` = '0' AND `ID` >= $pageIDsq ORDER BY `UPDATE_TIME` DESC LIMIT 15");
    }elseif($sort == 'shirt'){
        $q = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `TYPE` = 'SHIRT' AND `WINNER` = '0' AND `ID` >= $pageIDsq ORDER BY `UPDATE_TIME` DESC LIMIT 15");
    }elseif($sort == 'pants'){
        $q = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `TYPE` = 'PANTS' AND `WINNER` = '0' AND `ID` >= $pageIDsq ORDER BY `UPDATE_TIME` DESC LIMIT 15");
    }else{
        echo"<script>window.location='/Auction/?sort=all'</script>";exit();
    }
}
echo"

<div class='doublebox box4'>
    
    <div class='platformtitle'>
        <p><u><b>Sort</b></u></p>
    </div>
    
    <br>
    
    <a class='button btn-"; if($sort=='all'){echo"blue";}else{echo"nbg";} echo" hover nd' href='?sort=all'>All</a><br>
    <a class='button btn-"; if($sort=='community'){echo"blue";}else{echo"nbg";} echo" hover nd' href='?sort=community'>Community made</a><br>
    <br>
    <a class='button btn-"; if($sort=='hat'){echo"blue";}else{echo"nbg";} echo" hover nd' href='?sort=hat'>Hats</a><br>
    <a class='button btn-"; if($sort=='face'){echo"blue";}else{echo"nbg";} echo" hover nd' href='?sort=face'>Faces</a><br>
    <a class='button btn-"; if($sort=='mask'){echo"blue";}else{echo"nbg";} echo" hover nd' href='?sort=mask'>Face Accessories</a><br>
    <a class='button btn-"; if($sort=='tool'){echo"blue";}else{echo"nbg";} echo" hover nd' href='?sort=tool'>Tools</a><br>
    <a class='button btn-"; if($sort=='shoulder'){echo"blue";}else{echo"nbg";} echo" hover nd' href='?sort=shoulder'>Shoulder Items</a><br>
    <a class='button btn-"; if($sort=='shirt'){echo"blue";}else{echo"nbg";} echo" hover nd' href='?sort=shirt'>Shirts</a><br>
    <a class='button btn-"; if($sort=='pants'){echo"blue";}else{echo"nbg";} echo" hover nd' href='?sort=pants'>Pants</a><br><br>
    
    <br>
    <a class='button btn-blue hover nd' href='/Auction/create.php'>Create an auction</a>
    
    <br><br>
    
</div>

<div class='doublebox box3'>
    
    <div class='platformtitle shadow'>
        <p><u><b>Auction House</b></u></p>
    </div>
    
    <br><br>
    
    ";
    
    if($q == false || mysqli_num_rows($q)==0){echo"There are no auctions.";}else{
      while(($a = mysqli_fetch_array($q))){
        
      	$i = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$a[ITEM]'"));
      	$inv = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `INV` WHERE `ID` = '$a[INVID]'"));
      	$bids = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM `BIDS` WHERE `AUCTION` = '$a[0]'"));
      
        //price
      
      	if($bids==0){
          $price = "Starting bid: <i class='fa fa-money-bill-alt'></i> $a[STARTINGBID]";
        }else{
          $hbid = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `BIDS` WHERE `AUCTION` = '$a[0]' ORDER BY `ID` DESC LIMIT 1"));
          $price = "Highest Bid: <i class='fa fa-money-bill-alt'></i> $hbid[PRICE]";
        }
      
      	
      
        
        
        //rarity
            $color = 'txtcol-gold';
        
        //type
    
        echo"
    
        <a href='/Auction/item.php?id=$a[0]' class='nd asset'>
            <div class='marketcard'>
                <div class='marketcard-img'>
                    ";
      				
                      if($i['ONSALE_TIME']==0){
                        $v = "/Misc/IMGS/LimitedTag.png";
                      	#echo"<img src='/Misc/IMGS/LimitedTag.png' class='avatar' style='background-image:url(\"$i[PREV_IMG]\");background-repeat: no-repeat;'>";
                      }else{
                        $v = "/Misc/IMGS/LimitedTimerTag.png";
                        #echo"<img src='/Misc/IMGS/LimitedTimerTag.png' class='avatar' style='background-image:url(\"$i[PREV_IMG]\");background-repeat: no-repeat;'>";
                      }
      
                      echo"<img src='$v' class='avatar' style='background-image:url(\"$i[PREV_IMG]\");background-repeat: no-repeat;background-size: cover;'>";
      
      				echo"
                </div>
                <div class='$color'>
                    <p>(#$inv[SERIAL]) $i[1]</p>
                    <p>$price</p>
                    <p>$bids bids</p>
                </div>
            </div>&nbsp;&nbsp;
        </a>
        
        ";
    
    }}
    
    echo"
    
    <br><br>
    
    ";
    
    if(intval($pageID)!=1){
        echo "<a class='button3 btn-blue nd hover' href='?sort=$sort&page=". strval(intval($pageID) - 1) ."'><i class='fa fa-arrow-left'></i> Previous</a>";
    }else{

        echo "<a class='button3 btn-nbg nd hover'><i class='fa fa-arrow-left'></i> Previous</a>";
    }
    
    echo"
    
    &nbsp;&nbsp; Page $pageID &nbsp;&nbsp;
    
    <a class='button3 btn-blue nd hover' href='?sort=$sort&page=". strval(intval($pageID) + 1) ."'><i class='fa fa-arrow-right'></i> Next</a>
    
    <br><br>
    
</div>

</div>

";
/*
echo(time() + (3 * 86400));
echo"<br>";
echo(time() + (12 * 3600));
echo"<br>";
echo(time() + (30 * 60));*/

?>