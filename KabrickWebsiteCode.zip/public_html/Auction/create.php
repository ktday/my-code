<?php

include("../Misc/connect.php");

if(!isset($_COOKIE['KABRICK_U']) || !isset($_COOKIE['KABRICK_P'])){
    include("../404.php");exit();
}

if(!isset($_POST['serialid']) || !isset($_POST['startingbid']) || !isset($_POST['id'])){
  echo"<script>window.location='/Inventory/$account[1]'</script>";exit();
}

$id = mysqli_real_escape_string($conn,$_POST['id']);
$serial = mysqli_real_escape_string($conn,$_POST['serialid']);
$sbid = mysqli_real_escape_string($conn,$_POST['startingbid']);

$item = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$id'"));

if($item['STATUS']!='AP'){include("../404.php");exit();}

$invQ = mysqli_query($conn,"SELECT * FROM `INV` WHERE `ITEM` = '$id' AND `USER` = '$account[0]' AND `SERIAL` = '$serial'");
if(mysqli_num_rows($invQ)!=1){include("../404.php");exit();}

$inv = mysqli_fetch_array($invQ);

if($sbid<10){  echo"<script>window.alert('Price too low');window.location='/Market/item.php?id=$id'</script>";exit();}
if($sbid>250){echo"<script>window.alert('Price too high');window.location='/Market/item.php?id=$id'</script>";exit();}

$time = time();

mysqli_query($conn,"INSERT INTO `AUCTION` VALUES(NULL,'$id','$inv[0]','$account[0]','0','$time','$sbid','$item[TYPE]')");

echo"<script>window.location='/Auction/'</script>";exit();

?>