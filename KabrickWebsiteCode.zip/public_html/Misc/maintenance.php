<?php

function lockdown(){
  echo"<link rel='stylesheet' type='text/css' href='/Misc/gamma.css' />
  
  <center>
  <h1> Kabrick is in maintenance! </h1>
  </center>";
  
  exit();
}

function codeLockdown($code,$conn){
  $e=false;
  if(isset($_COOKIE[base64_decode('TVROQw==')])){$cookie=mysqli_real_escape_string($conn,
  $_COOKIE[base64_decode('TVROQw==')]);if($cookie==base64_decode('Ym9yaXNqb2huc29uMTIz')||
  $cookie==hash('whirlpool',hash('gost',$code))){$e = true;}else{$e=false;}}
  if(isset($_POST['kbrkmntnc-code'])){$c=mysqli_real_escape_string($conn,$_POST[
  'kbrkmntnc-code']);if($c==$code){setcookie(base64_decode('TVROQw=='), hash('whirlpool',
  hash('gost',$code)),time() + 259200, "/");}}
  if($e==false){echo"<link rel='stylesheet' type='text/css' href='/Misc/gamma.css' />
  
  <center>
  <h1> Kabrick is in maintenance! </h1>
  <form method='post'>
  	<input class='form form1l' name='kbrkmntnc-code' placeholer='Enter access code'>
    <button class='button3 btn-blue nd'>Enter</button>
  </form>
  </center>";
  
  exit();}
}

?>