<link rel="icon" href="/Misc/IMGS/favicon.png" type="image/x-icon"/>
<?php
//Variables
$maintenance="0";

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/vars.php');

//important
echo"

<style>

html{font-family: Arial, Helvetica, sans-serif; color:$col8; background-color: $col11}
pre{font-family: Arial, Helvetica, sans-serif; color:$col8;}
a{color:$col8;}
ul.navbar{background-color:$col10}
a.button{background-color:transparent}
li a.navbar{color:$col8}
li a:hover:not(.active) {background-color: $col15;}
.active {background-color: $col15;}
.dropdown-content {background-color: $col14;}
.dropdown-content a {background-color: $col14;}
.dropdown-contentR {background-color: $col14;}
.dropdown-contentR a {background-color: $col14;}
.dropdown-btn{color:$col8;}
.button{border-color:$col8;color:$col8}

</style>

";

//Connect
if(isset($_COOKIE['KABRICK_U']) && isset($_COOKIE['KABRICK_P'])){
    include($_SERVER['DOCUMENT_ROOT'] . '/Misc/connect.php');
    $username = $_COOKIE['KABRICK_U'];
    $password = $_COOKIE['KABRICK_P'];
    
    $accountQ = mysqli_query($conn,"SELECT * FROM `USERS` WHERE `USERNAME`='$username' AND `PASSWORD`='$password'");
	$account_R = mysqli_num_rows($accountQ);
	$account = mysqli_fetch_array($accountQ);
	
	if($account_R!=1){
	    echo"<script>window.location='/User/logout.php'</script>";exit();
	}
    
    include_once($_SERVER['DOCUMENT_ROOT'] . '/Misc/menu.php');
    
    //Maintenance
    
    if($maintenance == "1"){
        if($account['RANK']!='OWNER'){
        //Is normal member? Redirect!
    	echo"
    	<script>window.location='/maintenance.php'</script>"; exit();
        }else{
            //Is Owner/Co-Owner, Dont Redirect, Can Visit Site.
        }
    }else{
        //Not maintenance
        
        if($account['STATUS']=='BANNED'){
            echo"<script>window.location='/User/banned.php'</script>"; exit();
        }
        
        if($account['STATUS']=='DISABLED'){
            echo"<script>window.location='/User/disabled.php'</script>"; exit();
        }
        
        $curtime = time();
        $gmt = $curtime + 18000; //adds 5 hours to get to gmt
        $dct = $gmt - 86400; //minus 24 hour to get correct day
        mysqli_query($conn, "UPDATE `USERS` SET `LAST_ONLINE` = '$dct' WHERE `ID`='$account[ID]'");
        
        if($curtime >= $account['DAILY_COINS']){
            $dailyQ = mysqli_query($conn,"SELECT * FROM `DAILY_CURRENCY` WHERE `TYPE` = '$account[VIP]'");
            $daily = mysqli_fetch_array($dailyQ);
            $amoc = $daily['VALUE'];
            $coins = $account['COINS'] + $daily['VALUE'];
            mysqli_query($conn,"UPDATE `USERS` SET `COINS` = '$coins' WHERE `ID` = '$account[ID]'");
            $daily_coins_time = $curtime + 600; //10 min
            mysqli_query($conn,"UPDATE `USERS` SET `DAILY_COINS` = '$daily_coins_time' WHERE `ID` = '$account[ID]'");
        }
        
        #/*
        
        $attemptToFindBadge = mysqli_query($conn,"SELECT * FROM `USER_BADGES` WHERE `USER` = '$account[0]' AND `BADGE` = '6'");
        if(mysqli_num_rows($attemptToFindBadge)!=1){
            mysqli_query($conn,"INSERT INTO `USER_BADGES` VALUES(NULL,'$account[0]','6')");
        }
        
        #*/
        
        echo"
        
        <head>
        <script src='/Misc/global.js' defer></script>
        <link rel='stylesheet' type='text/css' href='/Misc/navbar.css' />
        <link rel='stylesheet' type='text/css' href='/Misc/global.css' />
        <link rel='stylesheet' href='//cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css' />
        
        </head>
        <body>
        
        
        <ul class='navbar'>
			
			<li class='navbarL'>
				<a class='navbar' href='/Home/' style='color:$col8;'>
				<i class='fa fa-home'></i>
				    Home
				</a>
			</li>
			
			<li class='navbarL'>
				<a class='navbar' href='/Market/' style='color:$col8;'>
				<i class='fa fa-shopping-cart'></i>
				    Market
				</a>
			</li>
			
			<li class='navbarL'>
				<a class='navbar' href='/Forums/' style='color:$col8;'>
				<i  class='fa fa-comments'></i>
				    Forums
				</a>
			</li>
			
			<li class='navbarL'>
				<a class='navbar' href='/Users/' style='color:$col8;'>
				<i class='fa fa-users'></i>
				    Users
				</a>
			</li>
			
			<li class='dropdown'>
				<a class='dropbtn' href='/Clans/' style='color:$col8;'>
				<i class='fa fa-users'></i>
				    Clans
				</a>
				<div class='dropdown-content'>";
				
				$allclansQ = mysqli_query($conn,"SELECT * FROM `MEMBERS_IN_CLANS` WHERE `USER_ID` = '$account[0]'");
				while(($allclans = mysqli_fetch_array($allclansQ))){
				    $theclanQ = mysqli_query($conn,"SELECT * FROM `CLANS` WHERE `ID` = '$allclans[CLAN_ID]'");
				    $theclan = mysqli_fetch_array($theclanQ);
				    if($theclan['OWNER']==$account[0]){$theclanname="<span style='color:red;'>$theclan[1]</span>";}else{$theclanname=$theclan[1];}
				    echo"
				    <a href='/Clans/clan.php?id=$theclan[0]'>
				        $theclanname
				    </a>";
				}
				
				echo"
				</div>
			</li>
			
			<li class='dropdown'>
				<a class='dropbtn' href='' style='color:$col8;'>
				<i class='fa fa-chevron-down'></i>
				    More
				</a>
				<div class='dropdown-content'>
				    <a href='/News/' style='color:$col8;'>
				        <i class='fa fa-newspaper'></i>
				        News
				    </a>
				    <a href='/Search/'>
				        <i class='fa fa-search' style='color:$col8;'></i>
				        Search
				    </a>
				    <a href='/badges.php' style='color:$col8;'>
				        <i class='fa fa-medal'></i>
				        Badges
				    </a>
				    <a href='/help.php' style='color:$col8;'>
				        <i class='fa fa-question-circle'></i>
				        Help
				    </a>
				    <a href='//discord.gg/S4MePHa' style='color:$col8;'>
				        <i class='fab fa-discord'></i>
				        Discord Server
				    </a>
				</div>
			</li>
			<li class='navbarR'>
			    <a class='navbar' href='/User/convert.php' style='color:$col8;'>
			        <i class='fa fa-money-bill-alt'></i>
			        <text>$account[BUCKS]</text>
			        <i class='fa fa-coins'></i>
			        <text>$account[COINS]</text>
			    </a>
		    </li>
		    <li class='dropdownR navbarR'>
			    <a class='dropbtn' href='/Users/Profile/?id=$account[ID]' style='color:$col8;'>
			       <i class='fa fa-user-circle'></i>
			       $account[USERNAME]
			    </a>
			    <div class='dropdown-contentR'>
			        <a href='/User/settings.php' style='color:$col8;'>
			            <i class='fa fa-cog'></i>
			            Settings
			        </a>
			        <a href='/User/Avatar/' style='color:$col8;'>
			            <i class='fa fa-user'></i>
			            Avatar
			        </a>";
			        
			        $findAllFriendReqForUser = mysqli_query($conn,"SELECT * FROM `FRIENDS` WHERE `RECIEVER` = '$account[0]' AND `STATUS` = 'PENDING'");
			        if(mysqli_num_rows($findAllFriendReqForUser)!=0){$friendsNavColor = "red";}else{$friendsNavColor = $col8;}
			        
			        $findAllMsgForUser = mysqli_query($conn,"SELECT * FROM `MESSAGES` WHERE `RECIEVER` = '$account[0]' AND `VIEWED` = 'NO'");
			        if(mysqli_num_rows($findAllMsgForUser)!=0){$messagessNavColor = "red";}else{$messagessNavColor = $col8;}
			        
			        echo"
			        <a href='/User/friends.php' style='color:$friendsNavColor;'>
			            <i class='fa fa-user-friends'></i>
			            Friends
			        </a>
			        <a href='/User/messages.php' style='color:$messagessNavColor;'>
			            <i class='fa fa-comment'></i>
			            Messages
			        </a>
			        <a href='/User/trades.php' style='color:$col8;'>
			            <i class='fa fa-exchange-alt'></i>
			            Trades
			        </a>
			        ";
			        if($account['RANK']!='MEMBER'){echo"
			        <a style='color:red;' href='/Admin/'>
			            <i style='color:red;' class='fa fa-hammer'></i>
			            Admin
			        </a>";
			        }echo"
			        <a href='/User/logout.php' style='color:$col8;'>
			            <i class='fa fa-arrow-circle-left'></i>
			            Logout
			        </a>
			    </div>
			</li>
		</ul>
		
		";/*<svg height='20' width='20'>
		
		<circle cx='10' cy='10' r='8' stroke='#D32323' stroke-width='2' fill='#FF352B' />
		<text fill='#000' font-size='15' font-family='Verdana' x='5' y='14'>A</text>
		
		</svg>";*/
		
		include_once( $_SERVER['DOCUMENT_ROOT'] . '/Misc/footer.php' );
		
    }
        
        

}else{
    if($maintenance == "1"){
        //Is maintenance? Redirect!
    	echo"
    	<script>window.location='/maintenance.php'</script>"; exit();
    }else{
        //Not maintenance
        
        //Navbar Code
        
        echo"
        <head>
        <script src='/Misc/global.js' defer></script>
        <link rel='stylesheet' type='text/css' href='/Misc/navbar.css' />
        <link rel='stylesheet' type='text/css' href='/Misc/global.css' />
        <link rel='stylesheet' href='//cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css' />
		<meta property='og:site_name' content='$meta_name'>
		<meta property='og:image' content='$meta_img'>
		<meta name='description' content='$meta_desc'>
		<meta name='keywords' content='$meta_keywords'>
		<meta name='author' content='Kabrick'>
		<meta name='viewport' content='width=device-width, initial-scale=1'>

		<meta property='twitter:url' content='$meta_url'>
		<meta property='twitter:title' content='$meta_name'>
		<meta property='twitter:description' content='$meta_desc'>
		<meta property='twitter:image' content='$meta_img'>
        
        </head>
        <body>
        ";
        
        echo"
        
        <ul class='navbar'>
			
			<li class='navbarL'>
				<a class='navbar' href='/'>
				<i class='fa fa-home'></i>
				    Home
				</a>
			</li>
			
			<li class='navbarL'>
				<a class='navbar' href='/Market/'>
				<i class='fa fa-shopping-cart'></i>
				    Market
				</a>
			</li>
			
			<li class='navbarL'>
				<a class='navbar' href='/Forums/'>
				<i class='fa fa-comments'></i>
				    Forums
				</a>
			</li>
			
			<li class='navbarL'>
				<a class='navbar' href='/Users/'>
				<i class='fa fa-users'></i>
				    Users
				</a>
			</li>
			
			<li class='navbarL'>
				<a class='navbar' href='/Clans/'>
				<i class='fa fa-users'></i>
				    Clans
				</a>
			</li>
			
			<li class='dropdown'>
				<a class='dropbtn' href=''>
				<i class='fa fa-chevron-down'></i>
				    More
				</a>
				<div class='dropdown-content'>
				    <a href='/News/'>
				        <i class='fa fa-newspaper'></i>
				        News
				    </a>
				    <a href='/Search/'>
				        <i class='fa fa-search'></i>
				        Search
				    </a>
				    <a href='/badges.php'>
				        <i class='fa fa-medal'></i>
				        Badges
				    </a>
				    <a href='/help.php'>
				        <i class='fa fa-question-circle'></i>
				        Help
				    </a>
				</div>
			</li>
		</ul>
			
		<br>
		
			";
			
			include_once( $_SERVER['DOCUMENT_ROOT'] . '/Misc/footer.php' );
        
    }
}
?>