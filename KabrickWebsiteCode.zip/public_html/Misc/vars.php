<?php

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/connect.php');

$time = time();

//echo"<script>window.location='/shutdown.php'</script>";exit(); //april fools >:)

if(isset($_COOKIE['KABRICK_U']) && isset($_COOKIE['KABRICK_P'])){
$username = $_COOKIE['KABRICK_U'];
$password = $_COOKIE['KABRICK_P'];
$accountQ = mysqli_query($conn,"SELECT * FROM `USERS` WHERE `USERNAME`='$username' AND `PASSWORD`='$password'");
$account = mysqli_fetch_array($accountQ);
  
  
      
      	// ADMIN LEVEL
        $rank = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `ROLES` WHERE `NAME` = '$account[RANK]'"));
  		$ar = $rank['RANK'];
}else{$ar=0;}

$CURRENT_ECONOMY = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `CURRENT_ECONOMY` WHERE `ID` = '1'"));

$ammount_usersQ = mysqli_query($conn, "SELECT * FROM `USERS` WHERE 1");
$ammount_users = mysqli_num_rows($ammount_usersQ);
$ammount_marketQ = mysqli_query($conn, "SELECT * FROM `MARKET` WHERE 1");
$ammount_market = mysqli_num_rows($ammount_marketQ);
$ammount_postsQ = mysqli_query($conn, "SELECT * FROM `FORUM_THREADS` WHERE 1");
$ammount_posts = mysqli_num_rows($ammount_postsQ);
$ammount_clansQ = mysqli_query($conn, "SELECT * FROM `CLANS` WHERE 1");
$ammount_clans = mysqli_num_rows($ammount_clansQ);
#$ammount_lightQ = mysqli_query($conn, "SELECT * FROM `USERS` WHERE `THEME` = 'LIGHT'");
#$ammount_light = mysqli_num_rows($ammount_lightQ);

$maintenance = false; //redirects all users to maintenance page
$theme = 1; //force theme, 1=normal, 2=halloween, 3=, 4=, 5=
$siteVer = "$CURRENT_ECONOMY[VER_SITE] ($CURRENT_ECONOMY[VS_TIME])"; //Site version. Format: <site.major_update.update> (Last update date)
$siteVerRaw = $CURRENT_ECONOMY['VER_SITE'];
$siteVerTime = $CURRENT_ECONOMY['VS_TIME'];

$backendVer = $CURRENT_ECONOMY['VER_BACK'];
$frontendVer = $CURRENT_ECONOMY['VER_FRONT'];
$sqlVer = $CURRENT_ECONOMY['VER_SQL'];

//OLD THEMES LAY HERE - RIP

#echo"$e";

$footer_text = "";
//$footerQ = mysqli_query($conn,"SELECT * FROM `FOOTER` WHERE 1"); // why was this active for so long?
//$footerN = mysqli_num_rows($footerQ);
//$randN = rand(1,$footerN);
//$footer_textQ = mysqli_query($conn,"SELECT * FROM `FOOTER` WHERE `ID` = '$randN'");
//$footer_textA = mysqli_fetch_array($footer_textQ);
//$footer_text = $footer_textA['TEXT'];

$meta_url = "https://kabrick.xyz";
$meta_blank_url = "kabrick.xyz";
$meta_name = "Kabrick";
$meta_desc = "";
$meta_img = "";
$meta_keywords = "Kabrick";

$config = [
  "usernameLengths" => [4,20],
  "usernameRegex" => "/^[A-Za-z0-9]*$/",
  "coins" => 1800,
  "StarterCoins" => [20,0],
  "usernameChangeBucksAmount" => 100,
  "clanPrice" => 10,
  "defaultClanDesc" => "Hi! Welcome to my clan!"
];

// discord embed colors
$dcol_limited = 13806637;
$dcol_rare = 6684859;
$dcol_event = 65365;
$dcol_white = 16777215;

$dcols = [
  "white"=>$dcol_white,
  "event"=>$dcol_event,
  "rare"=>$dcol_rare,
  "limited"=>$dcol_limited,
  "epic"=>$dcol_limited,
];

#include($_SERVER['DOCUMENT_ROOT'] . '/Misc/maintenance.php');
#codeLockdown("egg",$conn);
#lockdown();

// time to add some functions here ig (16/7/23 @ 20:27)
// functions moved (23/7/23 @ 15:00)



   /* $characters = '0123456789abcdefghijklmnopqrstuvwxyz';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;*/

$countries = [
  
  "GB" => "UK",
  "US" => "USA",
  "CA" => "Canada",
  "NL" => "Netherlands",
  "FR" => "France",
  "AE" => "UAE",
  "NO" => "Norway",
  "PL" => "Poland",
  "DE" => "Germany",
  
  "AF" => "Afghanistan",
  "AL" => "Albania",
  "DZ" => "Algeria",
  "AS" => "American Samoa",
  "AD" => "Andorra",
  "AO" => "Angola",
  "AI" => "Anguilla",
  "AQ" => "Antarctica",
  "AG" => "Antigua and Barbuda",
  "AR" => "Argentina",
  "AM" => "Armenia",
  "AW" => "Aruba",
  "AU" => "Australia",
  "AT" => "Austria",
  "AZ" => "Azerbaijan",
  
  "BS" => "The Bahamas",
  "BH" => "Bahrain",
  "BD" => "Bangladesh",
  "BB" => "Barbados",
  "BY" => "Belarus",
  "BE" => "Belgium",
  "BZ" => "Belize",
  "BJ" => "Benin",
  "BM" => "Bermuda",
  "BT" => "Bhutan",
  "BO" => "Bolivia",
  "BQ" => "Bonaire, Sint Eustatius and Saba",
  "BA" => "Bosnia and Herzegovina",
  "BW" => "Botswana",
  "BV" => "Bouvet Island",
  "BR" => "Brazil",
  "IO" => "British Indian Ocean Territory",
  "BN" => "Brunei",
  "BG" => "Bulgaria",
  "BF" => "Burkina Faso",
  "BI" => "Burundi",
  
  "CV" => "Cabo Verde",
  "KH" => "Cambodia",
  "CM" => "Cameroon",
  "KY" => "Cayman Islands",
  "CF" => "Central African Republic",
  "TD" => "Chad",
  "CL" => "Chile",
  "CN" => "China",
  "CX" => "Christmas Island",
  "CC" => "Cocos (Keeling) Islands",
  "CO" => "Colombia",
  "KM" => "Comoros",
  "CD" => "DRC",
  "CG" => "Congo",
  "CK" => "Cook Islands",
  "CR" => "Costa Rica",
  "HR" => "Croatia",
  "CU" => "Cuba",
  "CW" => "Cuarcao",
  "CY" => "Cyprus",
  "CZ" => "Czechia",
  "CI" => "Cote d'Ivore (Ivory Coast)",
  
  "DK" => "Denmark",
  "DJ" => "Djibouti",
  "DM" => "Dominica",
  "DO" => "Dominican Republic",
  
  "EC" => "Ecuador",
  "EG" => "Egypt",
  "SV" => "El Salvador",
  "GQ" => "Equatorial Guinea",
  "ER" => "Eritrea",
  "EE" => "Estonia",
  "SZ" => "Eswatini",
  "ET" => "Ethiopia",
  
  "FK" => "Falkland Islands",
  "FO" => "Faroe Islands",
  "FJ" => "Fiji",
  "FI" => "Finland",
  "GF" => "French Guiana",
  "PF" => "French Polynesia",
  "TF" => "French Southern Territories",
  
  "GA" => "Gabon",
  "GM" => "The Gambia",
  "GE" => "Georgia",
  "GH" => "Ghana",
  "GI" => "Gibraltar",
  "GR" => "Greece",
  "GL" => "Greenland",
  "GD" => "Grenada",
  "GP" => "Guadeloupe",
  "GU" => "Guam",
  "GT" => "Guatemala",
  "GG" => "Guernsey",
  "GN" => "Guinea",
  "GW" => "Guinea-Bissau",
  "GY" => "Guyana",
  
  "HT" => "Haiti",
  "HM" => "Heard Island and McDonald Islands",
  "HN" => "Honduras",
  "HK" => "Hong Kong SAR China",
  "HU" => "Hungary",
  
  "IS" => "Iceland",
  "IN" => "India",
  "ID" => "Indonesia",
  "IR" => "Iran",
  "IQ" => "Iraq",
  "IE" => "Ireland",
  "IM" => "Isle of Man",
  "IL" => "Israel",
  "IT" => "Italy",
  
  "JM" => "Jamaica",
  "JP" => "Japan",
  "JE" => "Jersey",
  "JO" => "Jordan",
  
  "KZ" => "Kazakhstan",
  "KE" => "Kenya",
  "KI" => "Kiribati",
  "KP" => "South Korea",
  "KR" => "North Korea",
  "KW" => "Kuwait",
  "KG" => "Kyrgyzstan",
  
  "LA" => "Laos",
  "LV" => "Latvia",
  "LB" => "Lebanon",
  "LS" => "Lesotho",
  "LR" => "Liberia",
  "LY" => "Libya",
  "LI" => "Liechtenstein",
  "LT" => "Lithuania",
  "LU" => "Luxembourg",
  
  "MO" => "Macao SAR China",
  "MG" => "Madagascar",
  "MW" => "Malawi",
  "MY" => "Malaysia",
  "MV" => "Maldives",
  "ML" => "Mali",
  "MT" => "Malta",
  "MH" => "Marshall Islands",
  "MQ" => "Martinique",
  "MR" => "Mauritania",
  "MU" => "Mauritius",
  "YT" => "Mayotte",
  "MX" => "Mexico",
  "FM" => "Micronesia",
  "MD" => "Moldova",
  "MC" => "Monaco",
  "MN" => "Mongolia",
  "ME" => "Montenegro",
  "MS" => "Montserrat",
  "MA" => "Morocco",
  "MZ" => "Mozambique",
  "MM" => "Myanmar (Burma)",
  
  "NA" => "Namibia",
  "NR" => "Nauru",
  "NP" => "Nepal",
  "NC" => "New Caledonia",
  "NZ" => "New Zealand",
  "NI" => "Nicaragua",
  "NE" => "Niger",
  "NG" => "Nigeria",
  "NU" => "Niue",
  "NF" => "Norfolk Island",
  "MK" => "North Macedonia",
  "MP" => "Northern Mariana Islands",
  
  "OM" => "Oman",
  
  "PK" => "Pakistan",
  "PW" => "Palau",
  "PS" => "Palestine",
  "PA" => "Panama",
  "PG" => "Papua New Guinea",
  "PY" => "Paraguay",
  "PE" => "Peru",
  "PH" => "Philippines",
  "PN" => "Pitcairn Islands",
  "PT" => "Portugal",
  "PR" => "Puerto Rico",
  
  "QA" => "Qatar",
  
  "RO" => "Romania",
  "RU" => "Russia",
  "RW" => "Rwanda",
  "RE" => "Réunion",
  
  "BL" => "Saint Barthélemy",
  "SH" => "Saint Helena, Ascension and Tristan da Cunha",
  "KN" => "Saint Kitts and Nevis",
  "LC" => "Saint Lucia",
  "MF" => "(French) Saint Martin",
  "PM" => "Saint Pierre and Miquelon",
  "VC" => "Saint Vincent and the Grenadines",
  "WS" => "Samoa",
  "SM" => "San Marino",
  "ST" => "Sao Tomé and Principe",
  "SA" => "Saudi Arabia",
  "SN" => "Senegal",
  "RS" => "Serbia",
  "SC" => "Seychelles",
  "SL" => "Sierra Leone",
  "SG" => "Singappre",
  "SX" => "(Dutch) Sint Maarten",
  "SK" => "Slovakia",
  "SI" => "Slovenia",
  "SB" => "Solomon Islands",
  "SO" => "Somalia",
  "ZA" => "South Africa",
  "GS" => "South Georgia and the South Sandwich Islands",
  "SS" => "South Sudan",
  "ES" => "Spain",
  "LK" => "Sri Lanka",
  "SD" => "Sudan",
  "SR" => "Suriname",
  "SJ" => "Svalbard (NO)",
  "SE" => "Sweden",
  "CH" => "Switzerland",
  "SY" => "Syria",
  
  "TW" => "Taiwan",
  "TJ" => "Tajikistan",
  "TZ" => "Tanzania",
  "TH" => "Thailand",
  "TL" => "Timor-Leste",
  "TG" => "Togo",
  "TK" => "Tokelau",
  "TO" => "Tonga",
  "TT" => "Trinidad and Tobago",
  "TN" => "Tunisia",
  "TR" => "Turkey",
  "TM" => "Turkmenistan",
  "TC" => "Turks and Caicos Islands",
  "TV" => "Tuvalu",
  
  "UG" => "Uganda",
  "UA" => "Ukraine",
  "UM" => "US Minor Outlying Islands",
  "UY" => "Uruguay",
  "UZ" => "Uzbekistan",
  
  "VA" => "Vatican City",
  "VU" => "Vanuatu",
  "VE" => "Venezuela",
  "VN" => "Vietnam",
  "VG" => "British Virgin Islands",
  "VI" => "US Virgin Islands",
  
  "WF" => "Wallis and Fatuna",
  "EH" => "Western Sahara",
  
  "YE" => "Yemen",
  
  "ZM" => "Zambia",
  "ZW" => "Zimbabwe",
  
  "AX" => "Aland Islands"
  
  ];

?>