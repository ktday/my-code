<?php

$meta_name = "Kabrick";

function embed($title, $desc, $page = "", $imgURL = false, $col = "#255052"){
  $siteURL = "http://kabrick.xyz";
  echo"
  <meta content='$title | Kabrick' property='og:title' />
  <meta content='$desc'  property='og:description' />
  <meta content='$siteURL/$page' property='og:url' />
  <meta content='$col' name='theme-color' data-react-helmet='true' />
  ";
  
  if($imgURL!=false){echo"<meta content='$siteURL/$imgURL' property='og:image' />";}
  
}

function defEmbed($type, $col = "#255052"){
  
  $def = [];
  
}

?>