<?php
for ($k = 0 ; $k < 45; $k++){ echo "<img src='$k.png'><br>"; }
?>