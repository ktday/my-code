function generateBucks(){
  document.body.innerHTML = "<div style='width:100%;height:100%;background-color:#fff;color:red;font-size:3rem'><p>You have been banned for hacking on kabrick.tk!</p></div>";
}