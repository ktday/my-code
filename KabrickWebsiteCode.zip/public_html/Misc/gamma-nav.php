<?php

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/vars.php');
include($_SERVER['DOCUMENT_ROOT'] . '/Misc/funct.php');
include($_SERVER['DOCUMENT_ROOT'] . '/lgt.php');
include($_SERVER['DOCUMENT_ROOT'] . '/Misc/maintenance.php');

include($_SERVER['DOCUMENT_ROOT'] . '/Events/Easter24-Header.php'); // Easter event 2024

#if(hash('whirlpool',hash('gost',$_SERVER['REMOTE_ADDR']))=='1cda3d82a46a68c3b4efb7168d89de770f6650e9d89bba63faa725f94596a7f928d7db2c1c95f929d9a46f5871c00d6d28c15a9cf5a9c27d2f37bea2586cd967'){
#    exit("Go Away Claus!");
#}

echo"

<link rel='icon' href='/Misc/IMGS/favicon.png' type='image/x-icon'/>

<link rel='stylesheet' href='//cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css' />

<script src='/Misc/global.js'></script>

<script src='https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>
";

$useragent=$_SERVER['HTTP_USER_AGENT'];
if(preg_match('/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i',$useragent)||preg_match('/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i',substr($useragent,0,4))){
    /*mobile css*/
    echo"<link rel='stylesheet' href='/Misc/gammam.css' />";
    #echo"<link rel='stylesheet' type='text/css' href='/Misc/russia.css' />";
    $mobile = true;
}else{
    /*pc css*/
    echo"<link rel='stylesheet' type='text/css' href='/Misc/gamma.css' />";
    #echo"<link rel='stylesheet' type='text/css' href='/Misc/russia.css' />";
    $mobile = false;
}

if(isset($_COOKIE['KABRICK_U'])&&isset($_COOKIE['KABRICK_P'])){
    include($_SERVER['DOCUMENT_ROOT'] . '/Misc/connect.php');
    $username = mysqli_real_escape_string($conn, $_COOKIE['KABRICK_U']);
    $password = mysqli_real_escape_string($conn, $_COOKIE['KABRICK_P']);
    
    $accountQ = $conn->prepare("SELECT * FROM `USERS` WHERE `USERNAME`=? AND `PASSWORD`=?");
    $accountQ->bind_param("ss", $username, $password);
    $accountQ->execute();
    $result = $accountQ->get_result();
	$account_R = mysqli_num_rows($result);
	$account = mysqli_fetch_array($result);
	
	if($account_R!=1){
	    echo"<script>window.location='/User/logout.php'</script>";exit();
	}
	
	if($maintenance == "1"){
        if($account['RANK']!='OWNER'){
        //Is normal member? Redirect!
    	echo"
    	<script>window.location='/maintenance.php'</script>"; exit();
        }else{
            //Is Owner/Co-Owner, Dont Redirect, Can Visit Site.
        }
    }else{
        //Not maintenance
        
        if($account['STATUS']=='DISABLED'){
            echo"<script>window.location='/User/logout.php'</script>"; exit();
        }
        
        $curtime = time();
        $gmt = $curtime + 18000; //adds 5 hours to get to gmt
        //$dct = $gmt - 86400; //minus 24 hour to get correct day
      
      	//check ghosted
      	if($account['GHOST']==1){
          if($account['RANK']=='MEMBER'){
            $stmt = $conn->prepare("UPDATE `USERS` SET `GHOST` = 0 WHERE `ID`=?");
            $stmt->bind_param("i", $account['ID']);
            $stmt->execute();
          }else{
            $stmt = $conn->prepare("UPDATE `USERS` SET `GTIME` = ? WHERE `ID`=?");
            $stmt->bind_param("ii", $gmt, $account['ID']);
            $stmt->execute();
          }
        }else{
          $stmt = $conn->prepare("UPDATE `USERS` SET `LAST_ONLINE` = ?, `LAST_DEVICE`='0' WHERE `ID`=?");
          $stmt->bind_param("ii", $gmt, $account['ID']);
          $stmt->execute();
        }
        
        if($account['ENDS']<time()&&$account['ENDS']!=0&&$account['VIP']!='NONE'){
            /*if($account['REP']=='TRUE'){
                if($account['BUCKS']<30){
                    //not enough bucks; cancel VIP
                    mysqli_query($conn,"UPDATE `USERS` SET `VIP` = 'NONE' WHERE `ID` = '$account[0]'");//VIP
                    mysqli_query($conn,"UPDATE `USERS` SET `ENDS` = '0' WHERE `ID` = '$account[0]'");//ENDS
                    mysqli_query($conn,"UPDATE `USERS` SET `REP` = 'FALSE' WHERE `ID` = '$account[0]'");//REP
                    echo"<script>window.alert('Not enough bucks to continue your VIP Membership. Membership has been cancelled!');window.reload()</script>";exit();
                }else{
                    //enough bucks, buy
                    mysqli_query($conn,"UPDATE `USERS` SET `BUCKS` = '". $account['BUCKS'] - 30 ."' WHERE `ID` = '$account[0]'");//BUCKS
                    mysqli_query($conn,"UPDATE `USERS` SET `VIP` = 'VIP' WHERE `ID` = '$account[0]'");//VIP
                    mysqli_query($conn,"UPDATE `USERS` SET `ENDS` = '". time() + 2800000 ."' WHERE `ID` = '$account[0]'");//ENDS
                    mysqli_query($conn,"UPDATE `USERS` SET `REP` = 'TRUE' WHERE `ID` = '$account[0]'");//REP
                }
            }else{*/
                mysqli_query($conn,"UPDATE `USERS` SET `VIP` = 'NONE' WHERE `ID` = '$account[0]'");//VIP
                echo"<script>window.alert('Your VIP membership has ended!');window.reload()</script>";exit();
            #}
        }
        
        if($curtime >= $account['DAILY_COINS']&&$account['STATUS']!='BANNED'){
            $dailyQ = mysqli_query($conn,"SELECT * FROM `DAILY_CURRENCY` WHERE `TYPE` = '$account[VIP]'");
            $daily = mysqli_fetch_array($dailyQ);
            $amoc = $daily['VALUE'];
            $coins = $account['COINS'] + $daily['VALUE'];
            mysqli_query($conn,"UPDATE `USERS` SET `COINS` = '$coins' WHERE `ID` = '$account[ID]'");
            $daily_coins_time = $curtime + $config['coins']; //10 min
            mysqli_query($conn,"UPDATE `USERS` SET `DAILY_COINS` = '$daily_coins_time' WHERE `ID` = '$account[ID]'");

            add($account[0], "Collect", $amoc);
        }
        
        /*$attemptToFindBadge = mysqli_query($conn,"SELECT * FROM `USER_BADGES` WHERE `USER` = '$account[0]' AND `BADGE` = '6'");
        if(mysqli_num_rows($attemptToFindBadge)!=1){
            mysqli_query($conn,"INSERT INTO `USER_BADGES` VALUES(NULL,'$account[0]','6')");
        }*/
        
        $homeLocat = "/Home/";
        $li = 1;
      
    }
}else{
    if($maintenance == "1"){
    echo"<script>window.location='/maintenance.php'</script>"; exit();
    }
    
    $homeLocat = "/";
    $li = 0;
  	$account = ["GHOST"=>0];
}

$CURRENT_ECONOMY = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `CURRENT_ECONOMY` WHERE `ID` = '1'"));

echo"

<ul class='nav'>
    
    <li class='navL nav'>
        <a href='$homeLocat' class='hovers'>
            <i class='fa fa-home'></i> Home
        </a>
    </li>
    
    <li class='navL nav'>
        <a href='/Market/' class='hovers'>
            <i class='fa fa-shopping-cart'></i> Market
        </a>
    </li>
    
    <li class='navL nav'>
        <a href='/Users/' class='hovers'>
            <i class='fa fa-users'></i> Users
        </a>
    </li>
    
    <li class='navL nav'>
        <a href='/Forums/' class='hovers'>
            <i class='fa fa-comments'></i> Forums
        </a>
    </li>
    
    <li class='navL nav'>
        <a href='/Clans/' class='hovers'>
            <i class='fa fa-users'></i> Clans
        </a>
    </li>
    
    <li class='navL nav'>
        <a href='/Auction/' class='hovers'>
            <i class='fa fa-shopping-cart'></i> Auction House
        </a>
    </li>
    
    <li class='navL nav btn-purple'>
        <a href='/Event/Easter2024'>
            <i class='fas fa-egg'></i> Easter 2024
        </a>
    </li>
    
    <li class='dropdown'>
		<a class='dropbtn hovers navL nav' ";if($mobile==false){echo"href=''";}echo">
		<i class='fa fa-chevron-down'></i>
		    More
		</a>
		<div class='dropdown-content'>
		    <a href='/News/' class='hovers'>
		        <i class='fa fa-newspaper'></i>
		        News
		    </a>
		    <a href='/Leaderboards/' class='hovers'>
		        <i class='fa fa-align-left'></i>
		        Leaderboard
		    </a>
		    <a href='/Badges/' class='hovers'>
		        <i class='fa fa-medal'></i>
		        Badges
		    </a>
		    <a href='/help.php' class='hovers'>
		        <i class='fa fa-question-circle'></i>
		        Help
		    </a>
		    <a href='//discord.gg/S4MePHa' class='hovers'>
		        <i class='fab fa-discord'></i>
		        Discord Server
		    </a>
		</div>
	</li>
	
	
	";
	
	#<li class='fr nav'>
    #    <a href='/Events/spooky-birthday-2021.php'>
    #        <i class='fa fa-gift'></i> EVENT
    #    </a>
    #</li>
	
	if($li==1){
      
      $amOfMSG = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM `MESSAGES` WHERE `RECIEVER` = '$account[0]' AND `VIEWED` = 'NO'"));
      $amOfTRD = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM `TRADES` WHERE `RECIEVER` = '$account[0]' AND `STATUS` = 'P'"));
      $amOfFRq = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM `FRIEND_REQ` WHERE `RECIEVER` = '$account[0]'"));
      if($amOfMSG>0){$msgcol = 'red';}else{$msgcol = 'white';}
      if($amOfTRD>0){$trdcol = 'red';}else{$trdcol = 'white';}
      if($amOfFRq>0){$frcol = 'red';}else{$frcol = 'white';}
	    
	    echo"
	    
	        <li class='nav fr'>
	            
	            <a href='/User/logout.php' class='hovers'>
	                
	                <i class='fa fa-arrow-circle-right'></i> Log out
	            
	            </a>
	            
	        </li>
	    
	        <li class='nav fr'>
	            
	            <a href='/User/settings.php?wallet' class='hovers'>
	                
	                <i class='fa fa-money-bill-alt'></i> $account[BUCKS]
	            
	                <i class='fa fa-coins'></i> $account[COINS]
	            
	            </a>
	            
	        </li>
	        
	        <li class='dropdown fr'>
	        
	            ";if($mobile==false){echo"
	            
	            <a class='dropbtn hovers nav' href='/Profile/$account[1]'>
        		    <i class='fa fa-user-circle'></i> $account[1]
        		</a>
        		
        		<div class='dropdown-content contR'>";
        		
        		}else{
        		    echo"
        		    
        		    <a class='dropbtn hovers nav'>
            		    <i class='fa fa-chevron-down'></i> My account
            		</a>
            		
            		<div class='dropdown-content contR'>
            		
            		<a class='dropbtn hovers nav' href='/Profile/$account[1]'>
            		    <i class='fa fa-user-circle'></i> My Profile
            		</a>
        		    
        		    ";
        		}
        		
        		echo"
        		    
        		    <a class='dropbtn hovers nav' href='/User/settings.php'>
            		    <i class='fa fa-cog'></i> Settings
            		</a>
            		
            		<a class='dropbtn hovers nav' href='/User/Avatar/'>
            		    <i class='fa fa-user'></i> Avatar
            		</a>
        		    
        		    <a class='dropbtn hovers nav' href='/Inventory/$account[1]'>
            		    <i class='fas fa-shopping-bag'></i> Inventory
            		</a>
            		
            		<a class='dropbtn hovers nav' href='/Friends/'>
            		    <e class='txtcol-$frcol'><i class='fa fa-user-friends'></i> Friends</e>
            		</a>
            		
            		<a class='dropbtn hovers nav' href='/Messages/'>
            		    <e class='txtcol-$msgcol'><i class='fa fa-envelope'></i> Messages</e>
            		</a>
            		
            		<a class='dropbtn hovers nav' href='/User/Trades/'>
            		    <e class='txtcol-$trdcol'><i class='fa fa-star'></i> Trades</e>
            		</a>
            		
            		";
            		
            		if($ar > 0){
            		
            		echo"
            		
            		<a class='txtcol-gold dropbtn hovers nav' href='/Admin/'>
            		    <i class='fa fa-hammer txtcol-gold'></i> Admin Panel
            		</a>
            		";}
            		
            		echo"
        		    
        		</div>
	        
	        </li>
	    
	    ";
	    
	}
	
	echo"
    
</ul>

<div class='mc'>

";

if($account['GHOST']==1){
  echo"
  
  <div class='noticebar btn-red'>
        
        <b>Ghost mode enabled</b>
        
    </div><br><br>
  
  ";
}

if($CURRENT_ECONOMY['NAV_TEXT'] != ''){
  
  if($CURRENT_ECONOMY['NAV_URL'] != ''){
    $nvbr_title = "<a href='$CURRENT_ECONOMY[NAV_URL]'>$CURRENT_ECONOMY[NAV_TEXT]</a>";
  }else{$nvbr_title = "<b>$CURRENT_ECONOMY[NAV_TEXT]</b>";}
  
  echo"
    
    <div class='noticebar btn-$CURRENT_ECONOMY[NAV_COLOR]'>
        
        $nvbr_title
        
    </div>
    ";}echo"
    
    <div class='ws'></div>
  
";

if(isset($_COOKIE['KABRICK_U'])){
  $bq = mysqli_query($conn,"SELECT * FROM `BANS` WHERE `USER` = '$account[0]'");
  if(mysqli_num_rows($bq)>0){
    include($_SERVER['DOCUMENT_ROOT'] . '/User/banned.php');exit();
  }
}

//echo($_SERVER['REQUEST_URI']);
    
?>