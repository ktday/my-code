<?php

if(isset($_GET['conn'])){
    if($_GET['conn']=='disconnect'){
        header("Location: /connect-0/");exit();
    }
}

$servername = "localhost";
$username = "lord7302_kabrick";
$password = "09DnjpR6";
$database = "lord7302_kabrick";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);

// Check connection
if (!$conn) {
    //die("Connection failed: " . mysqli_connect_error());
    header("Location: /connect-0/");exit();
}

if(isset($_COOKIE['KABRICK_U'])&&isset($_COOKIE['KABRICK_P'])){
$username = mysqli_real_escape_string($conn, $_COOKIE['KABRICK_U']);
$password = mysqli_real_escape_string($conn, $_COOKIE['KABRICK_P']);
$accountQ = $conn->prepare("SELECT * FROM `USERS` WHERE `USERNAME`=? AND `PASSWORD`=?");
$accountQ->bind_param("ss", $username, $password);
$accountQ->execute();
$result = $accountQ->get_result();
$account_R = mysqli_num_rows($result);
$account = mysqli_fetch_array($result);
}

$o = 0;

//die("Kabrick will be on maintenance until 4th sept.");exit();

/*if(isset($_COOKIE['ISLOGGEDIN'])){
    if($_COOKIE['ISLOGGEDIN']=="fjewhfeoihfioodshodjhvjehjhhvhcdsjbebjfkpsajopfjdj"){}
    else{

echo"<script>window.location='https://google.com/y'</script>";

header("Location: https://google.com/y");

exit();}}exit();*/


?>