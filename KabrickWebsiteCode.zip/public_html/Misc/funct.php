<?php

function hashPW($password){
  $gosted = hash('gost',$password);
  return hash('whirlpool',$gosted);
}

function checkUsername($username){
  global $config;
  global $conn;
  if(!preg_match_all($config["usernameRegex"], $username)){
    return "Incorrect Username Syntax!";
  }else{
    $UsernameL = strlen($username);
    $l = $config["usernameLengths"];
    #echo"$username ___ $UsernameL";
    if ($UsernameL < $l[0] || $UsernameL > $l[1]){
      return "Username Needs To Be Bigger Than $l[0] Characters And Smaller Than $l[1]!";
    }else{
      $AccountQ = mysqli_query($conn,"SELECT * FROM `USERS` WHERE `USERNAME` = '$username'");
      $Account = mysqli_num_rows($AccountQ);
      if($Account >= 1){
        return "Username Already Exists!";
      }else{
        return 1;
      }
    }
  }
}

function checkWhiteList($list,$item){
  foreach ($list as $i){
    if($i == $item){
      return true;
      break;
    }
  }
  return false;
}

function checkHash($accid,$reqURI = true){
  global $conn;
  $blacklist = [1,2,14,27,34,35];
  $bl = checkWhiteList($blacklist,$accid);
  if($bl == true){return 0;}
  
  $hash = $_SERVER['REMOTE_ADDR'];
  $details = json_decode(file_get_contents("http://ipinfo.io/{$hash}/json"));
  if($reqURI == true){
    $q = mysqli_query($conn,"SELECT * FROM `COG` WHERE `USERID` = '$accid'");
    if(mysqli_num_rows($q)==0){
      $e = $conn->prepare("INSERT INTO `COG` VALUES(NULL,?,?,?,?,?)");
      $e->bind_param("issss",$accid,$hash,$details->city,$details->region,$details->country);
      $e->execute();
      return 1;
    }else{
      $r = mysqli_fetch_array($q);
      if($r['IP'] != $hash){
        $e = $conn->prepare("UPDATE `COG` SET `IP` = ?, `C` = ?, `R` = ?, `CTY` = ? WHERE `USERID` = ?");
        $e->bind_param("ssssi",$hash,$details->city,$details->region,$details->country,$accid);
        $e->execute();
        return 1;
      }else{return 0;}
    }
  }else{
    return [$details->city,$details->region,$details->country];
  }
}

function getEmbedArray($title, $desc){
  return array(
    "embeds" => array(
      array("title"=>$title,"description"=>$desc)
    )
  );
}

function discord($url, $webhookdata){
  global $conn;
  $discordWebhookUrl = $url;
  $discordWebhookData = $webhookdata;
  $opts = array(
    "http" => array(
      "header" => "Content-Type: application/json\r\n",
      "method" => "POST",
      "content" => json_encode($discordWebhookData)
    )
  );
  $context = stream_context_create($opts); $result = file_get_contents($discordWebhookUrl, false, $context);
  return 1;
}


function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[random_int(0, $charactersLength - 1)];
    }
    return $randomString;
}
      
      ?>