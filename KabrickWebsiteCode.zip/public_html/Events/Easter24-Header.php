<?php

$eggHunt = false;

function create($userid){
    // Make file
    $file_path = $_SERVER['DOCUMENT_ROOT'] . "/Events/Easter24-Data/" . $userid . ".kbevdat";
    if (!file_exists($file_path)) {
        $file = fopen($file_path, 'w');
        fclose($file);

        $time = time();

        $defData = [
            "TheEgg" => false,
            "Posts" => 0,
            "Collect" => 0,
            "Buy" => false,
            "Wall" => false,
            "Message" => false,
            "Upload" => false,
            "Eaten" => false,
            "Started" => $time,
            "LastUpdate" => $time,
            "UserID" => $userid
        ];

        $dat = json_encode($defData);
        file_put_contents($file_path, $dat);
    }
}

function update($userid, $cat){
    return 0;
    $acceptable = ["TheEgg", "Buy", "Wall", "Message", "Upload", "Eaten"];
    if(in_array($cat, $acceptable)){

        create($userid);

        $file_path = $_SERVER['DOCUMENT_ROOT'] . "/Events/Easter24-Data/" . $userid . ".kbevdat";
        $file_data = file_get_contents($file_path);
        $data = json_decode($file_data, true);

        $data[$cat] = true;
        $data["LastUpdate"] = time();

        $dat = json_encode($data);
        file_put_contents($file_path, $dat);
    }
}

function add($userid, $cat, $val){
    return 0;
    $acceptable = ["Posts", "Collect"];
    if(in_array($cat, $acceptable)){

        create($userid);

        $file_path = $_SERVER['DOCUMENT_ROOT'] . "/Events/Easter24-Data/" . $userid . ".kbevdat";
        $file_data = file_get_contents($file_path);
        $data = json_decode($file_data, true);

        $data[$cat] = $data[$cat] + $val;
        $data["LastUpdate"] = time();

        $dat = json_encode($data);
        file_put_contents($file_path, $dat);
    }
}

function get_progress($userid){
    $file_path = $_SERVER['DOCUMENT_ROOT'] . "/Events/Easter24-Data/" . $userid . ".kbevdat";
    if (file_exists($file_path)) {

        $file_data = file_get_contents($file_path);
        $data = json_decode($file_data, true);
        return $data;

    }else{
        return null;
    }
}

function has_item($conn, $userid, $itemid){
    $q = mysqli_query($conn,"SELECT * FROM `INV` WHERE `ITEM` = '$itemid' AND `USER` = '$userid'");
    if(mysqli_num_rows($q) > 0){
        return true;
    }else{
        return false;
    }
}