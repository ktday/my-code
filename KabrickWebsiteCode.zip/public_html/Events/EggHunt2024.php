<?php

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');

if(!isset($_COOKIE['KABRICK_U']) || !isset($_COOKIE['KABRICK_P'])){
    echo"<script>window.location='/'</script>";exit();
}

echo"<title>Easter 2024 | $meta_name</title>";

create($account[0]);
$progress = get_progress($account[0]);
if($progress == null){
    $progress = [
        "TheEgg" => false,
        "Posts" => 0,
        "Collect" => 0,
        "Buy" => false,
        "Wall" => false,
        "Message" => false,
        "Upload" => false,
        "Eaten" => false
    ];
}

$perc = 0;
if($progress["TheEgg"]){$perc += 10;}
if($progress["Buy"]){$perc += 10;}
if($progress["Wall"]){$perc += 10;}
if($progress["Message"]){$perc += 10;}
if($progress["Upload"]){$perc += 10;}
if($progress["Eaten"]){$perc += 10;}
if($progress["Posts"] >= 3){$perc += 10;}
if($progress["Posts"] >= 5){$perc += 10;}
if($progress["Collect"] >= 100){$perc += 10;}
if($progress["Collect"] >= 200){$perc += 10;}

$col = "white";
if($perc >= 90){$col = "gold";}
elseif($perc >= 60){$col = "purple";}
elseif($perc >= 30){$col = "blue";}

if(!$progress["TheEgg"]){
    if(has_item($conn, $account[0], 90)){
        update($account[0], "TheEgg");
    }
}


if(isset($_POST["claim"])){

    $claim = mysqli_real_escape_string($conn, $_POST["claim"]);
    if($claim == '1'){
        // id 91 -> 30%
        if($perc >= 30){
            if(!has_item($conn, $account[0], 91)){
                $lastSerial = mysqli_query($conn,"SELECT * FROM `INV` WHERE `ITEM` = '91' ORDER BY ID DESC LIMIT 1");
                $res = mysqli_fetch_array($lastSerial);
                $ls = $res["SERIAL"] + 1;
                mysqli_query($conn,"INSERT INTO `INV` VALUES(NULL, '91', '$account[0]', 'SHOULDER', '$ls')");
            }
        }
    }
    if($claim == '2'){
        // id 92 -> 60%
        if($perc >= 60){
            if(!has_item($conn, $account[0], 92)){
                $lastSerial = mysqli_query($conn,"SELECT * FROM `INV` WHERE `ITEM` = '92' ORDER BY ID DESC LIMIT 1");
                $res = mysqli_fetch_array($lastSerial);
                $ls = $res["SERIAL"] + 1;
                mysqli_query($conn,"INSERT INTO `INV` VALUES(NULL, '92', '$account[0]', 'PET', '$ls')");
            }
        }
    }
    if($claim == '3'){
        // id 93 -> 100%
        if($perc >= 90){
            if(!has_item($conn, $account[0], 93)){
                $lastSerial = mysqli_query($conn,"SELECT * FROM `INV` WHERE `ITEM` = '93' ORDER BY ID DESC LIMIT 1");
                $res = mysqli_fetch_array($lastSerial);
                $ls = $res["SERIAL"] + 1;
                mysqli_query($conn,"INSERT INTO `INV` VALUES(NULL, '93', '$account[0]', 'PET', '$ls')");
            }
        }
    }
    if($claim == '4'){
        if(!has_item($conn, $account[0], 95)){
            $lastSerial = mysqli_query($conn,"SELECT * FROM `INV` WHERE `ITEM` = '95' ORDER BY ID DESC LIMIT 1");
            $res = mysqli_fetch_array($lastSerial);
                $ls = $res["SERIAL"] + 1;
            mysqli_query($conn,"INSERT INTO `INV` VALUES(NULL, '95', '$account[0]', 'PET', '$ls')");
        }
    }

    echo"<script>window.location = '/Event/Easter2024'</script>";
    exit();
}


echo"

<div class='doublebox box1'>
    <div class='platformtitle btn-purple'>
        <h2>Rewards</h2>
    </div>

    <img src='/Misc/IMGS/SHOP/P/91.png' />
    <h3>30% reward</h3>
    <h4>Shoulder Egg</h4>

    ";

    if($perc >= 30){
        if(has_item($conn, $account[0], 91)){
            echo"<p class='txtcol-gold'>Claimed</p>";
        }else{
            echo"<form method='post'> <button class='button btn-blue hover' name='claim' value='1'>Claim</button> </form>";
        }
    }

    echo"
    <hr>

    <img src='/Misc/IMGS/SHOP/P/92.png' />
    <h3>60% reward</h3>
    <h4>Purple Egg</h4>

    ";

    if($perc >= 60){
        if(has_item($conn, $account[0], 92)){
            echo"<p class='txtcol-gold'>Claimed</p>";
        }else{
            echo"<form method='post'> <button class='button btn-purple hover' name='claim' value='2'>Claim</button> </form>";
        }
    }

    echo"
    <hr>

    <img src='/Misc/IMGS/SHOP/P/93.png' />
    <h3>90% reward</h3>
    <h4>Golden Egg</h4>

    ";

    if($perc >= 90){
        if(has_item($conn, $account[0], 93)){
            echo"<p class='txtcol-gold'>Claimed</p>";
        }else{
            echo"<form method='post'> <button class='button btn-gold hover' name='claim' value='3'>Claim</button> </form>";
        }
    }

    echo"
</div>

<div class='doublebox box2'>
    <div class='platformtitle btn-purple'>
        <h2>Easter Event 2024</h2>
    </div>

    <p>Complete challenges and gain rewards!</p>
    
    <h1 class='txtcol-$col'>Progress: $perc%</h1>

    <h2>Quest List:</h2>

    <p"; if($progress["TheEgg"]){echo" class='txtcol-gold'";} echo">Buy The Egg</p>
    <p"; if($progress["Posts"] >= 3){echo" class='txtcol-gold'";} echo">Post or reply on the forums 3 times</p>
    <p"; if($progress["Posts"] >= 5){echo" class='txtcol-gold'";} echo">Post or reply on the forums 5 times</p>
    <p"; if($progress["Collect"] >= 100){echo" class='txtcol-gold'";} echo">Collect 100 coins from hourly currency</p>
    <p"; if($progress["Collect"] >= 200){echo" class='txtcol-gold'";} echo">Collect 200 coins from hourly currency</p>
    <span class='small1'>You collect 20 currency every 30 minutes. See more on the wallet page.</span>
    <p"; if($progress["Buy"]){echo" class='txtcol-gold'";} echo">Buy 1 common item</p>
    <p"; if($progress["Wall"]){echo" class='txtcol-gold'";} echo">Post to a group wall once</p>
    <p"; if($progress["Message"]){echo" class='txtcol-gold'";} echo">Message a user once</p>
    <p"; if($progress["Upload"]){echo" class='txtcol-gold'";} echo">Upload a shirt or pants</p>
    <span class='small1'>The piece of clothing must follow guidelines and be accepted by a moderator.</span>
    <p"; if($progress["Eaten"]){echo" class='txtcol-gold'";} echo">Eat the forbidden cheese</p>

    <h4>There is also a secret egg to collect hidden somewhere in the kabrick website!</h4>
    
</div>

";

?>