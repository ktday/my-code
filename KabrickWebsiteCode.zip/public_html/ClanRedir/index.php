<?php

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/embed.php');
#include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();


echo"<title>Clans | $meta_name</title>";

if(isset($_GET['id'])){
  $id = mysqli_real_escape_string($conn,$_GET['id']);
}else{include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();}


embed(
  "Clans",
  "This user has sent a clan invite link! Click here to view the clan they have sent!"
);

$q = mysqli_query($conn,"SELECT * FROM `CLANS` WHERE `INVITE` = '$id' ORDER BY `MEMBERS` DESC LIMIT 1");

if(mysqli_num_rows($q) == 0){
  /*$q = mysqli_query($conn,"SELECT * FROM `CLANS` WHERE `ID` = '$id' ORDER BY `MEMBERS` DESC LIMIT 1");
  if(mysqli_num_rows($q) == 0){*/
    include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
  /*}else{
    $clan = mysqli_fetch_array($q);
  }*/
}else{
  $clan = mysqli_fetch_array($q);
}

#header("Location: /Clan/$clan[0]");
echo"<script>window.location='/Clan/$clan[0]'</script>";
exit();
  
?>