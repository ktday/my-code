<?php

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');

if(isset($_GET['id'])){
  $id = mysqli_real_escape_string($conn,$_GET['id']);
}else{include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();}

$q = mysqli_query($conn,"SELECT * FROM `CLANS` WHERE `INVITE` = '$id' ORDER BY `MEMBERS` DESC LIMIT 1");

if(mysqli_num_rows($q) == 0){
  /*$q = mysqli_query($conn,"SELECT * FROM `CLANS` WHERE `ID` = '$id' ORDER BY `MEMBERS` DESC LIMIT 1");
  if(mysqli_num_rows($q) == 0){*/
    include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
  /*}else{
    $clan = mysqli_fetch_array($q);
  }*/
}else{
  $clan = mysqli_fetch_array($q);
}

#header("Location: /Clan/$clan[0]");
#echo"<script>window.location='/Clan/$clan[0]'</script>";

echo nl2br("Location: <a href='/Clan/$clan[0]'>$clan[NAME]</a>
Members: $clan[MEMBERS]
Icon URL: $clan[ICON_URL]
Owner: $clan[OWNER]
Status: $clan[STATUS]
Boosts: $clan[BOOSTS]
Locked: $clan[LOCKED]
Raw Description: $clan[DESCRIPTION]
Roles:
");

$qa = mysqli_query($conn,"SELECT * FROM `CLAN_ROLES` WHERE `CLAN` = '$clan[0]' ORDER BY `LISTID` ASC");

while(($a = mysqli_fetch_array($qa))){
  echo"-> [$a[LISTID]] $a[NAME]<br>";
}
  
?>