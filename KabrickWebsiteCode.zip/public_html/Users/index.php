<?php
echo"<title>Users | Kabrick.tk Beta</title>";
include($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');
#if(!isset($_COOKIE['KABRICK_U']) || !isset($_COOKIE['KABRICK_P'])){
#  include($_SERVER['DOCUMENT_ROOT'] . '/Users/offline.php');exit();
#}
?>
<center>
<div style='width:90%;' class='platform'>
<div class='platformtitle'>
<p><u><b>All Users</b></u></p>
</div>
<br><br>
<div id='users'></div>
<br><br>
</div>
</div>
<script>
  $(document).ready(function(){
    $("#users").load("/Users/get-users.php");
  });
  
  function getPage(page){
   $("#users").load("/Users/get-users.php?page="+page+"");
  }
</script>