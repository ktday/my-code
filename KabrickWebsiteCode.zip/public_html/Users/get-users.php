<?php
include("../Misc/connect.php");
include("../Misc/vars.php");
if(isset($_GET['page']) && is_numeric($_GET['page'])){
  $pageID = intval(mysqli_real_escape_string($conn,$_GET['page']));
  $pageIDsq = ($pageID-1) * 12;
  if($pageID<1){
    $pageID = 1;
    $pageIDsq = 0;
  }
}else{
  $pageID = 1;
  $pageIDsq = 0;
}
$query = mysqli_query($conn,"SELECT * FROM `USERS` WHERE `STATUS` = 'DEFAULT' ORDER BY `LAST_ONLINE` DESC LIMIT $pageIDsq, 12");
while(($u = mysqli_fetch_array($query))){
  if(strlen($u['USERNAME']) > 15){
    if($u['NAME']=="C"){$name="CENSORED";$uuid='';}else{$name = substr($u['USERNAME'], 0, 12)."...";$uuid=$u[1];}
  }else{
    if($u['NAME']=="C"){$name="CENSORED";$uuid='';}else{$name=$u['USERNAME'];$uuid=$u[1];}
  }
  if($u['NAME']=='C'||$u[0]==1){}else{
    $last3mins = (time() - 180) + 18000;
    if($u['LAST_ONLINE'] > $last3mins){
      if($u['LAST_DEVICE'] == '1'){
          $lo = "<i class='fa fa-mobile-alt txtcol-green'></i>";
      }else{
          $lo="<i class='fa fa-circle txtcol-green'></i>";
      }
    }else{
      $lo="<i class='fa fa-circle txtcol-red'></i>";
    }
    if($u['RANK']!='MEMBER'){$icon = "<i class='fa fa-hammer txtcol-red'></i>";}else{$icon='';}
    if($u['GTIME']>$u['LAST_ONLINE']&&$ar>4){$icon2 = " <i class='fa fa-ghost txtcol-red'></i>";}else{$icon2='';}
    echo"
    <a href='/Profile/$u[1]' class='nd'>
    <div class='marketcard'>
    <div class='marketcard-img'>
    <img src='$u[AVATAR_IMG_URL]' class='avatar'>
    </div>
    <p>$icon$icon2 $name $lo</p>
    </div>&nbsp;&nbsp;
    </a>";
  }
}

if(mysqli_num_rows($query) == 0){
  echo"
  <script>function egg(){document.getElementById('box').style.display = 'inline-block';}</script>

  <span class='fas fa-egg' onclick='egg()'></span>
  
  <div id='box' class='marketcard' style='display:none;'>
    <h2>You found an egg!</h2>
    <img src='/Misc/IMGS/SHOP/P/95.png' />
    <form method='post' action='/Event/Easter2024'>
    <button class='button3 btn-purple nd hover' name='claim' value='4'>Claim egg</button>
    </form>
  </div>

  ";
}

echo"<br />";
  if(intval($pageID)!=1){
        echo "<a style='cursor:pointer;' class='button3 btn-blue nd hover' onclick='getPage(".strval(intval($pageID) - 1).")'><i class='fa fa-arrow-left'></i> Previous</a>";
    }else{
        echo "<a style='cursor:pointer;' class='button3 btn-nbg nd hover'><i class='fa fa-arrow-left'></i> Previous</a>";
    }
    echo"
    &nbsp;&nbsp; Page $pageID &nbsp;&nbsp;
    <a style='cursor:pointer;' class='button3 btn-blue nd hover' onclick='getPage(".strval(intval($pageID) + 1).")'><i class='fa fa-arrow-right'></i> Next</a>
    <br><br>";
?>