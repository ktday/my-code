<?php

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');
include($_SERVER['DOCUMENT_ROOT'] . '/bbcode.php');

echo"<title>Profile | $meta_name</title>";

if(!isset($_COOKIE['KABRICK_U']) || !isset($_COOKIE['KABRICK_P'])){
    $e = false;
}else{$e=true;}

if(!isset($_GET['u'])){echo"<script>window.location='/Profile/$account[1]'</script>";exit();}

//get info

$id = mysqli_real_escape_string($conn,$_GET['u']);
$uQ = $conn->prepare("SELECT * FROM `USERS` WHERE `USERNAME` = ?");
$uQ->bind_param("s", $id);
$uQ->execute();
$res = $uQ->get_result();
if(mysqli_num_rows($res)!=1){echo(mysqli_fetch_array($res));include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();}
$u = mysqli_fetch_array($res);

//get old names

$oldNames = array();
$selectNames = mysqli_query($conn,"SELECT * FROM `UNAME_CHANGE` WHERE `USER` = '$u[0]'");
while(($n=mysqli_fetch_array($selectNames))){
    array_push($oldNames,$n['NAME']);
}
$oN = '';
foreach($oldNames as $n){
  $oN .= $n . '<br>';
}

if(strlen($oN)==0){
  $oNC = false;
}else{
  $oNC = true;
  $oNP = $oN;
}

#var_dump($oNC);

//icons

/*if($u['RANK']=='MEMBER'){
    $rank = '';
}elseif($u['RANK']=='OWNER'){
  	$rank = "<i class='fa fa-hammer txtcol-gold'></i>";
}else{
    $rank = "<i class='fa fa-hammer txtcol-red'></i>";
}*/

$rank = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `ROLES` WHERE `NAME` = '$u[RANK]'"));
if($rank['ICON']==""){$ur = "";}else{$ur = "<i style='color:$rank[COLOR];' title='$rank[ALIAS]' class='$rank[ICON]'></i>";}

if($u['VIP']=='ULTRA'){
    $vip = "<i class='fa fa-star txtcol-gold'></i>";
}elseif($u['VIP']=='MEGA'){
    $vip = "<i class='fa fa-star txtcol-silver'></i>";
}elseif($u['VIP']=='VIP'){
    $vip = "<i class='fa fa-star txtcol-bronze'></i>";
}else{
    $vip = '';
}

//forum posts updating

$amntForumQ1 = mysqli_query($conn,"SELECT * FROM `FORUM_THREADS` WHERE `UPLOADER` = '$u[0]' AND `STATUS` = 'POST'");
$amntForum1 = mysqli_num_rows($amntForumQ1);
$amntForumQ2 = mysqli_query($conn,"SELECT * FROM `FORUM_REPLIES` WHERE `UPLOADER` = '$u[0]' AND `STATUS` = 'POST'");
$amntForum2 = mysqli_num_rows($amntForumQ2);
$forum_posts = $amntForum2 + $amntForum1;
mysqli_query($conn,"UPDATE `USERS` SET `FORUM_POSTS` = '$forum_posts' WHERE `ID` = '$u[0]'");

//networth updating

/*$networth = 0;
$selectItems = mysqli_query($conn,"SELECT * FROM `INV` WHERE `USER` = '$u[0]'");
while(($invid=mysqli_fetch_array($selectItems))){
    $item = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$invid[ITEM]'"));
    $networth = $networth + 0;
}

mysqli_query($conn,"UPDATE `USERS` SET `NETWORTH` = '$networth' WHERE `ID` = '$id'");*/

//friendship status

if($e==true){
$friend = "<a href='/Friend/$id' class='btn-blue nd hover button'>Add Friend</a>";
$hasAdded = mysqli_query($conn,"SELECT * FROM `FRIENDS` WHERE (`U1` = '$account[ID]' AND `U2` = '$u[0]') OR (`U2` = '$account[ID]' AND `U1` = '$u[0]')");
if(mysqli_num_rows($hasAdded)>0){$friend="<span class='btn-green nd hover button'>Already friends!</span>";}
$hasAdded3 = mysqli_query($conn,"SELECT * FROM `FRIEND_REQ` WHERE `SENDER` = '$account[ID]' AND `RECIEVER` = '$u[0]'");
if(mysqli_num_rows($hasAdded3)>0){$friend="<span class='btn-nbg nd hover button'>Request Pending!</span>";}
$hasAdded4 = mysqli_query($conn,"SELECT * FROM `FRIEND_REQ` WHERE `RECIEVER` = '$account[ID]' AND `SENDER` = '$u[0]'");
if(mysqli_num_rows($hasAdded4)>0){$friend="<a href='/Friends/' class='btn-green nd hover button'>Accept!</a>";}
if($u[0]==$account[0]){$friend="<span class='btn-nbg nd hover button'>Add Friend</span>";}
}else{
  $friend="<span class='btn-nbg nd hover button'>Login to add friends</span>";
}

//extras

if($u['NAME']=="C"){$user_name="CENSORED$u[0]";}else{$user_name=$u['USERNAME'];}
    
$t1 = date("H:i", $u['LAST_ONLINE']);
$t2 = gmdate("j F Y", $u['LAST_ONLINE']);
$t3 = gmdate("j F Y", $u['JOINED']);

$last3mins = (time() - 180) + 18000;
if($u['LAST_ONLINE'] > $last3mins){
    if($u['LAST_DEVICE'] == '1'){
        $lo = "<i class='fa fa-mobile-alt txtcol-green'></i>";
    }else{
        $lo="<i class='fa fa-circle txtcol-green'></i>";
    }
    $t = 'Now!';
}else{
    $lo="<i class='fa fa-circle txtcol-red'></i>";
    $t = $t2;
}

if($u['STATUS']=='DISABLED'){
    include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
}

//code

if($u['STATUS']=='BANNED'){
  if($account['RANK']=='MEMBER'){
    include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
  }else{
    echo"
    
    <div class='platform'>
        <div class='platformtitle btn-red'>
            <h2>This user has been <u>Banned</u>, <u>Warned</u> or <u>Terminated</u> by an administrator.</h2>
        </div>
    </div>
    
    <br><br>
    
    ";
  }
}

if($ar>=3){
  $n = explode(":",$u['NOTE'],2);
  $col = [
    "blue",
    "green",
    "orange",
    "red"
  ];
  $c = $col[$n[0]];
  echo"<div class='noticebar btn-$c'>
  	Mod Note: $n[1]
  </div><br><br>";
}

echo"

<div class='doublebox box1'>
    
    <div class='platformtitle'>
        <p>$ur $vip $lo <u><b>$user_name</b></u></p>
    </div>
    
    <img src='$u[AVATAR_IMG_URL]' class='avatar'>
    
    <br><br>
    
    <p>\"".bbcode_to_html($u['BIO'])."\"</p>
    
    <hr>
    
    <h3>Stats:</h3>
    
    ";if($e==true){if($account['RANK']!='MEMBER'){echo"<p>ID: $u[0]</p>";}}
	
	if($oNC == true){

	echo"
    
    <p>Past Usernames <span class='popup'><i class='fa fa-stopwatch'></i><span class='popuptext'>$oNP</span></span></p>
    
    ";}echo"
    
    <p>Join Date: $t3</p>
    
    <p title='$t1, $t2'>Last Online: $t</p>
    
    ";

if($u['GHOST']==1 && $ar > 4){

  $t4 = date("H:i", $u['GTIME']);
  $t5 = gmdate("j F Y", $u['GTIME']);
  
  echo"<p class='txtcol-red'><i class='fas fa-ghost'></i> $t4, $t5</p>";

}

echo"
    
    <p>Forum Posts: $forum_posts</p>
    
    <p>Stars: $u[STARS]</p>
    
    ";/*<p class='txtcol-gold'>Networth: <i class='fa fa-money-bill-alt'></i> $networth</p>*/echo"
    
    <hr>
    
    <p><a href='/Inventory/$id' class='btn-blue nd hover button'>User inventory</a></p>
    
    ";
    
    if($e==true){if($account[0]!=$u[0]){
        
    echo"
    
    <hr>
    
    <p>$friend</p>
    
    <p><a href='/Message/$id' class='btn-blue nd hover button'>Message</a></p>
    <p><a href='/Trade/$id' class='btn-blue nd hover button'>Trade</a></p>
    
    ";if($e==true){if($account['RANK']!='MEMBER'&&$account['RANK']!='ASSET_UPLOADER'&&$account['RANK']!='FORUMS_MOD'){
        if($account['RANK']!='OWNER'&&$u['RANK']!='MEMBER'){}else{
        if($account[0]==$u[0]){}else{
        echo"<p><a href='/Admin/?BAN=$id' class='btn-red nd hover button'>Ban</a></p>
        <p><a href='/Admin/reset.php?id=$id' class='btn-red nd hover button'>Reset Avatar</a></p>";
        }}}
      
      if($e==true){if($account['RANK']=='OWNER'||$account['RANK']=='MANAGER'){
        echo"<p><a href='/Admin/manage.php?id=$id' class='btn-purple nd hover button'>Manage User</a></p>";
      }}
        
    }}}
    
    //select friends
    
    $fQ = mysqli_query($conn,"SELECT USERS.* FROM FRIENDS
     JOIN USERS ON USERS.ID = IF(FRIENDS.U1 = '$u[0]', FRIENDS.U2, FRIENDS.U1)
     WHERE FRIENDS.U1 = '$u[0]' OR FRIENDS.U2 = '$u[0]' ORDER BY FRIENDS.ID DESC");
    $fl0 = mysqli_num_rows($fQ);
    
    //select ~~items~~ clans (upd as of 21/7/23 14:15)
    
    $iQ = mysqli_query($conn,"SELECT CLANS.* FROM MEMBERS_IN_CLANS JOIN CLANS ON CLANS.ID = MEMBERS_IN_CLANS.CLAN_ID
     WHERE MEMBERS_IN_CLANS.USER_ID = '$u[0]' ORDER BY MEMBERS_IN_CLANS.ID DESC");
    $il0 = mysqli_num_rows($iQ);
    
    //select badges
    
    $bQ = mysqli_query($conn,"SELECT BADGES.* FROM USER_BADGES JOIN BADGES ON BADGES.ID = USER_BADGES.BADGE
     WHERE USER_BADGES.USER = '$u[0]' ORDER BY BADGES.ID ASC");
    $bl0 = mysqli_num_rows($bQ);
    
    echo"
    
</div>

<div class='doublebox box2'>
    
    <div class='platformtitle'>
        <h2>Extra Stats:</h2>
    </div>
    
    ";
    
echo"    <h3>Friends ($fl0)</h3>";
    
    if(mysqli_num_rows($fQ)<1){
        echo"<p>This user has no friends! ;c</p>";
    }else{
        $x = 0;
        while(($us = mysqli_fetch_array($fQ))){
            $x += 1; if($x > 5){break;}
            
            echo"
            <a href='/Profile/$us[1]' class='nd dib'>
                <div class='forum-av'>
        			<img src='$us[AVATAR_IMG_URL]'><br>
        			<p>$us[1]</p><br><br>
            	</div>
            </a>
            ";
        }
    }
    
    echo"
	
	<hr>
	
	<h3>Clans ($il0)</h3>
	
	";
	
	if($il0<1){
        echo"<p>This user is in no clans! ;c</p>";
    }else{
        $x = 0;
        while(($u = mysqli_fetch_array($iQ))){
            $x += 1; if($x > 5){break;}
            
            echo"
            <a href='/Clan/$u[0]' class='nd dib'>
                <div class='forum-av'>
        			<img src='$u[ICON_URL]' class='clanimg'><br>
        			<p>$u[1]</p><br><br>
            	</div>
            </a>
            ";
        }#}
    }
	
	echo"
	
	<hr>
	
	<h3>Badges ($bl0)</h3>
	
	";
	
	if(mysqli_num_rows($bQ)<1){
        echo"<p>This user has no badges! ;c</p>";
    }else{
        $x = 0;
        while(($u = mysqli_fetch_array($bQ))){
            $x += 1; if($x > 5){break;}
            
            echo"
            <a href='/Badges/?id=$u[0]' class='nd dib'>
                <div class='forum-av'>
        			<img src='$u[IMAGE]'><br>
        			<p>$u[1]</p><br><br>
            	</div>
            </a>
            ";
        }
    }
	
	echo"
    
</div>

</div>

";

?>