<?php

include('../../Misc/connect.php');

$giving = mysqli_real_escape_string($conn,$_GET['give']);
$getting = mysqli_real_escape_string($conn,$_GET['get']);
$uid = mysqli_real_escape_string($conn,$_GET['u']);
$time = time();

mysqli_query($conn,"INSERT INTO `TRADES` VALUES(NULL,'$account[0]','$uid','$giving','$getting','$time','P')");
echo"<script>window.alert('Sent Trade!');window.location='/Profile/$account[1]'</script>";

?>