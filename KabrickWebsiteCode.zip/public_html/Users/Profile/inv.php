<?php

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');
include($_SERVER['DOCUMENT_ROOT'] . '/bbcode.php');

echo"<title>Inventory | $meta_name</title>";

if(!isset($_COOKIE['KABRICK_U']) || !isset($_COOKIE['KABRICK_P'])){
    $e = false;
}else{$e=true;}

if(!isset($_GET['u'])){echo"<script>window.location='/Profile/$account[1]'</script>";exit();}

//get info

$id = mysqli_real_escape_string($conn,$_GET['u']);
$uQ = $conn->prepare("SELECT * FROM `USERS` WHERE `USERNAME` = ?");
$uQ->bind_param("s", $id);
$uQ->execute();
$res = $uQ->get_result();
if(mysqli_num_rows($res)!=1){echo(mysqli_fetch_array($res));include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();}
$u = mysqli_fetch_array($res);

if($u['NAME']=="C"){$user_name="CENSORED$u[0]";}else{$user_name=$u['USERNAME'];}

if(isset($_GET['sort']) && $_GET["sort"] != ""){
  $sort = mysqli_real_escape_string($conn,$_GET['sort']);
  if($sort == "RARE"){
    $q = mysqli_query($conn,"SELECT MARKET.*, INV.SERIAL FROM INV
   JOIN MARKET ON INV.ITEM = MARKET.ID
    WHERE INV.USER = '$u[0]' AND MARKET.RARITY = 'RARE'
     ORDER BY INV.ID DESC");
  }elseif($sort == "LIMITED"){
    $q = mysqli_query($conn,"SELECT MARKET.*, INV.SERIAL FROM INV
   JOIN MARKET ON INV.ITEM = MARKET.ID
    WHERE INV.USER = '$u[0]' AND MARKET.RARITY = 'EPIC'
     ORDER BY INV.ID DESC");
  }else{
    #$q = mysqli_query($conn,"SELECT * FROM `INV` WHERE `USER` = '$u[0]' AND `TYPE` = '$sort' ORDER BY `ID` DESC");
    $q = mysqli_query($conn,"SELECT MARKET.*, INV.SERIAL FROM INV
    JOIN MARKET ON INV.ITEM = MARKET.ID
      WHERE INV.USER = '$u[0]' AND INV.TYPE = '$sort'
      ORDER BY INV.ID DESC");
  }
}else{
  $q = mysqli_query($conn,"SELECT MARKET.*, INV.SERIAL FROM INV JOIN MARKET ON INV.ITEM = MARKET.ID
   WHERE INV.USER = '$u[0]' ORDER BY INV.ID DESC");
}

$baseurl = "/Inventory/" . $id;

echo"

<div class='doublebox box1'>
    
    <div class='platformtitle'>
        <p><u><b>$user_name</b></u></p>
    </div>
    
    <br><br>
    
    <a href='$baseurl' class='button btn-blue nd hover'>All</a>
    <a href='$baseurl/HAT' class='button btn-blue nd hover'>Hats</a>
    <a href='$baseurl/FACE' class='button btn-blue nd hover'>Faces</a>
    <a href='$baseurl/MASK' class='button btn-blue nd hover'>Masks</a>
    <a href='$baseurl/GEAR' class='button btn-blue nd hover'>Tools</a>
    <a href='$baseurl/SHOULDER' class='button btn-blue nd hover'>Shoulder</a>
    <a href='$baseurl/HAIR' class='button btn-blue nd hover'>Hairs</a>
    <a href='$baseurl/BACK' class='button btn-blue nd hover'>Back Accessories</a>
    <a href='$baseurl/BODY' class='button btn-blue nd hover'>Bodies</a>
    <a href='$baseurl/SHIRT' class='button btn-blue nd hover'>Shirts</a>
    <a href='$baseurl/PANTS' class='button btn-blue nd hover'>Pants</a>
    <hr>
    <a href='$baseurl/RARE' class='button btn-purple nd hover'>Rare Items</a>
    <a href='$baseurl/LIMITED' class='button btn-gold nd hover'>Limited Items</a>
    
</div>

<div class='doublebox box2'>
    
    <div class='platformtitle'>
        <h2>Inventory</h2>
    </div>
    
    ";
    
    if(mysqli_num_rows($q)<1){
        echo"<p>This user doesn't own anything in this category</p>";
    }else{
        while(($i = mysqli_fetch_array($q))){
          #$i = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$inv[ITEM]'"));
          if($i['STATUS']=='AP'){
            


            //rarity

            if($i['RARITY']=='DEF'){
                if($i['ONSALE_TIME']==0){
                    $color = 'txtcol-white';
                  	$rarity = 'Regular Item';
                }else{
                    $color = 'txtcol-red';
                  	$rarity = 'Timer Item';
                }
            }elseif($i['RARITY']=='RARE'){
                $color = 'txtcol-purple';
                $rarity = 'Rare Item';
            }elseif($i['RARITY']=='WAR'){
                $color = 'txtcol-war';
                $rarity = 'War Item';
            }elseif($i['RARITY']=='EPIC'){
                $color = 'txtcol-gold';
                $rarity = "Limited Item (#$i[SERIAL])";
            }elseif($i['RARITY']=='EVENT'){
                $color = 'txtcol-green';
                $rarity = 'Event Item';
            }elseif($i['RARITY']=='CUSTOM'){
                $color = 'txtcol-blue';
                $rarity = 'Custom Item';
            }else{
                $color = 'txtcol-white';
                $rarity = 'Regular Item';
            }

            echo"

            <a href='/Market/Item/$i[0]' class='nd asset'>
                <div class='marketcard'>
                    <div class='marketcard-img'>
                        ";

                        if($i['RARITY']=='EPIC'){
                          if($i['ONSALE_TIME']==0){
                            echo"<img src='/Misc/IMGS/LimitedTag.png' class='avatar' style='background-image:url(\"$i[PREV_IMG]\");background-repeat: no-repeat;background-size: cover;'>";
                          }else{
                            echo"<img src='/Misc/IMGS/LimitedTimerTag.png' class='avatar' style='background-image:url(\"$i[PREV_IMG]\");background-repeat: no-repeat;background-size: cover;'>";
                          }
                        }elseif($i['RARITY']=='RARE'){
                          if($i['ONSALE_TIME']==0){
                            echo"<img src='/Misc/IMGS/RareTag.png' class='avatar' style='background-image:url(\"$i[PREV_IMG]\");background-repeat: no-repeat;background-size: cover;'>";
                          }else{
                            echo"<img src='/Misc/IMGS/RareTimerTag.png' class='avatar' style='background-image:url(\"$i[PREV_IMG]\");background-repeat: no-repeat;background-size: cover;'>";
                          }
                        }elseif($i['RARITY']=='EVENT'){
                          if($i['ONSALE_TIME']==0){
                            echo"<img src='/Misc/IMGS/EventTag.png' class='avatar' style='background-image:url(\"$i[PREV_IMG]\");background-repeat: no-repeat;background-size: cover;'>";
                          }else{
                            echo"<img src='/Misc/IMGS/EventTimerTag.png' class='avatar' style='background-image:url(\"$i[PREV_IMG]\");background-repeat: no-repeat;background-size: cover;'>";
                          }
                        }elseif($i['RARITY']=='CUSTOM'){
                          echo"<img src='/Misc/IMGS/CustomTag.png' class='avatar' style='background-image:url(\"$i[PREV_IMG]\");background-repeat: no-repeat;background-size: cover;'>";
                        }elseif($i['RARITY']=='VIP'){
                          echo"<img src='/Misc/IMGS/VipTag.png' class='avatar' style='background-image:url(\"$i[PREV_IMG]\");background-repeat: no-repeat;background-size: cover;'>";
                        }else{
                          if($i['ONSALE_TIME']==0){
                            echo"<img src='$i[PREV_IMG]' class='avatar' style='background-repeat: no-repeat;background-size: cover;'>";
                          }else{
                            echo"<img src='/Misc/IMGS/TimerTag.png' class='avatar' style='background-image:url(\"$i[PREV_IMG]\");background-repeat: no-repeat;background-size: cover;'>";
                          }
                        }

                        echo"
                    </div>
                    <div class='$color'>
                        <p>$i[1]</p>
                        <p class='small1'>$rarity</p>
                    </div>
                </div>&nbsp;&nbsp;
            </a>
            ";
        }}
    }
	
	echo"
    
</div>

</div>

";

?>