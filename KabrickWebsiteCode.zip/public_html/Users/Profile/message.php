<?php

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');
include($_SERVER['DOCUMENT_ROOT'] . '/bbcode.php');

if(!isset($_COOKIE['KABRICK_U']) || !isset($_COOKIE['KABRICK_P'])){
    exit();
}

if(!isset($_GET['u'])){echo"<script>window.location='/Profile/$account[1]'</script>";exit();}

//get info

$id = mysqli_real_escape_string($conn,$_GET['u']);
$uQ = $conn->prepare("SELECT * FROM `USERS` WHERE `USERNAME` = ?");
$uQ->bind_param("s", $id);
$uQ->execute();
$res = $uQ->get_result();
if(mysqli_num_rows($res)!=1){include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();}
$u = mysqli_fetch_array($res);

if($u['NAME']=="C"){$user_name="CENSORED$u[0]";}else{$user_name=$u['USERNAME'];}

echo"<title>Message $user_name | $meta_name</title>";

if($u[0]==$account[0]||$u['STATUS']!='DEFAULT'){echo"<script>window.location='/Profile/$account[1]'</script>";exit();}

if(isset($_POST['msg'])){
  $msg = mysqli_real_escape_string($conn,$_POST['msg']);
  $title = mysqli_real_escape_string($conn,$_POST['title']);
  if(isset($_POST['makeMessageImportant1']) && $ar > 3){$imp = '1';}
  else{$imp = '0';}
  $uQ = $conn->prepare("INSERT INTO `MESSAGES` VALUES(NULL,?,?,?,'NO','$imp','$gmt',?,'0')");
  $uQ->bind_param("ssss", $account[0], $u[0], $msg, $title);
  $uQ->execute();
  update($account[0], "Message");
  $fm = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `MESSAGES` WHERE `TITLE` = '$title' AND `SENDER` = '$account[0]' ORDER BY ID DESC LIMIT 1"));
  echo"<script>window.location='/Msg/$fm[0]'</script>";exit();
}


echo"

<div class='platform'>
    
    <div class='platformtitle'>
        <p><u><b>Message $user_name</b></u></p>
    </div>
    
    <br><br>
    
    <form method='post'>
            
            <input class='form form1l' name='title' minlength='3' placeholder='Title'><br><br>
            <textarea class='form form1l' name='msg' minlength='5'></textarea><br><br>
            
            "; if($ar > 3){echo"<input type='checkbox' name='makeMessageImportant1' id='6942069' value='0'>
  <label for='6942069'>Important?</label>";} echo"
            
            <button class='button3 btn-blue nd hover'>Send!</button>
            <p class='small1'>By pressing 'Send!' you agree that this reply is not violating any of our <a href='/help.php'>Rules</a>.</p>
            
        </form>
    
</div>

</div>

";

?>