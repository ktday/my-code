<?php
include($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');

if(isset($_GET['id'])){
  $id = mysqli_real_escape_string($conn,$_GET['id']);
  $q = $conn->prepare("SELECT * FROM `USERS` WHERE `USERNAME` = ?");
  $q->bind_param("s",$id);
  $q->execute();
  $fr = $q->get_result();
  $id = mysqli_fetch_array($fr)[0];
  
  $q = $conn->prepare("SELECT * FROM `FRIEND_REQ` WHERE `SENDER` = ? AND `RECIEVER` = ?");
  $q->bind_param("ii",$account[0],$id);
  $q->execute();
  $fr = $q->get_result();
  if(mysqli_num_rows($fr)!=0){exit();}
  
  $q = $conn->prepare("SELECT * FROM `FRIEND_REQ` WHERE `SENDER` = ? AND `RECIEVER` = ?");
  $q->bind_param("ii",$id,$account[0]);
  $q->execute();
  $fr = $q->get_result();
  if(mysqli_num_rows($fr)!=0){exit();}
  
  $q = $conn->prepare("SELECT * FROM `FRIENDS` WHERE (`U1` = ? AND `U2` = ?) OR (`U1` = ? AND `U2` = ?)");
  $q->bind_param("iiii",$account[0],$id,$id,$account[0]);
  $q->execute();
  $fr = $q->get_result();
  if(mysqli_num_rows($fr)!=0){exit();}
  
  $q = $conn->prepare("INSERT INTO `FRIEND_REQ` VALUES(NULL,?,?)");
  $q->bind_param("ii",$account[0],$id);
  $q->execute();
  //redirect
  echo"<script>window.location='/Friends/'</script>";exit();
  
}

?>