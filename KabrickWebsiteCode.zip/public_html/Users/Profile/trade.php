<?php

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');

if(!isset($_COOKIE['KABRICK_U']) || !isset($_COOKIE['KABRICK_P'])){
    exit();
}

if(!isset($_GET['id'])){echo"<script>window.location='/Profile/$account[1]'</script>";exit();}

$uname = mysqli_real_escape_string($conn,$_GET['id']);
$uQ = $conn->prepare("SELECT * FROM `USERS` WHERE `USERNAME` = ?");
$uQ->bind_param("s", $uname);
$uQ->execute();
$res = $uQ->get_result();
if(mysqli_num_rows($res)!=1){include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();}
$u = mysqli_fetch_array($res);
$id = $u[0];

$acc1_INV = mysqli_query($conn,"SELECT * FROM `INV` WHERE `USER` = '$account[0]'");
$acc2_INV = mysqli_query($conn,"SELECT * FROM `INV` WHERE `USER` = '$id'");

$INV1 = array();
$INV2 = array();

$INVIDS1 = array();
$INVIDS2 = array();

while(($i=mysqli_fetch_array($acc1_INV))){
  $item = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$i[ITEM]'"));
  if($item['RARITY']=='EPIC'){
  	array_push($INV1,$i['ITEM']);
  	array_push($INVIDS1,$i['ID']);
  }
}

while(($i=mysqli_fetch_array($acc2_INV))){
  $item = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$i[ITEM]'"));
  if($item['RARITY']=='EPIC'){
  	array_push($INV2,$i['ITEM']);
  	array_push($INVIDS2,$i['ID']);
  }
}

echo"<title>Sending trade to $u[1]</title>


<script>

const giving = [];
const getting = [];

function remove(a,id){
  for( var i = 0; i < a.length; i++){
    if ( a[i] === id){
      a.splice(i, 1);
    }
  }
}

function give(id){
  if(giving.indexOf(id) === -1){
    giving.push(id);
    document.getElementById(id).innerHTML = 'Remove';
    document.getElementById(id).classList.remove('btn-green');
    document.getElementById(id).classList.add('btn-red');
  }else{
    remove(giving,id);
    document.getElementById(id).innerHTML = 'Add';
    document.getElementById(id).classList.remove('btn-red');
    document.getElementById(id).classList.add('btn-green');
  }
}

function get(id){
  if(getting.indexOf(id) === -1){
    getting.push(id);
    document.getElementById(id).innerHTML = 'Remove';
    document.getElementById(id).classList.remove('btn-green');
    document.getElementById(id).classList.add('btn-red');
  }else{
    remove(getting,id);
    document.getElementById(id).innerHTML = 'Add';
    document.getElementById(id).classList.remove('btn-red');
    document.getElementById(id).classList.add('btn-green');
  }
}

function submit(){
   var url = '/Users/Profile/subTrd.php?give=';
   var gi = giving.join(',');
   var ge = getting.join(',');
   url += gi;
   url += '&get=';
   url += ge;
   url += '&u=$id';
   $('#res').load(url);
}


</script>


<a class='button2 btn-red nd hover' href='/Profile/$u[1]'>Back</a>
<button class='button2 btn-blue nd hover' onclick='submit()'>Send Trade!</button><e id='res'></e><br>

<div class='doublebox box5'>

  <div class='platformtitle'>
  	<p>Your Inventory</p>
  </div><br>
  
  ";

  $ID = 0;
  foreach($INV1 as $id){
    $item = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$id'"));
    $inv = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `INV` WHERE `ID` = '$INVIDS1[$ID]'"));
    echo"<div class='marketcard'>
      <div class='marketcard-img'>
        <img src='$item[PREV_IMG]' class='avatar'>
      </div>
      <div class='txtcol-white'>
        <p>$item[NAME]<br><span class='small1'>#$inv[SERIAL]</span></p>
        <button onclick='give($inv[0])' id='$inv[0]' style='border:none;width:95%;cursor:pointer;' class='button btn-green nd'>Add</a>
      </div>
    </div>";
    $ID++;
  }

echo"

</div>

<div class='doublebox box6'>

  <div class='platformtitle'>
  	<p>$u[1]'s Inventory</p>
  </div><br>
  
  ";

  $ID = 0;
  foreach($INV2 as $id){
    $item = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$id'"));
    $inv = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `INV` WHERE `ID` = '$INVIDS2[$ID]'"));
    echo"<div class='marketcard'>
      <div class='marketcard-img'>
        <img src='$item[PREV_IMG]' class='avatar'>
      </div>
      <div class='txtcol-white'>
        <p>$item[NAME]<br><span class='small1'>#$inv[SERIAL]</span></p>
        <button onclick='get($inv[0])' id='$inv[0]' style='border:none;width:95%;cursor:pointer;' class='button btn-green nd'>Add</a>
      </div>
    </div>";
    $ID++;
  }

echo"

</div>";