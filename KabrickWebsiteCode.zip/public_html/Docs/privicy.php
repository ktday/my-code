<?php

echo"<title>Privicy | Kabrick.tk Beta</title>";

include('headerPage.php');

echo"

<h1>Privicy policy</h1>

";