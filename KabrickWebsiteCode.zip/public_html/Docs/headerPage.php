<?php

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');
include($_SERVER['DOCUMENT_ROOT'] . '/bbcode.php');

echo"

<style>

r{color:red}
left{float:left;margin-left:5rem;}

</style>

<div class='platform'>
    <div class='platformtitle'>
        <h2>Legal and informative documents</h2>
    </div>

    <br>

    <a href='/Docs/rules.php' class='button3 btn-blue nd hover'>Rules</a>

    <a href='/Docs/privicy.php' class='button3 btn-blue nd hover'>Privicy</a>

    <a href='/Docs/faq.php' class='button3 btn-blue nd hover'>FAQ</a>

    <a href='/Docs/credits.php' class='button3 btn-blue nd hover'>Credits</a>

    <br><br><hr><br>

    ";

?>