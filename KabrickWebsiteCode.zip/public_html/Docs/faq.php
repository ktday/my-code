<?php

echo"<title>FAQ | Kabrick.tk Beta</title>";

include('headerPage.php');

echo"

<h1>Frequently asked questions</h1>

";