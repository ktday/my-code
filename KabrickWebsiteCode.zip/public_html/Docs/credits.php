<?php

echo"<title>Credits | Kabrick.tk Beta</title>";

include('headerPage.php');

echo"

<h1>Credits</h1>

";