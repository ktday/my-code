<?php

echo"<title>Rules | Kabrick.tk Beta</title>";

include('headerPage.php');

echo"

<h1>Rules of $meta_name</h1>

";