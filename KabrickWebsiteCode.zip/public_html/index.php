<?php

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');

echo"<title>$meta_name</title>";

if(isset($_COOKIE['KABRICK_U']) || isset($_COOKIE['KABRICK_P'])){
    echo"<script>window.location='/Home/'</script>";exit();
}

$error = "none";

if(isset($_POST['l-username']) && isset($_POST['l-password'])){
    include_once( $_SERVER['DOCUMENT_ROOT'] . '/Misc/connect.php' );
    $login_username = mysqli_real_escape_string($conn,$_POST['l-username']);
    $login_password = mysqli_real_escape_string($conn,$_POST['l-password']);
    //$login_code = mysqli_real_escape_string($conn,$_POST['l-code']);
    $login_accountQ = mysqli_query($conn,"SELECT * FROM `USERS` WHERE `USERNAME` = '$login_username'");
	$login_account_rows = mysqli_num_rows($login_accountQ);
	$login_account = mysqli_fetch_array($login_accountQ);
	if($login_account_rows >= 1){
	    $gosted = hash('gost',$login_password);
        $password = hash('whirlpool',$gosted);
	    if($password==$login_account['PASSWORD']){
	        //if($login_code==$login_account['REG_CODE']){
	        setcookie('KABRICK_U', $login_account["USERNAME"], time() + 259200, "/"); //time() + 259200
		    setcookie('KABRICK_P', $login_account["PASSWORD"], time() + 259200, "/");
		    if($login_account['2FA']=='YES'){
		        header("Location: /2fa.php?order=set&accid=$login_account[0]");exit();
		    }
            $logincount = intval($login_account['LOGINCOUNT']) + 1;
            mysqli_query($conn,"UPDATE `USERS` SET `LOGINCOUNT` = '$logincount' WHERE `ID` = '$login_account[0]'");
            checkHash($login_account[0]);
          #var_dump($login_account[0]);exit();
		    header("Location: /Home/");exit();
		    exit();
	        /*}else{
	        $error = "Incorrect Reg Code!";
	        }*/
	    }else{
	        $error = "Incorrect Password!";
	    }
	}else{
	    $error = "User Doesnt Exist!";
	}
}
    
//register code

if(isset($_POST['username']) && isset($_POST['password']) && isset($_POST['password2']) && isset($_POST['email'])) {
    $set_username = mysqli_real_escape_string($conn,$_POST['username']);
    $set_password = mysqli_real_escape_string($conn,$_POST['password']);
    $set_password2 = mysqli_real_escape_string($conn,$_POST['password2']);
    #$set_code = mysqli_real_escape_string($conn,$_POST['code']);
    $set_email = mysqli_real_escape_string($conn,$_POST['email']);
    
    if ($set_password !== $set_password2){
        $error = "Passwords Are Not Identical!";
    }else{
      $usrnameCheck = checkUsername($set_username);
      if($usrnameCheck==1){
        $ip = $_SERVER['REMOTE_ADDR'];
		$time = time();
        $dc = time() + $config['coins'];
        $sc = $config["StarterCoins"];
        $pass = hashPW($set_password2);
        $addr = hashPW($ip);
        
        $insertrow = $conn->prepare("INSERT INTO `USERS` 
        								(`ID`,`USERNAME`,`PASSWORD`,`COINS`,`BUCKS`,`EMAIL`,`IP`,`JOINED`,`LAST_ONLINE`,`DAILY_COINS`) VALUES
                                        (NULL,?,?,?,?,?,?,?,?,?)");
        $insertrow->bind_param("ssiissiii",$set_username,$pass,$sc[0],$sc[1],$set_email,$addr,$time,$time,$dc);
        $insertrow->execute();
        
        $insertAvatar = $conn -> prepare("INSERT INTO `AVATAR` VALUES (NULL,0,0,0,0,0,0,0,0,0,0,0,0,0)");
        $insertAvatar -> execute();
        
        $details = json_decode(file_get_contents("http://ipinfo.io/{$ip}/json"));
        #echo $details->city; // -> "Mountain View"
        
        $dtxt = $details->city . ", " . $details->region . ", " . $details->country;
        $text = "Username: **$set_username**\nEmail: ||$set_email||\nIP: ||$ip||\nLocation: ||$dtxt||";
        $discordWebhookUrl = "https://discord.com/api/webhooks/1130262619450769489/ecn6zIKXbJYLexbpikSRAGvkKP1Ek9wNHvvqqmbOMpnpb9z2L9V4UK8uZSZGGJbketxf";
        $discordWebhookData = array("embeds" => array(array(
          "title"=>"User Account Created","description"=>$text,"url"=>$meta_url . "/Profile/$set_username","timestamp"=>date("Y-m-d",$time) . "T" . date("H:i:s",$time) . ".000Z")));
  		$opts = array("http" => array("header" => "Content-Type: application/json\r\n","method" => "POST","content" => json_encode($discordWebhookData)));
  		$context = stream_context_create($opts); $result = file_get_contents($discordWebhookUrl, false, $context);
        
        echo"<script>window.location='/'</script>";exit();
        
      }else{
        $error = $usrnameCheck;
      }
    }
}

//reset password

if(isset($_POST['RESET'])){
    /*$reset_username = mysqli_real_escape_string($conn,$_POST['RESET']);
    $check = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `USERNAME` = '$reset_username'"));
    if($check==1){
        $acc = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `USERNAME` = '$reset_username'"));
        function checkEmail($email) {
           $find1 = strpos($email, '@');
           $find2 = strpos($email, '.');
           return ($find1 !== false && $find2 !== false && $find2 > $find1);
        }
        
        if (checkEmail($acc['EMAIL'])) {
            
            $ip = hash('gost',$_SERVER['REMOTE_ADDR']);
            
            $Rtime = time() + (24/60)/60;
            $Ntime = $Rtime - 5/60;
            
            $select = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM `RESET` WHERE `END` > '$Ntime' AND `IP` = '$ip'"));
            
            if($select>0){
                echo"<script>window.alert('You can only send one email per 5 minutes');window.location='/'</script>";exit();
            }
            
            $randChar = rand(1000000000,9999999999);
            
           mail("$acc[EMAIL]",
            "Reset Password",
            "<h1>You have requested a Password Reset on kabrick.tk!</h1><br>
            If this was not you, ignore this email.<br><br>
            Follow this link to reset your password
            <a href='//definitelynotkabrickbeta.tk/reset.php?id=$randChar'>http://definitelynotkabrickbeta.tk/reset.php?id=$randChar</a>",
            "From: noreply@definitelynotkabrickbeta.tk\r\nContent-type:text/html;charset=UTF-8");
            
            mysqli_query($conn,"INSERT INTO `RESET` VALUES(NULL,'$randChar','$acc[0]','$Rtime','$ip')");
            
            echo"<script>window.alert('Sent email to $acc[1]! Check your spam folder.');window.location='/'</script>";exit();
            
        }else{
            $error = "You did not set a valid email address.";
        }
        
    }else{
        $error = "User doesn't exist.";
    }*/
  echo"<script>window.alert('You cannot reset passwords at this time, please message an admin on the discord server.')</script>";
}

/*


            <div class='formpad'></div>
            <br>
            <input class='form' placeholder='Regcode' name='l-code' required>

*/

echo"

<div class='platform'>
    <h2>Welcome To The Kabrick.xyz Beta Site!</h2>
    <p>Join the other $ammount_users users on the site!</p>
    <p>Kabrick.xyz is currently in beta, so there may be some bugs.</p>
    ";if($error !== "none"){
	    echo"<p class='txtcol-red'>$error</p>";
	}echo"
</div>

<br><br>

<div class='indexcard signincard'>
    <div class='indexcardtop'>
        <b>Log in</b>
    </div>
    <div class='indexcardbody'>
        <form method='post'>
            <input class='form' placeholder='Username' name='l-username' required>
            <div class='formpad'></div>
            <input class='form' placeholder='Password' type='password' name='l-password' required>
            <div class='formpad'></div>
            <button class='formbtn'>Login!</button>
        </form>
        
        <br><hr>
        
        <h2>Reset your password</h2>
        <p class='small1'>This will send an email to the your email that you set</p>
        
        <form method='post'>
            <input class='form' placeholder='Username' name='RESET' required>
            <div class='formpad'></div>
            <button class='formbtn'>Reset!</button>
        </form>
    </div>
</div>

<div class='indexcard signupcard'>
    <div class='indexcardtop'>
        <b>Register</b>
    </div>
    <div class='indexcardbody'>
        <form method='post'>
            <input class='form' placeholder='Username (A-Z,a-z,0-9)' name='username' required>
            <div class='formpad'></div>
            <input class='form' placeholder='Password' type='password' name='password' required>
            <div class='formpad'></div>
            <input class='form' placeholder='Confirm Password' type='password' name='password2' required>
            <div class='formpad'></div>
            <input class='form' placeholder='Email' type='email' name='email' required>
            <div class='formpad'></div>
            <br>
            
            <div class='formpad'></div>
            <button class='formbtn'>Register!</button>
            <p class='small1'>By registering, you agree to our <a class='ud small1' href='/help.php'>terms of service</a></p>
        </form>
    </div>
</div>

</div>

";

      #<input class='form' placeholder='Regcode' name='code' value='12881' required>
      #RIP Regcode Box 2021 - 17/07/23 @ 0:01
      
?>