<?php
error_reporting(E_ALL);

if(isset($_COOKIE['KABRICK_U']) || isset($_COOKIE['KABRICK_P'])){
    echo"<script>window.location='/Home/'</script>";exit();
}else{
    
    $login_alert = "none";
    
    if(isset($_POST['username']) && isset($_POST['password']) && isset($_POST['code'])){
        include_once( $_SERVER['DOCUMENT_ROOT'] . '/Misc/connect.php' );
        $login_username = mysqli_real_escape_string($conn,$_POST['username']);
	    $login_password = mysqli_real_escape_string($conn,$_POST['password']);
	    $login_code = mysqli_real_escape_string($conn,$_POST['code']);
	    $login_accountQ = mysqli_query($conn,"SELECT * FROM `USERS` WHERE `USERNAME` = '$login_username'");
		$login_account_rows = mysqli_num_rows($login_accountQ);
		$login_account = mysqli_fetch_array($login_accountQ);
		if($login_account_rows >= 1){
		    $gosted = hash('gost',$login_password);
            $password = hash('whirlpool',$gosted);
		    if($password==$login_account['PASSWORD']){
		        if($login_code==$login_account['REG_CODE']){
		        setcookie('KABRICK_U', $login_account["USERNAME"], time() + 259200, "/"); //time() + 259200
			    setcookie('KABRICK_P', $login_account["PASSWORD"], time() + 259200, "/");
			    header("Location: /Home/");exit();
			    exit();
		        }else{
		        $login_alert = "Incorrect Reg Code!";
		        }
		    }else{
		        $login_alert = "Incorrect Password!";
		    }
		}else{
		    $login_alert = "User Doesnt Exist!";
		}
    }
    include_once( $_SERVER['DOCUMENT_ROOT'] . '/Misc/navbar.php' );
    
    echo"
    <title>Kabrick.tk</title>
    <center>
    
        <h1><i style='color:$col8;' class='fa fa-user-plus'></i> <u><b>Login!</b></u></h1>
        
        <div class='box middle' style='background-color:$col12;border-color:$col13;'>
        
            <br>
            
            <form method='post' action='login.php'>
			    <input class='Ginput' name='username' placeholder='Username' required/><br>
				<input class='Ginput' name='password' placeholder='Password' required type='password'/><br>
				<input class='Ginput' name='code' placeholder='Reg Code (The One You Used On Registering)' required/><br>
				<button class='buttonF'> Login! </button>
			</form>
            
            ";if($login_alert !== "none"){
			    echo"<p style='color:red;'>$login_alert</p>";
			}echo"
			
		</div>
	</center>
</body>
</html>
            
    ";
}
?>