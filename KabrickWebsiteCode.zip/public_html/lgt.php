<?php
 function lgt($bbtext){
    $bbtags = array(
      '<' => '&lt;',
      '>' => '&gt;'
    
    );
    
    $bbtext = str_ireplace(array_keys($bbtags), array_values($bbtags), $bbtext);
    return $bbtext;
  }
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  //I am a cat
  
  
  
  
  
  
  
  
  
  /*echo"
  
  [b] -> Bold Text
  [/b] -> End Bold Text
  [i] -> Italic Text
  [/i] -> End Italic Text
  [u] -> Underlined Text
  [/u] -> End Underlined Text
  [s] -> Crossed Out Text
  [/s] -> End Crossed Out Text
  [heading] -> Heading
  [/heading] -> End Heading
  
  [br] -> New Line
  
  [l:market] -> To Market URL
      [l:forums] -> To Forums URL
      [l:users] -> To Users URL
      [l:news] -> To News URL
      [l:badges] -> To Badges URL
      [l:friends] -> To Friends URL
      [l:settings] -> To Settings URL
      [l:messages] -> To Messages URL
      [l:trades] -> To Trades URL
      [/l] -> Ends Any URL
  
  ";*/
?>