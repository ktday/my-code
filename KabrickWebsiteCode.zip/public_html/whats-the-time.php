<?php echo("Current time: ". time());
echo"<br>";
echo(strtotime('13 May 2021')."<br>");
echo(strtotime('14 May 2021'));
echo("<br>" . strtotime('6 July 2021') . " = 6 July 2021<br><br>");

echo("<br>" . strtotime('1 November 2021') . " = 1 November 2021<br><br>");
echo("<br>" . strtotime('9 September 2023') . " = 9 September 2023<br><br>");
echo("<br>" . strtotime('7 April 2024') . " = 7 April 2024<br><br>");

function generateRandomString($length = 5) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyz';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

echo(generateRandomString() . "-" . generateRandomString() . "-" . generateRandomString() . "-" . generateRandomString() . "-" . generateRandomString());

?>