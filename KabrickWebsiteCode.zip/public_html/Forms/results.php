<?php

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');
include($_SERVER['DOCUMENT_ROOT'] . '/bbcode.php');

if(!isset($_COOKIE['KABRICK_U']) || !isset($_COOKIE['KABRICK_P'])){
    echo"<script>window.location='/'</script>";exit();
}

if(isset($_GET['id'])){

    $fid = mysqli_real_escape_string($conn,$_GET['id']);

    $formQ = mysqli_query($conn,"SELECT FORMS.*, USERS.USERNAME FROM `FORMS` INNER JOIN USERS ON USERS.ID = FORMS.CREATOR WHERE FORMS.FORMID = '$fid'");
    if(mysqli_num_rows($formQ) != 1){
        include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
    }

    $form = mysqli_fetch_array($formQ);
    $id = $form["ID"];

    if($account["ID"] == $form["CREATOR"] || $ar >= 4){

        // has access
        $folder_path = $_SERVER['DOCUMENT_ROOT'] . "/Forms/Data/$id/";
        if (file_exists($folder_path)) {

            if(!file_exists("Forms/$id.kbform")){
                include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');
                $url = "https://discord.com/api/webhooks/1026936015539163196/sFsdbfdP6q_OahTFgjJOWLOTYKwtZ_tQiNdD5E8gorcGfK7e2ZogxNeZPeeWtqI17ucw";
                $data = array(
                    "embeds" => array(
                        array("title"=>"Error with form","description"=>"The form with the ID $id has been attempted to be accessed, but a file for the form does not exist. Please create the file, or disable the form.")
                    )
                );
                discord($url, $data);
                exit();
            }

            $file = file_get_contents("Forms/$id.kbform");
            $data = json_decode($file, true);
            if ($data === null && json_last_error() !== JSON_ERROR_NONE) {
                include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');
                $url = "https://discord.com/api/webhooks/1026936015539163196/sFsdbfdP6q_OahTFgjJOWLOTYKwtZ_tQiNdD5E8gorcGfK7e2ZogxNeZPeeWtqI17ucw";
                $data = array(
                    "embeds" => array(
                        array("title"=>"Error with form","description"=>"The form with the ID $id has been attempted to be accessed, but the JSON data has not been formatted correctly. Please edit the file, or disable the form.")
                    )
                );
                discord($url, $data);
                exit();
            }

            echo"<title>Results for Form | $meta_name</title>";
            echo"<center><h1>Results for form \"$form[TITLE]\"</h1>";
            echo"<a href='/Form/$fid' class='button3 btn-blue nd hover'>Return to form</a>";
            if($ar >= 4){echo"<a href='/Admin/' class='button3 btn-red nd hover'>Admin Panel</a>";}
            echo"</center><br><br>";

            $file_pattern = $folder_path . '*.kbformdata';
            $files = glob($file_pattern);
            foreach ($files as $file) {
                if (file_exists($file)) {
                    $file_data = file_get_contents($file);

                    $fdata = json_decode($file_data, true);
                    
                    // Display nicely :)
                    echo"
                    
                    <div class='platform' id='$fdata[USERNAME]'>
                        <div class='platformtitle'>
                            <p>Response by <b>$fdata[USERNAME]</b> (#$fdata[USERID])</p>
                        </div>";

                        $x = 0;
                        foreach($data["QUESTIONS"] as $q){
                            $x = $x + 1;
                            echo"<h2>$q[TITLE]</h2><p>\"";
                            echo($fdata["DATA"][$x] . "\"</p>");
                            echo"<span class='small1'>Type: $q[TYPE]</span>";
                        }
                    echo"
                    <br><br>
                    <a href='/Message/$fdata[USERNAME]' class='button3 btn-blue nd hover'>Send a message</a>
                    <a href='/Profile/$fdata[USERNAME]' class='button3 btn-blue nd hover'>View Profile</a>
                    <br><br></div><br><br>";
                } else {
                    echo "File $file does not exist.<br><br>";
                }
            }

        }else{
            echo"<h1>There are no responses to this form.</h1>";
        }

    }else{
        include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
    }
}else{
    include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
}