<?php

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');

if(!isset($_COOKIE['KABRICK_U']) || !isset($_COOKIE['KABRICK_P'])){
    echo"<script>window.location='/'</script>";exit();
}

if($account["ISBANNED_FORMS"] == 'TRUE'){
    include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');
    $url = "https://discord.com/api/webhooks/1026936015539163196/sFsdbfdP6q_OahTFgjJOWLOTYKwtZ_tQiNdD5E8gorcGfK7e2ZogxNeZPeeWtqI17ucw";
    $data = array(
        "embeds" => array(
            array("title"=>"Laugh at this user","description"=>"$account[USERNAME] has tried to submit a form, but they are banned from using the forms. Laugh at this user.")
        )
    );
    discord($url, $data);
    exit();
}

if(isset($_GET['id'])){

    $id = mysqli_real_escape_string($conn,$_GET['id']);

    $formQ = mysqli_query($conn,"SELECT FORMS.*, USERS.USERNAME FROM `FORMS` INNER JOIN USERS ON USERS.ID = FORMS.CREATOR WHERE FORMS.ID = '$id'");
    if(mysqli_num_rows($formQ) != 1){
        include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
    }

    $form = mysqli_fetch_array($formQ);

    if($form["ENABLED"]!='1'){
        include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
    }

    $data = [];
    foreach($_POST as $k=>$v){
        if(strpos($k, 'form-') === 0){
            $iid = intval(substr($k, strlen('form-')));
            $data[$iid] = $v;
        }
    }

    if(count($data) > 0){
        ksort($data);
        $json = json_encode(
            [
                "USERNAME" => $account["USERNAME"],
                "USERID" => $account["ID"],
                "FORMID" => intval($id),
                "DATA" => $data
            ],
        JSON_PRETTY_PRINT);

        // Make folder
        $folder_path = $_SERVER['DOCUMENT_ROOT'] . "/Forms/Data/$id/";
        if (!file_exists($folder_path)) {
            mkdir($folder_path, 0777, true);
        }
        
        // Make file
        $file_path = $folder_path . $account["ID"] . ".kbformdata";
        if (!file_exists($file_path)) {
            $file = fopen($file_path, 'w');
            fclose($file);
        }

        file_put_contents($file_path, $json);

        // Discord embed
        $url = "https://discord.com/api/webhooks/1026936015539163196/sFsdbfdP6q_OahTFgjJOWLOTYKwtZ_tQiNdD5E8gorcGfK7e2ZogxNeZPeeWtqI17ucw";
        $data = array(
            "embeds" => array(
                array("title"=>"Form answered","description"=>"The form \"$form[TITLE]\" has been answered by $account[USERNAME]")
            )
        );
        discord($url, $data);

        echo"<script>window.location = '/Form/$form[FORMID]';</script>";exit();
    }else{
        echo"<h1>You have not entered any data</h1><h3>Please resubmit the form with data.</h3>";
    }

}else{

    include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();

}