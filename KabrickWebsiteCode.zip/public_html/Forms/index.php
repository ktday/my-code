<?php

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');
include($_SERVER['DOCUMENT_ROOT'] . '/bbcode.php');

if(!isset($_COOKIE['KABRICK_U']) || !isset($_COOKIE['KABRICK_P'])){
    echo"<script>window.location='/'</script>";exit();
}

if(isset($_GET['id'])){

    $fid = mysqli_real_escape_string($conn,$_GET['id']);

    $formQ = mysqli_query($conn,"SELECT FORMS.*, USERS.USERNAME FROM `FORMS` INNER JOIN USERS ON USERS.ID = FORMS.CREATOR WHERE FORMS.FORMID = '$fid'");
    if(mysqli_num_rows($formQ) != 1){
        include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
    }

    $form = mysqli_fetch_array($formQ);
    $id = $form["ID"];

    if($form["ENABLED"]!='1'){
        include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
    }
    
    // Make file
    
        /*$file = fopen($file_path, 'w');
        fclose($file);*/

    // Check form

    if(!file_exists("Forms/$id.kbform")){
        include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');
        $url = "https://discord.com/api/webhooks/1026936015539163196/sFsdbfdP6q_OahTFgjJOWLOTYKwtZ_tQiNdD5E8gorcGfK7e2ZogxNeZPeeWtqI17ucw";
        $data = array(
            "embeds" => array(
                array("title"=>"Error with form","description"=>"The form with the ID $id has been attempted to be accessed, but a file for the form does not exist. Please create the file, or disable the form.")
            )
        );
        discord($url, $data);
        exit();
    }

    $file = file_get_contents("Forms/$id.kbform");
    $data = json_decode($file, true);
    if ($data === null && json_last_error() !== JSON_ERROR_NONE) {
        include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');
        $url = "https://discord.com/api/webhooks/1026936015539163196/sFsdbfdP6q_OahTFgjJOWLOTYKwtZ_tQiNdD5E8gorcGfK7e2ZogxNeZPeeWtqI17ucw";
        $data = array(
            "embeds" => array(
                array("title"=>"Error with form","description"=>"The form with the ID $id has been attempted to be accessed, but the JSON data has not been formatted correctly. Please edit the file, or disable the form.")
            )
        );
        discord($url, $data);
        exit();
    }

    echo"<title>$form[TITLE] | $meta_name</title>";

    $title = $form["TITLE"];
    $desc = bbcode_to_html($data["DESC"]);
    $final = $data["FINAL"];
    $creator = $form["USERNAME"];

    // Check if form entered

    $folder_path = $_SERVER['DOCUMENT_ROOT'] . "/Forms/Data/$id/";
    if (file_exists($folder_path)) {
        $file_path = $folder_path . $account["ID"] . ".kbformdata";
        if (file_exists($file_path)) {
            echo"<div class='platform'>
                <div class='platformtitle btn-gold'>
                    <p><u><b>Form Completed</b></u></p>
                </div>

                <p>$final</p>
                ";
                if($ar >= 4 || $data["CREATOR"] == $account["ID"]){echo"<a href='/Forms/Results/$fid' class='button3 btn-blue nd hover'>View Results</a><br><br>";}
            echo"</div>";
            exit();
        }
    }

    echo"

        <style>.mc{width:35%!important;}</style>
    
        <div class='platform'>
            <div class='platformtitle btn-gold'>
                <p><u><b>$title</b></u></p>
            </div>

            <p>$desc</p>

            <p>Created by $creator</p>
            <span class='small1'>These forms will take in your kabrick username automatically</span>
            ";if($ar >= 4 || $data["CREATOR"] == $account["ID"]){echo"<br><br><a href='/Forms/Results/$fid' class='button3 btn-blue nd hover'>View Results</a><br><br>";}
            echo"
        </div><br><br>

        <form method='post' action='/Forms/Post/$id'>
    
    ";

    $x = 0;
    foreach($data["QUESTIONS"] as $q){
        $x = $x + 1;
        echo"
        
        <div class='platform'>
            <div class='platformtitle'>
                <p>Question $x</p>
            </div>

            <h3><u>$q[TITLE]</u></h3>

        ";

        if(array_key_exists("DESC", $q)){
            $desc = bbcode_to_html($q["DESC"]);
            echo"<p>$desc</p>";
        }

        $req = false;
        if(array_key_exists("REQUIRED",$q)){
            if($q["REQUIRED"] == true){
                $req = true;
            }
        }

        if($q["TYPE"] == "INPUT"){

            if(array_key_exists("MAX",$q)){
                $max = $q["MAX"];
            }else{
                $max = 63;
            }
            

            echo"<input type='text' class='form form1l' maxlength='$max' placeholder='Enter your answer here' name='form-$x' ";
            if($req){echo"required";}
            echo"><br><br>";
        }elseif($q["TYPE"] == "NUMBER"){
            echo"<input type='number' class='form form1l' placeholder='Enter a number here' name='form-$x' ";
            if(array_key_exists("MAX", $q)){echo"max='$q[MAX]' ";}
            if(array_key_exists("MIN", $q)){echo"max='$q[MIN]' ";}
            echo"required><br><br>";
        }elseif($q["TYPE"] == "TEXTAREA"){
            echo"<textarea class='form form1l' placeholder='Enter your answer here' name='form-$x' ";
            if(array_key_exists("MAX", $q)){echo"max='$q[MAX]' ";}
            else{echo("max='255' ");}
            echo"required></textarea><br><br>";
        }elseif($q["TYPE"] == "RADIO"){
            foreach($q["ANSWERS"] as $a){
                echo"<input type='radio' value='$a' name='form-$x' required><label>$a</label><br><br>";
            }
        }elseif($q["TYPE"] == "DROPDOWN"){
            echo"<select name='form-$x' class='form form1l' required>";
            foreach($q["ANSWERS"] as $a){
                echo"<option>$a</option>";
            }
            echo"</select><br><br>";
        }else{
            echo"This question is invalid. Please skip this.";
        }

        if($req){echo"<span class='small1'>This is a required question</span>";}

        echo"</div><br><br>";
    }


    echo"

    <center><button class='button3 btn-blue nd hover'>Submit</button></center>
    
    </form>

    ";


}else{
    include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
}

?>