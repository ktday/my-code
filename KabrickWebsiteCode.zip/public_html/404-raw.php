<center>
    
    <style>
        
        p{font-size:10rem;}
        
    </style>
    
    <p>404</p>
    <h2>The page you have requested cannot be found.</h2>
    
    </div>
    
</center>