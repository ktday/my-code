<?php

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');

echo"<title>Leaderboards | $meta_name</title>";

if(!isset($_COOKIE['KABRICK_U']) || !isset($_COOKIE['KABRICK_P'])){
    
}

if(!isset($_GET['type'])){
    echo"<script>window.location='/Leaderboards/Forum'</script>";exit();
}

$type = mysqli_real_escape_string($conn,$_GET['type']);

if($type=='Forum'){
    $t = 'FORUM_POSTS';
    $after = "Posts";
}elseif($type=='Bucks'){
    $t = 'BUCKS';
    $after = "Bucks";
}elseif($type=='Coins'){
    $t = 'COINS';
    $after = "Coins";
}else{
    echo"<script>window.location='/Leaderboards/Forum'</script>";exit();
}

$υβ = 'UNVERIFIED';
$β = 'VERIFIED';

$listQ = $conn->prepare("SELECT * FROM `USERS` WHERE `STATUS` = 'DEFAULT' AND `$t` != '0' ORDER BY `$t` DESC LIMIT 10");
//$listQ->bind_param("s", $t);
$listQ->execute();
$list = $listQ->get_result();

echo"

<div class='doublebox box1'>
    <div class='platformtitle'>
        <h2>Leaderboards</h2>
        If something appears to be out of the ordinary, click report on their profile.
    </div><br>
    
    <a href='/Leaderboards/Forum' class='button btn-blue nd hover'>Forum Posts</a>
    
    <a href='/Leaderboards/Bucks' class='button btn-blue nd hover'>Bucks</a>
    <a href='/Leaderboards/Coins' class='button btn-blue nd hover'>Coins</a>
    
</div>

<div class='doublebox box2'>
    
    ";
    
    $x = 1;
    while(($u = mysqli_fetch_array($list))){
        if($x==1){$c='gold';}elseif($x==2){$c='silver';}elseif($x==3){$c='bronze';}else{$c='white';}
        echo"
        <a href='/Profile/$u[1]' class='nd'>
            
            <div class='forum-av'>
    			<img src='$u[AVATAR_IMG_URL]'><br><br>
        	</div>
        		
        	<div class='forum-st'>
        		<text class='txtcol-$c'><b>#$x $u[1]</b><br><br>$u[$t] $after</text><br><br>
        	</div>
        	
        </a><hr>
        ";$x = $x + 1;
    }
    
    echo"
    
</div>

</div>

";

?>