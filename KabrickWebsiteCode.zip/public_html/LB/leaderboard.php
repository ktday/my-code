<?php

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/navbar.php');

if(isset($_COOKIE['KABRICK_U']) || isset($_COOKIE['KABRICK_P'])){}else{
    echo"<script>window.location='/'</script>";
}

echo"
<title>Kabrick.tk - Forum Leaderboard</title>
<center>
<h1><i style='color:$col8;' class='fa fa-comments'></i> <u><b>Forum Leaderboard</b></u></h1>
<div class='box middle' style='background-color:$col12;border-color:$col13;'>
    <br>
    <a href='/Forums/'>Return</a><br><br>
    ";
    
    $findEveryone = mysqli_query($conn,"SELECT * FROM `USERS` WHERE `STATUS` = 'VERIFIED' OR `STATUS` = 'UNVERIFIED' ORDER BY `FORUM_POSTS` DESC");
    $x = 1;
    
    while(($everyone=mysqli_fetch_array($findEveryone))){
        echo"#$x <a id='$everyone[0]' href='/Users/Profile/?id=$everyone[0]'>$everyone[1]</a> has <b>$everyone[FORUM_POSTS]</b> Forum Posts!<br><br>";
        $x = $x + 1;
        if($x==4){echo"<hr><br>";}
    }
    
    echo"
    <br>
</div>
</center>
</body>
</html>";

?>