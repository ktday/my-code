<?php

include_once("Misc/gamma-nav.php");

if(!isset($_GET['id'])){
  include_once("404-raw.php");exit();
}else{
  $id = mysqli_real_escape_string($conn,$_GET['id']);
  $url = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `_redir` WHERE `ID` = '$id'"));
  echo"<script>window.location = '$url[URL]'</script><p>Get the fuck out of here.</p>";
}