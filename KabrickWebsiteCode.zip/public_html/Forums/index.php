<?php

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');

echo"<title>Forums | $meta_name</title>";

if(isset($_COOKIE['KABRICK_U']) || isset($_COOKIE['KABRICK_P'])){
    if($account['ISBANNED_FORUMS']=='TRUE'){
    	echo"<script>window.alert('You have been banned from using the forums!');window.location='/'</script>";exit();
	}
	$e = true;
}else{$e=false;}
#echo $e ? 'true' : 'false';

$forumsQ = mysqli_query($conn,"SELECT * FROM `FORUMS` WHERE 1");

echo"

<div class='platform'>

    <div class='platformtitle'>
        <p>Welcome to the Kabrick.tk forums!</p>
    </div>

";

if($e==false){
  echo"Login to use the forums!";exit();
}

while(($forums=mysqli_fetch_array($forumsQ))){
    if($forums['PRIVATE']=='NO'){
        echo"
        
        <br>
        <div class='forumclass'>
            <p><a href='topic.php?id=$forums[0]' class='nd'><i class='fa fa-comments'></i> $forums[NAME]<br><span class='small1'>$forums[DESCRIPTION]</span></a></p>
        </div>
        
        ";
    }elseif($forums['PRIVATE']=='ADMIN'){
        if($e==true){if($account['RANK']=='ADMIN'||$account['RANK']=='OWNER'||$account['RANK']=='EXECUTIVE'||$account['RANK']=='MANAGER'||$account['RANK']=='MODERATOR'){
        echo"
        
        <br>
        <div class='forumclass'>
            <p><a href='topic.php?id=$forums[0]' class='nd'><span class='txtcol-red'><i class='fa fa-comments'></i> $forums[NAME]</span><br><span class='small1'>$forums[DESCRIPTION]</span></a></p>
        </div>
        
        ";
        }}
    }elseif($forums['PRIVATE']=='VIP'){
        if($e==true){if($account['VIP']!='NONE'){
        echo"
        
        <br>
        <div class='forumclass'>
            <p><a href='topic.php?id=$forums[0]' class='nd'><span class='txtcol-gold'><i class='fa fa-comments'></i> $forums[NAME]</span><br><span class='small1'>$forums[DESCRIPTION]</span></a></p>
        </div>
        
        ";
        }}
    }
}

echo"

<br>

</div></div>

";

if($account[0]==2){
$forumsQ = mysqli_query($conn,"SELECT * FROM `FORUM_THREADS` WHERE 1 ORDER BY `ID` DESC");
  
    
    while(($f = mysqli_fetch_array($forumsQ))){
        
        $u = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$f[UPLOADER]'"));
        $r = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM `FORUM_REPLIES` WHERE `POST` = '$f[0]'"));
        if($f['LOCKED']=='YES'){$l="<span class='fa fa-lock'></span> ";}else{$l='';}
      	if($f['PINNED']=='YES'){$p="<span class='fa fa-thumbtack'></span> ";}else{$p='';}
      	if($f['STATUS']=='DELETED'){$b="<span class='fa fa-hammer'></span> ";}else{$b='';}
      	if($f['STATUS']=='CENSORED'){$p="<span class='fa fa-ban'></span> ";}else{$c='';}
      $ttl = lgt($f['TITLE']);
        
        echo"
        
        <div class='forumpost'>
        
            <a href='/Forums/Post/$f[0]'>$l$p$b$c$ttl<br><span class='small2'>By $u[1] - $r Replies</span></a>
        
        </div><br>
        
        ";
    }
}

?>