<?php

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');
include($_SERVER['DOCUMENT_ROOT'] . '/Forums/main.php');

echo"<title>Forums | $meta_name</title>";

if(isset($_COOKIE['KABRICK_U']) || isset($_COOKIE['KABRICK_P'])){
    if($account['ISBANNED_FORUMS']=='TRUE'){
    	include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
	}
    $e = true;
}else{$e=false;exit();}

if(!isset($_GET['id'])||!is_numeric($_GET['id'])){
    echo"<script>window.location='/Forums/'</script>";exit();
}

$id = mysqli_real_escape_string($conn,$_GET['id']);

$topicQ = mysqli_query($conn,"SELECT * FROM `FORUMS` WHERE `ID` = '$id'");
$topic = mysqli_fetch_array($topicQ);
if(mysqli_num_rows($topicQ)==0){include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();}

if($topic['PRIVATE']=='ADMIN'){
    if($ar < 2){
        einclude($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
    }
}elseif($topic['PRIVATE']=='VIP'){
    if($account['VIP']=='NONE'){
        include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
    }
}

$forumsPQ = mysqli_query($conn,"SELECT * FROM `FORUM_THREADS` WHERE `TOPIC` = '$id' AND `PINNED` = 'YES' AND `STATUS` = 'POST' ORDER BY `ID` ASC");
$forumsQ = mysqli_query($conn,"SELECT * FROM `FORUM_THREADS` WHERE `TOPIC` = '$id' AND `PINNED` = 'NO' AND `STATUS` = 'POST' ORDER BY `ID` DESC");

if($e==true&&isset($_POST['t'])&&isset($_POST['b'])){
    if($account['ISBANNED_FORUMS']=='TRUE'){
        include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
    }
    $data_t = mysqli_real_escape_string($conn,$_POST['t']);
    $data_b = mysqli_real_escape_string($conn,$_POST['b']);
  
    $lpq = searchLastPost($account[0],time());
  	if($lpq == 1){
      $pp = postPost($account[0],$data_t,$data_b,$id);
      if($pp == 2){echo"<script>window.alert('Title should be between $tlen[0] and $tlen[1] characters');window.location='/Forums/Topic/$id'</script>";exit();}
      if($pp == 3){echo"<script>window.alert('Body should be between $blen[0] and $blen[1] characters');window.location='/Forums/Topic/$id'</script>";exit();}
      if($pp == 1){
        add($account[0], "Posts", 1);
      	$lastPost = findLastPost($account[0]);
        if($lastPost == 0){echo"<script>window.location='/Forums/Topic/$id'</script>";exit();}
        else{echo"<script>window.location='/Forums/Post/$lastPost[ID]'</script>";exit();}
      }
    }
}

echo"

<div class='platform'>
    
    <div class='platformtitle'>
        <p><u><b>$topic[1]</b></u><br><span class='small2'>$topic[2]</span></p>
    </div>
    
    <br>";if($e==true){echo"
    
    <script>
    
    function logs() {
        document.getElementById('logdiv').style.display = 'block';
        document.getElementById('logdivo').style.display = 'block';
    }
    
    function clogs() {
        document.getElementById('logdiv').style.display = 'none';
        document.getElementById('logdivo').style.display = 'none';
    }
    
    </script>
    
    <button onclick='logs()' class='button3 btn-blue nd hover'>Create a thread</button>
    
    <br><br>
    
    <div id='logdivo' class='logdiv wallet-overlay' style='display: none;'></div>
    
    <div id='logdiv' class='logdiv wallet-alert-overlay' style='display: none;'>
        
        <div class='wallet-alert'>
            
            <div class='platformtitle border-radius-5px'>
                <p><u><b>Create a thread in $topic[1]</b></u></p>
            </div>
            
            <form method='post'>
            
                <br>
                
                <input class='form form1l' name='t' minlength='$tlen[0]' maxlength='$tlen[1]' placeholder='Title'><br><br>
                
                <textarea class='form form1l' name='b' minlength='$blen[0]' maxlength='$blen[1]'></textarea><br><br>
                
                <button class='button3 btn-blue nd hover'>Post!</button>
                <p class='small1'>By pressing 'Post!' you agree that this post is not violating any of our <a href='/help.php'>Rules</a>.</p>
                
            </form>
            
            <br><button onclick='clogs()' class='button3 btn-blue nd hover'>Close</button>
            
            
        </div>
        
    </div>
    
    ";}
    
    while(($f = mysqli_fetch_array($forumsPQ))){
        
        $u = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$f[UPLOADER]'"));
        $r = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM `FORUM_REPLIES` WHERE `POST` = '$f[0]'"));
        if($f['LOCKED']=='YES'){$l=" <span class='fa fa-lock'></span>";}else{$l='';}
      
      $ttl = lgt($f['TITLE']);
        
        echo"
        
        <div class='forumpost'>
        
            <a href='/Forums/Post/$f[0]'><span class='fa fa-thumbtack'></span>$l $ttl<br><span class='small2'>By $u[1] - $r Replies</span></a>
        
        </div><br>
        
        ";
    }
    
    while(($f = mysqli_fetch_array($forumsQ))){
        
        $u = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$f[UPLOADER]'"));
        $r = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM `FORUM_REPLIES` WHERE `POST` = '$f[0]'"));
        if($f['LOCKED']=='YES'){$l="<span class='fa fa-lock'></span> ";}else{$l='';}
      
      $ttl = lgt($f['TITLE']);
        
        echo"
        
        <div class='forumpost'>
        
            <a href='/Forums/Post/$f[0]'>$l$ttl<br><span class='small2'>By $u[1] - $r Replies</span></a>
        
        </div><br>
        
        ";
    }
    
    echo"
    
</div>
</div>

";

?>