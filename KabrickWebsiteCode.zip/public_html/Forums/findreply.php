<?php
include($_SERVER['DOCUMENT_ROOT'] . '/Misc/navbar.php');

if(isset($_COOKIE['KABRICK_U']) || isset($_COOKIE['KABRICK_P'])){}else{
    echo"<script>window.location='/'</script>";
}
if(isset($_GET['id'])){$id = mysqli_real_escape_string($conn,$_GET['id']);
$eQ=mysqli_query($conn,"SELECT * FROM `FORUM_REPLIES` WHERE `ID` = '$id'");
$e=mysqli_fetch_array($eQ);
$pQ=mysqli_query($conn,"SELECT * FROM `FORUM_THREADS` WHERE `ID` = '$e[4]'");
$p=mysqli_fetch_array($pQ);
echo"<script>window.location='/Forums/post.php?id=$p[0]#r$id'</script>";}
else{echo"<script>window.location='/'</script>";}