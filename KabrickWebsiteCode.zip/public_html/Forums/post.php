<?php

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');
include($_SERVER['DOCUMENT_ROOT'] . '/bbcode.php');
include($_SERVER['DOCUMENT_ROOT'] . '/Forums/main.php');

echo"<title>Forums | $meta_name</title>";

if(isset($_COOKIE['KABRICK_U']) || isset($_COOKIE['KABRICK_P'])){
    if($account['ISBANNED_FORUMS']=='TRUE'){
    	include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
	}
  $e = true;
}else{$e = false;exit();}

if($account['RANK']=='OWNER'){$r=6;}
elseif($account['RANK']=='MANAGER'){$r=5;}
elseif($account['RANK']=='EXECUTIVE'){$r=4;}
elseif($account['RANK']=='ADMIN'){$r=3;}
elseif($account['RANK']=='MODERATOR'){$r=2;}
else{$r=0;}

if(isset($_GET['id'])&&is_numeric($_GET['id'])){

$id = mysqli_real_escape_string($conn,$_GET['id']);

$forumsQ = mysqli_query($conn,"SELECT * FROM `FORUM_THREADS` WHERE `ID` = '$id'");
if(mysqli_num_rows($forumsQ)==0){include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();}
$forums = mysqli_fetch_array($forumsQ);

$forumQ = mysqli_query($conn,"SELECT * FROM `FORUMS` WHERE `ID` = '$forums[TOPIC]'");
if(mysqli_num_rows($forumQ)==0){include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();}
$forum = mysqli_fetch_array($forumQ);

if($forums['LOCKED']=='YES'){$cp=0;}else{$cp=1;}
  
  $xr1 = "";
  $xrtitle = lgt($forums['TITLE']);
  $xrbody = bbcode_to_html(nl2br(htmlentities($forums['BODY'])));
  $xr0 = 1;

if($forums['STATUS']=='CENSORED'){
    $name="Post Censored";$body="This post has been censored by an admin!";
    $xr0 = 2;
}elseif($forums['STATUS']=='MODERATED'){
    $name="Post Moderated";$body="This post has been moderated by an admin!";$cp=0;
    $xr0 = 3;
}elseif($forums['STATUS']=='DELETED'){
  if($ar!=6){
    include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
  }else{
    $xr1 = "style='background-color:#411;'";
    $name = $xrtitle;
    $body = $xrbody;
  }
}else{
    $name=lgt($forums['TITLE']);$body=bbcode_to_html(nl2br(htmlentities($forums['BODY'])));
}

$repQ = mysqli_query($conn,"SELECT * FROM `FORUM_REPLIES` WHERE `POST` = '$id'");
$repN = mysqli_num_rows($repQ);

$uQ = mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$forums[UPLOADER]'");
        $u = mysqli_fetch_array($uQ);
        $d = date("H:i", $forums['TIME']);
        $d2 = gmdate("j F Y", $forums['TIME']);
  		if($r>0){
         $btn = "<button class='button3 btn-red nd hover' name='delete'>Delete Thread</button>"; 
         $btn2 = "<button class='button3 btn-red nd hover' name='censor'>Censor Thread</button>"; 
        }else{
         $btn = null;
          $btn2 = null;
        }
  		$rank = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `ROLES` WHERE `NAME` = '$u[RANK]'"));
        if($rank['ICON']==""){$ur = "";}else{$ur = "<i class='$rank[ICON]'></i>";}
        /*if($u['RANK']=='OWNER'||$u['RANK']=='MANAGER'||$u['RANK']=='EXECUTIVE'||$u['RANK']=='ADMIN'||$u['RANK']=='MODERATOR'||$u['RANK']=='FORUMS_MOD'){
            $ur="<i class='fa fa-hammer txtcol-red'></i>";
        }else{
            $ur='';
        }*/
        
if($e == true && isset($_POST['b'])){
    if($account['ISBANNED_FORUMS']=='TRUE'){
        include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
    }
    $data_b = mysqli_real_escape_string($conn,$_POST['b']);
  
    if($ar > 4){$cmdq = checkForCommand($data_b,intval($id));}else{$cmdq = false;}
  
  	if($cmdq != true){
  
        $lpq = searchLastReply($account[0],time());
        if($lpq == 1){
            $pp = postReply($account[0],$data_b,intval($id));
            if($pp == 3){echo"<script>window.alert('Body should be between $blen[0] and $blen[1] characters');window.location='/Forums/Post/$id'</script>";exit();}
            if($pp == 1){
                add($account[0], "Posts", 1);
                echo"<script>window.location='/Forums/Post/$id'</script>";exit();
            }
        }
    }else{
      echo"<script>window.location='/Forums/Post/$id'</script>";exit();
    }
}
  
if(isset($_POST['delete'])){
 //being forced at gunpoint to do this, oh well
 // - jp boi
  $del = $_POST['delete'];
  if($r>0){
    mysqli_query($conn,"UPDATE `FORUM_THREADS` SET `STATUS`='DELETED' WHERE `ID`='$id'");
    echo"<script>window.alert('Successfully deleted thread!');window.location='/Forums/post.php?id=$id'</script>";exit();
  }else{
        echo"<script>window.alert('bro ur not an admin u fuking autist');window.location='/Forums/post.php?id=$id'</script>";exit();
  }
}
  
if(isset($_POST['censor'])){
 //jew
  $del = $_POST['censor'];
  if($r>0){
    mysqli_query($conn,"UPDATE `FORUM_THREADS` SET `STATUS`='CENSORED' WHERE `ID`='$id'");
    echo"<script>window.alert('Successfully censored thread!');window.location='/Forums/post.php?id=$id'</script>";exit();
  }else{
        echo"<script>window.alert('bro ur not an admin u fuking autist');window.location='/Forums/post.php?id=$id'</script>";exit();
  }
}

if($e==true){echo"

<script>

function logs() {
    document.getElementById('logdiv').style.display = 'block';
    document.getElementById('logdivo').style.display = 'block';
}

function clogs() {
    document.getElementById('logdiv').style.display = 'none';
    document.getElementById('logdivo').style.display = 'none';
}

</script>

<div id='logdivo' class='logdiv wallet-overlay' style='display: none;'></div>
    
<div id='logdiv' class='logdiv wallet-alert-overlay' style='display: none;'>
    
    <div class='wallet-alert'>
        
        <div class='platformtitle border-radius-5px'>
            <p><u><b>Reply to $u[1]</b></u></p>
        </div>
        
        <form method='post'>
        
            <br>
            
            <textarea class='form form1l' name='b' minlength='5' maxlength='500'></textarea><br><br>
            
            <button class='button3 btn-blue nd hover'>Reply!</button>
            <p class='small1'>By pressing 'Reply!' you agree that this reply is not violating any of our <a href='/help.php'>Rules</a>.</p>
            
        </form>
        
        <br><button onclick='clogs()' class='button3 btn-blue nd hover'>Close</button>
        
        
    </div>
    
</div>";}echo"

<div class='platform' $xr1>

    <div class='platformtitle'>
        <h2>$name</h2>
    </div>
    
    Created at $d, $d2<br>
    <span class='small1'>Posted in <a href='/Forums/Topic/$forum[0]' class='small1'>$forum[NAME]</a></span>
    
    <div class='forum-body'>
    
        <div class='forum-av'>
            <a href='/Profile/$u[1]'>
                <img src='$u[AVATAR_IMG_URL]'>
                <br>
                <br>
                <b style='color:$rank[COLOR];'>$u[1] $ur</b>
            </a>
        </div>
    
        <div class='forum-st'>
            $body
        </div>
        <form method='post'>
        $btn
        </form>        <form method='post'>
        $btn2
        </form>
    
    </div>
    
    <br>
    
    ";if($e==true){echo"<button onclick='logs()' class='button3 btn-blue nd hover'>Reply</button>";}echo"
    
    <br><br>

</div>

";

$replies = mysqli_query($conn,"SELECT * FROM `FORUM_REPLIES` WHERE `POST` = '$id' AND `STATUS` != 'DELETED' ORDER BY `ID` ASC LIMIT 10");

while(($r=mysqli_fetch_array($replies))){
    
    $uuQ = mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$r[UPLOADER]'");
    $uu = mysqli_fetch_array($uuQ);
    $dd = date("H:i", $r['TIME']);
    $dd2 = gmdate("j F Y", $r['TIME']);
    $rank = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `ROLES` WHERE `NAME` = '$uu[RANK]'"));
    if($rank['ICON']==""){$uur = "";}else{$uur = "<i class='$rank[ICON]'></i>";}
    
    $body=bbcode_to_html(nl2br(htmlentities($r['TEXT'])));
    
    echo"
    
    <br><br>
    
    <div class='platform'>
        
        Replied at $dd, $dd2
        
        <div class='forum-body'>
        
            <div class='forum-av'>
                <a href='/Profile/$uu[1]'>
                    <img src='$uu[AVATAR_IMG_URL]'>
                    <br>
                    <br>
                    <b style='color:$rank[COLOR];'>$uu[1] $uur</b>
                </a>
            </div>
        
            <div class='forum-st'>
                $body
            </div>
        
        </div>
    
    </div>
    
    ";
}

echo"

</div>

";

}

?>