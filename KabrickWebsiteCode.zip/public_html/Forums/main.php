<?php

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/connect.php');
  
$tlen = [3,45];
$blen = [5,512];

function searchLastPost($accid,$time){
  global $conn;
  $time2 = $time - 300;
  $q = $conn->prepare("SELECT * FROM `FORUM_THREADS` WHERE `UPLOADER` = ? AND `TIME` > ?");
  $q->bind_param("ii",$accid,$time2);
  $q->execute();
  $c = $q->num_rows;
  if($c > 0){return 0;}
  else{return 1;}
}

function searchLastReply($accid,$time){
  global $conn;
  $time2 = $time - 60;
  $q = $conn->prepare("SELECT * FROM `FORUM_REPLIES` WHERE `UPLOADER` = ? AND `TIME` > ?");
  $q->bind_param("ii",$accid,$time2);
  $q->execute();
  $c = $q->num_rows;
  if($c > 0){return 0;}
  else{return 1;}
}

function findLastPost($accid){
  global $conn;
  $q = $conn->prepare("SELECT * FROM `FORUM_THREADS` WHERE `UPLOADER` = ?");
  $q->bind_param("i",$accid);
  $q->execute();
  $c = $q->get_result();
  if($q->num_rows < 1){return 0;}
  else{return mysqli_fetch_array($q);}
}

function postPost($accid,$title,$desc,$topic){
  global $conn;
  $time = time();
  
  global $tlen;
  global $blen;
  
  if(!(strlen($title) >= $tlen[0] && strlen($title) <= $tlen[1])){
    return 2;
  }
  
  if(!(strlen($desc) >= $blen[0] && strlen($desc) <= $blen[1])){
    return 3;
  }
  
  $q = $conn->prepare("INSERT INTO `FORUM_THREADS` (`ID`,`TITLE`,`BODY`,`UPLOADER`,`TIME`,`TOPIC`) VALUES (NULL,?,?,?,?,?)");
  $q->bind_param("ssiii",$title,$desc,$accid,$time,$topic);
  $q->execute();
  
  return 1;
}

function postReply($accid,$desc,$topic){
  global $conn;
  $time = time();
  
  global $blen;
  
  if(!(strlen($desc) >= $blen[0] && strlen($desc) <= $blen[1])){
    return 3;
  }
  
  $q = $conn->prepare("INSERT INTO `FORUM_REPLIES` (`ID`,`TEXT`,`UPLOADER`,`TIME`,`POST`) VALUES (NULL,?,?,?,?)");
  $q->bind_param("siii",$desc,$accid,$time,$topic);
  $q->execute();
  
  return 1;
}

function checkForCommand($text,$postID){
  global $conn;
  if(substr($text,0,5) == "!move"){
    $channel = substr($text,6,1);
    
    $q = $conn->prepare("UPDATE `FORUM_THREADS` SET `TOPIC` = ? WHERE `ID` = ?");
    $q->bind_param("ii",$channel,$postID);
    $q->execute();
    
    return true;
  }
  elseif(substr($text,0,5) == "!help"){
    echo"<script>window.alert('!move [topic], !delete, !censor, !reset, !lock <1/0>, !pin <1/0>');</script>";
    return true;
  }
  elseif(substr($text,0,7) == "!delete"){
    
    $q = $conn->prepare("UPDATE `FORUM_THREADS` SET `STATUS` = 'DELETED' WHERE `ID` = ?");
    $q->bind_param("i",$postID);
    $q->execute();
    
    return true;
  }
  elseif(substr($text,0,7) == "!censor"){
    
    $q = $conn->prepare("UPDATE `FORUM_THREADS` SET `STATUS` = 'CENSORED' WHERE `ID` = ?");
    $q->bind_param("i",$postID);
    $q->execute();
    
    return true;
  }
  elseif(substr($text,0,6) == "!reset"){
    
    $q = $conn->prepare("UPDATE `FORUM_THREADS` SET `STATUS` = 'POST' WHERE `ID` = ?");
    $q->bind_param("i",$postID);
    $q->execute();
    
    return true;
  }
  elseif(substr($text,0,5) == "!lock"){
    $channel = substr($text,6,1);
    
    if($channel != '1' && $channel != '0'){echo"<script>window.alert('Must use 1 and 0, like !lock 1');</script>";return true;}
    if($channel == '1'){$egg="YES";}else{$egg="NO";}
    
    $q = $conn->prepare("UPDATE `FORUM_THREADS` SET `LOCKED` = '$egg' WHERE `ID` = ?");
    $q->bind_param("i",$postID);
    $q->execute();
    
    return true;
  }
  elseif(substr($text,0,4) == "!pin"){
    $channel = substr($text,5,1);
    
    if($channel != '1' && $channel != '0'){echo"<script>window.alert('Must use 1 and 0, like !pin 1');</script>";return true;}
    if($channel == '1'){$egg="YES";}else{$egg="NO";}
    
    $q = $conn->prepare("UPDATE `FORUM_THREADS` SET `PINNED` = '$egg' WHERE `ID` = ?");
    $q->bind_param("i",$postID);
    $q->execute();
    
    return true;
  }
  else{
    return false;
  }
}

?>