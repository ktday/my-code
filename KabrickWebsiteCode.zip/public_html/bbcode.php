<?php
 function bbcode_to_html($bbtext){
    $bbtags = array(
      '<' => '&lt;',
      '>' => '&gt;',
      
      '&lt;br /&gt;' => '<br>',
      '&lt;br&gt;' => '<br>',
      '\\n' => "<br>",
      '\\r' => "",
      
      '[heading]' => '<h2>','[/heading]' => '</h2>',
      /*'[heading]' => '<h2>','[/heading2]' => '</h2>',
      '[heading]' => '<h3>','[/heading3]' => '</h3>',
      '[h1]' => '<h1>','[/h1]' => '</h1>',
      '[h2]' => '<h2>','[/h2]' => '</h2>',
      '[h3]' => '<h3>','[/h3]' => '</h3>',
  
      '[paragraph]' => '<p>','[/paragraph]' => '</p>',
      '[para]' => '<p>','[/para]' => '</p>',
      '[p]' => '<p>','[/p]' => '</p>',
      '[left]' => '<p style="text-align:left;">','[/left]' => '</p>',
      '[right]' => '<p style="text-align:right;">','[/right]' => '</p>',
      '[center]' => '<p style="text-align:center;">','[/center]' => '</p>',
      '[justify]' => '<p style="text-align:justify;">','[/justify]' => '</p>',
  */
      #'[bold]' => '<span style="font-weight:bold;">','[/bold]' => '</span>',
      #'[italic]' => '<i>','[/italic]' => '</i>',
      #'[underline]' => '<span style="text-decoration:underline;">','[/underline]' => '</span>',
      '[b]' => '<span style="font-weight:bold;">','[/b]' => '</span>',
      '[i]' => '<i>','[/i]' => '</i>',
      '[u]' => '<span style="text-decoration:underline;">','[/u]' => '</span>',
      '[s]' => '<s>','[/s]' => '</s>',
      #'[break]' => '<br>',
      '[br]' => '<br>',
      '[hr]' => '<hr>',
      '[line]' => '<div style="border-top:1px solid;"></div><br>',
      '[line:d]' => '<div style="border-top:1px dotted;"></div><br>',
      '[tooltip]' => '<span title="', '[/tooltip]' => '">', '[//tooltip]' => '</span>',
      '[newline]' => '<br>',
      '[nl]' => '<br>',
      
      //urls
      '[l:market]' => "<a href='/Market/'>",
      '[l:forums]' => "<a href='/Forums/'>",
      '[l:users]' => "<a href='/Users/'>",
      '[l:news]' => "<a href='/News/'>",
      '[l:badges]' => "<a href='/badges.php'>",
      '[l:friends]' => "<a href='/User/friends.php'>",
      '[l:settings]' => "<a href='/User/settings.php'>",
      '[l:messages]' => "<a href='/User/messages.php'>",
      '[l:trades]' => "<a href='/User/trades.php'>",
      '[l:bbcodehelppage]' => "<a href='/bbcode-e.php'>",
      '[l:help]' => "<a href='/help.php'>",
      '[/l]' => "</a>",
      
      //color
      '[col:r]' => "<span style='color:red'>",
      '[col:b]' => "<span style='color:blue'>",
      '[col:g]' => "<span style='color:green'>",
      '[col:o]' => "<span style='color:orange'>",
      '[col:p]' => "<span style='color:purple'>",
      '[col:pi]' => "<span style='color:pink'>",
      '[col:y]' => "<span style='color:yellow'>",
      '[col:lb]' => "<span style='color:lightblue'>",
      '[col:k]' => "<span class='txtcol-kabrick'>",
      '[col:w]' => "<span class='txtcol-war'>",
      '[/col]' => "</span>",
      
    /*  
      '[unordered_list]' => '<ul>','[/unordered_list]' => '</ul>',
      '[ul]' => '<ul>','[/ul]' => '</ul>',
    
      '[ordered_list]' => '<ol>','[/ordered_list]' => '</ol>',
      '[ol]' => '<ol>','[/ol]' => '</ol>',
      '[list]' => '<li>','[/list]' => '</li>',
      '[li]' => '<li>','[/li]' => '</li>',
        
      '[*]' => '<li>','[/*]' => '</li>',
      '[code]' => '<pre>','[/code]' => '</pre>',
      '[quote]' => '<blockquote>','[/quote]' => '</blockquote>',
      '[preformatted]' => '<pre>','[/preformatted]' => '</pre>',
      '[pre]' => '<pre>','[/pre]' => '</pre>',  
      
      //Emojis
      //Created by Tech
      //I wouldn't brag about that, buddy - Luke
      
      ':)' => '<img src="/assets/emojis/smile.png"></img>',
      ':(' => '<img src="/assets/emojis/sad.png"></img>',
      ':P' => '<img src="/assets/emojis/tongue.png"></img>', ':p' => '<img src="/assets/emojis/tonuge.png"></img>',       
      ':*' => '<img src="/assets/emojis/kiss.png"></img>',    
      ':|' => '<img src="/assets/emojis/none.png"></img>',    
      ':^)' => '<img src="/assets/emojis/oops.png"></img>',   
      ':D' => '<img src="/assets/emojis/grin.png"></img>',
*/

	// deleting links !!!
	'goatse.info' => '[ Link Removed ]',
	'pornhub.com' => '[ Link Removed ]',
	
	'<a href="h' => '[ Link Removed ]',
	'<a href="//' => '[ Link Removed ]',
	'<a href="w' => '[ Link Removed ]',
	"<a href='//" => '[ Link Removed ]',
	"<a href='w" => '[ Link Removed ]',
	"<a href='h" => '[ Link Removed ]',
	
	'.co' => '[ Link Removed ]',
	'.net' => '[ Link Removed ]',
	'.org' => '[ Link Removed ]',
    
    //Bad Words
    #'fuck' => '[ Censored ]',
    #'Fuck' => '[ Censored ]',
    #'shit' => '[ Censored ]',
    #'Shit' => '[ Censored ]',
    #'Crap' => '[ Censored ]',
    #'crap' => '[ Censored ]',
    'Porn' => '[ Censored ]',
    'porn' => '[ Censored ]',
    'penis' => '[ Censored ]',
    'Penis' => '[ Censored ]',
    'nigger' => '[ Censored ]',
    'Nigger' => '[ Censored ]',
    'nigga' => '[ Censored ]',
    'Nigga' => '[ Censored ]',
    'cunt' => '[ Censored ]',
    'Cunt' => '[ Censored ]',
    'bitch' => '[ Censored ]',
    'Bitch' => '[ Censored ]',
      
    'kill yourself' => 'keep yourself safe',
    'kill your self' => 'keep yourself safe',
    'kys' => 'keep yourself safe',
      
    'cabrick' => "kabrick"
      
    #'<script>' => 'I am cringe ',
    
    );
    
    $bbtext = str_ireplace(array_keys($bbtags), array_values($bbtags), $bbtext);
  
   /* $bbextended = array(
      "/\[url](.*?)\[\/url]/i" => "<a style=\"color:#444\" href=\"$1\">$1</a>",
      "/\[url=(.*?)\](.*?)\[\/url\]/i" => "<a style=\"color:#444\" href=\"$1\">$2</a>", 
      "/\[email=(.*?)\](.*?)\[\/email\]/i" => "<a href=\"mailto:$1\">$2</a>",
      "/\[mail=(.*?)\](.*?)\[\/mail\]/i" => "<a href=\"mailto:$1\">$2</a>",
      "/\[youtube\]([^[]*)\[\/youtube\]/i" => "<iframe src=\"https://youtube.com/embed/$1\" width=\"560\" height=\"315\"></iframe>",
    );
    
    /*
      "/\[img\]([^[]*)\[\/img\]/i" => "<img class=\"forumImage\" src=\"$1\" alt=\" \" />",
      "/\[image\]([^[]*)\[\/image\]/i" => "<img src=\"$1\" alt=\" \" />",
      "/\[image_left\]([^[]*)\[\/image_left\]/i" => "<img src=\"$1\" alt=\" \" class=\"img_left\" />",
      "/\[image_right\]([^[]*)\[\/image_right\]/i" => "<img src=\"$1\" alt=\" \" class=\"img_right\" />",
  
    foreach($bbextended as $match=>$replacement){
      $bbtext = preg_replace($match, $replacement, $bbtext);
    }*/
    return $bbtext;
  }
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  //I am a cat
  
  
  
  
  
  
  
  
  
  /*echo"
  
  [b] -> Bold Text
  [/b] -> End Bold Text
  [i] -> Italic Text
  [/i] -> End Italic Text
  [u] -> Underlined Text
  [/u] -> End Underlined Text
  [s] -> Crossed Out Text
  [/s] -> End Crossed Out Text
  [heading] -> Heading
  [/heading] -> End Heading
  
  [br] -> New Line
  
  [l:market] -> To Market URL
      [l:forums] -> To Forums URL
      [l:users] -> To Users URL
      [l:news] -> To News URL
      [l:badges] -> To Badges URL
      [l:friends] -> To Friends URL
      [l:settings] -> To Settings URL
      [l:messages] -> To Messages URL
      [l:trades] -> To Trades URL
      [/l] -> Ends Any URL
  
  ";*/
?>