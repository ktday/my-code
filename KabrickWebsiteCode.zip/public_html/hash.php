<?php
if(isset($_POST['B'])){
$gosted = hash('gost',$_POST['B']);
$password = hash('whirlpool',$gosted);
echo"$password<br>";
}
echo"<form method='post'>
<input name='B'>
</form>";

echo(hash('whirlpool',hash('gost',$_SERVER['REMOTE_ADDR'])));
echo("<br>" . $_SERVER['REMOTE_ADDR']);

exit();
?>