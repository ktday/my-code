<?php  echo"
  
<pre>  [b] -> Bold Text
  [/b] -> End Bold Text
  [i] -> Italic Text
  [/i] -> End Italic Text
  [u] -> Underlined Text
  [/u] -> End Underlined Text
  [s] -> Crossed Out Text
  [/s] -> End Crossed Out Text
  [heading] -> Heading
  [/heading] -> End Heading
  
  [br] -> New Line
  [line] -> Adds a solid line
  [line:d] -> Adds a dotted line
  
  [l:help] -> To Help URL
  [l:market] -> To Market URL
  [l:forums] -> To Forums URL
  [l:users] -> To Users URL
  [l:news] -> To News URL
  [l:badges] -> To Badges URL
  [l:friends] -> To Friends URL
  [l:settings] -> To Settings URL
  [l:messages] -> To Messages URL
  [l:trades] -> To Trades URL
  [/l] -> Ends Any URL
  
  [col:r] -> Red Text
  [col:b] -> Blue Text
  [col:g] -> Green Text
  [col:o] -> Orange Text
  [col:p] -> Purple Text
  [col:pi] -> Pink Text
  [col:y] -> Yellow Text
  [col:lb] -> Light Blue Text
  [/col] -> Ends Color
  
  </pre>
  
";/*<script>function makeid(length) {
   var result           = '';
   var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789`¬¦!£$%^&*()|\-_=+[]{};:@#~<>,./?';
   var charactersLength = characters.length;
   for ( var i = 0; i < length; i++ ) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
   }
   return result;
};window.alert(makeid(15))</script>";*/?>