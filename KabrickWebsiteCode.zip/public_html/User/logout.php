<?php
setcookie('KABRICK_U','',1, '/');
setcookie('KABRICK_P','',1, '/');
echo"<script>window.location='/'</script>";
?>