<?php
include($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');

if(isset($_GET['id'])){
  $id = mysqli_real_escape_string($conn,$_GET['id']);
  $q = $conn->prepare("SELECT * FROM `FRIEND_REQ` WHERE `ID` = ?");
  $q->bind_param("i",$id);
  $q->execute();
  $fr = $q->get_result()->fetch_assoc();
  if($fr['RECIEVER']!=$account[0]){
    exit();
  }else{
    //Add Friend 
    $q = $conn->prepare("INSERT INTO `FRIENDS` VALUES(NULL,?,?)");
    $q->bind_param("ii",$fr['SENDER'],$account[0]);
    $q->execute();
    //Delete FR
    $w = $conn->prepare("DELETE FROM `FRIEND_REQ` WHERE `SENDER` = ? AND `RECIEVER` = ?");
    $w->bind_param("ii",$fr['SENDER'],$account[0]);
    $w->execute();
    //redirect
    echo"<script>window.location='/Friends/'</script>";exit();
  }
}
?>