<?php exit();

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');

echo"<title>Promocodes | $meta_title</title>";

if(!isset($_COOKIE['KABRICK_U']) || !isset($_COOKIE['KABRICK_P'])){
    include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
}

echo"

<div class='platform'>
	<div class='platformtitle'>
    	<p>Bruh this is on the settings page now so fuck off</p>
        <p class='small1'>(Yea sry i was rude this was ages ago) 8/2/23</p>
    </div>
</div>

</div>

";

?>