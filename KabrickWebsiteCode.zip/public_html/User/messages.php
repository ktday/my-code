<?php
include($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');
include($_SERVER['DOCUMENT_ROOT'] . '/bbcode.php');

echo"<title>Messages | $meta_name</title>";

if(!isset($_COOKIE['KABRICK_U']) || !isset($_COOKIE['KABRICK_P'])){
  echo"<script>window.location='/'</script>";exit();
}
$MSG = mysqli_query($conn,"SELECT * FROM `MESSAGES` WHERE `RECIEVER` = '$account[0]' AND `SENDER` != '1' ORDER BY `ID` DESC LIMIT 3");
echo"

<script>
$(document).ready(function(){
  inbound();
});

function inbound() {
  $('#msgs').load('/User/messages-inbound.php');
}

function outbound() {
  $('#msgs').load('/User/messages-outbound.php');
}

function system() {
  $('#msgs').load('/User/messages-system.php');
}

function important() {
  $('#msgs').load('/User/messages-important.php');
}


</script>

";

echo"

<div class='doublebox box1'>
  <br>
  <button class='button btn-blue nd' onclick='inbound()'>Inbound</button>
  <button class='button btn-blue nd' onclick='outbound()'>Outbound</button>
  <button class='button btn-blue nd' onclick='system()'>System</button>
  
  <br>
  
  <div class='platformtitle'>
  	<p>Recent Messages</p>
  </div>
  
  <br>
  
  ";

  if(mysqli_num_rows($MSG)==0){
    echo"You have never recieved a message!";
  }else{
    while(($m=mysqli_fetch_array($MSG))){
      $u = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$m[SENDER]'"));
        $ttl = lgt($m['TITLE']);
      echo"
      <a href='/Msg/$m[0]'>$ttl</a><br>
      Sent by <a href='/Profile/$u[1]'>$u[1]</a>
      <br><hr><br>";
    }
  }

  echo"
</div>

<div class='doublebox box2' id='msgs'>
  
</div>

";
?>