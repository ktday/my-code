<?php

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/vars.php');
echo"<title>BANNED | $meta_name</title>";

if(!isset($_COOKIE['KABRICK_U']) || !isset($_COOKIE['KABRICK_P'])){
    include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();
}

$bq = mysqli_query($conn,"SELECT * FROM `BANS` WHERE `USER` = '$account[0]'");
if(mysqli_num_rows($bq)<1){include($_SERVER['DOCUMENT_ROOT'] . '/404-raw.php');exit();}
$b = mysqli_fetch_array($bq);

if(isset($_GET['release'])){
  if(time() > $b['END'] && $b['TYPE']!='TERM'){
    mysqli_query($conn,"DELETE FROM `BANS` WHERE `ID` = '$b[0]'");
    mysqli_query($conn,"UPDATE `USERS` SET `STATUS` = 'DEFAULT' WHERE `ID` = '$account[0]'");
    echo"<script>window.location = '/'</script>";exit();
  }
}

if($b['TYPE']=='BAN'){$action='banned';$note='You will be unbanned at ' . date("H:i", $b['END'] + 18000) . ' on ' . gmdate("j F Y", $b['END'] + 18000);}
elseif($b['TYPE']=='TERM'){$action='terminated';$note='You will not be able to reactivate your account.';}
else{$action='warned';$note='Your account will be reactivated when you press the button.';}

if((time() > $b['END'] && $b['TYPE']=='BAN') || $b['TYPE']=='WARN'){
  $btn = "<a href='/?release' class='button3 btn-blue nd hover'>Release me!</a>";
}else{
  $btn = "<button class='button3 btn-red nd' disabled>We cannot reactivate your account</button>";
}

$m = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$b[MOD]'"));

echo"

<div class='platform'>
	<div class='platformtitle'>
    	<p><u><b>You have been $action on $meta_name!</b></u></p>
    </div>
    
    <p>Ban Reason: \"$b[REASON]\"</p>
    <p>Moderator: $m[1]</p>
    <p>$note</p>
    
    $btn<br><br>
</div>

</div>

";