<?php

echo"<title>Gallery | Kabrick.tk Beta</title>";

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');

if(!isset($_COOKIE['KABRICK_U']) || !isset($_COOKIE['KABRICK_P'])){
    echo"<script>window.location='/'</script>";exit();
}

$selectLimiteds = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `RARITY` = 'EPIC'");

echo"

<div class='platform nbg'>
    
    <div class='platformtitle'>
        <p><b><u>My gallery</u></b></p>
    </div>
    
    <br>
    
    ";
    
    while(($l = mysqli_fetch_array($selectLimiteds))){
        
        if($l['STATUS']=='UAP'){
            //do not print anything :))))
        }else{
        
            /*$v = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `VALUES` WHERE `ITEM` = '$l[0]'"));
            
            $id = $v[0];*/
            
            //find
            
            $iso = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM `INV` WHERE `USER` = '$account[0]' AND `ITEM` = '$l[0]'"));
            $invid = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `INV` WHERE `USER` = '$account[0]' AND `ITEM` = '$l[0]'"));
            
            if($iso>0){
                
                $img = $l['PREV_IMG'];
                $imgc = "avatar";
                $name = $l[1];
              $e = "#" . $invid['SERIAL'];
                
            }else{
                
                /*if($v['IOTW']=='T'){
                    
                    $img = "/Misc/IMGS/unknown_asset.png";
                    $imgc = "avatar";
                    $name = "?";
                    
                }else{*/
                    
                    $img = $l['PREV_IMG'];
                    $imgc = "avatars";
                    $name = $l[1];
              $e = "Not Owned";
                    
                #}
                
            }
            
            echo"
            
            <a href='/Market/item.php?id=$l[0]' class='nd'>
                <div class='marketcard'>
                    <div class='marketcard-img'>
                        <img src='$img' class='$imgc'>
                    </div>
                    <div class='txtcol-gold'>
                        <p>$name</p>
                        <p>$e</p>
                    </div>
                </div>
            </a>&nbsp;&nbsp;
            
            ";
        
        }
    }
    
    //select all limiteds
    //finding value
    //print
    
    //select value
    //find item
    //if not limited then dont show
    //print
    
    echo"
    
</div>

</div>

";

?>