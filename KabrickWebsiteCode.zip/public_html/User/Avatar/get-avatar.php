<?php
//header('Access-Control-Allow-Origin: *');
//header('Access-Control-Allow-Methods: GET, POST');
//header("Access-Control-Allow-Headers: X-Requested-With");
include($_SERVER['DOCUMENT_ROOT'] . '/Misc/connect.php');
$username = mysqli_real_escape_string($conn, $_COOKIE['KABRICK_U']);
$password = mysqli_real_escape_string($conn, $_COOKIE['KABRICK_P']);
$accountQ = $conn->prepare("SELECT * FROM `USERS` WHERE `USERNAME`=? AND `PASSWORD`=?");
$accountQ->bind_param("ss", $username, $password);
$accountQ->execute();
$result = $accountQ->get_result();
$account_R = mysqli_num_rows($result);
$account = mysqli_fetch_array($result);
?>
<center>
<img src="<?=$account['AVATAR_IMG_URL']?>">
</center>