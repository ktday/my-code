<?php
include("../../Misc/connect.php");
$iQ = mysqli_query($conn,"SELECT * FROM `INV` WHERE `USER` = '$account[ID]' ORDER BY `ID` DESC");
$il0 = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM `INV` WHERE `USER` = '$account[ID]'"));
if($il0 == 0){
  die("You have no items to wear!");
}else{
  while($inventory = mysqli_fetch_array($iQ)){
    $item = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$inventory[ITEM]'"));
    if($item['STATUS'] == "AP"){
?>
<div class='marketcard'>
  <div class='marketcard-img'>
    <img src='<?=$item['PREV_IMG']?>' class='avatar'>
  </div>
  <div class='txtcol-white'>
    <p><?=$item['NAME']?></p>
    <a onclick='wearItem(<?=$item['ID']?>)' style='border:none;width:95%;cursor:pointer;' class='button btn-green nd'>Equip</a>
  </div>
</div>
<?php
                                }
  }
}
?>