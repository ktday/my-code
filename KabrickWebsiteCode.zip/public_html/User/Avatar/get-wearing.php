<?php
include("../../Misc/connect.php");
$findUserAvatar = $conn->query("SELECT * FROM `AVATAR` WHERE `UID` = '$account[0]'");
$userAvatar = (object) $findUserAvatar->fetch_assoc();
$itemArray = array(
  "HAT" => $userAvatar->{'HAT'},
  "HAT2" => $userAvatar->{'HAT2'},
  "HAT3" => $userAvatar->{'HAT3'},
  "HAIR" => $userAvatar->{'HAIR'},
  "BACK" => $userAvatar->{'BACK'},
  "SHIRT" => $userAvatar->{'SHIRT'},
  "GEAR" => $userAvatar->{'GEAR'},
  "PANTS" => $userAvatar->{'PANTS'},
  "BODY" => $userAvatar->{'BODY'},
  "FACE" => $userAvatar->{'FACE'},
  "SHOULDER" => $userAvatar->{'SHOULDER'},
  "MASK" => $userAvatar->{'MASK'}
);
foreach ($itemArray as $potato => $item) {
  if($item != 0){
    $itemID = $item;
    $findItem = $conn->query("SELECT * FROM `MARKET` WHERE `ID` = '$itemID'");
    if ($findItem->num_rows >= 0) {
      $item2 = (object) $findItem->fetch_assoc();
      $kek = $potato;
?>
<div class='marketcard'>
  <div class='marketcard-img'>
    <img src='<?=$item2->PREV_IMG?>' class='avatar'></img>
</div>
<div class='txtcol-white'>
  <p><?=$item2->NAME?></p>
  <a onclick='removeItem("<?=$item2->TYPE?>")' style='border:none;width:95%;cursor:pointer;' class='button btn-red nd'>Remove</a>
</div>
</div>
<?php
      }
  }else{
  }
}
?>