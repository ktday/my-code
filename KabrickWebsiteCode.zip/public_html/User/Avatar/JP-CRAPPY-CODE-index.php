<?php
echo"<title>Edit Avatar | Kabrick.tk Beta</title>";
include($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');
if(!isset($_COOKIE['KABRICK_U']) || !isset($_COOKIE['KABRICK_P'])){
  echo"<script>window.location='/'</script>";exit();
}
echo"
<br>
<div class='doublebox box1'>
<div class='platformtitle'><h2>My Avatar</h2></div>
<div id='avatar3'><img src='$account[AVATAR_IMG_URL]'></div>
<br><br>
<a class='button btn-red nd' onclick='reset()'>Reset</a><br>
<a class='button btn-blue nd'onclick='redraw()'>Redraw</a>
</div>
<div class='doublebox box2'>
<div class='platformtitle'><p>Currently Wearing</p></div>
<div style='overflow: auto;white-space: nowrap;' id='wearing'></div>
</div><div style='height:400px;'></div>
<div class='platform'>
<div class='platformtitle'><p>Inventory</p></div>
<div id='inv'></div>
</div>
</div></div>
";
?>
<script>          
  function redraw(){
    $('#avatar3').html('<iframe style="width:200px;height:200px;border:0px;" src="/User/Avatar/get-avatar.php"></iframe>');
    getWear();
  };

  $(document).ready(function(){
    //redraw();
    $('#inv').load('/User/Avatar/get-inventory.php');
    getWear();
  });

  function wearItem(id){
    $('#avatar3').load('/User/Avatar/render.php?render='+id+'');
    getWear();
    redraw();
  }

  function removeItem(type){
    $('#avatar3').load('/User/Avatar/render.php?remove='+type+'');
    getWear();
    redraw();
    console.log(type);
  }

  function reset(){
    $('#avatar3').load('/User/Avatar/render.php?reset');
    getWear();
    redraw();
  }

  function getWear(){
    $('#wearing').load('/User/Avatar/get-wearing.php');
  }
</script>