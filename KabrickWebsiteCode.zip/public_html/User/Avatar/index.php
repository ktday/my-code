<?php

echo"<title>Customize | Kabrick.tk Beta</title>";

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');
//exit();

if(!isset($_COOKIE['KABRICK_U']) || !isset($_COOKIE['KABRICK_P'])){
    echo"<script>window.location='/'</script>";exit();
}

$DOMAIN = $meta_blank_url;

if(isset($_GET['reset'])){
    if($account['AVATAR_IMG_URL']!='/Misc/IMGS/avatar.png'){unlink("/home/lord7302/domains/$DOMAIN/public_html".$account['AVATAR_IMG_URL']);}
    mysqli_multi_query($conn,"
    UPDATE `AVATAR` SET
        `HAT` = '0',
        `HAT2` = '0',
        `HAT3` = '0',
        `HAIR` = '0',
        `FACE` = '0',
        `GEAR` = '0',
        `SHOULDER` = '0',
        `MASK` = '0',
        `SHIRT` = '0',
        `PANTS` = '0',
        `BACK` = '0',
        `BODY` = '0',
        `PET` = '0'
    WHERE `UID` = '$account[0]';

    UPDATE `USERS` SET `AVATAR_IMG_URL` = '/Misc/IMGS/avatar.png' WHERE `ID` = '$account[0]';
    ");
    echo"<script>window.alert('Successfully Reset Avatar!');window.location='/User/Avatar/'</script>";exit();
}
elseif(isset($_GET['render'])){
  
    ############################################################################### echo"<script>window.alert('pause for errors r1')</script>";
    $id = mysqli_real_escape_string($conn,$_GET['render']);
    $findav = mysqli_query($conn,"SELECT * FROM `AVATAR` WHERE `UID` = '$account[0]'");
    $av = mysqli_fetch_array($findav);
    
    $finditem = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$id'");
    $item = mysqli_fetch_array($finditem);
    
    #echo"<script>window.alert('$id, $item[NAME]')</script>";
    
    $findinvid = mysqli_query($conn,"SELECT * FROM `INV` WHERE `USER` = '$account[0]' AND `ITEM` = '$id'");
    if(mysqli_num_rows($findinvid)<1){
        
        echo"<script>window.location='/User/Avatar/'</script>";
        
    }else{
        
        if($item['TYPE']=='HAT'){
            $av = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `AVATAR` WHERE `UID` = '$account[0]'"));
            mysqli_query($conn,"UPDATE `AVATAR` SET `HAT` = '$id' WHERE `UID` = '$account[0]'");
            mysqli_query($conn,"UPDATE `AVATAR` SET `HAT2` = '$av[HAT]' WHERE `UID` = '$account[0]'");
            mysqli_query($conn,"UPDATE `AVATAR` SET `HAT3` = '$av[HAT2]' WHERE `UID` = '$account[0]'");
        }else{
            mysqli_query($conn,"UPDATE `AVATAR` SET `$item[TYPE]` = '$id' WHERE `UID` = '$account[0]'");
        }
        
        echo"<script>window.location='/User/Avatar/?draw'</script>";
        
    }
    
    exit();
}
elseif(isset($_GET['remove'])){
    $id = mysqli_real_escape_string($conn,$_GET['remove']);
    
    mysqli_query($conn,"UPDATE `AVATAR` SET `$id` = '0' WHERE `UID` = '$account[0]'");
    
    echo"<script>window.location='/User/Avatar/?draw'</script>";
}
elseif(isset($_GET['draw'])){
  
  
    ############################################################################### echo"<script>window.alert('pause for errors d1')</script>";
    
    $findav = mysqli_query($conn,"SELECT * FROM `AVATAR` WHERE `UID` = '$account[0]'");
    $av = mysqli_fetch_array($findav);
    
    if($av['HAT']!='0'){
        $findAsset = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$av[HAT]'");
        $Asset = mysqli_fetch_array($findAsset);
        $avatarItemUrlHAT = $Asset['AV_IMG'];
    }
    if($av['HAT2']!='0'){
        $findAsset = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$av[HAT2]'");
        $Asset = mysqli_fetch_array($findAsset);
        $avatarItemUrlHAT2 = $Asset['AV_IMG'];
    }
    if($av['HAT3']!='0'){
        $findAsset = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$av[HAT3]'");
        $Asset = mysqli_fetch_array($findAsset);
        $avatarItemUrlHAT3 = $Asset['AV_IMG'];
    }
    if($av['HAIR']!='0'){
        $findAsset = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$av[HAIR]'");
        $Asset = mysqli_fetch_array($findAsset);
        $avatarItemUrlHAT = $Asset['AV_IMG'];
    }
    if($av['FACE']!='0'){
      	if($av['BODY']=='0'){
        	$findAsset = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$av[FACE]'");
        	$Asset = mysqli_fetch_array($findAsset);
        	$avatarItemUrlFACE = $Asset['AV_IMG'];
        }else{
          echo"<script>window.alert('cannot equip faces with bodies')";
          mysqli_query($conn,"UPDATE `AVATAR` SET `FACE` = '0' WHERE `UID` = '$account[0]'");
        }
    }
    if($av['GEAR']!='0'){
        $findAsset = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$av[GEAR]'");
        $Asset = mysqli_fetch_array($findAsset);
        $avatarItemUrlGEAR = $Asset['AV_IMG'];
    }
    if($av['SHOULDER']!='0'){
        $findAsset = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$av[SHOULDER]'");
        $Asset = mysqli_fetch_array($findAsset);
        $avatarItemUrlSHOULDER = $Asset['AV_IMG'];
    }
    if($av['MASK']!='0'){
        $findAsset = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$av[MASK]'");
        $Asset = mysqli_fetch_array($findAsset);
        $avatarItemUrlMASK = $Asset['AV_IMG'];
    }
    if($av['SHIRT']!='0'){
        $findAsset = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$av[SHIRT]'");
        $Asset = mysqli_fetch_array($findAsset);
        $avatarItemUrlSHIRT = $Asset['AV_IMG'];
    }
    if($av['PANTS']!='0'){
        $findAsset = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$av[PANTS]'");
        $Asset = mysqli_fetch_array($findAsset);
        $avatarItemUrlPANTS = $Asset['AV_IMG'];
    }
    if($av['BACK']!='0'){
        $findAsset = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$av[BACK]'");
        $Asset = mysqli_fetch_array($findAsset);
        $avatarItemUrlBACK = $Asset['AV_IMG'];
    }
    if($av['PET']!='0'){
        $findAsset = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$av[PET]'");
        $Asset = mysqli_fetch_array($findAsset);
        $avatarItemUrlPET = $Asset['AV_IMG'];
    }
    
    /*if($item['TYPE']=='HAT'){$avatarItemUrlHAT=$item['AV_IMG'];}
    elseif($item['TYPE']=='FACE'){$avatarItemUrlFACE=$item['AV_IMG'];}
    elseif($item['TYPE']=='GEAR'){$avatarItemUrlGEAR=$item['AV_IMG'];}
    elseif($item['TYPE']=='SHOULDER'){$avatarItemUrlSHOULDER=$item['AV_IMG'];}
    elseif($item['TYPE']=='MASK'){$avatarItemUrlMASK=$item['AV_IMG'];}
    elseif($item['TYPE']=='SHIRT'){$avatarItemUrlSHIRT=$item['AV_IMG'];}
    elseif($item['TYPE']=='PANTS'){$avatarItemUrlPANTS=$item['AV_IMG'];}*/
    ############################################################################### echo"<script>window.alert('pause for errors d2')</script>";
  
  	if($av['BODY']!='0'){
      $findAsset = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$av[BODY]'");
      $Asset = mysqli_fetch_array($findAsset);
      $defAvImg = $Asset['AV_IMG'];
    }else{
      $defAvImg = "/Misc/IMGS/avatar.png";
    }
    
    $img_dir_pre = "/home/lord7302/domains/$DOMAIN/public_html";
    #$palette_img = imagecreatefrompng($img_dir_pre.$defAvImg);
    
    if($account['AVATAR_IMG_URL']!='/Misc/IMGS/avatar.png'){unlink($img_dir_pre.$account['AVATAR_IMG_URL']);}
    
    if($av['BACK']!='0'){
        $palette_img = imagecreatefrompng($img_dir_pre.$avatarItemUrlBACK);
        $img0 = imagecreatefrompng($img_dir_pre.$defAvImg);
        imagecopy($palette_img,$img0,0,0,0,0,121,181);
    }else{
      $palette_img = imagecreatefrompng($img_dir_pre.$defAvImg);
    }
  	imagesavealpha($palette_img, true);
  
    if($av['PET']!='0'){
        $img_n1 = imagecreatefrompng($img_dir_pre.$avatarItemUrlPET);
        imagecopy($palette_img,$img_n1,0,0,0,0,121,181);
    }
    if($av['FACE']!='0'&&($av['BODY']=='0')){
        $img_1 = imagecreatefrompng($img_dir_pre.$avatarItemUrlFACE);
        imagecopy($palette_img,$img_1,0,0,0,0,121,181);
    }
    if($av['SHIRT']!='0'){
        $img_2 = imagecreatefrompng($img_dir_pre.$avatarItemUrlSHIRT);
        imagecopy($palette_img,$img_2,0,0,0,0,121,181);
    }
    if($av['PANTS']!='0'){
        $img_3 = imagecreatefrompng($img_dir_pre.$avatarItemUrlPANTS);
        imagecopy($palette_img,$img_3,0,0,0,0,121,181);
    }
    if($av['HAIR']!='0'){
        $img_6_4 = imagecreatefrompng($img_dir_pre.$avatarItemUrlHAIR);
        imagecopy($palette_img,$img_6_4,0,0,0,0,121,181);
    }
    if($av['MASK']!='0'){
        $img_5 = imagecreatefrompng($img_dir_pre.$avatarItemUrlMASK);
        imagecopy($palette_img,$img_5,0,0,0,0,121,181);
    }
    if($av['SHOULDER']!='0'){
        $img_4 = imagecreatefrompng($img_dir_pre.$avatarItemUrlSHOULDER);
        imagecopy($palette_img,$img_4,0,0,0,0,121,181);
    }
    if($av['HAT3']!='0'){
        $img_6_3 = imagecreatefrompng($img_dir_pre.$avatarItemUrlHAT3);
        imagecopy($palette_img,$img_6_3,0,0,0,0,121,181);
    }
    if($av['HAT2']!='0'){
        $img_6_2 = imagecreatefrompng($img_dir_pre.$avatarItemUrlHAT2);
        imagecopy($palette_img,$img_6_2,0,0,0,0,121,181);
    }
    if($av['HAT']!='0'){
        $img_6 = imagecreatefrompng($img_dir_pre.$avatarItemUrlHAT);
        imagecopy($palette_img,$img_6,0,0,0,0,121,181);
    }
    if($av['GEAR']!='0'){
        $img_7 = imagecreatefrompng($img_dir_pre.$avatarItemUrlGEAR);
        imagecopy($palette_img,$img_7,0,0,0,0,121,181);
    }
    
    $r = rand(0,1000000000000000);
    imagepng($palette_img,$img_dir_pre."/Misc/IMGS/AVATARS/$r.png");
    $image_pre = "/Misc/IMGS/AVATARS/$r.png";
    
    mysqli_query($conn,"UPDATE `USERS` SET `AVATAR_IMG_URL` = '$image_pre' WHERE `ID` = '$account[0]'");
    
    ############################################################################### echo"<script>window.alert('pause for errors*')</script>";
    echo"<script>window.location='/User/Avatar/'</script>";
  	exit();
}

echo"

<br>
    <div class='doublebox box1'>
        <div class='platformtitle'>
            <h2>My Avatar</h2>
        </div>
        <img src='$account[AVATAR_IMG_URL]'><br><br>
        <a class='button btn-red nd' href='?reset'>Reset</a><br>
        <a class='button btn-blue nd' href='?draw'>Redraw</a>
    </div>
    <div class='doublebox box2'>
        <div class='platformtitle'><p>Currently Wearing</p></div>
        ";
        $invQ = mysqli_query($conn,"SELECT * FROM `AVATAR` WHERE `UID` = '$account[0]'");
        $inv=mysqli_fetch_array($invQ);
        
        $findItem = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$inv[GEAR]'");
        $item=mysqli_fetch_array($findItem);
        if($inv['GEAR']!='0'){
            
            if(strlen($item['NAME'])>10){
        		$name = substr($item['NAME'], 0, 10)."..";
            }else{
                $name = $item['NAME'];
            }
            
            if($item['RARITY']=='DEF'){
                $color = 'txtcol-white';
            }elseif($item['RARITY']=='RARE'){
                $color = 'txtcol-purple';
            }elseif($item['RARITY']=='EPIC'){
                $color = 'txtcol-gold';
            }else{
                $color = 'txtcol-white';
            }
            
            echo"<div class='dib'><a href='?remove=GEAR' class='nd $color' title='$item[1]'><img src='$item[PREV_IMG]' class='avatar'><br>$name</a><br><span class='small1'>Gear</span></div>";
        }else{
            echo"<div class='dib'><img src='/Misc/IMGS/avatar.png' class='avatars'><br>Not Equipped<br><span class='small1'>Gear</span></div>";
        }
        
        $findItem = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$inv[HAT]'");
        $item=mysqli_fetch_array($findItem);
        if($inv['HAT']!='0'){
            
            if(strlen($item['NAME'])>10){
        		$name = substr($item['NAME'], 0, 10)."..";
            }else{
                $name = $item['NAME'];
            }
            
            if($item['RARITY']=='DEF'){
                $color = 'txtcol-white';
            }elseif($item['RARITY']=='RARE'){
                $color = 'txtcol-purple';
            }elseif($item['RARITY']=='EPIC'){
                $color = 'txtcol-gold';
            }else{
                $color = 'txtcol-white';
            }
            
            echo"<div class='dib'><a href='?remove=HAT' class='nd $color' title='$item[1]'><img src='$item[PREV_IMG]' class='avatar'><br>$name</a><br><span class='small1'>Hat</span></div>";
        }else{
            echo"<div class='dib'><img src='/Misc/IMGS/avatar.png' class='avatars'><br>Not Equipped<br><span class='small1'>Hat</span></div>";
        }
        
        $findItem = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$inv[HAT2]'");
        $item=mysqli_fetch_array($findItem);
        if($inv['HAT2']!='0'){
            
            if(strlen($item['NAME'])>10){
        		$name = substr($item['NAME'], 0, 10)."..";
            }else{
                $name = $item['NAME'];
            }
            
            if($item['RARITY']=='DEF'){
                $color = 'txtcol-white';
            }elseif($item['RARITY']=='RARE'){
                $color = 'txtcol-purple';
            }elseif($item['RARITY']=='EPIC'){
                $color = 'txtcol-gold';
            }else{
                $color = 'txtcol-white';
            }
            
            echo"<div class='dib'><a href='?remove=HAT2' class='nd $color' title='$item[1]'><img src='$item[PREV_IMG]' class='avatar'><br>$name</a><br><span class='small1'>Hat</span></div>";
        }else{
            echo"<div class='dib'><img src='/Misc/IMGS/avatar.png' class='avatars'><br>Not Equipped<br><span class='small1'>Hat</span></div>";
        }
        
        $findItem = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$inv[HAT3]'");
        $item=mysqli_fetch_array($findItem);
        if($inv['HAT3']!='0'){
            
            if(strlen($item['NAME'])>10){
        		$name = substr($item['NAME'], 0, 10)."..";
            }else{
                $name = $item['NAME'];
            }
            
            if($item['RARITY']=='DEF'){
                $color = 'txtcol-white';
            }elseif($item['RARITY']=='RARE'){
                $color = 'txtcol-purple';
            }elseif($item['RARITY']=='EPIC'){
                $color = 'txtcol-gold';
            }else{
                $color = 'txtcol-white';
            }
            
            echo"<div class='dib'><a href='?remove=HAT3' class='nd $color' title='$item[1]'><img src='$item[PREV_IMG]' class='avatar'><br>$name</a><br><span class='small1'>Hat</span></div>";
        }else{
            echo"<div class='dib'><img src='/Misc/IMGS/avatar.png' class='avatars'><br>Not Equipped<br><span class='small1'>Hat</span></div>";
        }
        
        $findItem = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$inv[HAIR]'");
        $item=mysqli_fetch_array($findItem);
        if($inv['HAIR']!='0'){
            
            if(strlen($item['NAME'])>10){
        		$name = substr($item['NAME'], 0, 10)."..";
            }else{
                $name = $item['NAME'];
            }
            
            if($item['RARITY']=='DEF'){
                $color = 'txtcol-white';
            }elseif($item['RARITY']=='RARE'){
                $color = 'txtcol-purple';
            }elseif($item['RARITY']=='EPIC'){
                $color = 'txtcol-gold';
            }else{
                $color = 'txtcol-white';
            }
            
            echo"<div class='dib'><a href='?remove=HAIR' class='nd $color' title='$item[1]'><img src='$item[PREV_IMG]' class='avatar'><br>$name</a><br><span class='small1'>Hair</span></div>";
        }else{
            echo"<div class='dib'><img src='/Misc/IMGS/avatar.png' class='avatars'><br>Not Equipped<br><span class='small1'>Hair</span></div>";
        }
        
        $findItem = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$inv[BODY]'");
        $item=mysqli_fetch_array($findItem);
        if($inv['BODY']!='0'){
            
            if(strlen($item['NAME'])>10){
        		$name = substr($item['NAME'], 0, 10)."..";
            }else{
                $name = $item['NAME'];
            }
            
            if($item['RARITY']=='DEF'){
                $color = 'txtcol-white';
            }elseif($item['RARITY']=='RARE'){
                $color = 'txtcol-purple';
            }elseif($item['RARITY']=='EPIC'){
                $color = 'txtcol-gold';
            }else{
                $color = 'txtcol-white';
            }
            
            echo"<div class='dib'><a href='?remove=BODY' class='nd $color' title='$item[1]'><img src='$item[PREV_IMG]' class='avatar'><br>$name</a><br><span class='small1'>Character</span></div>";
        }else{
            echo"<div class='dib'><img src='/Misc/IMGS/avatar.png' class='avatars'><br>Not Equipped<br><span class='small1'>Character</span></div>";
        }
        
        echo"<br><br>";
        
        $findItem = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$inv[MASK]'");
        $item=mysqli_fetch_array($findItem);
        if($inv['MASK']!='0'){
            
            if(strlen($item['NAME'])>10){
        		$name = substr($item['NAME'], 0, 10)."..";
            }else{
                $name = $item['NAME'];
            }
            
            if($item['RARITY']=='DEF'){
                $color = 'txtcol-white';
            }elseif($item['RARITY']=='RARE'){
                $color = 'txtcol-purple';
            }elseif($item['RARITY']=='EPIC'){
                $color = 'txtcol-gold';
            }else{
                $color = 'txtcol-white';
            }
            
            echo"<div class='dib'><a href='?remove=MASK' class='nd $color' title='$item[1]'><img src='$item[PREV_IMG]' class='avatar'><br>$name</a><br><span class='small1'>Mask</span></div>";
        }else{
            echo"<div class='dib'><img src='/Misc/IMGS/avatar.png' class='avatars'><br>Not Equipped<br><span class='small1'>Mask</span></div>";
        }
        
        $findItem = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$inv[SHOULDER]'");
        $item=mysqli_fetch_array($findItem);
        if($inv['SHOULDER']!='0'){
            
            if(strlen($item['NAME'])>10){
        		$name = substr($item['NAME'], 0, 10)."..";
            }else{
                $name = $item['NAME'];
            }
            
            if($item['RARITY']=='DEF'){
                $color = 'txtcol-white';
            }elseif($item['RARITY']=='RARE'){
                $color = 'txtcol-purple';
            }elseif($item['RARITY']=='EPIC'){
                $color = 'txtcol-gold';
            }else{
                $color = 'txtcol-white';
            }
            
            echo"<div class='dib'><a href='?remove=SHOULDER' class='nd $color' title='$item[1]'><img src='$item[PREV_IMG]' class='avatar'><br>$name</a><br><span class='small1'>Shoulder</span></div>";
        }else{
            echo"<div class='dib'><img src='/Misc/IMGS/avatar.png' class='avatars'><br>Not Equipped<br><span class='small1'>Shoulder</span></div>";
        }
        
        $findItem = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$inv[BACK]'");
        $item=mysqli_fetch_array($findItem);
        if($inv['BACK']!='0'){
            
            if(strlen($item['NAME'])>10){
        		$name = substr($item['NAME'], 0, 10)."..";
            }else{
                $name = $item['NAME'];
            }
            
            if($item['RARITY']=='DEF'){
                $color = 'txtcol-white';
            }elseif($item['RARITY']=='RARE'){
                $color = 'txtcol-purple';
            }elseif($item['RARITY']=='EPIC'){
                $color = 'txtcol-gold';
            }else{
                $color = 'txtcol-white';
            }
            
            echo"<div class='dib'><a href='?remove=BACK' class='nd $color' title='$item[1]'><img src='$item[PREV_IMG]' class='avatar'><br>$name</a><br><span class='small1'>Back Accessory</span></div>";
        }else{
            echo"<div class='dib'><img src='/Misc/IMGS/avatar.png' class='avatars'><br>Not Equipped<br><span class='small1'>Back Accessory</span></div>";
        }
        
        $findItem = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$inv[SHIRT]'");
        $item=mysqli_fetch_array($findItem);
        if($inv['SHIRT']!='0'){
            
            if(strlen($item['NAME'])>10){
        		$name = substr($item['NAME'], 0, 10)."..";
            }else{
                $name = $item['NAME'];
            }
            
            if($item['RARITY']=='DEF'){
                $color = 'txtcol-white';
            }elseif($item['RARITY']=='RARE'){
                $color = 'txtcol-purple';
            }elseif($item['RARITY']=='EPIC'){
                $color = 'txtcol-gold';
            }else{
                $color = 'txtcol-white';
            }
            
            echo"<div class='dib'><a href='?remove=SHIRT' class='nd $color' title='$item[1]'><img src='$item[PREV_IMG]' class='avatar'><br>$name</a><br><span class='small1'>Shirt</span></div>";
        }else{
            echo"<div class='dib'><img src='/Misc/IMGS/avatar.png' class='avatars'><br>Not Equipped<br><span class='small1'>Shirt</span></div>";
        }
        
        $findItem = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$inv[PANTS]'");
        $item=mysqli_fetch_array($findItem);
        if($inv['PANTS']!='0'){
            
            if(strlen($item['NAME'])>10){
        		$name = substr($item['NAME'], 0, 10)."..";
            }else{
                $name = $item['NAME'];
            }
            
            if($item['RARITY']=='DEF'){
                $color = 'txtcol-white';
            }elseif($item['RARITY']=='RARE'){
                $color = 'txtcol-purple';
            }elseif($item['RARITY']=='EPIC'){
                $color = 'txtcol-gold';
            }else{
                $color = 'txtcol-white';
            }
        
            echo"<div class='dib'><a href='?remove=PANTS' class='nd $color' title='$item[1]'><img src='$item[PREV_IMG]' class='avatar'><br>$name</a><br><span class='small1'>Pants</span></div>";
        }else{
            echo"<div class='dib'><img src='/Misc/IMGS/avatar.png' class='avatars'><br>Not Equipped<br><span class='small1'>Pants</span></div>";
        }
        
        $findItem = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$inv[FACE]'");
        $item=mysqli_fetch_array($findItem);
        if($inv['FACE']!='0'){
            
            if(strlen($item['NAME'])>10){
        		$name = substr($item['NAME'], 0, 10)."..";
            }else{
                $name = $item['NAME'];
            }
            
            if($item['RARITY']=='DEF'){
                $color = 'txtcol-white';
            }elseif($item['RARITY']=='RARE'){
                $color = 'txtcol-purple';
            }elseif($item['RARITY']=='EPIC'){
                $color = 'txtcol-gold';
            }else{
                $color = 'txtcol-white';
            }
        
            echo"<div class='dib'><a href='?remove=FACE' class='nd $color' title='$item[1]'><img src='$item[PREV_IMG]' class='avatar'><br>$name</a><br><span class='small1'>Face</span></div>";
        }else{
            echo"<div class='dib'><img src='/Misc/IMGS/avatar.png' class='avatars'><br>Not Equipped<br><span class='small1'>Face</span></div>";
        }
        
        $findItem = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$inv[PET]'");
        $item=mysqli_fetch_array($findItem);
        if($inv['PET']!='0'){
            
            if(strlen($item['NAME'])>10){
        		$name = substr($item['NAME'], 0, 10)."..";
            }else{
                $name = $item['NAME'];
            }
            
            if($item['RARITY']=='DEF'){
                $color = 'txtcol-white';
            }elseif($item['RARITY']=='RARE'){
                $color = 'txtcol-purple';
            }elseif($item['RARITY']=='EPIC'){
                $color = 'txtcol-gold';
            }else{
                $color = 'txtcol-white';
            }
            
            echo"<div class='dib'><a href='?remove=PET' class='nd $color' title='$item[1]'><img src='$item[PREV_IMG]' class='avatar'><br>$name</a><br><span class='small1'>Pet</span></div>";
        }else{
            echo"<div class='dib'><img src='/Misc/IMGS/avatar.png' class='avatars'><br>Not Equipped<br><span class='small1'>Pet</span></div>";
        }
        
        
        
        echo"
    </div><div style='height:65%'></div>
    <div class='platform'>
        <div class='platformtitle'><h4>Edit</h4></div>
        ";
        $invQ = mysqli_query($conn,"SELECT * FROM `INV` WHERE `USER` = '$account[0]' ORDER BY `ID` DESC");
        while(($inv=mysqli_fetch_array($invQ))){
            $findItem = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$inv[ITEM]'");
            $item=mysqli_fetch_array($findItem);
            
            if(strlen($item['NAME'])>10){
        		$name = substr($item['NAME'], 0, 10)."..";
            }else{
                $name = $item['NAME'];
            }
            
            if($item['RARITY']=='DEF'){
                $color = 'txtcol-white';
            }elseif($item['RARITY']=='RARE'){
                $color = 'txtcol-purple';
            }elseif($item['RARITY']=='EPIC'){
                $color = 'txtcol-gold';
            }else{
                $color = 'txtcol-white';
            }
            
            if($item['STATUS']=="AP"){
                echo"<div class='dib'><a href='?render=$item[0]' class='nd $color' title='$item[1]'><img src='$item[PREV_IMG]' class='avatar'><br>$name</a></div>";
            }elseif($item['STATUS']=="SECRET"){
                echo"<div class='dib'><a href='?render=$item[0]' class='nd $color' title='$item[1]'><img src='$item[PREV_IMG]' class='avatar'><br>$name <i class='fa fa-lock'></i></a></div>";
            }
        }
        echo"
    </div>
    <br>

</div>

";

?>