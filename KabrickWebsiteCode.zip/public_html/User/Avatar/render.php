<?php
include($_SERVER['DOCUMENT_ROOT'] . '/Misc/connect.php');
if(isset($_COOKIE['KABRICK_U'])&&isset($_COOKIE['KABRICK_P'])){
  include($_SERVER['DOCUMENT_ROOT'] . '/Misc/connect.php');
  $username = mysqli_real_escape_string($conn, $_COOKIE['KABRICK_U']);
  $password = mysqli_real_escape_string($conn, $_COOKIE['KABRICK_P']);

  $accountQ = $conn->prepare("SELECT * FROM `USERS` WHERE `USERNAME`=? AND `PASSWORD`=?");
  $accountQ->bind_param("ss", $username, $password);
  $accountQ->execute();
  $result = $accountQ->get_result();
  $account_R = mysqli_num_rows($result);
  $account = mysqli_fetch_array($result);

  if($account_R!=1){
    echo"<script>window.location='/User/logout.php'</script>";exit();
  }

}else{exit();}

if(isset($_GET['reset'])){
  mysqli_query($conn,"UPDATE `USERS` SET `AVATAR_IMG_URL` = '/Misc/IMGS/avatar.png' WHERE `ID` = '$account[0]'");
  mysqli_query($conn,"UPDATE `AVATAR` SET `HAT` = '0' WHERE `UID` = '$account[0]'");
  mysqli_query($conn,"UPDATE `AVATAR` SET `HAT2` = '0' WHERE `UID` = '$account[0]'");
  mysqli_query($conn,"UPDATE `AVATAR` SET `HAT3` = '0' WHERE `UID` = '$account[0]'");
  mysqli_query($conn,"UPDATE `AVATAR` SET `HAIR` = '0' WHERE `UID` = '$account[0]'");
  mysqli_query($conn,"UPDATE `AVATAR` SET `BACK` = '0' WHERE `UID` = '$account[0]'");
  mysqli_query($conn,"UPDATE `AVATAR` SET `BODY` = '0' WHERE `UID` = '$account[0]'");
  mysqli_query($conn,"UPDATE `AVATAR` SET `FACE` = '0' WHERE `UID` = '$account[0]'");
  mysqli_query($conn,"UPDATE `AVATAR` SET `GEAR` = '0' WHERE `UID` = '$account[0]'");
  mysqli_query($conn,"UPDATE `AVATAR` SET `SHOULDER` = '0' WHERE `UID` = '$account[0]'");
  mysqli_query($conn,"UPDATE `AVATAR` SET `MASK` = '0' WHERE `UID` = '$account[0]'");
  mysqli_query($conn,"UPDATE `AVATAR` SET `SHIRT` = '0' WHERE `UID` = '$account[0]'");
  mysqli_query($conn,"UPDATE `AVATAR` SET `PANTS` = '0' WHERE `UID` = '$account[0]'");
  header('Location: /User/Avatar/render.php?draw');
}
elseif(isset($_GET['render'])){
  $id = mysqli_real_escape_string($conn,$_GET['render']);
  $findav = mysqli_query($conn,"SELECT * FROM `AVATAR` WHERE `UID` = '$account[0]'");
  $av = mysqli_fetch_array($findav);
  $finditem = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$id'");
  $item = mysqli_fetch_array($finditem);
  $findinvid = mysqli_query($conn,"SELECT * FROM `INV` WHERE `USER` = '$account[0]' AND `ITEM` = '$id'");
  if(mysqli_num_rows($findinvid)<1){
    echo"<script>window.location='/User/Avatar/'</script>";
  }
  if($item['TYPE']=='HAT'){
    $av = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `AVATAR` WHERE `UID` = '$account[0]'"));
    mysqli_query($conn,"UPDATE `AVATAR` SET `HAT` = '$id' WHERE `UID` = '$account[0]'");
    mysqli_query($conn,"UPDATE `AVATAR` SET `HAT2` = '$av[HAT]' WHERE `UID` = '$account[0]'");
    mysqli_query($conn,"UPDATE `AVATAR` SET `HAT3` = '$av[HAT2]' WHERE `UID` = '$account[0]'");
  }else{
    mysqli_query($conn,"UPDATE `AVATAR` SET `$item[TYPE]` = '$id' WHERE `UID` = '$account[0]'");
  }
  header('Location: /User/Avatar/render.php?draw');
}
elseif(isset($_GET['remove'])){
  $type = mysqli_real_escape_string($conn,$_GET['remove']);
  mysqli_query($conn,"UPDATE `AVATAR` SET `$type` = '0' WHERE `UID` = '$account[0]'");
  header('Location: /User/Avatar/render.php?draw');
}
elseif(isset($_GET['draw'])){

  $findav = mysqli_query($conn,"SELECT * FROM `AVATAR` WHERE `UID` = '$account[0]'");
  $av = mysqli_fetch_array($findav);

  if($av['HAT']!='0'){
    $findAsset = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$av[HAT]'");
    $Asset = mysqli_fetch_array($findAsset);
    $avatarItemUrlHAT = $Asset['AV_IMG'];
  }
  if($av['HAT2']!='0'){
    $findAsset = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$av[HAT2]'");
    $Asset = mysqli_fetch_array($findAsset);
    $avatarItemUrlHAT2 = $Asset['AV_IMG'];
  }
  if($av['HAT3']!='0'){
    $findAsset = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$av[HAT3]'");
    $Asset = mysqli_fetch_array($findAsset);
    $avatarItemUrlHAT3 = $Asset['AV_IMG'];
  }
  if($av['HAIR']!='0'){
    $findAsset = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$av[HAIR]'");
    $Asset = mysqli_fetch_array($findAsset);
    $avatarItemUrlHAIR = $Asset['AV_IMG'];
  }
  if($av['FACE']!='0'){
    $findAsset = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$av[FACE]'");
    $Asset = mysqli_fetch_array($findAsset);
    $avatarItemUrlFACE = $Asset['AV_IMG'];
  }
  if($av['GEAR']!='0'){
    $findAsset = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$av[GEAR]'");
    $Asset = mysqli_fetch_array($findAsset);
    $avatarItemUrlGEAR = $Asset['AV_IMG'];
  }
  if($av['SHOULDER']!='0'){
    $findAsset = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$av[SHOULDER]'");
    $Asset = mysqli_fetch_array($findAsset);
    $avatarItemUrlSHOULDER = $Asset['AV_IMG'];
  }
  if($av['MASK']!='0'){
    $findAsset = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$av[MASK]'");
    $Asset = mysqli_fetch_array($findAsset);
    $avatarItemUrlMASK = $Asset['AV_IMG'];
  }
  if($av['SHIRT']!='0'){
    $findAsset = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$av[SHIRT]'");
    $Asset = mysqli_fetch_array($findAsset);
    $avatarItemUrlSHIRT = $Asset['AV_IMG'];
  }
  if($av['PANTS']!='0'){
    $findAsset = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$av[PANTS]'");
    $Asset = mysqli_fetch_array($findAsset);
    $avatarItemUrlPANTS = $Asset['AV_IMG'];
  }
  if($av['BACK']!='0'){
    $findAsset = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$av[BACK]'");
    $Asset = mysqli_fetch_array($findAsset);
    $avatarItemUrlBACK = $Asset['AV_IMG'];
  }

  $img_dir_pre = "/home/lord7302/domains/definitelynotkabrickbeta.tk/public_html";
  $palette_img = imagecreatefrompng($img_dir_pre."/Misc/IMGS/avatar.png");

  imagesavealpha($palette_img, true);
  if($av['BACK']!='0'){
    $img_0 = imagecreatefrompng($img_dir_pre.$avatarItemUrlBACK);
    imagecopy($palette_img,$img_0,0,0,0,0,121,181);
  }
  if($av['FACE']!='0'){
    $img_1 = imagecreatefrompng($img_dir_pre.$avatarItemUrlFACE);
    imagecopy($palette_img,$img_1,0,0,0,0,121,181);
  }
  if($av['SHIRT']!='0'){
    $img_2 = imagecreatefrompng($img_dir_pre.$avatarItemUrlSHIRT);
    imagecopy($palette_img,$img_2,0,0,0,0,121,181);
  }
  if($av['PANTS']!='0'){
    $img_3 = imagecreatefrompng($img_dir_pre.$avatarItemUrlPANTS);
    imagecopy($palette_img,$img_3,0,0,0,0,121,181);
  }
  if($av['MASK']!='0'){
    $img_4 = imagecreatefrompng($img_dir_pre.$avatarItemUrlMASK);
    imagecopy($palette_img,$img_4,0,0,0,0,121,181);
  }
  if($av['HAIR']!='0'){
    $img_5 = imagecreatefrompng($img_dir_pre.$avatarItemUrlHAIR);
    imagecopy($palette_img,$img_5,0,0,0,0,121,181);
  }
  if($av['SHOULDER']!='0'){
    $img_6 = imagecreatefrompng($img_dir_pre.$avatarItemUrlSHOULDER);
    imagecopy($palette_img,$img_6,0,0,0,0,121,181);
  }
  if($av['HAT3']!='0'){
    $img_7 = imagecreatefrompng($img_dir_pre.$avatarItemUrlHAT3);
    imagecopy($palette_img,$img_7,0,0,0,0,121,181);
  }
  if($av['HAT2']!='0'){
    $img_8 = imagecreatefrompng($img_dir_pre.$avatarItemUrlHAT2);
    imagecopy($palette_img,$img_8,0,0,0,0,121,181);
  }
  if($av['HAT']!='0'){
    $img_9 = imagecreatefrompng($img_dir_pre.$avatarItemUrlHAT);
    imagecopy($palette_img,$img_9,0,0,0,0,121,181);
  }
  if($av['GEAR']!='0'){
    $img_10 = imagecreatefrompng($img_dir_pre.$avatarItemUrlGEAR);
    imagecopy($palette_img,$img_10,0,0,0,0,121,181);
  }

  $r = rand(0,1000000000000000);
  imagepng($palette_img,$img_dir_pre."/Misc/IMGS/AVATARS/".$r.".png");
  $image_pre = "/Misc/IMGS/AVATARS/".$r.".png";

  mysqli_query($conn,"UPDATE `USERS` SET `AVATAR_IMG_URL` = '$image_pre' WHERE `ID` = '$account[0]'");
?>
<script>
  $('#avatar3').html('<iframe style="width:200px;height:200px;border:0px;" src="http://kabrickbeta.tk/User/Avatar/get-avatar.php"></iframe>');
</script>
<?php
}
?>