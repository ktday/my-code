<?php

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');

if(!isset($_COOKIE['KABRICK_U']) || !isset($_COOKIE['KABRICK_P'])){
    exit();
}

if(isset($_GET['id'])){

echo"<title>My Trades | $meta_name</title>";

$id = mysqli_real_escape_string($conn,$_GET['id']);
$trade = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `TRADES` WHERE `ID` = '$id'"));
if($trade['RECIEVER']!=$account[0]){
  exit();
}
if($trade['STATUS']!='P'){
  exit();
}
$u = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$trade[SENDER]'"));

$giving = explode(',',$trade['GIVING']); #ik its called giving but this is what the user is getting
$getting = explode(',',$trade['GETTING']); #and this is what the user is giving

echo"

<div class='platform'>

  <div class='platformtitle'>
    <p>Trade from <a href='/Profile/$u[1]'>$u[1]</a></p>
  </div><br>
  
  <h2>You are giving</h3>
  
  ";

  foreach($getting as $invid){
    $inv = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `INV` WHERE `ID` = '$invid'"));
    $item = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$inv[ITEM]'"));
    
    echo"
    
    <div class='marketcard'>
      <div class='marketcard-img'>
        <img src='$item[PREV_IMG]' class='avatar'>
      </div>
      <div class='txtcol-white'>
        <p>$item[NAME] (#$inv[SERIAL])</p>
      </div>
    </div>
    
    ";
    
  }

echo"

<br><hr><br>
  
  <h2>You are getting</h3>
  
  ";

  foreach($giving as $invid){
    $inv = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `INV` WHERE `ID` = '$invid'"));
    $item = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$inv[ITEM]'"));
    
    echo"
    
    <div class='marketcard'>
      <div class='marketcard-img'>
        <img src='$item[PREV_IMG]' class='avatar'>
      </div>
      <div class='txtcol-white'>
        <p>$item[NAME] (#$inv[SERIAL])</p>
      </div>
    </div>
    
    ";
    
  }

echo"

  <br><hr><br>

  <a href='/User/Trades/trade.php?a=$id' class='button2 btn-green nd hover'>Accept</a>
  <a href='/User/Trades/trade.php?d=$id' class='button2 btn-red nd hover'>Decline</a><br><br>

</div>

";
  
}elseif(isset($_GET['d'])){
  $tradeID = mysqli_real_escape_string($conn,$_GET['d']);
  $trade = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `TRADES` WHERE `ID` = '$tradeID'"));

  if($account[0]!=$trade['RECIEVER']){
    echo"FAILED";exit();
  }

  mysqli_query($conn,"UPDATE `TRADES` SET `STATUS` = 'D' WHERE `ID` = '$trade[0]'");

  echo"<script>window.alert('Succesfully Declined Trade!');window.location='/User/Trades/'</script>";exit();
  
}elseif(isset($_GET['a'])){
  $tradeID = mysqli_real_escape_string($conn,$_GET['a']);
  $trade = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `TRADES` WHERE `ID` = '$tradeID'"));

  if($account[0]!=$trade['RECIEVER']){
    echo"FAILED";exit();
  }
  
  $giving = explode(',',$trade['GIVING']); #ik its called giving but this is what the user is getting
  $getting = explode(',',$trade['GETTING']); #and this is what the user is giving
  $giid = [];$geid = [];
  
  #loop through GIVING and check if they own the items B)
  # no sneaky
  foreach($giving as $invid){
    $item = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `INV` WHERE `ID` = '$invid'"));
    if($item['USER']!=$trade['SENDER']){
      echo"FAILED";exit();
    }else{
      array_push($giid,$item['ITEM']);
    }
  }

  foreach($getting as $invid){
    $item = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `INV` WHERE `ID` = '$invid'"));
    if($item['USER']!=$account[0]){
      echo"FAILED";exit();
    }else{
      array_push($geid,$item['ITEM']);
    }
  }

  #okay NOW transfer
  $x = 0;
  $query = "";
  foreach($giving as $invid){
    #mysqli_query($conn,"UPDATE `INV` SET `USER` = '$account[0]' WHERE `ID` = '$invid'");
    $query = $query . " UPDATE `INV` SET `USER` = '$account[0]' WHERE `ID` = '$invid';
    INSERT INTO `INVID` VALUES (NULL,'$invid','$trade[SENDER]','$account[0]','TRADE','$trade[0]','$giid[$x]');";
    $x = $x + 1;
  }

  $x = 0;
  foreach($getting as $invid){
    #mysqli_query($conn,"UPDATE `INV` SET `USER` = '$trade[SENDER]' WHERE `ID` = '$invid'");
    $query = $query . " UPDATE `INV` SET `USER` = '$trade[SENDER]' WHERE `ID` = '$invid';
    INSERT INTO `INVID` VALUES (NULL,'$invid','$account[0]','$trade[SENDER]','TRADE','$trade[0]','$geid[$x]');";
    $x = $x + 1;
  }
  $query = $query . " UPDATE `TRADES` SET `STATUS` = 'A' WHERE `ID` = '$trade[0]';";
  mysqli_multi_query($conn,$query);
	#echo ($query);

  echo"<script>window.alert('Succesfully Accepted Trade!');window.location='/User/Trades/'</script>";exit();
}

?>