<?php

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');

if(!isset($_COOKIE['KABRICK_U']) || !isset($_COOKIE['KABRICK_P'])){
    exit();
}

echo"<title>My Trades | $meta_name</title>";

$trades = mysqli_query($conn,"SELECT * FROM `TRADES` WHERE `RECIEVER` = '$account[0]' AND `STATUS` = 'P'");

echo"

<div class='platform'>

  <div class='platformtitle'>
    <p>My Trades</p>
  </div><br>
  
  ";

  while(($t=mysqli_fetch_array($trades))){
    $t1 = date("H:i", $t['TIME']);
	$t2 = gmdate("j F Y", $t['TIME']);
	$u = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$t[SENDER]'"));
    echo"
    <a href='/User/Trades/trade.php?id=$t[0]'>Trade Sent</a> by <a href='/Profile/$u[1]'>$u[1]</a> at $t1 $t2<br><hr><br>
    ";
  }

  echo"

</div>

";

?>