<?php
include("../Misc/connect.php");
include("../lgt.php");

$MSG = mysqli_query($conn,"SELECT * FROM `MESSAGES` WHERE `SENDER` = '1' AND `RECIEVER` = '$account[0]' ORDER BY `ID` DESC");

echo"

<div class='platformtitle'>
  <p>System Messages (". mysqli_num_rows($MSG) .")</p>
</div>

<br>

";

if(mysqli_num_rows($MSG)==0){
  echo"You haven't sent any messages!";
}else{
  while(($m=mysqli_fetch_array($MSG))){
    $u = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '1'"));
    
    if($m['IMPORTANT'] == 1){$ttl = "<a href='/Msg/$m[0]' class='txtcol-red'><i class='fas fa-exclamation-triangle'></i> " . lgt($m['TITLE']) . "</a>";}
    else{$ttl = "<a href='/Msg/$m[0]'>" . lgt($m['TITLE']) . "</a>";}
    
    echo"
    
    $ttl "; if($m['VIEWED']=='YES'){echo"<i class='fa fa-eye'></i>";} echo"<br>
    From <a href='/Profile/$u[1]'>$u[1]</a>
    
    <br><hr><br>
    
    ";
  }
}