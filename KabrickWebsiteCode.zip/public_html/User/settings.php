<?php

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');

echo"<title>Settings | $meta_name</title>";

if(!isset($_COOKIE['KABRICK_U']) || !isset($_COOKIE['KABRICK_P'])){
    echo"<script>window.location='/'</script>";exit();
}

if($account['VIP']=='VIP'){
    $membership = "Normal VIP";
}elseif($account['VIP']=='MEGA'){
    $membership = "Mega VIP";
}elseif($account['VIP']=='ULTRA'){
    $membership = "Ultra VIP";
}else{
    $membership = "None";
}

if($account['ENDS']==0){
    $t1 = "Never";
    $t2 = "!";
}else{
    $t1 = date("H:i", $account['ENDS'])." ";
    $t2 = gmdate("j F Y", $account['ENDS']);
}

if(isset($_POST['bio'])){
    $bio = mysqli_real_escape_string($conn,$_POST['bio']);
    if(strlen($bio)<1||strlen($bio)>500){
        echo"
        <script>window.alert('Bio too long/short!')</script>
        <script>window.location='/User/settings.php'</script>";exit();
    /*}elseif($bio==$itemEggPhrase){
        
        $selectEgg = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `USER` = '$account[0]' AND `ITEM` = '$itemEggID'");
        $Egg = mysqli_num_rows($selectEgg);
        
        if($Egg==0&&$itemEggID!=0){
            $selectEggSerial = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ITEM` = '$itemEggID'");
            $EggSerial = mysqli_num_rows($selectEggSerial) + 1;
            mysqli_query($conn,"INSERT INTO `INV` VALUES(NULL,'$itemEggID','$account[0]','$EggSerial')");
        }
        
        mysqli_query($conn,"UPDATE `USERS` SET `BIO` = '$bio' WHERE `ID` = '$account[ID]'");
        echo"
        <script>window.alert('Bio Has Been Updated!')</script>
        <script>window.location='/User/settings.php'</script>";*/
    }else{
        mysqli_query($conn,"UPDATE `USERS` SET `BIO` = '$bio' WHERE `ID` = '$account[ID]'");
        echo"
        <script>window.alert('Bio Has Been Updated!')</script>
        <script>window.location='/User/settings.php'</script>";exit();
    }
}

if(isset($_POST['name'])){
    $username = mysqli_real_escape_string($conn,$_POST['name']);
    $passwordBH = mysqli_real_escape_string($conn,$_POST['password']);
    $password = hashPW($passwordBH);
    $UsernameL = strlen($username);
    if($password!=$account['PASSWORD']){
      echo"<script>window.alert('Passwords are not identical!');window.location='/User/settings.php'</script>";exit();
    }else{
      $usrnameCheck = checkUsername($username);
      if($usrnameCheck!=1){
        echo"<script>window.alert('$usrnameCheck');window.location='/User/settings.php'</script>";exit();
      }else{
	     if($account['BUCKS']<$config["usernameChangeBucksAmount"]) {echo"<script>window.alert('Not enough Bucks!');window.location='/User/settings.php'</script>";exit();
         }else{$b=$account['BUCKS'] - $config["usernameChangeBucksAmount"]; mysqli_query($conn,"UPDATE `USERS` SET `BUCKS` = '$b' WHERE `ID` = '$account[0]'");
	            //complete
                mysqli_query($conn,"INSERT INTO `UNAME_CHANGE` VALUES(NULL,'$account[0]','$account[1]')");
	            mysqli_query($conn,"UPDATE `USERS` SET `USERNAME` = '$username' WHERE `ID` = '$account[0]'");
	            echo"<script>window.alert('Username Changed!');window.location='/'</script>";exit();
	        }
        }
    }
}


if(isset($_POST['p1'])){
    $passN = hash('whirlpool',hash('gost',mysqli_real_escape_string($conn,$_POST['p1'])));
    $pass2 = hash('whirlpool',hash('gost',mysqli_real_escape_string($conn,$_POST['p12'])));
    $pass1 = hash('whirlpool',hash('gost',mysqli_real_escape_string($conn,$_POST['p2'])));
    
    if($passN!=$pass2){
        
        echo"<script>window.alert('Passwords are not identical!');window.location='/User/settings.php'</script>";exit();
      
    }else{
    
        if($pass1!=$account['PASSWORD']){
            echo"<script>window.alert('Incorrect Password!');window.location='/User/settings.php'</script>";exit();
        }else{
            mysqli_query($conn,"UPDATE `USERS` SET `PASSWORD` = '$passN' WHERE `ID` = '$account[0]'");
    	    echo"<script>window.alert('Password Changed!');window.location='/'</script>";exit();
        }
    }
}

/*if(isset($_POST['vip'])){                    ######################### VIP BUYING WAS REMOVED AS OF UPDATE 2.0.117 (4/10/22) ##########################
    
    $type = mysqli_real_escape_string($conn,$_POST['vip']);
    
    if($type==1){
        //1 month only
        
        if($account['BUCKS']<100){
            //not enough bucks
            echo"<script>window.alert('Not enough bucks!');window.location='/User/settings.php'</script>";exit();
        }else{
            //enough bucks, buy
            mysqli_query($conn,"UPDATE `USERS` SET `BUCKS` = '". $account['BUCKS'] - 100 ."' WHERE `ID` = '$account[0]'");//BUCKS
            mysqli_query($conn,"UPDATE `USERS` SET `VIP` = 'VIP' WHERE `ID` = '$account[0]'");//VIP
            mysqli_query($conn,"UPDATE `USERS` SET `ENDS` = '". time() + 2800000 ."' WHERE `ID` = '$account[0]'");//ENDS
            mysqli_query($conn,"UPDATE `USERS` SET `REP` = 'FALSE' WHERE `ID` = '$account[0]'");//REP
        }
    }else{
        //infinite.
        
        if($account['BUCKS']<100){
            //not enough bucks
            echo"<script>window.alert('Not enough bucks!');window.location='/User/settings.php'</script>";exit();
        }else{
            //enough bucks, buy
            mysqli_query($conn,"UPDATE `USERS` SET `BUCKS` = '". $account['BUCKS'] - 100 ."' WHERE `ID` = '$account[0]'");//BUCKS
            mysqli_query($conn,"UPDATE `USERS` SET `VIP` = 'VIP' WHERE `ID` = '$account[0]'");//VIP
            mysqli_query($conn,"UPDATE `USERS` SET `ENDS` = '". time() + 2800000 ."' WHERE `ID` = '$account[0]'");//ENDS
            mysqli_query($conn,"UPDATE `USERS` SET `REP` = 'TRUE' WHERE `ID` = '$account[0]'");//REP
        }
        
    }
    
}*/

if(isset($_POST['newgift'])){
    if($account['CAN_GIFT']=='TRUE'){
      	$OPT = mysqli_real_escape_string($conn,$_POST['giftOPT']);
        $id = rand(1000000000,9999999999);
        $time=time();
        mysqli_query($conn,"INSERT `GIFTS` VALUES(NULL,'$account[0]','$id','$OPT','0','$time')");
      	include_once($_SERVER['DOCUMENT_ROOT'] . '/Admin/FUNCT.php');
      	logAction(99,0,"[$OPT] $id");
        echo"<script>window.alert('Successfully created gift (Code: $id)')</script>";
        echo"<script>window.location=''</script>";exit();
    }else{
        exit();
    }
}

if(isset($_POST['giftcode'])){
    exit();
    $code=mysqli_real_escape_string($conn,$_POST['giftcode']);
    $cQ=mysqli_query($conn,"SELECT * FROM `GIFTS` WHERE `CODE` = '$code'");
    if(mysqli_num_rows($cQ)!=1){
        echo"<script>window.location=''</script>";exit();
    }else{
        $c=mysqli_fetch_array($cQ);
        if($c['REDEEMED_BY']!='0'){
            echo"<script>window.alert('You\'re too slow! Someone has already claimed this gift!');window.location=''</script>";exit();
        }else{
            if($c['SENT_BY']==$account[0]){
                echo"<script>window.alert('Why are you redeeming your own gift?');window.location=''</script>";exit();
            }else{
                if($account['VIP']!='NONE'){
                    echo"<script>window.alert('...But you already have VIP...');window.location=''</script>";exit();
                }
                $time=time();
              	if($c['TYPE']=='1M_NORMAL'||$c['TYPE']=='1M_MEGA'){
              		$at = 2800000;
                }elseif($c['TYPE']=='3M_NORMAL'||$c['TYPE']=='3M_MEGA'){
              		$at = 8400000;
                }elseif($c['TYPE']=='INF_NORMAL'||$c['TYPE']=='INF_MEGA'){
              		$at = -$time;###########################################################################CHANGE############################
                }
                if($account['ENDS']<$time){$ends=$time + 2800000;}else{$ends=$account['ENDS'] + 2800000;}
                if($account['VIP']=="NONE"){mysqli_query($conn,"UPDATE `USERS` SET `VIP` = 'VIP' WHERE `ID` = '$account[0]'");}
                mysqli_query($conn,"UPDATE `USERS` SET `ENDS` = '$ends' WHERE `ID` = '$account[0]'");
                mysqli_query($conn,"UPDATE `GIFTS` SET `REDEEMED_BY` = '$account[0]' WHERE `ID` = '$c[0]'");
                mysqli_query($conn,"UPDATE `USERS` SET `REP` = 'FALSE' WHERE `ID` = '$account[0]'");//REP
                echo"<script>window.alert('Gift redeemed! Enjoy your month of VIP Membership!');window.location=''</script>";exit();
            }
        }
    }
    
}

if(isset($_POST['redeem'])){
  	$code=mysqli_real_escape_string($conn,$_POST['redeem']);
    $cQ=mysqli_query($conn,"SELECT * FROM `GIFTS` WHERE `CODE` = '$code'");
    if(mysqli_num_rows($cQ)!=1){
      $pQ=mysqli_query($conn,"SELECT * FROM `PROMOCODES` WHERE `CODE` = '$code'");
      if(mysqli_num_rows($pQ)==1){
        //promocode
        $p = mysqli_fetch_array($pQ);
        $c = mysqli_query($conn,"SELECT * FROM `PROMOCODE_REDEEMS` WHERE `P` = '$p[0]' AND `USER` = '$account[0]'");
        if(mysqli_num_rows($c)>0){
          echo"<script>window.alert('You have already redeemed $code');window.location='/User/settings.php'</script>";exit();
        }else{
          if($p['ISACTIVE']==1){//is active
            if($p['MAXUSES'] == 0 || $p['MAXUSES'] > $p['USES']){ // MAX USES NOT MET YET -> CONTINUE
            //figure out what it does
            if($p['ISCASH']==1){
              //grant cash
              $cash = $account['BUCKS'] + $p['ITEMID'];
              mysqli_query($conn,"UPDATE `USERS` SET `BUCKS` = '$cash' WHERE `ID` = '$account[0]'");
              $res = "$p[ITEMID] Bucks";
            }else{
              //grant item
              $itemq = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$p[ITEMID]'");
              $i = mysqli_fetch_array($itemq);
              $invq = mysqli_query($conn,"SELECT * FROM `INV` WHERE `ITEM` = '$p[ITEMID]' AND `USER` = '$account[0]'");
              if(mysqli_num_rows($invq)>0){
                echo"<script>window.alert('You already own the assigned item');window.location='/User/settings.php'</script>";exit();
              }else{
                mysqli_query($conn,"INSERT INTO `INV` VALUES(NULL,'$p[ITEMID]','$account[0]','$i[TYPE]','0')");
                $res = "$i[NAME]";
              }
            }
            $time = time();
            if($p['MAXUSES'] != 0 && $p['USES'] = ($p['MAXUSES'] - 1)){mysqli_query($conn,"UPDATE `PROMOCODES` SET `TIME_REMOVE` = '$time', `ISACTIVE` = '0' WHERE `ID` = $p[0]");} # Last one >:)
              
            mysqli_query($conn,"INSERT INTO `PROMOCODE_REDEEMS` VALUES(NULL,'$account[0]','$p[0]')");
            mysqli_query($conn,"UPDATE `PROMOCODES` SET `USES` = '" . strval(intval($p['USES']) + 1) . "' WHERE `ID` = $p[0]");
            echo"<script>window.alert('Successfully redeemed $code! You got $res!');window.location='/User/settings.php'</script>";exit();
            #echo"<script>window.alert('Successfully redeemed $code! You got $res!')</script>";exit();
            }else{
              // MAX USES MET
              echo"<script>window.alert('This code is expired!');window.location='/User/settings.php'</script>";exit();
            }
          }else{
            echo"<script>window.alert('This code is expired!');window.location='/User/settings.php'</script>";exit();
          }
        }
      }else{
        //fake code
        echo"<script>window.alert('Code $code does not exist');window.location='/User/settings.php'</script>";exit();
      }
    }else{
      //Gift code
      #echo"<script>window.alert('Gift code $code exists');window.location='/User/settings.php'</script>";exit();
      $c = mysqli_fetch_array($cQ);
      if($c['REDEEMED_BY']==0){
        if($c['SENT_BY']==$account[0]){
          echo"<script>window.alert('Code $code does not exist');window.location='/User/settings.php'</script>";exit();
        }else{
          $time = time();
          if($c['TYPE']=='1M_NORMAL'){
            $tp = 'VIP';
            $tm = $time + 2630000;
            $ae = '1 Month VIP';
          }elseif($c['TYPE']=='3M_NORMAL'){
            $tp = 'VIP';
            $tm = $time + 7890000;
            $ae = '3 Months VIP';
          }elseif($c['TYPE']=='INF_NORMAL'){
            $tp = 'VIP';
            $tm = 0;
            $ae = 'Infinite VIP';
          }elseif($c['TYPE']=='1M_MEGA'){
            $tp = 'MEGA';
            $tm = $time + 2630000;
            $ae = '1 Month Mega VIP';
          }elseif($c['TYPE']=='3M_MEGA'){
            $tp = 'MEGA';
            $tm = $time + 7890000;
            $ae = '3 Months Mega VIP';
          }elseif($c['TYPE']=='INF_MEGA'){
            $tp = 'VIP';
            $tm = 0;
            $ae = 'Infinite Mega VIP';
          }

          mysqli_query($conn,"UPDATE `USERS` SET `VIP` = '$tp', `ENDS` = '$tm' WHERE `ID` = '$account[0]'");
          mysqli_query($conn,"UPDATE `GIFTS` SET `REDEEMED_BY` = '$account[0]' WHERE `ID` = '$c[0]'");
          
          echo"<script>window.alert('Successfully redeemed $ae!');window.location='/User/settings.php'</script>";exit();
          
      	}
        
      }else{
        echo"<script>window.alert('Code $code does not exist');window.location='/User/settings.php'</script>";exit();
      }
    }
}

if(isset($_POST['cancel'])){
    mysqli_query($conn,"UPDATE `USERS` SET `REP` = 'FALSE' WHERE `ID` = '$account[0]'");//REP
    echo"<script>window.alert('Your VIP subscription has been canceled! Your account will no longer be charged monthly.');window.location=''</script>";exit();
}

if(isset($_POST['convert'])){
  $amm = mysqli_real_escape_string($conn,$_POST['convert']);
  $type = mysqli_real_escape_string($conn,$_POST['conversion_type']);
  if(!is_numeric($amm)){echo"<script>window.alert('The ammount is a non-numeric value, make sure you are only inputting numbers!');window.location='/User/settings.php?wallet'</script>";exit();}
  if($amm<1){echo"<script>window.alert('Nil or negative value encountered');window.location='/User/settings.php?wallet'</script>";exit();}
  if($type=='BUCKS'){ // Coins -> Bucks
    if($account['COINS']<$amm){
      echo"<script>window.alert('You do not have enough coins');window.location='/User/settings.php?wallet'</script>";exit();
    }
    if($amm%5!=0){
      echo"<script>window.alert('Please input a multiple of 5');window.location='/User/settings.php?wallet'</script>";exit();
    }
    $B = $amm / 5;
    $b = $account['BUCKS'] + $B;
    $c = $account['COINS'] - $amm;
    mysqli_query($conn,"UPDATE `USERS` SET `COINS` = '$c' WHERE `ID` = '$account[0]'");
    mysqli_query($conn,"UPDATE `USERS` SET `BUCKS` = '$b' WHERE `ID` = '$account[0]'");
    echo"<script>window.alert('Success!');window.location='/User/settings.php?wallet'</script>";exit();
    
  }elseif($type=='COINS'){ // Bucks -> Coins
    if($account['BUCKS']<$amm){
      echo"<script>window.alert('You do not have enough bucks');window.location='/User/settings.php?wallet'</script>";exit();
    }
    $C = $amm * 5;
    $c = $account['COINS'] + $C;
    $b = $account['BUCKS'] - $amm;
    mysqli_query($conn,"UPDATE `USERS` SET `COINS` = '$c' WHERE `ID` = '$account[0]'");
    mysqli_query($conn,"UPDATE `USERS` SET `BUCKS` = '$b' WHERE `ID` = '$account[0]'");
    echo"<script>window.alert('Success!');window.location='/User/settings.php?wallet'</script>";exit();
  }
}

if(isset($_POST['ghost'])){
  if($ar>2){
    if($account['GHOST']==1){
      mysqli_query($conn,"UPDATE `USERS` SET `GHOST` = '0' WHERE `ID` = '$account[0]'");
    }else{
      mysqli_query($conn,"UPDATE `USERS` SET `GHOST` = '1' WHERE `ID` = '$account[0]'");
    }
    echo"<script>window.location='/User/settings.php'</script>";exit();
  }
}
  
  
$dc1 = date("H:i:s", $account['DAILY_COINS'] + 18000);
$dc2 = gmdate("j F Y", $account['DAILY_COINS'] + 18000);

$dc3 = gmdate("H:i:s", $account['DAILY_COINS'] - $time);

//script

echo"

<script>

function makeid(length) {
   var result           = '';
   var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789`¬¦!£$%^&*()|\-_=+[]{};:@#~<>,./?';
   var charactersLength = characters.length;
   for ( var i = 0; i < length; i++ ) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
      pass = 'Randomly Generated Password: ' + result
   }
   
   window.alert(pass);
};

function page1() {
    
    document.getElementById('page1').style.display = 'block';
    document.getElementById('page2').style.display = 'none';
    document.getElementById('page3').style.display = 'none';
    document.getElementById('page4').style.display = 'none';
    
}

function page2() {
    
    document.getElementById('page1').style.display = 'none';
    document.getElementById('page2').style.display = 'block';
    document.getElementById('page3').style.display = 'none';
    document.getElementById('page4').style.display = 'none';
    
}

function page3() {
    
    document.getElementById('page1').style.display = 'none';
    document.getElementById('page2').style.display = 'none';
    document.getElementById('page3').style.display = 'block';
    document.getElementById('page4').style.display = 'none';
    
}

function page4() {
    
    document.getElementById('page1').style.display = 'none';
    document.getElementById('page2').style.display = 'none';
    document.getElementById('page3').style.display = 'none';
    document.getElementById('page4').style.display = 'block';
    
}

</script>

";

echo"

<div class='doublebox box1'>
    
    <div class='platformtitle'>
        <p>Settings</p>
    </div>
    
    <br>
    
    <button onclick='page1()' class='button btn-blue nd hover'>General</button>
    
    <button onclick='page2()' class='button btn-blue nd hover'>Account Info</button>
    
    <button onclick='page3()' class='button btn-green nd hover'>Wallet</button>
    
    <button onclick='page4()' class='button btn-gold nd hover'>Codes</button>
    
    <br>
    
</div>

<div class='doublebox box2'>

    <div id='page1' style='display:block;'>
    
        <div class='platformtitle'>
            <h2>General</h2>
        </div><br>
    
        <form id='bio' method='post'>
        
            <span>Update BIO</span><br>
            
            <textarea class='form form1l' maxlength='500' name='bio'>$account[BIO]</textarea><br>
            
            <button class='button btn-blue nd'>Update</button>
        
        </form>
        
        ";

if($ar>2){

  if($account['GHOST']==1){$gh = "Enabled";}else{$gh = "Disabled";}
  
  echo"
  <br><br>
  		<form id='ghost' method='post'>
        	<span>Ghost Mode ($gh)</span><br>
            <button class='button2 btn-blue nd' name='ghost'>Update</button>
        </form>
  
  ";

}

  $totc = $account['COINS'] +      ($account['BUCKS'] * 5);
  $totb = $account['BUCKS'] + floor($account['COINS'] / 5);

  // Egg Hunt 2024
  if($eggHunt){
    $prog = get_progress($account[0]);
    if($prog == null){
      create($account[0]);
      $proceed = true;
    }else{
      if($prog["Eaten"]){
        $proceed = false;
      }else{
        $proceed = true;
      }
    }
    if($proceed){
      if(isset($_GET["eat"])){
        update($account[0], "Eaten");
        echo"<script>window.alert('Nom.');</script>";
      }else{
        echo"
        <hr>
        <h3>The forbidden cheese</h3>
        <p>You have found the forbidden cheese. You can eat it if you want, but I wouldn't recommend that...</p>
        <a class='fas fa-cheese nd' href='?eat' style='color:#ff0;font-size:2rem;'></a><br><br>
         
        ";
      }
      
    }
  }

echo"
    </div>
    
    <div id='page2' style='display:none;'>
    
        <div class='platformtitle'>
            <h2>Account info</h2>
        </div><br>
    
        <form id='name' method='post'>
        
            <span>Update Username</span><br><br>
            
            <input class='form form1l' maxlength='25' name='name' placeholder='New Username'></input><br>
            <input class='form form1l' type='password' name='password' placeholder='Your Current Password'></input><br><br>
            
            <button class='button btn-blue nd'>Update for "; echo($config['usernameChangeBucksAmount']); echo" Bucks</button>
        
        </form>
        
        <br><hr>
        
        <form id='pass' method='post'>
        
            <span>Update Password</span><br><br>
            
            <input class='form form1l' type='password' name='p1' placeholder='New Password'></input><br>
            <input class='form form1l' type='password' name='p12' placeholder='New Password (Again)'></input><br>
            <input class='form form1l' type='password' name='p2' placeholder='Your Current Password'></input><br><br>
            
            <button class='button btn-blue nd'>Update</button>
        
        </form>
        
        <button class='button btn-green nd' onclick='makeid(20)'>Generate password</button>
    </div>
    
    <div id='page3' style='display:none;'>
    
        <div class='platformtitle btn-green'>
            <h2>Wallet & Conversion</h2>
        </div>
        
        Conversion Rates:<br>
        
        <p style='font-size:2rem;'>
        1 <i class='fa fa-money-bill-alt'></i> <i class='fa fa-sync-alt'></i> 5 <i class='fa fa-coins'></i>
        </p>
        
        <br><br>
        <form method='post'>
        <input class='form form1l' name='convert' type='number' max='10000' min='1'>
        <select name='conversion_type' class='form form1l'>
        	<option value='BUCKS'>Coins -> Bucks</option>
            <option value='COINS'>Bucks -> Coins</option>
        </select>
        <button class='button3 btn-blue hover'>Convert!</button>
        </form>
        
        <br><hr>
        
        <p>Daily Currency in: $dc1 $dc2 (GMT)<br>$dc3 relative time</p>
        
        <hr>
        <h3>Your Wallet:</h3>
        
        Coins: $account[COINS] <i class='fa fa-coins'></i><br>
        Bucks: $account[BUCKS] <i class='fa fa-money-bill-alt'></i><br>
        Total: $totc <i class='fa fa-coins'></i> OR $totb <i class='fa fa-money-bill-alt'></i><br>
        
    </div>
    
    <div id='page4' style='display:none;'>
    
        <div class='platformtitle btn-gold'>
            <h2>Redeem</h2>
        </div>
        
        <p>Recieve an item or bucks from a promocode, or enter a VIP code to get VIP!</p>
        
        <form method='post'>
        
            <input class='form' name='redeem' minlength='4' maxlength='16' placeholder='Gift Code' style='text-transform: uppercase;'>
            
            <button class='button3 btn-gold nd hover'>Redeem!</button>
        
        </form>
        
        ";

		if($account['CAN_GIFT']=='TRUE'){echo"
        
        <hr>
        
        <h3>Gift Inventory</h3>
        
        <form method='post'>
        
        	<select name='giftOPT' class='form form1l'>
        		<option>1M_NORMAL</option>
        		<option>3M_NORMAL</option>
        		<option>1M_MEGA</option>
        		<option>3M_MEGA</option>
                ";if($account['RANK']=='MANAGER'||$account['RANK']=='OWNER'){echo"<option disabled>- - - - - - -</option><option>INF_NORMAL</option><option>INF_MEGA</option>";}echo"
          	</select>
       	
        
            <button class='button3 btn-green nd hover' name='newgift'>Create a gift</button>
            <p class='small1'>Abuse of the gifting system will result in it being taken away.</p>
            
        </form>
        
        ";
        
        $q = mysqli_query($conn,"SELECT * FROM `GIFTS` WHERE `SENT_BY` = '$account[0]' ORDER BY `ID` DESC");
        while(($c = mysqli_fetch_array($q))){
            
            $t3 = date("H:i", $c['TIME'])." ";
            $t4 = gmdate("j F Y", $c['TIME']);
            
            if($c['REDEEMED_BY']==0){
                $span = "<span class='fa fa-star txtcol-gold'></span>";
            }else{
                $span = "<span class='fa fa-check txtcol-green' title='REDEEMED BY $c[REDEEMED_BY]'></span>";
            }
          
            if($c['TYPE']=='1M_NORMAL'){
              $t = "1 Month";
            }elseif($c['TYPE']=='3M_NORMAL'){
              $t = "3 Months";
            }elseif($c['TYPE']=='INF_NORMAL'){
              $t = "Infinite";
            }elseif($c['TYPE']=='1M_MEGA'){
              $t = "1 Month Mega";
            }elseif($c['TYPE']=='3M_MEGA'){
              $t = "3 Months Mega";
            }elseif($c['TYPE']=='INF_MEGA'){
              $t = "Infinite Mega";
            }
            
            echo"
            
            <div class='giftbox'>
                $span $t VIP Membership (Code: $c[CODE])<br>
                <span class='small1'>Made at $t3 on $t4</span>
            </div>
            
            ";
        }}
        
        echo"
    
    </div>

</div>

</div>

";

if(isset($_GET['wallet'])){
  echo"<script>page3();</script>";
}

//
        //<h4> <i class='fa fa- txtcol-'></i> Benefit </h4>

/*

$itemEggID = 0;
$itemEggPhrase = "Egg2021";

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/navbar.php');

if(isset($_COOKIE['KABRICK_U']) || isset($_COOKIE['KABRICK_P'])){}else{
    echo"<script>window.location='/'</script>";}
    
if(isset($_GET['upd'])){
if(isset($_POST['usrn'])){
    if(!isset($_POST['pass'])||$_POST['pass']==''){
        //pass not set
        echo"<script>window.alert('Please put your current password to change your name');window.location='/User/settings.php?upd'</script>";
    }else{
        $username = mysqli_real_escape_string($conn,$_POST['usrn']);
        $passwordBH = mysqli_real_escape_string($conn,$_POST['pass']);
        $passwordH1 = hash('gost',$passwordBH);
        $password = hash('whirlpool',$passwordH1);
        $UsernameL = strlen($username);
	    if ($UsernameL < 2 || $UsernameL > 20){
		    echo"<script>window.alert('Username Needs To Be Bigger Than 2 Characters And Smaller Than 20!');window.location='/User/settings.php?upd'</script>";
	    }else{
	        if($password!=$account['PASSWORD']){
	            echo"<script>window.alert('Passwords are not identical!');window.location='/User/settings.php?upd'</script>";
	        }else{
	            $re = '/^[A-Za-z0-9]*$/';
		        if(!preg_match_all($re, $username)){
		            echo"<script>window.alert('Incorrect Username Syntax!');window.location='/User/settings.php?upd'</script>";
		        }else{if($account['BUCKS']<50){echo"<script>window.alert('Not enough Bucks!');window.location='/User/settings.php?upd'</script>";}else{$b=$account['BUCKS']- 50;mysqli_query($conn,"UPDATE `USERS` SET `BUCKS` = '$b' WHERE `ID` = '$account[0]'");
		            //complete
		            mysqli_query($conn,"UPDATE `USERS` SET `USERNAME` = '$username' WHERE `ID` = '$account[0]'");
		            echo"<script>window.alert('Username Changed!');window.location='/login.php'</script>";
		        }}
	        }
	    }
    }
}
if(isset($_POST['usrp'])){
    if(!isset($_POST['oldp'])||$_POST['oldp']==''){
        //pass not set
        echo"<script>window.alert('Please put your current password');window.location='/User/settings.php?upd'</script>";
    }else{
        $passwordBH = mysqli_real_escape_string($conn,$_POST['usrp']);
        $passwordH1 = hash('gost',$passwordBH);
        $password = hash('whirlpool',$passwordH1);
        $passwordBHN = mysqli_real_escape_string($conn,$_POST['oldp']);
        $passwordH1N = hash('gost',$passwordBHN);
        $passwordN = hash('whirlpool',$passwordH1N);
        if($passwordN!=$account['PASSWORD']){
            echo"<script>window.alert('Passwords are not identical!');window.location='/User/settings.php?upd'</script>";
        }else{
            mysqli_query($conn,"UPDATE `USERS` SET `PASSWORD` = '$password' WHERE `ID` = '$account[0]'");
		    echo"<script>window.alert('Password Changed!');window.location='/login.php'</script>";
        }
    }
}
echo"
<script>function makeid(length) {
   var result           = '';
   var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789`¬¦!£$%^&*()|\-_=+[]{};:@#~<>,./?';
   var charactersLength = characters.length;
   for ( var i = 0; i < length; i++ ) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
      pass = 'Randomly Generated Password: ' + result
   }
   return pass;
};</script>
<title>Kabrick.tk - User Settings</title>
<center>
<h1><i style='color:$col8;' class='fa fa-cog'></i> <u><b>User Settings</b></u></h1>
<div class='box middle' style='background-color:$col12;border-color:$col13;'>
    <h2>Update username or password</h2>
    <form method='post' enctype='multipart/form-data' title='When you change your name, Keep in mind that this is a change that can only be reversed by paying the correct amount again. Also remember that your Username is public and everyone that visits the site is allowed to see it. After changing, you will be logged out. Only change your name if you are cirtain. Changing your name to something innapropriate will get your account Banned!'>
        <p>Username</p>
        <input style='border:1px solid black;border-radius:5px;width:300px;padding:5px;margin-bottom:5px;' placeholder='$account[USERNAME]' name='usrn' required></input>
        <input style='border:1px solid black;border-radius:5px;width:300px;padding:5px;margin-bottom:5px;' placeholder='Password' name='pass' required></input>
	    <button style='border:1px solid black;padding:5px;width:120px;margin:5px;margin-left: 5px;margin-right: 5px;border-radius: 5px;'>Update for 50 bucks!</button>
    </form>
    <form method='post' enctype='multipart/form-data' title='Passwords are NOT stored in plain text and are hashed, meaning that no one is able to find out your password. Please remember when you are changing your password, change it to something secure and dont forget your password (I strongly recommend saving the password). After changing, you will be logged out. The administration team are not responsible for you losing a password.'>
        <p>Password</p>
        <input style='border:1px solid black;border-radius:5px;width:300px;padding:5px;margin-bottom:5px;' placeholder='Old password' name='oldp' required></input>
        <input style='border:1px solid black;border-radius:5px;width:300px;padding:5px;margin-bottom:5px;' placeholder='New password' name='usrp' required></input>
	    <button style='border:1px solid black;padding:5px;width:120px;margin:5px;margin-left: 5px;margin-right: 5px;border-radius: 5px;'>Save</button>
    </form>
    <button class='button' onclick='window.alert(makeid(15))'>Randomly Generate a Password</button>
    <br><br>
</div>
</center>
</body>
</html>";

}else{
    
if($account['VIP']=='VIP'){
    $membership = "Normal VIP";
}elseif($account['VIP']=='MEGA'){
    $membership = "Mega VIP";
}elseif($account['VIP']=='ULTRA'){
    $membership = "Ultra VIP";
}else{
    $membership = "None";
}

if(isset($_POST['bio'])){
    $bio = mysqli_real_escape_string($conn,$_POST['bio']);
    if($bio==''||$bio=='­'){
        echo"
        <script>window.alert('Add Something Into The Bio!')</script>
        <script>window.location='/User/settings.php'</script>";
    }elseif($bio==$itemEggPhrase){
        
        $selectEgg = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `USER` = '$account[0]' AND `ITEM` = '$itemEggID'");
        $Egg = mysqli_num_rows($selectEgg);
        
        if($Egg==0&&$itemEggID!=0){
            $selectEggSerial = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ITEM` = '$itemEggID'");
            $EggSerial = mysqli_num_rows($selectEggSerial) + 1;
            mysqli_query($conn,"INSERT INTO `INV` VALUES(NULL,'$itemEggID','$account[0]','$EggSerial')");
        }
        
        mysqli_query($conn,"UPDATE `USERS` SET `BIO` = '$bio' WHERE `ID` = '$account[ID]'");
        echo"
        <script>window.alert('Bio Has Been Updated!')</script>
        <script>window.location='/User/settings.php'</script>";
    }else{
        mysqli_query($conn,"UPDATE `USERS` SET `BIO` = '$bio' WHERE `ID` = '$account[ID]'");
        echo"
        <script>window.alert('Bio Has Been Updated!')</script>
        <script>window.location='/User/settings.php'</script>";
    }
}

if(isset($_POST['theme'])){
    $theme = mysqli_real_escape_string($conn,$_POST['theme']);
    
        mysqli_query($conn,"UPDATE `USERS` SET `THEME` = '$theme' WHERE `ID` = '$account[ID]'");
        echo"
        <script>window.alert('Theme Has Been Updated!')</script>
        <script>window.location='/User/settings.php'</script>";
}

echo"
<title>Kabrick.tk - User Settings</title>
<center>
<h1><i style='color:$col8;' class='fa fa-cog'></i> <u><b>User Settings</b></u></h1>
<div class='box middle' style='background-color:$col12;border-color:$col13;'>
    <br>
    <h2>General Settings</h2>
    <form method='post' enctype='multipart/form-data'>
        <p><i style='color:$col8;' class='fa fa-paint-brush'></i> Update Theme</p>
        <select name='theme' style='padding:5px;padding-left:10px;padding-right:20px;margin-top:7.5px;border-radius:5px;'>
	        <option name='LIGHT'>LIGHT</option>
	        <option name='DARK'>DARK</option>
	        ";
	        
	        $themeQ = mysqli_query($conn,"SELECT * FROM `THEMES` WHERE 1");
	        while(($theme=mysqli_fetch_array($themeQ))){
	        
	        if(mysqli_num_rows(mysqli_query($conn,"SELECT * FROM `INV_T` WHERE `THEME_ID` = '$theme[0]' AND `USER_ID` = '$account[0]'"))==1){
	            echo"<option name='$theme[THEME_ID]'>$theme[THEME_ID]</option>";
	            
	        }
	        
	        }
	            
	        echo"
	        
	    </select>
	    <button style='border:1px solid black;padding:5px;width:120px;margin:5px;margin-left: 5px;margin-right: 5px;border-radius: 5px;'>Save</button>
    </form>
    <form method='post' enctype='multipart/form-data'>
        <p><i style='color:$col8;' class='fa fa-comment'></i> Update Bio</p>
        <input style='border:1px solid black;border-radius:5px;width:300px;padding:5px;margin-bottom:5px;' placeholder='$account[BIO]' name='bio' required></input>
	    <button style='border:1px solid black;padding:5px;width:120px;margin:5px;margin-left: 5px;margin-right: 5px;border-radius: 5px;'>Save</button>
    </form>
    
    <i style='color:$col8;' class='fa fa-ban'></i> <a href='/User/modlogs.php'>View All Bans</a> | <i style='color:$col8;' class='fa fa-paint-brush'></i> <a href='/User/Avatar.'>Edit Avatar</a>
    <br><br><div style='border-top:1px dotted;'></div><br>
    <p><i class='fa fa-user-alt'></i> Membership</p>
    <p>Active membership: $membership</p>
    <p><a href='/User/membership.php'>More Info On Memberships</a></p>
    <p><i class='fa fa-gift'></i> <a href='/User/membership.php?gift'>Send A Gift To Another User!</a></p>
    <div style='border-top:1px dotted;'></div><br>
        <a href='?upd'><i style='color:$col8;' class='fa fa-pencil-alt'></i> Update Username or password</a>
</div>
</center>
</body>
</html>";}

*/?>