<?php
include($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');
include($_SERVER['DOCUMENT_ROOT'] . '/bbcode.php');
echo"<title>Message | $meta_name</title>";

if(!isset($_COOKIE['KABRICK_U']) || !isset($_COOKIE['KABRICK_P'])){
  echo"<script>window.location='/'</script>";exit();
}

if(!isset($_GET['id'])){
  exit();
}

$id = mysqli_real_escape_string($conn,$_GET['id']);
$MSG = mysqli_query($conn,"SELECT * FROM `MESSAGES` WHERE `ID` = '$id'");

if(mysqli_num_rows($MSG)!=1){
  exit();
}

$m = mysqli_fetch_array($MSG);

if($m['RECIEVER']!=$account[0]&&$m['SENDER']!=$account[0]&&$ar<5){
  exit();
}

if(isset($_POST['replyBdy'])){ # REPLY
	$body = mysqli_real_escape_string($conn,$_POST['replyBdy']);
    $title = "RE: " . substr($m['TITLE'],0,21);
    if($m['SENDER'] == $account[0]){$send = $m['RECIEVER'];} else {$send = $m['SENDER'];}
    $time = time();
    $q = $conn->prepare("INSERT INTO `MESSAGES` VALUES(NULL,?,?,?,'NO','0',?,?,?)");
    $q->bind_param("iisisi",$account[0],$send,$body,$time,$title,$id);
    $q->execute();
    update($account[0], "Message");
    echo"<script>window.location = '/Messages/'</script>";
}else{

if($m['RECIEVER']==$account[0]&&$m['VIEWED']=='NO'){
  mysqli_query($conn,"UPDATE `MESSAGES` SET `VIEWED` = 'YES' WHERE `ID` = '$id'");
}

if($m['RECIEVER']==$account[0]){
  $userID = $m['SENDER'];
}elseif($m['SENDER']==$account[0]){
  $userID = $m['SENDER'];
}else{
  $userID = $m['SENDER'];
}

$u = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$userID'"));
$u2 = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$m[RECIEVER]'"));

if($u['RANK']=='OWNER'||$u['RANK']=='MANAGER'||$u['RANK']=='EXECUTIVE'||$u['RANK']=='ADMIN'||$u['RANK']=='MODERATOR'){
  $ur="<i class='fa fa-hammer txtcol-red'></i>";
}else{
  $ur='';
}

$body=bbcode_to_html(nl2br(htmlentities($m['MESSAGE'])));

$d = date("H:i", $m['TIME']);
$d2 = gmdate("j F Y", $m['TIME']);
    
    /*if($m['IMPORTANT'] == 1){$ttl = "<span class='txtcol-red'><i class='fas fa-exclamation-triangle'></i> $m[TITLE]</span>";}
    /*else{$ttl = $m[TITLE];}*/
  
  $ttl = lgt($m['TITLE']);

echo"

<div class='platform'>
  <div class='platformtitle "; if($m['IMPORTANT'] == 1){echo"btn-red";} echo"'>
  	<p>$ttl</p>
  </div>
  
  Created at $d, $d2
    <span class='small1'>To $u2[1]</span>
    
    "; if($m['REPLY'] != 0){echo"<br><a href='/Msg/$m[REPLY]'>Reply to previous message</a><br>";} echo"
    
    <div class='forum-body'>
    
        <div class='forum-av'>
            <a href='/Profile/$u[1]'>
                <img src='$u[AVATAR_IMG_URL]'>
                <br>
                <br>
                <b>$u[1] $ur</b>
            </a>
        </div>
    
        <div class='forum-st'>
            $body
        </div>
    
    </div>
    
    
    
    <br><br><hr><h3>Reply to message</h3>
    
    <form method='post'>
            
            <textarea class='form form1l' name='replyBdy' minlength='5' placeholder='Enter reply here, title will automatically be set'></textarea><br><br>
            
            <button class='button3 btn-blue nd hover'>Reply!</button>
            <p class='small1'>By pressing 'Send!' you agree that this reply is not violating any of our <a href='/help.php'>Rules</a>.</p>
            
        </form>
  
</div>

";}