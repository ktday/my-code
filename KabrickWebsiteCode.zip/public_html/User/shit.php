<?php
exit();

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');
include($_SERVER['DOCUMENT_ROOT'] . '/bbcode.php');

if(isset($_COOKIE['KABRICK_U']) || isset($_COOKIE['KABRICK_P'])){}else{
    echo"<script>window.location='/'</script>";exit();
}

if(isset($_GET['id'])){$id=mysqli_real_escape_string($conn,$_GET['id']);$t='v';$head="View message";}
elseif(isset($_GET['send'])){$t='s';$head="Send Message";}
elseif(isset($_GET['rep'])){$t='r';$head="Reply To Message";$id=mysqli_real_escape_string($conn,$_GET['rep']);}
else{echo"<script>window.location='/User/messages.php'</script>";exit();}

echo"
<title>Kabrick.tk - $head</title>
<center>
<div class='platform' style='border-color:$col13;'>
    
    ";
    
    if($t=="s"){
        
        if(isset($_POST['t'])&&isset($_POST['b'])&&isset($_POST['n'])){
            $t = mysqli_real_escape_string($conn,$_POST['t']);
            $b = mysqli_real_escape_string($conn,$_POST['b']);
            $usrn = mysqli_real_escape_string($conn,$_POST['n']);
            $idQ = mysqli_query($conn,"SELECT * FROM `USERS` WHERE `USERNAME` = '$usrn'");
            $id = mysqli_fetch_array($idQ);
            
            if(strlen($t)>25){echo"<script>window.location='messages.php'</script>";exit();}
            if(strlen($b)>255){echo"<script>window.location='messages.php'</script>";exit();}
            if(strlen($t)<3){echo"<script>window.location='messages.php'</script>";exit();}
            if(strlen($b)<5){echo"<script>window.location='messadges.php'</script>";exit();}
            if(mysqli_num_rows($idQ)!=1){echo"<script>window.location='messadges.php'</script>";exit();}
            
            $cflpQ = mysqli_query($conn,"SELECT * FROM `MESSAGES` WHERE `SENDER` = '$account[0]' ORDER BY `ID` DESC LIMIT 1");
            $cflp = mysqli_fetch_array($cflpQ);
            
            $time = time();
            if(mysqli_num_rows($cflpQ)>0){
            $time5minago = time() - 300;
            if($time5minago < $cflp['TIME']){
                echo"<script>window.alert('You have already recently sent a message!');window.location='messages.php'</script>";exit();
            }else{
                mysqli_query($conn,"INSERT INTO `MESSAGES` VALUES(NULL,'$account[0]','$id[0]','$b','NO','$time','$t')");
                echo"<script>window.alert('Successfully sent $t!');window.location='messages.php?t=out'</script>";exit();
            }}else{
                mysqli_query($conn,"INSERT INTO `MESSAGES` VALUES(NULL,'$account[0]','$id[0]','$b','NO','$time','$t')");
                echo"<script>window.alert('Successfully sent $t!');window.location='messages.php?t=out'</script>";exit();
            }
            
        }
        
        echo"
        <form method='post'>
	
    	    <input style='border:1px solid black;border-radius:5px;width:150px;padding:5px;margin-bottom:5px;' placeholder='Users name' title='Who are you sending it to?' name='n' minlength='3' maxlength='20' required><br>
    	    <input style='border:1px solid black;border-radius:5px;width:300px;padding:5px;margin-bottom:5px;' placeholder='Title' name='t' minlength='3' maxlength='25' required><br>
            <textarea style='border:1px solid black;border-radius:5px;padding:5px;margin-bottom:5px;width:400px;height:100px' name='b' placeholder='Input message here' minlength='5' maxlength='255' required></textarea><br>
            <button style='border:1px solid black;padding:5px;width:120px;margin:5px;margin-left: 5px;margin-right: 5px;border-radius: 5px;'>Send!</button>
    	
    	</form>
    	
    	<br><br><a href='messages.php?t=in'>Back to message list</a>
        
        ";
        
    }elseif($t=="r"){
        
        if(isset($_POST['b'])){
            $b = mysqli_real_escape_string($conn,$_POST['b']);
            
            $msgQ = mysqli_query($conn,"SELECT * FROM `MESSAGES` WHERE `ID` = '$id'");
            $msg = mysqli_fetch_array($msgQ);
            
            $usrToSend = mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$msg[SENDER]'");
            $usr = mysqli_fetch_array($usrToSend);
            
            $t = "RE: " . $msg['TITLE'];
            
            if(strlen($b)>255){echo"<script>window.location='messages.php'</script>";exit();}
            if(strlen($b)<5){echo"<script>window.location='messadges.php'</script>";exit();}
            
            $cflpQ = mysqli_query($conn,"SELECT * FROM `MESSAGES` WHERE `SENDER` = '$account[0]' ORDER BY `ID` DESC LIMIT 1");
            $cflp = mysqli_fetch_array($cflpQ);
            
            $time = time();
            if(mysqli_num_rows($cflpQ)>0){
            $time5minago = time() - 300;
            if($time5minago < $cflp['TIME']){
                echo"<script>window.alert('You have already recently sent a message!');window.location='messages.php'</script>";exit();
            }else{
                mysqli_query($conn,"INSERT INTO `MESSAGES` VALUES(NULL,'$account[0]','$usr[0]','$b','NO','$time','$t')");
                echo"<script>window.alert('Successfully sent $t!');window.location='messages.php?t=out'</script>";exit();
            }}else{
                mysqli_query($conn,"INSERT INTO `MESSAGES` VALUES(NULL,'$account[0]','$usr[0]','$b','NO','$time','$t')");
                echo"<script>window.alert('Successfully sent $t!');window.location='messages.php?t=out'</script>";exit();
            }
            
        }
        
        echo"
        <h1>$head</h1>
        <form method='post'>
            <textarea class='form form2l' name='b' placeholder='Input message here' minlength='5' maxlength='255' required></textarea><br>
            <button class='button2 btn-blue nd'>Send!</button>
    	
    	</form>
    	
    	<br><br><a href='message.php?id=$id'>Return to message</a> | <a href='messages.php?t=in'>Back to message list</a>
        
        ";
        
    }else{
        
        $msgQ = mysqli_query($conn,"SELECT * FROM `MESSAGES` WHERE `ID` = '$id'");
        $msg = mysqli_fetch_array($msgQ);
        
        if(mysqli_num_rows($msgQ)!=1){echo"<script>window.location='messages.php'</script>";exit();}
        
        if($msg['RECIEVER']!=$account[0]){echo"<script>window.location='messages.php'</script>";exit();}
        
        $uQ = mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$msg[SENDER]'");
        $u = mysqli_fetch_array($uQ);
        
        echo"
        
        <div class='platformtitle'>
        <p>\"$msg[TITLE]\"</p>
        </div>
        
        <div class='left' style='margin:30px'>
        	<div title='The person who sent you this message!' style='display:inline-block;margin:20px;' class='middle'>
        			<a href='/Users/Profile/?id=$u[0]'>
        				<img src='$u[AVATAR_IMG_URL]'><br>
        				<text>";if($u['RANK']!="MEMBER")echo"<i title='Administrator (Level: $u[RANK])' style='color:red;' class='fa fa-hammer'></i>";echo" $u[1]</text><br><br>
        		</a>
        	</div>
        		
        	<div style='display:inline-block;width: 500px;margin:0px;' class='middle'>
        		<div style='display:inline-block;width:600px;'>
        			<div style='max-width:500px;margin:auto;word-wrap:break-word;'><text title='What they are saying in their message. If you find this breaking any of our rules, click Report!' style='font-size:15px;'>".bbcode_to_html(nl2br(htmlentities($msg['MESSAGE'])))."</text></div><br><br>
        			<p><i class='fa fa-reply'></i> <a title='Create a private Reply to this message!' href='?rep=$id'>Reply</a> | <i class='fa fa-exclamation-triangle'></i> <a title='If you find this message breaking any rules, Click this to report it to an admin! (Spam reporting or false reporting MAY lead to a ban. Do not hesitate to report this if it is breaking any rules.)' href=''>Report</a></p>
        		</div><br>
        	</div>
        </div>
        <a href='messages.php'>Return to messages</a>
        
        ";
        
        if($msg['VIEWED']=="NO"){mysqli_query($conn,"UPDATE MESSAGES SET `VIEWED` = 'YES' WHERE `ID` = '$id'");}
        
    }
    
    echo"
    
    <br>
</div>
</center>
</body>
</html>";

?>