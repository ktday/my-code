<?php
include($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');

echo"<title>Friends | $meta_name</title>";

if(!isset($_COOKIE['KABRICK_U']) || !isset($_COOKIE['KABRICK_P'])){
  echo"<script>window.location='/'</script>";exit();
}

$req = mysqli_query($conn,"SELECT * FROM `FRIEND_REQ` WHERE `RECIEVER` = '$account[0]' ORDER BY `ID` DESC");

if(mysqli_num_rows($req) != 0){
  
  echo"<div class='platform nbg'>
  <div class='platformtitle'><p><u><b>Friend Requests</b></u></p></div><br>";
  
  while(($r = mysqli_fetch_array($req))){
    $u = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$r[SENDER]'"));
    echo"
    <a href='/Profile/$u[1]' class='nd'>
    <div class='marketcard'>
    <div class='marketcard-img'>
    <img src='$u[AVATAR_IMG_URL]' class='avatar'>
    </div>
    <p>$u[1]</p>
    <a href='/Friends/Accept/$r[0]' class='button btn-green'>Accept</a><br>
    <a href='/Friends/Decline/$r[0]' class='button btn-red'>Decline</a>
    </div>&nbsp;&nbsp;
    </a>";
  }
  echo"</div><br><br>";
}

echo"<div class='platform nbg'>
  <div class='platformtitle'><p><u><b>Friends</b></u></p></div><br>";

$friends = mysqli_query($conn,"SELECT * FROM `FRIENDS` WHERE `U1` = '$account[0]' OR `U2` = '$account[0]' ORDER BY `ID` DESC");

while(($f = mysqli_fetch_array($friends))){
  $uid = $f['U1'] == $account[0] ? "U2" : "U1";
  $u = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$f[$uid]'"));
  $rank = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `ROLES` WHERE `NAME` = '$u[RANK]'"));
  if($rank['ICON']!=""){$i = "<i class='$rank[ICON]' style='color:$rank[COLOR];'></i>";}else{$i="";}
  echo"
    <a href='/Profile/$u[1]' class='nd'>
    <div class='marketcard'>
    <div class='marketcard-img'>
    <img src='$u[AVATAR_IMG_URL]' class='avatar'>
    </div>
    <p>$i $u[1]</p>
    </div>&nbsp;&nbsp;
    </a>";
}