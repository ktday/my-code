<?php

echo"<title>Help & Rules | Kabrick.tk Beta</title>";

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');
include($_SERVER['DOCUMENT_ROOT'] . '/bbcode.php');



echo"

<style>

r{color:red}
left{float:left;margin-left:5rem;}

</style>

<div class='platform'>
    <div class='platformtitle'>
        <h2>Help & Rules</h2>
    </div>
    
    <p>In order to keep everyone safe, we have set some rules for the site.<br>
    <b>By registering, you <r>automatically agree</r> to these rules.</b></p>
    
    <hr>
    
        <h1>RULES</h1>
        
        <hr>
        <h2>--Accounts--</h2>
        
            <h4>[1] Coinfarming & Alt Hoarding</h4>
        	Coinfarming (Collecting coins on alternate accounts and trading it to a main account) or Alt Hoarding (Collecting limited items on alternate accounts and trading to a main account) will result in a punishment and could leave your account banned or terminated.
        	
        	<h4>[2] Using other people's accounts</h4>
        	Logging into accounts that have not been registered by you will result in a ban or possibly a termination. This goes whether consent is given or not. If you find someone is in your account, Change your password and contact a member of staff. This also includes requesting a password change using someone elses email.
        	
        	<h4>[3] Selling or Giving Accounts away</h4>
        	Selling or giving Kabrick accounts onsite or offsite will leave your account terminated. This includes telling someone else your password.

        <hr>
        <h2>--Forums & Messaging--</h2>
        
            <h4>[4] Bullying + Harrassment</h4>
        	Any form of Bullying, Harrassment or Discrimination of any kind will result in a warn or potentially a ban. Swearing is allowed on the forums and messages but swearing at someone will trigger a punishment.
        	
        	<h4>[5] Sexual content / NSFW</h4>
        	NFSW (Not Safe For Work) Content will result in a ban.
        	
        	<h4>[6] Images + Links</h4>
        	Posting any kind of images on the forums, in messages, item descriptions, clan bios, user bios or anywhere else will result in a ban. This also means that you cannot send links of any kind anywhere. If this image or link is also related to NSFW or Gore, it could leave your account terminated. This also includes any kind of media including documents, videos, gifs and audios.
        	
        	<h4>[7] Advertising</h4>
        	Any form of advertising other sites, servers, games or anything else will result in a ban. Advertising onsite features like clans or items will result in a warn or no punishment.
        	
        	<h4>[8] Raiding & Spamming</h4>
        	Spamming on the forums will lead to the post being deleted (Reducing forum post count). Raiding, contributing to raids or protests will result in long bans or terminations depending on the severity of the raid or protest. Remember that you can suggest anything in the suggestions channel in our discord server or message a member of staff.

        <hr>
        <h2>--Credits--</h2>
        
        <ul>
        	<li>Spooky - Creator and Head Developer of Kabrick</li>
        	<li>JP - Developer and Helper</li>
        	<li>MrMrDay - Contributed to several assets</li>
        	<li>Westport - Long-time moderator</li>
        	<li>anonymoususer345 - Long-time Moderator</li>
        </ul>
    
    <p class='small1'>Site Version: $siteVer | &copy LRS 2018 - 2023</p>
    
</div>

</div>

";

?>