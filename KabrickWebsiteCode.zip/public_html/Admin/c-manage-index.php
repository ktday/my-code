<?php
include("../Misc/connect.php");

if($account['RANK']=='OWNER'){$r=6;}
elseif($account['RANK']=='MANAGER'){$r=5;}
else{exit();}


$num1 = $account['UUID'];

echo"

<h2>Manage Clans</h2>

<h2> All Clans: </h2>
      
<div style='overflow:scroll;'>
      
<table>

<tr>
	<th>ID</th>
    <th>Name</th>
    <th>CID</th>
    <th>Time Made</th>
    <th>Owner</th>
    <th>Members</th>
    <th>Boosts</th>
    <th>Status</th>
    <th colspan='2'>Actions</th>
</tr>
      
";

$usrs = mysqli_query($conn,"SELECT * FROM `CLANS` WHERE 1");
while(($u = mysqli_fetch_array($usrs))){
  
  $t = gmdate("j F Y", $u['TIME']);
  
  if($u['STATUS']=='PARTNER'){$txtc = 'txtcol-purple';}
  elseif($u['STATUS']=='UNVERIFIED'){$txtc = 'txtcol-orange';}
  elseif($u['STATUS']=='OK'){$txtc = 'txtcol-white';}
  else{$txtc = 'txtcol-red';}
  
  $usr = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$u[OWNER]'"));
  
  echo"<tr>
  	<td>$u[0]</td>
  	<td>$u[NAME]</td>
  	<td>$u[INVITE]</td>
  	<td>$t</td>
  	<td><a href='/Profile/$usr[1]'>$usr[1]</a></td>
  	<td>$u[MEMBERS]</td>
  	<td>$u[BOOSTS]</td>
  	<td class='$txtc'>$u[STATUS]</td>
    <td><a href='/Clan/$u[0]' class='fa fa-users'></a></td>
    <td><a href='/cx/$u[INVITE]' class='fa fa-cog'></a></td>
  </tr>";
}

echo"
</table>
<br><br>
</div>
";


?>