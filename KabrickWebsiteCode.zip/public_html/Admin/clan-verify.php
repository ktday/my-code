<?php
include("../Misc/connect.php");
$ITEMS = mysqli_query($conn,"SELECT * FROM `CLANS` WHERE `STATUS` = 'UNVERIFIED'");

if($account['RANK']=='OWNER'){$r=6;}
elseif($account['RANK']=='MANAGER'){$r=5;}
else{exit();}

$UUID = $account['UUID'];

echo"

<h2>Verify Clans</h2>
            
";

if(mysqli_num_rows($ITEMS)==0){
  echo"There are no clans to verify!";
}else{
  while(($i=mysqli_fetch_array($ITEMS))){
    $u = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$i[OWNER]'"));
    
    echo"
    
    <div>
    
      <img src='$i[ICON_URL]' class='fl' style='left:1rem;
    width: 10rem;
    height: 10rem;
'>
      
      <p><b>$i[NAME]</b></p>
      
      $i[INVITE]<br>
      
      Created by $u[1]<br>
      
      <a href='/Clan/$i[0]'>Head to clan</a><br>
      
      <form method='post'>
      	<button name='ac_$UUID' value='$i[0]' class='button3 btn-green nd hover'>Accept</button>
      	<button name='dc_$UUID' value='$i[0]' class='button3 btn-red nd hover'>Decline</button>
      </form>
    
    </div>
    
    <hr>
    
    ";
    
  }
}

?>