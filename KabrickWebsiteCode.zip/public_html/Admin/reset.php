<?php

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');

if(!isset($_COOKIE['KABRICK_U']) || !isset($_COOKIE['KABRICK_P'])){
    echo"<script>window.location='/'</script>";exit();
}

if($account['RANK']=='OWNER'){$r=6;}
elseif($account['RANK']=='MANAGER'){$r=5;}
elseif($account['RANK']=='EXECUTIVE'){$r=4;}
elseif($account['RANK']=='ADMIN'){$r=3;}
elseif($account['RANK']=='MODERATOR'){$r=2;}
else{echo"<script>window.location='/'</script>";exit();/*fuck off*/}

if(isset($_GET['id'])){
  $uQ = mysqli_query($conn,'SELECT * FROM USERS WHERE USERNAME = "' . mysqli_real_escape_string($conn,$_GET['id']) . '"');
  if(mysqli_num_rows($uQ)!=1){
    echo"<script>window.alert('User not found " . mysqli_num_rows($uQ) . "');</script>";exit();
  }
  $u = mysqli_fetch_array($uQ);
  if($r==2||$r==3){
    if($u['RANK'] == 'OWNER'||$u['RANK'] == 'MANAGER'||$u['RANK'] == 'EXECUTIVE'||$u['RANK'] == 'ADMIN'||$u['RANK'] == 'MODERATOR'){
      echo"<script>window.alert('Cannot admin an admin');</script>";exit();
    }
  }
  if($u['RANK'] == 'OWNER'){
    echo"<script>window.alert('no u');</script>";exit();
  }
  mysqli_multi_query($conn,"
    UPDATE `AVATAR` SET
        `HAT` = '0',
        `HAT2` = '0',
        `HAT3` = '0',
        `HAIR` = '0',
        `FACE` = '0',
        `GEAR` = '0',
        `SHOULDER` = '0',
        `MASK` = '0',
        `SHIRT` = '0',
        `PANTS` = '0',
        `BACK` = '0',
        `BODY` = '0',
        `PET` = '0'
    WHERE `UID` = '$u[0]';

    UPDATE `USERS` SET `AVATAR_IMG_URL` = '/Misc/IMGS/avatar.png' WHERE `ID` = '$u[0]';
    ");
  echo"<script>window.location='/Profile/" . mysqli_real_escape_string($conn,$_GET['id']) . "'</script>";exit();
}