<?php
include_once($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');
include_once($_SERVER['DOCUMENT_ROOT'] . '/Admin/FUNCT.php');

if($account['RANK']=='OWNER'){$r=6;}
elseif($account['RANK']=='MANAGER'){$r=5;}
else{exit();}

$UUID = $account['UUID'];

if(!isset($_GET['id'])){
  exit();
}

$id = mysqli_real_escape_string($conn,$_GET['id']);
$u = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `USERNAME` = '$id'"));

if($u[0]==2&&$account[0]!=2){
  exit();
}

if($u[0]==1&&$account[0]!=2){
  exit();
}

$ipAlts = array();
$selectSameIP = mysqli_query($conn,"SELECT * FROM `USERS` WHERE `IP` = '$u[IP]' AND `ID` != '$u[0]'");
while(($ipu = mysqli_fetch_array($selectSameIP))){
  array_push($ipAlts,$ipu);
}
$passAlts = array();
$selectSamePass = mysqli_query($conn,"SELECT * FROM `USERS` WHERE `PASSWORD` = '$u[PASSWORD]' AND `ID` != '$u[0]'");
while(($pwu = mysqli_fetch_array($selectSamePass))){
  array_push($passAlts,$pwu);
}

$forumPosts = array(); $forumReplies = array();
$findForumPosts = mysqli_query($conn,"SELECT * FROM `FORUM_THREADS` WHERE `UPLOADER` = '$u[0]'");
while(($fps = mysqli_fetch_array($findForumPosts))){
  array_push($forumPosts,$fps);
}
$findForumReplies = mysqli_query($conn,"SELECT * FROM `FORUM_REPLIES` WHERE `UPLOADER` = '$u[0]'");
while(($fps = mysqli_fetch_array($findForumReplies))){
  array_push($forumReplies,$fps);
}

if(isset($_POST['GRANT'])){
  $iid = mysqli_real_escape_string($conn,$_POST['GRANT']);
  $item = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$iid'"));
  if($item['RARITY']=='EPIC'&&$r!=6){
    echo"<script>window.alert('Only OWNER can grant limiteds & customs');window.location='/Admin/manage.php?id=$id'</script>";
  }elseif($item['RARITY']=='CUSTOM'&&$r!=6){
    echo"<script>window.alert('Only OWNER can grant limiteds & customs');window.location='/Admin/manage.php?id=$id'</script>";
  }else{
  	$findSerial = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `INV` WHERE `ITEM` = '$iid' ORDER BY `ID` DESC LIMIT 1"));
    $serial = $findSerial['SERIAL'] + 1;
  	mysqli_query($conn,"INSERT INTO `INV` VALUES(NULL,'$iid','$u[0]','$item[TYPE]','$serial')");
    logAction(51,$u[0],"[$iid] $item[1]");
    echo"<script>window.alert('Successfully Granted $item[1] to $u[1]!');window.location='/Admin/manage.php?id=$id'</script>";
  }
}

if(isset($_POST['upd-vip-time'])){
  $t = mysqli_real_escape_string($conn,$_POST['upd-vip-time']);
  $last = substr($t, -1);
  $first = substr($t, 0, 1);
  
  if($first == 'r'){
    $strF = substr($t, 1);
    $baseTime = time();
  }else{
    $strF = $t;
    $baseTime = $u['ENDS'];
  }
  
  if($last == 'h'){
    $type = 1;
    $strL = rtrim($strF, "h");
  }elseif($last == 'd'){
    $type = 0;
    $strL = rtrim($strF, "d");
  }else{
    echo("<script>window.location='/Admin/manage.php?id=$id'</script>");
    exit();
  }
  
  echo("$strL<br>$first<br>$last<br>");
  
  if(is_numeric($strL)){
    if($type == 1){
      $Ntime = $baseTime + ($strL * 3600);
    }else{
      $Ntime = $baseTime + ($strL * 86400);
    }
    
    //update it now
    mysqli_query($conn,"UPDATE `USERS` SET `ENDS` = '$Ntime' WHERE `ID` = '$u[0]'");
    echo("<script>alert('Successfully added $strF to VIP time');window.location='/Admin/manage.php?id=$id'</script>");
    
  }else{
    echo("<script>window.location='/Admin/manage.php?id=$id'</script>");
    exit();
  }
  
  exit();
}

if(isset($_POST['reset-vip'])){
  mysqli_query($conn,"UPDATE `USERS` SET `ENDS` = '0' WHERE `ID` = '$u[0]'");
  echo("<script>alert('Successfully reset VIP time');window.location='/Admin/manage.php?id=$id'</script>");
}

if(isset($_POST['upd-u'])){
  $newu = mysqli_real_escape_string($conn,$_POST['upd-u']);
  logAction(55,$u[0],"[$u[0]] from \"$u[1]\" to \"$newu\"");
  mysqli_query($conn,"UPDATE `USERS` SET `USERNAME` = '$newu' WHERE `ID` = '$u[0]'");
  echo("<script>alert('Set new username to: $newu');window.location='/Admin/manage.php?id=$newu'</script>");
}

if(isset($_POST['upd-b'])){
  $newb = mysqli_real_escape_string($conn,$_POST['upd-b']);
  logAction(53,$u[0],"[$u[0]] from \"$u[BIO]\" to \"$newb\"");
  mysqli_query($conn,"UPDATE `USERS` SET `BIO` = '$newb' WHERE `ID` = '$u[0]'");
  echo("<script>alert('Set bio');window.location='/Admin/manage.php?id=$id'</script>");
}

if(isset($_POST['grantTheEward'])){
  if($r==6){
  mysqli_query($conn,"INSERT INTO `USER_BADGES` VALUES(NULL,'$u[0]','4')");
  logAction(52,$u[0]);
  echo("<script>alert('Successfully granted the E-ward, oooohhhhhhhhh....');window.location='/Admin/manage.php?id=$id'</script>");
}}

if(isset($_POST['upd-rank'])){
  if($account['RANK']!='OWNER'){
    exit();
  }else{
    $new = mysqli_real_escape_string($conn,$_POST['upd-rank']);
    logAction(50,$u[0],"[$u[0] $u[1]] from \"$u[RANK]\" to \"$new\"");
    mysqli_query($conn,"UPDATE `USERS` SET `RANK` = '$new' WHERE `ID` = '$u[0]'");
    echo("<script>alert('Rank has been changed');window.location='/Admin/manage.php?id=$id'</script>");
  }
}

if(isset($_POST['upd-status'])){
  if($account['RANK']!='OWNER'){
    exit();
  }else{
    $new = mysqli_real_escape_string($conn,$_POST['upd-status']);
    mysqli_query($conn,"UPDATE `USERS` SET `STATUS` = '$new' WHERE `ID` = '$u[0]'");
    echo("<script>alert('Status has been changed');window.location='/Admin/manage.php?id=$id'</script>");
  }
}

if(isset($_POST['upd-cg'])){
  if($account['RANK']!='OWNER'){
    exit();
  }else{
    $new = mysqli_real_escape_string($conn,$_POST['upd-cg']);
    logAction(54,$u[0],"to $new");
    mysqli_query($conn,"UPDATE `USERS` SET `CAN_GIFT` = '$new' WHERE `ID` = '$u[0]'");
    echo("<script>alert('CAN_GIFT has been changed');window.location='/Admin/manage.php?id=$id'</script>");
  }
}

if(isset($_POST['upd-vip'])){
    $new = mysqli_real_escape_string($conn,$_POST['upd-vip']);
    mysqli_query($conn,"UPDATE `USERS` SET `VIP` = '$new' WHERE `ID` = '$u[0]'");
    echo("<script>alert('VIP has been changed');window.location='/Admin/manage.php?id=$id'</script>");
}

if(isset($_POST['upd-fb'])){
    $new = mysqli_real_escape_string($conn,$_POST['upd-fb']);
    mysqli_query($conn,"UPDATE `USERS` SET `ISBANNED_FORUMS` = '$new' WHERE `ID` = '$u[0]'");
    echo("<script>alert('Forum Ban has been changed');window.location='/Admin/manage.php?id=$id'</script>");
}

if(isset($_POST['em'])){
  $msg = mysqli_real_escape_string($conn,$_POST['em']);
  $ttl = mysqli_real_escape_string($conn,$_POST['emT']);
  if(strpos($u["EMAIL"], "@")!==false){
    //mail
    mail($u["EMAIL"],$ttl,$msg);
    echo("<script>alert('Sent email.');window.location='/Admin/manage.php?id=$id'</script>");
  }else{
    echo("<script>alert('User has invalid email');window.location='/Admin/manage.php?id=$id'</script>");
  }
}

if(isset($_POST['upd-p'])){
  if($account['RANK']!='OWNER'){
    exit();
  }else{
    $new = mysqli_real_escape_string($conn,$_POST['upd-p']);
    $pass = hashPW($new);
    mysqli_query($conn,"UPDATE `USERS` SET `PASSWORD` = '$pass' WHERE `ID` = '$u[0]'");
    echo("<script>alert('Password has been updated');window.location='/Admin/manage.php?id=$id'</script>");
    exit();
  }
}

if(isset($_POST['v-p'])){
  if($account['RANK']!='OWNER'){
    exit();
  }else{
    $new = mysqli_real_escape_string($conn,$_POST['v-p']);
    $pass = hashPW($new);
    #$u = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$u[0]'"));
    if($u['PASSWORD'] == $pass){
      echo("<script>alert('True ($new)');window.location='/Admin/manage.php?id=$id'</script>");
    }else{
      echo("<script>alert('false');window.location='/Admin/manage.php?id=$id'</script>");
    }
    exit();
  }
}


if(isset($_POST['badgeID'])){
  $badgeID = mysqli_real_escape_string($conn,$_POST['badgeID']);
  $a = mysqli_query($conn,"SELECT * FROM `USER_BADGES` WHERE `BADGE` = '$badgeID' AND `USER` = '$u[0]'");
  if(mysqli_num_rows($a)==0){
    $q = $conn->prepare("INSERT INTO `USER_BADGES` VALUES (NULL,?,?)");
    $q->bind_param("ii",$u[0],$badgeID);
    $q->execute();
  }else{
    $q = $conn->prepare("DELETE FROM `USER_BADGES` WHERE `USER` = ? AND `BADGE` = ?");
    $q->bind_param("ii",$u[0],$badgeID);
    $q->execute();
  }
  echo("<script>alert('Success!');window.location='/Admin/manage.php?id=$id'</script>");
}

#### VARS ####

$t1 = date("H:i", $u['ENDS']);
$t2 = gmdate("j F Y", $u['ENDS']);

$t3 = date("H:i", $u['JOINED']);
$t4 = gmdate("j F Y", $u['JOINED']);

$t5 = date("H:i", $u['LAST_ONLINE']);
$t6 = gmdate("j F Y", $u['LAST_ONLINE']);

$t7 = date("H:i", $u['DAILY_COINS']);
$t8 = gmdate("j F Y", $u['DAILY_COINS']);

#### SCRIPTS ####

echo"

<script>

function page1() {
    document.getElementById('page1').style.display = 'block';
    document.getElementById('page2').style.display = 'none';
    document.getElementById('page3').style.display = 'none';
    document.getElementById('page4').style.display = 'none';
    document.getElementById('page5').style.display = 'none';
    document.getElementById('page6').style.display = 'none';
    document.getElementById('page7').style.display = 'none';
}

function page2() {
    document.getElementById('page1').style.display = 'none';
    document.getElementById('page2').style.display = 'block';
    document.getElementById('page3').style.display = 'none';
    document.getElementById('page4').style.display = 'none';
    document.getElementById('page5').style.display = 'none';
    document.getElementById('page6').style.display = 'none';
    document.getElementById('page7').style.display = 'none';
}

function page3() {
    document.getElementById('page1').style.display = 'none';
    document.getElementById('page2').style.display = 'none';
    document.getElementById('page3').style.display = 'block';
    document.getElementById('page4').style.display = 'none';
    document.getElementById('page5').style.display = 'none';
    document.getElementById('page6').style.display = 'none';
    document.getElementById('page7').style.display = 'none';
}

function page4() {
    document.getElementById('page1').style.display = 'none';
    document.getElementById('page2').style.display = 'none';
    document.getElementById('page3').style.display = 'none';
    document.getElementById('page4').style.display = 'block';
    document.getElementById('page5').style.display = 'none';
    document.getElementById('page6').style.display = 'none';
    document.getElementById('page7').style.display = 'none';
}

function page5() {
    document.getElementById('page1').style.display = 'none';
    document.getElementById('page2').style.display = 'none';
    document.getElementById('page3').style.display = 'none';
    document.getElementById('page4').style.display = 'none';
    document.getElementById('page5').style.display = 'block';
    document.getElementById('page6').style.display = 'none';
    document.getElementById('page7').style.display = 'none';
}

function page6() {
    document.getElementById('page1').style.display = 'none';
    document.getElementById('page2').style.display = 'none';
    document.getElementById('page3').style.display = 'none';
    document.getElementById('page4').style.display = 'none';
    document.getElementById('page5').style.display = 'none';
    document.getElementById('page6').style.display = 'block';
    document.getElementById('page7').style.display = 'none';
}

function page7() {
    document.getElementById('page1').style.display = 'none';
    document.getElementById('page2').style.display = 'none';
    document.getElementById('page3').style.display = 'none';
    document.getElementById('page4').style.display = 'none';
    document.getElementById('page5').style.display = 'none';
    document.getElementById('page6').style.display = 'none';
    document.getElementById('page7').style.display = 'block';
}

</script>

";

$ipq = mysqli_query($conn,"SELECT * FROM `COG` WHERE `USERID` = '$u[0]' LIMIT 1");
if(mysqli_num_rows($ipq) >= 1){

  $ip = mysqli_fetch_array($ipq);

  $c = $ip['CTY'];
  if(array_key_exists($c, $countries)){$cn = $countries[$c];}else{$cn = $c;}

  $infoTable = [
    
    ["ID",$u[0]],
    ["Username",$u['USERNAME']],
    ["Coins",$u['COINS']],
    ["Bucks" , $u['BUCKS']],
    ["Stars" , $u['STARS']],
    ["Ghost" , $u['GHOST']],
    ["Rank" , $u['RANK']],
    ["VIP" , $u['VIP']],
    ["Status" , $u['STATUS']],
    ["Forum Posts" , $u['FORUM_POSTS']],
    ["Networth" , $u['NETWORTH']],
    ["Email" , $u['EMAIL']],
    ["IP" , $ip['IP']],
    ["Location" , "$cn ($c)"]
    
    ];

}else{
  $infoTable = [
    
    ["ID",$u[0]],
    ["Username",$u['USERNAME']],
    ["Coins",$u['COINS']],
    ["Bucks" , $u['BUCKS']],
    ["Stars" , $u['STARS']],
    ["Ghost" , $u['GHOST']],
    ["Rank" , $u['RANK']],
    ["VIP" , $u['VIP']],
    ["Status" , $u['STATUS']],
    ["Forum Posts" , $u['FORUM_POSTS']],
    ["Networth" , $u['NETWORTH']],
    ["Email" , $u['EMAIL']],
    ["Logged in", "<span color='red'>FALSE</span>"]
    
    ];
}
  

#PAGES

# ID    # PAGE NAME
#####################
# 1     # General
# 2     # Moderation
# 3     # Badges
# 4     # Economy
# 5     # Items
# 6     # Posts
# 7     # Owner Only

echo"

<title>Manage $id</title>

<div class='doublebox box1'>

	<div class='platformtitle'>
      <p>$id</p>
    </div>
    
    <br>
    
    <button class='button btn-blue nd hover' onclick='page1()'>General</button>
    <button class='button btn-blue nd hover' onclick='page2()'>Moderation</button>
    <button class='button btn-blue nd hover' onclick='page3()'>Badges</button>
    <button class='button btn-blue nd hover' onclick='page4()'>Economy</button>
    <button class='button btn-blue nd hover' onclick='page5()'>Items</button>
    <button class='button btn-blue nd hover' onclick='page6()'>Forum</button>
    <button class='button btn-blue nd hover' onclick='page7()'>Owner Options</button>
    <a class='button btn-green nd hover' href='/Profile/$id'>Go to profile</a>
    <a class='button btn-green nd hover' href='/Admin/'>Back</a>
    
    <br><hr><br>
    
    Rank: $u[RANK]<br>
    Status: $u[STATUS]<br>
    Forum Ban: $u[ISBANNED_FORUMS]<br><br>
    
    Joined: $t3 $t4<br>
    Last online: $t5 $t6<br>
    Daily coins: $t7 $t8<br>
    
    <br>
    
    VIP: $u[VIP]<br>
    VIP Ends: $t1 $t2<br>

</div>

<div class='doublebox box2'>

	<div id='page1' style='display:none;'>
    	
        <div class='platformtitle'>
        	<p>General</p>
        </div><br>
        
        Name <form method='post'><input class='form form1l' minlength='1' maxlength='20' name='upd-u' placeholder='$u[1]' required></form>
        
        Bio <form method='post'><textarea class='form form1l' minlength='5' maxlength='200' name='upd-b' required>$u[BIO]</textarea><button class='button3 hover'>Submit</button></form>
        
        <table>
        ";

foreach($infoTable as $i){
  echo"<tr><th>$i[0]</th><td>$i[1]</td></tr>";
}

echo"

	</table>
        
    </div>

	<div id='page2' style='display:none;'>
    	
        <div class='platformtitle'>
        	<p>Moderation</p>
        </div><br>
        
        <a href='/Admin/?BAN=$u[1]' class='button2 btn-red'>Ban user <span class='fas fa-external-link-alt'></span></a><br><br>
        
        FORUM BAN ($u[ISBANNED_FORUMS]) <form method='post'><select name='upd-fb' required class='form form1l'><option>TRUE</option><option>FALSE</option></select><button class='button3 hover'>Submit</button></form>
        
        <br><br>
        
        <h3>User's Alts:</h3>
        
        ";
		
		foreach($ipAlts as $i){
          echo("<a href='/Profile/$i[1]'>$i[1]</a> (Same IP) <a href='/Admin/manage.php?id=$i[1]' class='fa fa-cog nd'></a><br>");
        }
		
		foreach($passAlts as $i){
          echo("<a href='/Profile/$i[1]'>$i[1]</a> (Same Password) <a href='/Admin/manage.php?id=$i[1]' class='fa fa-cog nd'></a><br>");
        }

      if(count($ipAlts) == 0 && count($passAlts) == 0){
        echo("No alts have been found.");
      }

echo"
        
    </div>

	<div id='page3' style='display:none;'>
    	
        <div class='platformtitle'>
        	<p>Badges</p>
        </div><br>
        
        ";

		$badges = mysqli_query($conn,"SELECT * FROM `USER_BADGES` WHERE `USER` = '$u[0]'");
		if(mysqli_num_rows($badges)>0){while(($ub = mysqli_fetch_array($badges))){
          $b = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `BADGES` WHERE `ID` = '$ub[BADGE]'"));
          echo"<a href='/Badges/?id=$b[0]' class='nd dib'>
                <div class='forum-av'>
        			<img src='$b[IMAGE]'><br>
        			<p>$b[1]</p><br><br>
            	</div>
            </a>";
        }}
		
		$testfore = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM `USER_BADGES` WHERE `USER` = '$u[0]' AND `BADGE` = '4'"));
		if($testfore == 0){
          echo"<br>E-ward<br><br><form method='post'><button class='button3 btn-gold nd hover' name='grantTheEward'>Grant the E-ward</button></form><br>Only give to the best of users ;)";
        }else{
          echo"<br>This user has already been E-warded!";
        }

echo"

	<form method='post'>
    	<input class='form form2l' name='badgeID' type='number' placeholder='Badge ID'>
        <button class='button3 btn-blue nd hover'>Grant/Revoke</button>
    </form>
        
    </div>

	<div id='page4' style='display:none;'>
    	
        <div class='platformtitle'>
        	<p>Economy</p>
        </div><br>
        
         Bucks ($u[BUCKS]) <form method='post'><input class='form form1l' type='number' min='0' name='upd-bucks' value='$u[BUCKS]' required></form>
         
         Coins ($u[COINS]) <form method='post'><input class='form form1l' type='number' min='0' name='upd-coins' value='$u[COINS]' required></form>
         
         <br>
         
         VIP ($u[VIP]) <form method='post'><select name='upd-vip' required class='form form1l'><option>NONE</option><option>VIP</option><option>MEGA</option></select><button class='button3 hover'>Submit</button></form>

		 <form method='post'><button class='button3 hover' name='reset-vip'>Reset VIP Timer (Infinite VIP)</button></form>
         
         <span title='do **d to add days, **h to add hours or do r**d/r**h to set it to ** days/hours from now (timer reset to now and added)'>Add VIP Time (Hover)</span>
         <form method='post'><input class='form form1l' name='upd-vip-time' placeholder='**h/**d' required></form>

    </div>

	<div id='page5' style='display:none;'>
    	
        <div class='platformtitle'>
        	<p>Items / Inventory</p>
        </div><br>
        
        Grant an Item <form method='post'><input class='form form1l' type='number' name='GRANT' placeholder='Item ID' required><button class='button3 hover'>Grant!</button></form>
        
        <h3>Created Items</h3>
        
        ";

$itemsQ = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `UPLOADER` = '$u[0]'");
if(mysqli_num_rows($itemsQ)==0){
  echo"<p>This user hasnt made any items yet</p>";
}else{
  echo"<table>
  
    <tr>
      <th>ID</th>
      <th>Name</th>
      <th>Price</th>
      <th>Type</th>
      <th>Rarity</th>
      <th>Stock</th>
      <th>Status</th>
    </tr>
  
  ";
  while(($it = mysqli_fetch_array($itemsQ))){
    echo"<tr>
  	<td>$it[0]</td>
  	<td><a href='/Market/Item/$it[0]'>$it[NAME]</a></td>
  	<td>$it[PRICE] $it[PRICE_TYPE]</td>
  	<td>$it[TYPE]</td>
  	<td>$it[RARITY]</td>
  	<td>$it[STOCK_REMAINING] / $it[STOCK]</td>
  	<td>$it[STATUS]</td>
  </tr>";
  }
  echo"</table>";
}

echo"
        
    </div>

	<div id='page6' style='display:none;'>
    	
        <div class='platformtitle'>
        	<p>Forum Posts</p>
        </div><br>
        
        <h3>User's Forum Posts:</h3>
        
        ";
		
		foreach($forumPosts as $f){
          $ttl = lgt($f[1]);
          echo("<a class='nd' href='/Forums/post.php?id=$f[0]'>$ttl</a><br>");
        }

echo"
        
        <h3>User's Forum Replies:</h3>
        
        ";
		
		foreach($forumReplies as $f){
          if($f['STATUS']=='CENSORED'||$f['STATUS']=='MODERATED'){
            $i = "<i class='fa fa-hammer txtcol-red'></i>";
          }elseif($f['STATUS']=='DELETED'){
            $i = "<i class='fa fa-times txtcol-red'></i>";
          }else{
            $i = '';
          }
            $ttl = lgt($f[1]);
          echo("<a class='nd' href='/Forums/post.php?id=$f[POST]'>\"$ttl\" on forum post id $f[POST]</a> $i<br>");
        }

echo"
        
    </div>

	<div id='page7' style='display:none;'>
    	
        <div class='platformtitle'>
        	<p>Owner Options</p>
        </div><br>
        
        ";

		if($account['RANK']!='OWNER'){
          echo"You cannot see this page. nice try.";
        }else{
          echo"
          
          
          Password <form method='post'><input class='form form1l' minlength='1' name='upd-p' placeholder='Enter new password' required></form>
          
          <form method='post'>
          	User Rank: $u[RANK]<br>
            <select name='upd-rank' class='form form1l'>
              <option>MEMBER</option>
              <option>ASSET_UPLOADER</option>
              <option>MODERATOR</option>
              <option>ADMIN</option>
              <option>EXECUTIVE</option>
            </select>
            <button class='button3 hover'>Update!</button>
            
          </form>
          
          <form method='post'>
          	User Status: $u[STATUS]<br>
            <select name='upd-status' class='form form1l'>
              <option>DEFAULT</option>
              <option>BANNED</option>
              <option>DISABLED</option>
            </select>
            <button class='button3 hover'>Update!</button>
            
          </form>
          
          <form method='post'>
          	CAN_GIFT: $u[CAN_GIFT]<br>
            <select name='upd-cg' class='form form1l'>
              <option>TRUE</option>
              <option>FALSE</option>
            </select>
            <button class='button3 hover'>Update!</button>
            
          </form>
          
          Verify Password <form method='post'><input class='form form1l' minlength='1' name='v-p' placeholder='Enter password' required></form>
          
          <form method='post'>
          
            Email ($u[EMAIL])
            <input name='emT' placeholder='Subject'>
            <textarea name='em' plceholder='Message'></textarea>
            <button class='button3 hover'>Send Email!</button>
          
          </form>
          
          ";
        }

echo"
        
    </div>

</div>

";



?>