<?php
include("../Misc/connect.php");
include("../Admin/FUNCT.php");

if($account['RANK']=='OWNER'){$r=6;}
else{exit();}

#    LOG TABLE

# ID    # ACTION                 # DET
       
# 0     # Hack                   #
# 1     # Notice Bar Change      #
# 2     # Grant                  # <AMM> <TYPE>    # <USER2>
# 3     # Upload Item            # <IID>
# 4     # Item Accepted          # <IID>
# 5     # Item Declined          # <IID>
# 6     # User Banned            # [User: <USER>] <REASON>

# 99    # Gift Created           # <GIFT ID>

$num1 = $account['UUID'];

echo"

<h2>Logs</h2>
            
";

$LOGS = mysqli_query($conn,"SELECT * FROM `NEWLOGS` WHERE 1 ORDER BY `ID` DESC LIMIT 100");

while(($i=mysqli_fetch_array($LOGS))){
  $ltime = gmdate("j F Y", $i['TIME'] + 18000) . ' @ ' . date("H:i", $i['TIME'] + 18000);
  /*$user = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$i[USER]'"));
  if($i['ACTION']==0){
    $action = 'HACK';
    $res = "$user[1] HACK ($ltime)";
  }elseif($i['ACTION']==1){
    $action = 'Changed Notice Bar';
    $res = "$user[1] Changed Notice Bar ($ltime)";
  }elseif($i['ACTION']==2){
    $action = 'Granted';
    $user2 = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$i[USER2]'"));
    $res = "$user[1] Granted $i[DET] to $user2[1] ($ltime)";
  }elseif($i['ACTION']==3){
    $action = 'Uploaded';
    $res = "$user[1] Uploaded $i[DET] ($ltime)";
  }elseif($i['ACTION']==4){
    $action = 'Accepted';
    $res = "$user[1] Accepted $i[DET] ($ltime)";
  }elseif($i['ACTION']==5){
    $action = 'Declined';
    $res = "$user[1] Declined $i[DET] ($ltime)";
  }elseif($i['ACTION']==6){
    $action = 'Banned';
    $user2 = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$i[USER2]'"));
    $res = "$user[1] Banned $user2[1] for: $i[DET] ($ltime)";
  }elseif($i['ACTION']==99){
    $action = 'Created a gift';
    $res = "$user[1] Created the gift $i[DET] ($ltime)";
  }*/
  $action = formatAction($i['ACTION']);
  $res = formatText($i['ACTION'],$i['USER2'],$i['DET']);
  $user = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$i[USER]'"));
  
  echo"$user[1] $action | $res<br>";
}

?>