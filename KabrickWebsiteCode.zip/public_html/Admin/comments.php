<?php
include("../Misc/connect.php");
include("../Admin/FUNCT.php");

if($account['RANK']=='OWNER'){$r=6;}
else{exit();}

$num1 = $account['UUID'];

echo"

<h2>Recent Comments</h2>
            
<table>
  <tr>
  	<th>ID</th>
    <th>Item</th>
    <th>User</th>
    <th>Comment</th>
  </tr>
            
";

$LOGS = mysqli_query($conn,"SELECT * FROM `COMMENTS` WHERE 1 ORDER BY `ID` DESC LIMIT 100");

while(($i=mysqli_fetch_array($LOGS))){
  $u = mysqli_fetch_array(mysqli_query($conn,"SELECT `USERNAME` FROM `USERS` WHERE `ID` = '$i[USER]'"));
  $item = mysqli_fetch_array(mysqli_query($conn,"SELECT `TYPE`, `NAME` FROM `MARKET` WHERE `ID` = '$i[ITEM]'"));
  
  echo"
  <tr>
    <td>$i[ID]</td>
    <td><a href='/Market/Item/$i[ITEM]'>$item[NAME]</a> ($item[TYPE])</td>
    <td><a href='/Profile/$u[USERNAME]'>$u[USERNAME]</a></td>
    <td>$i[COMMENT]</td>
  </tr>";
}

echo"</table>";

?>