<?php
include_once($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');

if($account['RANK']=='OWNER'){$r=6;}
elseif($account['RANK']=='MANAGER'){$r=5;}
else{exit();}

$UUID = $account['UUID'];

$enabled = mysqli_query($conn,"SELECT * FROM `REG_CODES` WHERE `ENABLED` = 'YES'");
$disabled = mysqli_query($conn,"SELECT * FROM `REG_CODES` WHERE `ENABLED` = 'NO'");
$expired = mysqli_query($conn,"SELECT * FROM `REG_CODES` WHERE `ENABLED` = 'EXPIRED' AND `USED_BY` != '0'");

if(isset($_POST['create'])){
    $id = rand(10000,99999);
    $idQ = mysqli_query($conn,"SELECT * FROM `REG_CODES` WHERE `CODE` = '$id'");
    if(mysqli_num_rows($idQ)!=0){
        echo"<script>window.alert('Reg Code Creation Failed');window.location='/Admin/regcodes.php'</script>";exit();
    }else{
        mysqli_query($conn,"INSERT INTO `REG_CODES` VALUES(NULL,'ONE-TIME','$id','NO','0')");
        echo"<script>window.alert('Reg Code $id has been created.');window.location='/Admin/regcodes.php'</script>";exit();
    }
}elseif(isset($_POST['ues'])){
    $id = mysqli_real_escape_string($conn,$_POST['ues']);
    $rcQ = mysqli_query($conn,"SELECT * FROM `REG_CODES` WHERE `ID` = '$id'");
    $rc = mysqli_fetch_array($rcQ);
    if($rc['ENABLED']=='YES'){
        mysqli_query($conn,"UPDATE `REG_CODES` SET `ENABLED` = 'NO' WHERE `ID` = '$id'");
        echo"<script>window.alert('Reg Code Status Updated To Disabled! $id');window.location='/Admin/regcodes.php'</script>";exit();
    }elseif($rc['ENABLED']=='NO'){
        mysqli_query($conn,"UPDATE `REG_CODES` SET `ENABLED` = 'YES' WHERE `ID` = '$id'");
        echo"<script>window.alert('Reg Code Status Updated To Enabled!');window.location='/Admin/regcodes.php'</script>";exit();
    }else{
        echo"<script>window.location='/Admin/regcodes.php'</script>";
    }
}

#### SCRIPTS ####

echo"

<div class='platform'>
	<div class='platformtitle'><p><u><b>Regcodes</b></u></p></div>
    
    <br><br>
    
    <a class='button2 btn-blue nd' href='/Admin/'>Retourner</a><form method='post'><button class='button2 btn-blue nd' name='create'>Create Regcode <span class='fas fa-plus'></span></button></form>
    
    <br><br>
    
    <table>
    
    <tr>
    	<th>ID</th>
        <th>Code</th>
        <th>Type</th>
        <th>Used By</th>
        <th>Update Enabled Status</th>
    </tr>
    
    <tr>
    	<th colspan='5'>Enabled / Not used</th>
    </tr>
    
    ";

	while(($i = mysqli_fetch_array($enabled))){
      echo"
      
      <tr>
      	<td>$i[0]</td>
        <td>$i[CODE]</td>
        <td colspan='2'>$i[TYPE]</td>
        <td><form method='post'><button name='ues' value='$i[0]' class='button btn-red'>Disable</button></form></td>
      </tr>
      
      ";
    }

echo"
    
    <tr>
    	<th colspan='5'>Disabled</th>
    </tr>
    
    ";

	while(($i = mysqli_fetch_array($disabled))){
      echo"
      
      <tr>
      	<td>$i[0]</td>
        <td>$i[CODE]</td>
        <td colspan='2'>$i[TYPE]</td>
        <td><form method='post'><button name='ues' value='$i[0]' class='button btn-green'>Enable</button></form></td>
      </tr>
      
      ";
    }

echo"
    
    <tr>
    	<th colspan='5'>Expired</th>
    </tr>
    
    ";

	while(($i = mysqli_fetch_array($expired))){
      echo"
      
      <tr>
      	<td>$i[0]</td>
        <td>$i[CODE]</td>
        <td>$i[TYPE]</td>
        <td colspan='2'><a href='/Profile/$i[USED_BY]'>$i[USED_BY]</a></td>
      </tr>
      
      ";
    }

echo"
    
    </table>
    
</div>

</div>

";



?>