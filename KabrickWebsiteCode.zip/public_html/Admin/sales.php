<?php
include("../Misc/connect.php");
include("../Admin/FUNCT.php");

if($account['RANK']=='OWNER'){$r=6;}
elseif($account['RANK']=='MANAGER'){$r=5;}
elseif($account['RANK']=='EXECUTIVE'){$r=4;}
else{exit();}

$num1 = $account['UUID'];

echo"

<h2>Sales</h2>
            
<table>
  <tr>
  	<th>INVID</th>
    <th>Item</th>
    <th>User</th>
    <th>Item Price</th>
    <th>Item Rarity</th>
    <th>Serial</th>
  </tr>
            
";

$LOGS = mysqli_query($conn,"SELECT MARKET.*, USERS.USERNAME, INV.SERIAL, INV.ID AS `INVID` FROM INV
INNER JOIN MARKET ON MARKET.ID = INV.ITEM
INNER JOIN USERS ON USERS.ID = INV.USER
WHERE 1 ORDER BY INV.ID DESC LIMIT 100;");

while(($i=mysqli_fetch_array($LOGS))){
  if($i['RARITY']=='EPIC'){$txtc = 'txtcol-gold';}
  elseif($i['RARITY']=='RARE'){$txtc = 'txtcol-purple';}
  elseif($i['RARITY']=='EVENT'){$txtc = 'txtcol-green';}
  elseif($i['RARITY']=='CUSTOM'){$txtc = 'txtcol-blue';}
  elseif($i['RARITY']=='VIP'){$txtc = 'txtcol-red';}
  else{$txtc = 'txtcol-white';}
  
  echo"
  <tr>
    <td><a href='/Admin/Trace/?id=$i[INVID]'>$i[INVID]</a></td>
    <td><a href='/Market/Item/$i[ID]'>$i[NAME]</a> ($i[TYPE])</td>
    <td><a href='/Profile/$i[USERNAME]'>$i[USERNAME]</a></td>
    <td>$i[PRICE] $i[PRICE_TYPE]</td>
    <td class='$txtc'>$i[RARITY]</td>
    <td>$i[SERIAL]</td>
  </tr>";
}

echo"</table>";

?>