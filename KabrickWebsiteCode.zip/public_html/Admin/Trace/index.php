<?php
include_once($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');

if(!isset($_COOKIE['KABRICK_U']) || !isset($_COOKIE['KABRICK_P'])){
    echo"<script>window.location='/'</script>";exit();
}

if($account['RANK']=='OWNER'){$r=6;}
elseif($account['RANK']=='MANAGER'){$r=5;}
elseif($account['RANK']=='EXECUTIVE'){$r=4;}
elseif($account['RANK']=='ADMIN'){$r=3;}
elseif($account['RANK']=='MODERATOR'){$r=2;}
else{echo"<script>window.location='/'</script>";exit();}

$UUID = $account['UUID'];

echo"<title>INVID Traceback | $meta_name</title>

<div class='platform'>

";

if(isset($_GET['id'])){
  
  $id = mysqli_real_escape_string($conn,$_GET['id']);
  $q = mysqli_query($conn,"SELECT * FROM `INV` WHERE `ID` = '$id'");
  if(mysqli_num_rows($q)==1){
    $invid = mysqli_fetch_array($q);
    
    echo"<div class='platformtitle'><p><u><b>Ownership history for INVID #$invid[0]</b></u></p></div><br>";
    
    $i = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$invid[ITEM]'"));
    
    $q2 = mysqli_query($conn,"SELECT * FROM `INVID` WHERE `INVID` = '$id' ORDER BY `ID` DESC");
    if(mysqli_num_rows($q2) > 0){
    	while(($a = mysqli_fetch_array($q2))){
          $old = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$a[OLD]'"));
          $new = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$a[NEW]'"));

          if($a['TYPE'] == 'TRADE'){
            echo"
            <div class='forumpost'>

                    <a href='/Market/Item/$i[0]'>$i[NAME]</a> was Traded From $old[USERNAME] to $new[USERNAME]<br><span class='small2'>TRADE ID $a[INT2]</span>

                </div><br>";
          }elseif($a['TYPE'] == 'SALE'){
            echo"
            <div class='forumpost'>

                    <a href='/Market/Item/$i[0]'>$i[NAME]</a> was Sold From $old[USERNAME] to $new[USERNAME]<br><span class='small2'>Sold for $a[INT2] Bucks</span>

                </div><br>";
          }elseif($a['TYPE'] == 'TRANSFER'){
            echo"
            <div class='forumpost'>

                    <a href='/Market/Item/$i[0]'>$i[NAME]</a> was Transferred From $old[USERNAME] to $new[USERNAME]<br><span class='small2'><br></span>

                </div><br>";
          }
              }
          }else{

                  $u = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$invid[USER]'"));
                  echo"<div class='forumpost'>

                    <a href='/Market/Item/$i[0]'>$i[NAME]</a> was Bought originally by $u[USERNAME]<br><span class='small2'>User has not traded or sold item.</span>

                </div><br>";
      
    }
    
  }
  
}else{
  
  echo"<div class='platformtitle'><p><u><b>Recent INVID Changes</b></u></p></div>";
  
  $q = mysqli_query($conn,"SELECT * FROM `INVID` ORDER BY `ID` DESC LIMIT 10");
  while(($a = mysqli_fetch_array($q))){
    $old = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$a[OLD]'"));
    $new = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$a[NEW]'"));
    $i = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$a[ITEM]'"));
    
    if($a['TYPE'] == 'TRADE'){
      echo"
      <div class='forumpost'>

              <a href='?id=$a[INVID]'>$i[NAME] was Traded From $old[USERNAME] to $new[USERNAME]<br><span class='small2'>TRADE ID $a[INT2]</span></a>

          </div><br>";
    }elseif($a['TYPE'] == 'SALE'){
      echo"
      <div class='forumpost'>

              <a href='?id=$a[INVID]'>$i[NAME] was Sold From $old[USERNAME] to $new[USERNAME]<br><span class='small2'>Sold for $a[INT2] Bucks</span></a>

          </div><br>";
  }elseif($a['TYPE'] == 'TRANSFER'){
            echo"
            <div class='forumpost'>

                    <a href='/Market/Item/$i[0]'>$i[NAME]</a> was Transferred From $old[USERNAME] to $new[USERNAME]<br><span class='small2'><br></span>

                </div><br>";
          }
  
}}