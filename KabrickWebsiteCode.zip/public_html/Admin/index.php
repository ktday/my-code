<?php

include_once($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');


include_once('FUNCT.php');

#    LOG TABLE

# ID    # ACTION
       
# 0     # Hack
# 1     # Notice Bar Change
# 2     # Grant
# 3     # Upload Item
# 4     # Item Accepted
# 5     # Item Declined


function leave() {
  echo"<script>window.location='/'</script>";exit();
}

function travel($site) {
  echo"<script>window.location='$site'</script>";exit();
}

function alert($site) {
  echo"<script>window.alert('$site')</script>";
}

if(!isset($_COOKIE['KABRICK_U']) || !isset($_COOKIE['KABRICK_P'])){
    leave();
}

if($account['RANK']=='OWNER'){$r=6;}
elseif($account['RANK']=='MANAGER'){$r=5;}
elseif($account['RANK']=='EXECUTIVE'){$r=4;}
elseif($account['RANK']=='ADMIN'){$r=3;}
elseif($account['RANK']=='MODERATOR'){$r=2;}
elseif($account['RANK']=='ASSET_MOD'){leave();}
elseif($account['RANK']=='FORUMS_MOD'){leave();}
elseif($account['RANK']=='ASSET_UPLOADER'){$r=1;}
else{leave();}

$UUID = $account['UUID'];

echo"<title>$meta_name Administration Panel</title>";

//log();
//exit();

/*
category               # Perms  # URL
###########################################
-staff info            #        # staff-info.php
-stats                 #        # stats.php
-site settings         # 3      # site-settings.php
-logs                  # 6      # logs.php
-user item verify      # 2      # None  [NOBTN]
-item verify           # 5      # admin-verify.php
-item upload           # 1      # upload-item.php
-user                  # 3/5    # None
-economy               # 5      # economy.php
-ban                   # 2/3    # ban.php
-owner                 # 6      # owner.php
*/

######################## SCRIPTS ########################

if(isset($_POST['notice_bar_'.$UUID.''])&&isset($_POST['notice_bar_color_'.$UUID])){                ############### NOTICE BAR UPDATE ###############
  if($r<3){
    //hack
    mysqli_query($conn,"UPDATE `USERS` SET `STATUS` = 'DISABLED' WHERE `ID` = '$account[0]'");
    logAction(0,0);
    echo"<script>window.location='/User/logout.php'</script>";
    exit();
  }else{
    //it be me :))
    $txt = mysqli_real_escape_string($conn,$_POST['notice_bar_'.$UUID]);
    $col = mysqli_real_escape_string($conn,$_POST['notice_bar_color_'.$UUID]);
    
    if(isset($_POST["notice_bar_url_$UUID"])){
      mysqli_query($conn,"UPDATE `CURRENT_ECONOMY` SET `NAV_URL` = '" . mysqli_real_escape_string($conn,$_POST['notice_bar_url_'.$UUID]) . "' WHERE `ID` = '1'");
    }

    mysqli_query($conn,"UPDATE `CURRENT_ECONOMY` SET `NAV_TEXT` = '$txt' WHERE `ID` = '1'");
    mysqli_query($conn,"UPDATE `CURRENT_ECONOMY` SET `NAV_COLOR` = '$col' WHERE `ID` = '1'");
    logAction(1,0,"[$col] $txt");
    travel('/Admin/');
  }
}

if(isset($_POST['grant_'.$UUID])&&isset($_POST['grant_type_'.$UUID])){              ############## GRANT ECONOMY ##################
  if($r<5){
    //hack
    mysqli_query($conn,"UPDATE `USERS` SET `STATUS` = 'DISABLED' WHERE `ID` = '$account[0]'");
    logAction(0,0);
    echo"<script>window.location='/User/logout.php'</script>";
    exit();
  }else{
    //it be me :))
    $amm = mysqli_real_escape_string($conn,$_POST['grant_'.$UUID]);
    $type = mysqli_real_escape_string($conn,$_POST['grant_type_'.$UUID]);
    
    if(isset($_POST['grant_name_'.$UUID])){
      $name = mysqli_real_escape_string($conn,$_POST['grant_name_'.$UUID]);
      if(strlen($name)!=0){
        $findUser = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `USERNAME` = '$name'"));
        if($findUser==1){
          $user = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `USERNAME` = '$name'"));
        }else{
          alert('User doesnt exist!');
          travel('/Admin/');
        }
      }else{
        $user = $account;
      }
    }else{
      $user = $account;
    }
    
    if($type=='Coins'){
      $t = 'COINS';
    }elseif($type=='Bucks'){
      $t = 'BUCKS';
    }
    if($type!='COINS' && $type!='BUCKS'){exit("inspect.");}
    
    if($amm>500){
      if($account[0]!=2){
        alert('Too much granted!');
        travel('/Admin/');
      }
    }
    
    $getCoins = $user[$type];
    $c = $amm + $getCoins;

    mysqli_query($conn,"UPDATE `USERS` SET `$type` = '$c' WHERE `ID` = '$user[0]'");
    logAction(2,$user[0],"$amm $type");
    travel('/Admin/');
  }
}

if(isset($_POST['givecurr']) && isset($_POST['gct'])){                               ############### DEPOSIT ECONOMY ##################
  if($r<6){
    //hack
    mysqli_query($conn,"UPDATE `USERS` SET `STATUS` = 'DISABLED' WHERE `ID` = '$account[0]'");
    logAction(0,0);
    echo"<script>window.location='/User/logout.php'</script>";
    exit();
  }else{
    $amm = mysqli_real_escape_string($conn,$_POST['givecurr']);
    $type = mysqli_real_escape_string($conn,$_POST['gct']);
    if($type!='COINS' && $type!='BUCKS'){exit("inspect.");}
    if($account[$type] >= intval($amm)){
      $t = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '1'"));
      $yb = $account[$type] - intval($amm);
      $tb = $t[$type] + intval($amm);
      mysqli_query($conn,"UPDATE `USERS` SET `$type` = '$yb' WHERE `ID` = '$account[0]'");
      mysqli_query($conn,"UPDATE `USERS` SET `$type` = '$tb' WHERE `ID` = '1'");
        alert('Yes');
        travel('/Admin/');
    }else{
      exit("nah");
    }
  }
}

                                                                                     ################ ITEM UPLOADING ##################
if(isset($_POST['upl_name_'.$UUID])){
  if($r<1){
    //hack
    mysqli_query($conn,"UPDATE `USERS` SET `STATUS` = 'DISABLED' WHERE `ID` = '$account[0]'");
    logAction(0,0);
    echo"<script>window.location='/User/logout.php'</script>";
    exit();
  }else{
    $name = mysqli_real_escape_string($conn,$_POST['upl_name_'.$UUID]);
    
    if(!preg_match_all("/^[^<>]*$/",$name)){echo"<script>window.alert('Invalid characters in name');window.location='/Admin/'</script>";exit();}
    
    $desc = mysqli_real_escape_string($conn,$_POST['upl_desc_'.$UUID]);
    $price = mysqli_real_escape_string($conn,$_POST['upl_price_'.$UUID]);
    $pt = mysqli_real_escape_string($conn,$_POST['upl_pt_'.$UUID]);
    $type = mysqli_real_escape_string($conn,$_POST['upl_type_'.$UUID]);
    $img = $_FILES['upl_img_'.$UUID];
    $stock = mysqli_real_escape_string($conn,$_POST['upl_stock_'.$UUID]);
    $rarity = mysqli_real_escape_string($conn,$_POST['upl_rarity_'.$UUID]);
    $onst = mysqli_real_escape_string($conn,$_POST['upl_onst_'.$UUID]);
    
    if($pt=="select"){echo"<script>window.alert('Invalid price type')</script>";echo"<script>window.location='/Admin/'</script>";exit();}
    if($type=="select"){echo"<script>window.alert('Invalid item type')</script>";echo"<script>window.location='/Admin/'</script>";exit();}
    if($rarity=="select"){echo"<script>window.alert('Invalid rarity')</script>";echo"<script>window.location='/Admin/'</script>";exit();}
    
    if(isset($img)){
      if ($img["error"] > 0){
        echo "<script>window.alert('Error: " . $img["error"] . "')</script>";echo"<script>window.location='/Admin/'</script>";exit();
      }else{
        $info = getimagesize($img['tmp_name']);
        if($info === FALSE){echo"<script>window.alert('info false');window.location='/Admin/'</script>";exit();}
        if (($info[2] !== IMAGETYPE_PNG)) {
          echo"<script>window.alert('Not A Valid Image file!')</script>";
          echo"<script>window.location='/Admin/'</script>";exit();
        }
        $ammOfItemQ = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE 1");
        $ammOfItem = mysqli_num_rows($ammOfItemQ) + 1;
        $img_dir_pre = "/home/lord7302/domains/$meta_blank_url/public_html";
        $img_dir_suf = "/Misc/IMGS/SHOP/A/$ammOfItem.png";
        $image_dir = $img_dir_pre.$img_dir_suf;
        move_uploaded_file($img['tmp_name'], $image_dir);
        $image_av = $img_dir_suf;

        if($rarity!="EPIC"&&$stock!=0){$stock==0;}
        if($rarity=="EPIC"){if($stock==0){$stock=1;} $st = $stock - 1;}else{$st = 0;}

        if($type == "BACK"){
          $palette_img = imagecreatefrompng($image_av);
          $av_img = imagecreatefrompng($img_dir_pre.$img_dir_suf);
          imagesavealpha($palette_img, true);
          imagecopy($palette_img,$img_dir_pre."/Misc/IMGS/avatar.png",0,0,0,0,121,181);
        }elseif($type == 'BODY'){
          $palette_img = imagecreatefrompng($img_dir_pre.$image_av);
          imagesavealpha($palette_img, true);
        }else{
          $palette_img = imagecreatefrompng($img_dir_pre."/Misc/IMGS/avatar.png");
          $av_img = imagecreatefrompng($img_dir_pre.$img_dir_suf);
          imagesavealpha($palette_img, true);
          imagecopy($palette_img,$av_img,0,0,0,0,121,181);
        }

        imagepng($palette_img,$img_dir_pre."/Misc/IMGS/SHOP/P/".$ammOfItem.".png");
        $image_pre = "/Misc/IMGS/SHOP/P/".$ammOfItem.".png";

        $time = time();
        
        if($onst!=0){
          $onsaleTime = intval($onst) * 3600;
        }else{
          $onsaleTime = 0;
        }

        #mysqli_query($conn,"INSERT INTO `MARKET` VALUES(NULL,'$name','$desc','$price','$pt','$type','$stock','$st','$onsaleTime','$rarity','0','$account[0]','$time','$time','$image_pre','$image_av','UAP')");
        mysqli_query($conn,"INSERT INTO `INV` VALUES(NULL,'$ammOfItem','$account[0]','$pt','1')");
        $q = $conn->prepare("INSERT INTO `MARKET` VALUES(NULL,?,?,?,?,?,?,?,?,?,'0',?,?,?,?,?,'UAP')");
        $q->bind_param("ssissiiisiiiss", $name, $desc, $price, $pt, $type, $stock, $st, $onsaleTime, $rarity, $account[0], $time, $time, $image_pre, $image_av);
        $q->execute();
        logAction(3,0,"[$ammOfItem] $name");
        echo"<script>window.alert('Item Uploaded! Awaiting approval');window.location='/Market/item.php?id=$ammOfItem'</script>";exit();
      }
    }else{echo"<script>window.alert('No images selected');window.location='/Admin/'</script>";exit();}
  }
}

if(isset($_POST['a_'.$UUID])){              ############## ACCEPT (ADMIN) ITEM ##################
  if($r<2){
    //hack
    mysqli_query($conn,"UPDATE `USERS` SET `STATUS` = 'DISABLED' WHERE `ID` = '$account[0]'");
    logAction(0,0);
    echo"<script>window.location='/User/logout.php'</script>";
    exit();
  }else{
    $itemID = mysqli_real_escape_string($conn,$_POST['a_'.$UUID]);
    $item = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$itemID'"));
    if($item['STATUS']!='UAP'){
      echo"<script>window.alert('Item has already been accepted/declined');window.location='/Admin/'</script>";exit();
    }
    $time = time();
    mysqli_query($conn,"UPDATE `MARKET` SET `STATUS` = 'AP' WHERE `ID` = '$itemID'");
    mysqli_query($conn,"UPDATE `MARKET` SET `TIME` = '$time' WHERE `ID` = '$itemID'");
    mysqli_query($conn,"UPDATE `MARKET` SET `UPDATE_TIME` = '$time' WHERE `ID` = '$itemID'");
    if($item['ONSALE_TIME']!=0){
      $ot = time() + $item['ONSALE_TIME'];
      mysqli_query($conn,"UPDATE `MARKET` SET `ONSALE_TIME` = '$ot' WHERE `ID` = '$itemID'");
    }
    #message
    mysqli_query($conn,"INSERT INTO `MESSAGES` VALUES(NULL,'1','$item[UPLOADER]','$account[1] has accepted your item, \"$item[1]\"','NO','0','$time','Item Accepted!','0')");
    logAction(4,0,$itemID);
    iNotif($itemID);
    echo"<script>window.location='/Market/item.php?id=$itemID'</script>";exit();
  }
}

if(isset($_POST['asa_'.$UUID])){              ############## ACCEPT (ADMIN) ITEM WITHOUT PING ##################
  if($r<2){
    //hack
    mysqli_query($conn,"UPDATE `USERS` SET `STATUS` = 'DISABLED' WHERE `ID` = '$account[0]'");
    logAction(0,0);
    echo"<script>window.location='/User/logout.php'</script>";
    exit();
  }else{
    $itemID = mysqli_real_escape_string($conn,$_POST['asa_'.$UUID]);
    $item = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$itemID'"));
    if($item['STATUS']!='UAP'){
      echo"<script>window.alert('Item has already been accepted/declined');window.location='/Admin/'</script>";exit();
    }
    $time = time();
    mysqli_query($conn,"UPDATE `MARKET` SET `STATUS` = 'AP' WHERE `ID` = '$itemID'");
    mysqli_query($conn,"UPDATE `MARKET` SET `TIME` = '$time' WHERE `ID` = '$itemID'");
    mysqli_query($conn,"UPDATE `MARKET` SET `UPDATE_TIME` = '$time' WHERE `ID` = '$itemID'");
    if($item['ONSALE_TIME']!=0){
      $ot = time() + $item['ONSALE_TIME'];
      mysqli_query($conn,"UPDATE `MARKET` SET `ONSALE_TIME` = '$ot' WHERE `ID` = '$itemID'");
    }
    #message
    mysqli_query($conn,"INSERT INTO `MESSAGES` VALUES(NULL,'1','$item[UPLOADER]','$account[1] has accepted your item, \"$item[1]\"','NO','0','$time','Item Accepted!','0')");
    logAction(4,0,$itemID);
    #iNotif($itemID);
    echo"<script>window.location='/Market/item.php?id=$itemID'</script>";exit();
  }
}

if(isset($_POST['d_'.$UUID])){              ############## DECLINE (ADMIN) ITEM ##################
  if($r<2){
    //hack
    mysqli_query($conn,"UPDATE `USERS` SET `STATUS` = 'DISABLED' WHERE `ID` = '$account[0]'");
    logAction(0,0);
    echo"<script>window.location='/User/logout.php'</script>";
    exit();
  }else{
    $itemID = mysqli_real_escape_string($conn,$_POST['d_'.$UUID]);
    $item = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$itemID'"));
    if($item['STATUS']!='UAP'){
      echo"<script>window.alert('Item has already been accepted/declined');window.location='/Admin/'</script>";exit();
    }
    $time = time();
    mysqli_query($conn,"UPDATE `MARKET` SET `STATUS` = 'BAN' WHERE `ID` = '$itemID'");
    mysqli_query($conn,"UPDATE `MARKET` SET `UPDATE_TIME` = '$time' WHERE `ID` = '$itemID'");
    #message
    mysqli_query($conn,"INSERT INTO `MESSAGES` VALUES(NULL,'1','$item[UPLOADER]','$account[1] has declined your item, \"$item[1]\"','NO','0','$time','Item Declined!','0')");
    logAction(5,0,$itemID);
    echo"<script>window.location='/Market/item.php?id=$itemID'</script>";exit();
  }
}

if(isset($_POST['aui_'.$UUID])){              ############## ACCEPT (USER) ITEM ##################
  if($r<2){
    //hack
    mysqli_query($conn,"UPDATE `USERS` SET `STATUS` = 'DISABLED' WHERE `ID` = '$account[0]'");
    logAction(0,0);
    echo"<script>window.location='/User/logout.php'</script>";
    exit();
  }else{
    $itemID = mysqli_real_escape_string($conn,$_POST['aui_'.$UUID]);
    $item = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$itemID'"));
    if($item['STATUS']!='UAP'){
      echo"<script>window.alert('Item has already been accepted/declined');window.location='/Admin/'</script>";exit();
    }
    if($item['TYPE']!='PANTS'&&$item['TYPE']!='SHIRT'){echo"<script>window.alert('Invalid item type');window.location='/Admin/'</script>";exit();}
    $time = time();
    mysqli_query($conn,"UPDATE `MARKET` SET `STATUS` = 'AP' WHERE `ID` = '$itemID'");
    mysqli_query($conn,"UPDATE `MARKET` SET `TIME` = '$time' WHERE `ID` = '$itemID'");
    mysqli_query($conn,"UPDATE `MARKET` SET `UPDATE_TIME` = '$time' WHERE `ID` = '$itemID'");
    #message
    mysqli_query($conn,"INSERT INTO `MESSAGES` VALUES(NULL,'1','$item[UPLOADER]','$account[1] has accepted your item, \"$item[1]\"','NO','0','$time','Item Accepted!','0')");
    logAction(7,0,$itemID);
    #iNotif($itemID);
    #egg hunt 2024
    update($item["UPLOADER"], "Upload");
    echo"<script>window.location='/Market/item.php?id=$itemID'</script>";exit();
  }
}

if(isset($_POST['dui_'.$UUID])){              ############## DECLINE (USER) ITEM ##################
  if($r<2){
    //hack
    mysqli_query($conn,"UPDATE `USERS` SET `STATUS` = 'DISABLED' WHERE `ID` = '$account[0]'");
    logAction(0,0);
    echo"<script>window.location='/User/logout.php'</script>";
    exit();
  }else{
    $itemID = mysqli_real_escape_string($conn,$_POST['dui_'.$UUID]);
    $item = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$itemID'"));
    if($item['STATUS']!='UAP'){
      echo"<script>window.alert('Item has already been accepted/declined');window.location='/Admin/'</script>";exit();
    }
    if($item['TYPE']!='PANTS'&&$item['TYPE']!='SHIRT'){echo"<script>window.alert('Invalid item type');window.location='/Admin/'</script>";exit();}
    $time = time();
    mysqli_query($conn,"UPDATE `MARKET` SET `STATUS` = 'BAN' WHERE `ID` = '$itemID'");
    mysqli_query($conn,"UPDATE `MARKET` SET `UPDATE_TIME` = '$time' WHERE `ID` = '$itemID'");
    #message
    mysqli_query($conn,"INSERT INTO `MESSAGES` VALUES(NULL,'1','$item[UPLOADER]','$account[1] has declined your item, \"$item[1]\"','NO','0','$time','Item Declined!','0')");
    logAction(8,0,$itemID);
    echo"<script>window.location='/Market/item.php?id=$itemID'</script>";exit();
  }
}

if(isset($_POST['ac_'.$UUID])){              ############## ACCEPT CLAN ##################
  if($r<2){
    //hack
    mysqli_query($conn,"UPDATE `USERS` SET `STATUS` = 'DISABLED' WHERE `ID` = '$account[0]'");
    logAction(0,0);
    echo"<script>window.location='/User/logout.php'</script>";
    exit();
  }else{
    $itemID = mysqli_real_escape_string($conn,$_POST['ac_'.$UUID]);
    $item = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `CLANS` WHERE `ID` = '$itemID'"));
    if($item['STATUS']!='UNVERIFIED'){
      echo"<script>window.alert('Clan has already been accepted/declined');window.location='/Admin/'</script>";exit();
    }
    mysqli_query($conn,"UPDATE `CLANS` SET `STATUS` = 'OK' WHERE `ID` = '$itemID'");
    #message
    mysqli_query($conn,"INSERT INTO `MESSAGES` VALUES(NULL,'1','$item[OWNER]','$account[1] has accepted your clan, \"$item[1]\": members can now join this clan!','NO','0','$time','Clan Accepted!','0')");
    logAction(9,0,"Clan ID: $itemID, Name: $item[NAME]");
    echo"<script>window.location='/Clan/$itemID'</script>";exit();
  }
}

if(isset($_POST['dc_'.$UUID])){              ############## DECLINE CLAN ##################
  if($r<2){
    //hack
    mysqli_query($conn,"UPDATE `USERS` SET `STATUS` = 'DISABLED' WHERE `ID` = '$account[0]'");
    logAction(0,0);
    echo"<script>window.location='/User/logout.php'</script>";
    exit();
  }else{
    $itemID = mysqli_real_escape_string($conn,$_POST['dc_'.$UUID]);
    $item = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `CLANS` WHERE `ID` = '$itemID'"));
    if($item['STATUS']!='UNVERIFIED'){
      echo"<script>window.alert('Clan has already been accepted/declined');window.location='/Admin/'</script>";exit();
    }
    mysqli_query($conn,"UPDATE `CLANS` SET `STATUS` = 'BANNED' WHERE `ID` = '$itemID'");
    #message
    mysqli_query($conn,"INSERT INTO `MESSAGES` VALUES(NULL,'1','$item[OWNER]','$account[1] has declined your clan, \"$item[1]\". This could be because of an inappropriate name or icon.','NO','0','$time','Clan Declined!','0')");
    logAction(10,0,"Clan ID: $itemID, Name: $item[NAME]");
    echo"<script>window.location='/Clan/$itemID'</script>";exit();
  }
}

if(isset($_POST['upd_'.$UUID])&&isset($_POST['upd_type_'.$UUID])){              ############## OWNER PANEL - POST UPDATE ##################
  if($r!=6){
    //hack
    mysqli_query($conn,"UPDATE `USERS` SET `STATUS` = 'DISABLED' WHERE `ID` = '$account[0]'");
    logAction(0,0);
    echo"<script>window.location='/User/logout.php'</script>";
    exit();
  }else{
    $text = mysqli_real_escape_string($conn,$_POST['upd_'.$UUID]);
    $title = mysqli_real_escape_string($conn,$_POST['upd_type_'.$UUID]);
    $desc = "[$siteVerRaw] $text";

    $discordWebhookUrl = "https://discord.com/api/webhooks/907378561680298044/HrYA3awemtAQypAUudhPlTG33gBv1mq4_8kTddSXD_lb-tvGUVUH_cP1eozxoRolnLDb";
    $discordWebhookData = array(
      "embeds" => array(
        array("title"=>$title,"description"=>"$desc")#16762880 limiteds
      ),
      "content" => ""
    );
    $opts = array(
      "http" => array(
        "header" => "Content-Type: application/json\r\n",
        "method" => "POST",
        "content" => json_encode($discordWebhookData)
      )
    );
    $context = stream_context_create($opts); $result = file_get_contents($discordWebhookUrl, false, $context);
    
    #Embed done -> time to log
    
    $time = time();
    mysqli_query($conn,"INSERT INTO `DEVLOG` VALUES (NULL,'$siteVerRaw','$time','$siteVerTime','$backendVer','$frontendVer','$sqlVer','$text','$title')");
    
    echo"<script>window.location='/Admin/'</script>";exit();
  }
}

if(isset($_POST['verChange_'.$UUID])&&isset($_POST['ver_type_'.$UUID])){              ############## OWNER PANEL - CHANGE VERSION ##################
  if($r!=6){
    //hack
    mysqli_query($conn,"UPDATE `USERS` SET `STATUS` = 'DISABLED' WHERE `ID` = '$account[0]'");
    logAction(0,0);
    echo"<script>window.location='/User/logout.php'</script>";
    exit();
  }else{
    $newVer = mysqli_real_escape_string($conn,$_POST['verChange_'.$UUID]);
    $verType = mysqli_real_escape_string($conn,$_POST['ver_type_'.$UUID]);
    
    if($verType!='VER_SITE'&&$verType!='VS_TIME'&&$verType!='VER_SQL'&&$verType!='VER_BACK'&&$verType!='VER_FRONT'){
      exit();
    }
    
    mysqli_query($conn,"UPDATE `CURRENT_ECONOMY` SET `$verType` = '$newVer' WHERE `ID` = '1'");
    
    echo"<script>window.location='/Admin/'</script>";exit();
  }
}

if(isset($_POST['giftOpenID_'.$UUID])&&isset($_POST['giftItemID_'.$UUID])){
  if($r!=6){
    //hack
    mysqli_query($conn,"UPDATE `USERS` SET `STATUS` = 'DISABLED' WHERE `ID` = '$account[0]'");
    logAction(0,0);
    echo"<script>window.location='/User/logout.php'</script>";
    exit();
  }else{
    $giftID = mysqli_real_escape_string($conn,$_POST['giftOpenID_'.$UUID]);
    $itemID = mysqli_real_escape_string($conn,$_POST['giftItemID_'.$UUID]);
    $findItem = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$itemID'"));
    
    $selectINV = mysqli_query($conn,"SELECT * FROM `INV` WHERE `ITEM` = '$giftID'");
    while(($i = mysqli_fetch_array($selectINV))){
      mysqli_query($conn,"INSERT INTO `INV` VALUES(NULL,'$itemID','$i[USER]','$findItem[TYPE]','$i[SERIAL]')");
    }
    
    if(isset($_POST['giftOffsale_'.$UUID])){
      mysqli_query($conn,"UPDATE `MARKET` SET `PRICE_TYPE` = 'OFFSALE' WHERE `ID` = '$giftID'");
    }
    
    if(isset($_POST['giftChangeGiftName_'.$UUID])){
      $findGift = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$giftID'"));
      mysqli_query($conn,"UPDATE `MARKET` SET `NAME` = 'Opened $findGift[NAME]' WHERE `ID` = '$giftID'");
    }
    mysqli_multi_query($conn,"UPDATE `MARKET` SET `UPDATE_TIME` = '" .  time()   . "' WHERE `ID` = '$giftID';
    						  UPDATE `MARKET` SET `UPDATE_TIME` = '" . time() +1 . "' WHERE `ID` = '$itemID'");
    travel("/Market/item.php?id=$itemID");
  }
}

if(isset($_POST['umang'])){                                               ############## User manage hub ##############
  if($r<5){
    //hack
    mysqli_query($conn,"UPDATE `USERS` SET `STATUS` = 'DISABLED' WHERE `ID` = '$account[0]'");
    logAction(0,0);
    echo"<script>window.location='/User/logout.php'</script>";
    exit();
  }else{
    $uname = mysqli_real_escape_string($conn,$_POST['umang']);
    travel("/Admin/manage.php?id=$uname");
  }
}

if(isset($_POST['ban_u_'.$UUID])&&isset($_POST['ban_r_'.$UUID])&&isset($_POST['ban_t_'.$UUID])){   ############# BAN USERS #############
  if($r<2){
    //hack
    mysqli_query($conn,"UPDATE `USERS` SET `STATUS` = 'DISABLED' WHERE `ID` = '$account[0]'");
    logAction(0,0);
    echo"<script>window.location='/User/logout.php'</script>";
    exit();
  }else{
    $uname = mysqli_real_escape_string($conn,$_POST['ban_u_'.$UUID]);
    $reason = mysqli_real_escape_string($conn,$_POST['ban_r_'.$UUID]);
    $type = mysqli_real_escape_string($conn,$_POST['ban_t_'.$UUID]);
    if($r<3 && $type=='Termination'){
      exit();
    }else{
      # sort out times and shit
      if($type == 'Warn'){$t = 'WARN';}elseif($type == 'Termination'){$t = 'TERM';}else{$t = 'BAN';}
      if($type == '1h'){$ti=3600;}elseif($type == '6h'){$ti=21600;}elseif($type == '1d'){$ti=86400;}elseif($type == '3d'){$ti=259200;}elseif($type == '7d'){$ti=604800;}elseif($type == '14d'){$ti=1209600;}elseif($type == '30d'){$ti=2595600;}else{$ti=0;}
      $time = time(); $end = $time + $ti; # when it ends
      
      if(strpos($uname, '#') === 0){
        $uq = mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '". substr($uname,1) . "'"); # idk wtf this is for
      }else{
        $uq = mysqli_query($conn,"SELECT * FROM `USERS` WHERE `USERNAME` = '$uname'");
      }
      if(mysqli_num_rows($uq)!=1){
        echo"<script>window.alert('User does not exist');window.location='/Admin/'";exit(); # oops
      }else{
        $u = mysqli_fetch_array($uq);
        if($u['RANK']!='MEMBER'&&$account['RANK']!='OWNER'){exit();} # only owner can ban moderator+
        $bq = mysqli_query($conn,"SELECT * FROM `BANS` WHERE `USER` = '$u[0]'");
        if(mysqli_num_rows($bq)>0){
          $b = mysqli_fetch_array($bq);
          if($b['TYPE']!='WARN'){
            echo"<script>window.alert('User is already banned');window.location='/Admin/'";exit(); # Brooo hes already banned
          }else{
            mysqli_query($conn,"UPDATE `BANS` SET `REASON` = '$reason' AND `TYPE` = '$t' AND `MOD` = '$account[0]' AND `START` = '$time' AND `END` = '$end' WHERE `USER` = '$u[0]'");
            mysqli_query($conn,"UPDATE `USERS` SET `STATUS` = 'BANNED' WHERE `ID` = '$u[0]'");
            logAction(6,$u[0],"(UPDATED) - $reason [$type]");
            #need to message 'em
            $msgtxt = "Your warn was updated to a ban for $type";
            mysqli_query($conn,"INSERT INTO `MESSAGES` VALUES(NULL,'1','$u[0]','$msgtxt','NO','1','$time','Warn updated to ban','0')");
            echo"<script>window.alert('Warn was updated to a ban; REASON was updated.');window.location='/Admin/'</script>";exit(); # warn -> ban (i forgot you could do this)
          }
        }else{
          mysqli_query($conn,"INSERT INTO `BANS` VALUES(NULL,'$u[0]','$reason','$t','$account[0]','$time','$end')");
          if($t!='WARN'){mysqli_query($conn,"UPDATE `USERS` SET `STATUS` = 'BANNED' WHERE `ID` = '$u[0]'");}
          logAction(6,$u[0],"$reason [$type]");
          #time to message, again
          $msgtxt = "Your account has been banned ($type), reason: $reason";
          mysqli_query($conn,"INSERT INTO `MESSAGES` VALUES(NULL,'1','$u[0]','$msgtxt','NO','1','$time','Ban Notice','0')");
          echo"<script>window.alert('$u[1] was banned.');window.location='/Admin/'</script>";exit();
        }
      }
    }
  }
}
  
#################### JAVASCRIPT HERE ####################

echo"

<script>

function SINFO(){
   $('#panel').load('/Admin/staff-info.php');
}

function STATS(){
   $('#panel').load('/Admin/stats.php');
}

function SISET(){
   $('#panel').load('/Admin/site-settings.php');
}

function S_ECO(){
   $('#panel').load('/Admin/economy.php');
}

function UPLDI(){
   $('#panel').load('/Admin/upload-item.php');
}

function ADVER(){
   $('#panel').load('/Admin/admin-verify.php');
}

function CLVER(){
   $('#panel').load('/Admin/clan-verify.php');
}

function UMANG(){
   $('#panel').load('/Admin/u-manage-index.php');
}

function CMANG(){
   $('#panel').load('/Admin/c-manage-index.php');
}


function BANUS(){
   $('#panel').load('/Admin/ban.php');
}

function CODES(){
   $('#panel').load('/Admin/codes.php');
}

function DVLOG(){
   $('#panel').load('/Admin/devlog.php');
}

function IMANG(){
   $('#panel').load('/Admin/i-manage-index.php');
}

function USVER(){
   $('#panel').load('/Admin/user-verify.php');
}

function AUCTN(){
   $('#panel').load('/Admin/auction.php');
}

function SALES(){
   $('#panel').load('/Admin/sales.php');
}

</script>

";

if($r==6){
  echo"

  <script>

  function CMMTS(){
     $('#panel').load('/Admin/comments.php');
  }

  function MSGSS(){
     $('#panel').load('/Admin/messages.php');
  }

  function ALOGS(){
     $('#panel').load('/Admin/logs.php');
  }

  function WORLD(){
     $('#panel').load('/Admin/world.php');
  }

  function OWNER(){
     $('#panel').load('/Admin/owner.php');
  }

  </script>

  ";
}

$rank = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `ROLES` WHERE `NAME` = '$account[RANK]'"));

echo"

<div class='doublebox box1'>
    
    <div class='platformtitle'>
        <h2>Admin Panel</h2>
    </div>
    
    <br>
    
    Your rank is: <span style='color:$rank[COLOR];'>$rank[ALIAS] <i class='$rank[ICON]'></i></span>
    
    <hr><br>
    
    Information<br>
    
    <button onclick='SINFO()' class='button btn-gold nd hover'><i class='far fa-address-card'></i> Staff Info</button><br>
    <button onclick='DVLOG()' class='button btn-blue nd hover'><i class='far fa-newspaper'></i> Devlog</button><br>
    
    ";


	if($r >= 2){
	echo"<button onclick='STATS()' class='button btn-blue nd hover'><i class='far fa-chart-bar'></i> Stats</button><br>";
    }

// ITEM MANAGEMENT (0)

    echo"<hr>Item Management<br>
    <button onclick='UPLDI()' class='button btn-blue nd hover'><i class='fas fa-file-upload'></i> Upload Item</button><br>";

	if($r >= 2){
      echo"<button onclick='USVER()' class='button btn-blue nd hover'><i class='far fa-check-circle'></i> Verify User Items</button><br>";
    }

	if($r >= 5){
      echo"<button onclick='ADVER()' class='button btn-purple nd hover'><i class='far fa-check-circle'></i> Verify Items</button><br>";
    }

// MANAGEMENT (3)

	if($r >= 3){
      echo"<hr>Management<br>";

      if($r >= 5){
        echo"<button onclick='UMANG()' class='button btn-purple nd hover'><i class='fas fa-users-cog'></i> User Management</button><br>
        <button onclick='IMANG()' class='button btn-purple nd hover'><i class='fab fa-redhat'></i> Item Management</button><br>
        <button onclick='CMANG()' class='button btn-purple nd hover'><i class='fas fa-users'></i> Clan Management</button><br>
        <button onclick='AUCTN()' class='button btn-blue nd hover'><i class='fas fa-shopping-cart'></i> Auctions</button><br>
        <button onclick='CODES()' class='button btn-blue nd hover'><i class='far fa-keyboard'></i> Promocodes</button><br>
        <button onclick='SISET()' class='button btn-blue nd hover'><i class='fas fa-cog'></i> Site Settings</button><br>";
      }

      if($r >= 4){
        echo"<button onclick='S_ECO()' class='button btn-blue nd hover'><i class='far fa-money-bill-alt'></i> Economy</button><br>";
        echo"<button onclick='CLVER()' class='button btn-blue nd hover'><i class='fas fa-users'></i> Verify Clans</button><br>";
        echo"<button onclick='SALES()' class='button btn-blue nd hover'><i class='fas fa-money-bill-alt'></i> Item Sales</button><br>";
      }
      
      echo"<button onclick='BANUS()' class='button btn-orange nd hover'><i class='fas fa-hammer'></i> Ban Users</button><br>";
    }

	if($r == 6){
      echo"<hr>Owner<br>
      <button onclick='CMMTS()' class='button btn-blue nd hover'><i class='fas fa-comment'></i> Comments</button><br>
      <button onclick='MSGSS()' class='button btn-purple nd hover'><i class='fas fa-mail-bulk'></i> Messages</button><br>
      <button onclick='WORLD()' class='button btn-purple nd hover'><i class='fas fa-globe'></i> World</button><br>
      <button onclick='ALOGS()' class='button btn-purple nd hover'><i class='fas fa-align-left'></i> Logs</button><br>
      <button onclick='OWNER()' class='button btn-gold nd hover'><i class='fas fa-user-tie'></i> Owner</button><br>";
    }
    
    /*<button onclick='page1()' class='button btn-$c_1 nd hover'>Reports & Logs</button><br>
    <button onclick='page2()' class='button btn-$c_2 nd hover'>Asset Management</button><br>
    <button onclick='page3()' class='button btn-$c_3 nd hover'>Ban & Verify</button><br>
    <button onclick='page4()' class='button btn-$c_4 nd hover'>User Management</button><br>
    <button onclick='page5()' class='button btn-$c_5 nd hover'>Manager Panel</button><br>
    <button onclick='page6()' class='button btn-$c_6 nd hover'>Owner Panel</button><br>*/


if(isset($_GET['BAN'])){
  $usr = mysqli_real_escape_string($conn,$_GET['BAN']);
  echo"<script>window.onload = function a(){ $('#panel').load('/Admin/ban.php?user=$usr');}</script>";
}
      
    echo"
    
</div>

<div class='doublebox box2'>
    
    <div id='panel'>

";