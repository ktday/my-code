<?php
include("../Misc/connect.php");
include("../Misc/vars.php");

function mnr($query){
  return mysqli_num_rows($query);
}

function mq($query){
  global $conn;
  return mysqli_query($conn,$query);
}

$users = mnr(mq("SELECT * FROM `USERS` WHERE 1"));
$vip = mnr(mq("SELECT * FROM `USERS` WHERE `VIP` = 'VIP'"));
$mvip = mnr(mq("SELECT * FROM `USERS` WHERE `VIP` = 'MEGA'"));
$uvip = mnr(mq("SELECT * FROM `USERS` WHERE `VIP` = 'ULTRA'"));
$admin = mnr(mq("SELECT * FROM `USERS` WHERE `RANK` != 'MEMBER'"));

$items = mnr(mq("SELECT * FROM `MARKET` WHERE 1"));
$appr = mnr(mq("SELECT * FROM `MARKET` WHERE `STATUS` = 'AP'"));
$banned = mnr(mq("SELECT * FROM `MARKET` WHERE `STATUS` = 'BAN'"));
$cc = mnr(mq("SELECT * FROM `MARKET` WHERE `TYPE` = 'SHIRT' OR `TYPE` = 'PANTS'"));
$lim = mnr(mq("SELECT * FROM `MARKET` WHERE `RARITY` = 'EPIC'"));
$sold = mnr(mq("SELECT * FROM `INV` WHERE 1"));

$posts = mnr(mq("SELECT * FROM `FORUM_THREADS` WHERE 1"));
$replies = mnr(mq("SELECT * FROM `FORUM_REPLIES` WHERE 1"));
$forum = $posts + $replies;
$locked = mnr(mq("SELECT * FROM `FORUM_THREADS` WHERE `LOCKED` = 'YES'"));
$pinned = mnr(mq("SELECT * FROM `FORUM_THREADS` WHERE `PINNED` = 'YES'"));

$clans = mnr(mq("SELECT * FROM `CLANS` WHERE 1"));

$txtUsers = nl2br("<h3>$users Users</h3>- $vip users with VIP
- $mvip users with MEGA VIP
- $uvip users with ULTRA VIP
- $admin users with administrative perms
");

$txtItems = nl2br("<h3>$items Items</h3>- $sold total items sold
- $appr Approved
- $banned Banned or declined
- $cc Community created items
- $lim Limited items
");

$txtForum = nl2br("<h3>$forum Forum Posts</h3>- $posts Posts
- $replies Replies
- $pinned Posts Pinned
- $locked Posts Locked
");

$txtClans = nl2br("<h3>$clans Clans</h3>");

$txtVer = nl2br("<h3>Site Version: $siteVer</h3>- Backend Version: $backendVer
- Frontend Version: $frontendVer
- Database Version: $sqlVer");


echo"

<h1>Site Statistics</h1><hr>

$txtUsers

$txtItems

$txtForum

$txtClans

$txtVer

<hr>
<h1>Roles</h1>

<table>

<tr>
	<th>ID</td>
	<th>Name</td>
	<th>Color</td>
	<th>Icon</td>
</tr>

";

$q = mysqli_query($conn,"SELECT * FROM `ROLES` WHERE `PV` = '1'");

while(($a = mysqli_fetch_array($q))){
  echo"
  
  <tr>
  	<td>$a[0]</td>
  	<td>$a[ALIAS]</td>
  	<td style='color:$a[COLOR]'>$a[COLOR]</td>
  	<td><i class='$a[ICON]'></i></td>
  </tr>
  
  ";
}

echo"</table>";

if($ar >= 5){
  
  #$dailyQ = mysqli_query($conn,"SELECT * FROM `DAILY_CURRENCY` WHERE `TYPE` = '$account[VIP]'");
  
  $unltxt = "Username Limits: " . $config["usernameLengths"][0] . " min, " . $config["usernameLengths"][1] . " max";
  $stctxt = "Starter Coins: " . $config["StarterCoins"][0] . "C, " . $config["StarterCoins"][1] . "B";
  #$dctime = date("H:i:s",$config["coins"]);
  $dctime = gmdate("H:i:s",600);
  
  echo"
  
  <hr>
  
  <h1>Config</h1>
  
  - $unltxt <br>
  - Username Regex: $config[usernameRegex] <br>
  - $stctxt <br>
  - Daily Coins Time: $dctime <br>
  - Username Change Amount: $config[usernameChangeBucksAmount] Bucks <br>
  
  <h3>Daily Income</h3>
  
  <table>
  <tr>
  	<th>VIP Type</th>
    <th>Coins</th>
  </tr>
  
  ";
  
  $q = mysqli_query($conn,"SELECT * FROM `DAILY_CURRENCY` WHERE 1");
  
  while(($a = mysqli_fetch_array($q))){
    echo"
    
    <tr>
      <td>$a[TYPE]</td>
      <td>$a[VALUE]</td>
    </tr>
    
    ";
  }
  
  echo"</table>";
  
}

?>