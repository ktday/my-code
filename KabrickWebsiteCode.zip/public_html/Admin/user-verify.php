<?php
include("../Misc/connect.php");
$ITEMS = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `STATUS` = 'UAP' AND `TYPE` = 'SHIRT' OR `TYPE` = 'PANTS' AND `STATUS` = 'UAP'");

if($account['RANK']=='OWNER'){$r=6;}
elseif($account['RANK']=='MANAGER'){$r=5;}
elseif($account['RANK']=='EXECUTIVE'){$r=4;}
elseif($account['RANK']=='ADMIN'){$r=3;}
elseif($account['RANK']=='MODERATOR'){$r=2;}
else{exit();}

$UUID = $account['UUID'];

echo"

<h2>Verify Items (LVL1)</h2>
            
";

if(mysqli_num_rows($ITEMS)==0){
  echo"There are no items to verify!";
}else{
  while(($i=mysqli_fetch_array($ITEMS))){
    $u = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$i[UPLOADER]'"));
    
    echo"
    
    <div style='height:181px;'>
    
      <img src='$i[AV_IMG]' class='fl' style='left:1rem;'>
      
      <p><b>$i[NAME]</b></p>
      
      \"$i[DESCRIPTION]\"<br>
      
      $i[PRICE] $i[PRICE_TYPE]<br>
      
      $i[TYPE]<br>
      
      <form method='post'>
      	<button name='aui_$UUID' value='$i[0]' class='button3 btn-green nd hover'>Accept</button>
      	<button name='dui_$UUID' value='$i[0]' class='button3 btn-red nd hover'>Decline</button>
      </form>
    
    </div>
    
    ";
    
  }
}

?>