<?php
include("../Misc/connect.php");

if($account['RANK']=='OWNER'){$r=6;}
elseif($account['RANK']=='MANAGER'){$r=5;}
else{exit();}


$num1 = $account['UUID'];

echo"

<h2>Manage Auctions</h2>

<form method='post'>
	<input name='umang' class='form form1l' placeholder='Username'>
    <button class='button3 btn-blue'>Go</button>
</form>

<br><hr><br>

<h2> Active Auctions: </h2>
      
<table>

<tr>
	<th>ID</th>
    <th>Item</th>
    <th>User</th>
    <th>Starting Bid</th>
    <th>Bids</th>
    <th>Highest Bid</th>
    <th>Invid</th>
    <th>Time</th>
    <th></th>
</tr>
      
";

$usrs = mysqli_query($conn,"SELECT * FROM AUCTION WHERE `WINNER` = '0'");
while(($u = mysqli_fetch_array($usrs))){
  
  $bidQ = mysqli_query($conn,"SELECT * FROM `BIDS` WHERE `AUCTION` = '$u[0]'");
  $bids = mysqli_num_rows($bidQ);
  if($bids==0){$hbid='0';}else{
    
    $hbidder = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `BIDS` WHERE `AUCTION` = '$u[0]' ORDER BY `PRICE` DESC LIMIT 1"));
    
    $hbid = $hbidder['PRICE'];}
  
  $t1 = date("H:i", $u['TIME']);
  $t2 = gmdate("j F Y", $u['TIME']);
  
  echo"<tr>
  	<td>$u[0]</td>
  	<td><a href='/Market/item.php?id=$u[ITEM]'>$u[ITEM]</a></td>
  	<td><a href='/Users/Profile/$u[USER]'>$u[USER]</a></td>
  	<td>$u[STARTINGBID]</td>
  	<td>$bids</td>
  	<td>$hbid</td>
  	<td>$u[INVID]</td>
  	<td>$t1 $t2</td>
    <td><a href='/Auction/item.php?id=$u[0]' class='fa fa-hammer'></a></td>
  </tr>";
}

echo"
</table>
<br><br>

<h2> Inactive Auctions: </h2>
      
<table>

<tr>
	<th>ID</th>
    <th>Item</th>
    <th>User</th>
    <th>Starting Bid</th>
    <th>Bids</th>
    <th>Highest Bid</th>
    <th>Winner</th>
    <th>Invid</th>
    <th>Time</th>
    <th></th>
</tr>
      
";

$usrs = mysqli_query($conn,"SELECT * FROM AUCTION WHERE `WINNER` != '0'");
while(($u = mysqli_fetch_array($usrs))){
  
  $bidQ = mysqli_query($conn,"SELECT * FROM `BIDS` WHERE `AUCTION` = '$u[0]'");
  $bids = mysqli_num_rows($bidQ);
  if($bids==0){$hbid='0';}else{
    
    $hbidder = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `BIDS` WHERE `AUCTION` = '$u[0]' ORDER BY `PRICE` DESC LIMIT 1"));
    
    $hbid = $hbidder['PRICE'];}
  
  $t1 = date("H:i", $u['TIME']);
  $t2 = gmdate("j F Y", $u['TIME']);
  
  echo"<tr>
  	<td>$u[0]</td>
  	<td><a href='/Market/item.php?id=$u[ITEM]'>$u[ITEM]</a></td>
  	<td><a href='/Users/Profile/$u[USER]'>$u[USER]</a></td>
  	<td>$u[STARTINGBID]</td>
  	<td>$bids</td>
  	<td>$hbid</td>
  	<td><a href='/Users/Profile/$u[WINNER]'>$u[WINNER]</a></td>
  	<td>$u[INVID]</td>
  	<td>$t1 $t2</td>
    <td><a href='/Auction/item.php?id=$u[0]' class='fa fa-hammer'></a></td>
  </tr>";
}

echo"
</table>
<br><br>
";


?>