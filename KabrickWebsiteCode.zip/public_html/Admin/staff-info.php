<?php
include("../Misc/connect.php");

$artist = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `ROLES` WHERE `NAME` = 'ASSET_UPLOADER'"));
$mod = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `ROLES` WHERE `NAME` = 'MODERATOR'"));
$adm = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `ROLES` WHERE `NAME` = 'ADMIN'"));
$exe = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `ROLES` WHERE `NAME` = 'EXECUTIVE'"));
$mng = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `ROLES` WHERE `NAME` = 'MANAGER'"));
$owner = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `ROLES` WHERE `NAME` = 'OWNER'"));

echo"

<h1>Staff Information</h1><hr>

<h2>Roles & Perms</h2>

<h4 style='color:$artist[COLOR];' title='$artist[RANK]'>$artist[ALIAS] <i class='$artist[ICON]'></i></h4>
- Can Upload Items<br>

<br>

<h4 style='color:$mod[COLOR];' title='$mod[RANK]'>$mod[ALIAS] <i class='$mod[ICON]'></i></h4>
- Can View site stats<br>
- Can Ban Users<br>
- Can reset users avatars<br>
- Can Verify user-created items<br>
- Can Delete + censor threads<br>

<br>

<h4 style='color:$adm[COLOR];' title='$adm[RANK]'>$adm[ALIAS] <i class='$adm[ICON]'></i></h4>
- Can Perm Ban Users<br>
- Can Access and change Site Settings<br>
- Can Enable \"Ghost Mode\"<br>

<br>

<h4 style='color:$exe[COLOR];' title='$exe[RANK]'>$exe[ALIAS] <i class='$exe[ICON]'></i></h4>
- Can Grant users bucks/coins<br>
- Can View item owners + serial<br>

<br>

<h4 style='color:$mng[COLOR];' title='$mng[RANK]'>$mng[ALIAS] <i class='$mng[ICON]'></i></h4>
- Can Manage Site Economy<br>
- Can Verify Admin-Created Items<br>
- Can View & Edit Advanced User Info<br>
- Can View & Edit Items<br>
- Can View Current and Past Auctions<br>
- Can View Current and Past Promocodes<br>

<br>

<h4 style='color:$owner[COLOR];' title='$owner[RANK]'>$owner[ALIAS] <i class='$owner[ICON]'></i></h4>
- Can do anything :)<br>

<br><hr><br>

<h2>Item Uploading</h2>

<h4>Item Name = Name itll appear as in the market</h4>

<h4>Item Description = Mini description fitting the item</h4>

<h4>Price / Price Type:</h4>
- When price type = Coins/Bucks, Price should be more than 0. This will make the item <b>Purchasable</b><br>
- When price type = Free, Price should remain at 0. This will make the item <b>Free for anyone to get</b><br>
- When price type = Offsale, Price should remain at 0. This will make the item <b>Not purchasable</b><br>

<h4>Item Type = Layer at which the item should be rendered</h4>
- Hat = Item on the players head<br>
- Face = Change in expression etc<br>
- Gear = Something held in the hand<br>
- Shoulder = Something on the players shoulder<br>
- Mask = Something in front of the players face<br>
- Back = Something placed on the players back (Rendered underneath the avatar)<br>
- Body = Something that changes the players body<br>

<h4>Image Uploading Rules:</h4>
- Item must be of size <b>108 x 181 Pixels</b><br>
- The image must be <b>Transparent</b><br>
- The image must not contain the default avatar image<br>

<h4>Rarity, Stock & Onsale Time</h4>
- DEF rarity = for regular items in the market<br>
- RARE rarity = for more expensive, rarer or harder to obtain items</br>
- EPIC rarity = for items with limited stock (<b>MUST have either stock > 0 OR Onsale time > 0h</b>)<br>
<br>
- Stock is only for <b>EPIC Items</b>, it will determine how many people can buy the item before it goes offsale<br>
<br>
- Onsale time is the amount of time before the item goes offsale (Measured in <b>Hours</b> From verification)<br>
(Example: if onsale time is set to 24h, the item will only be obtainable for 24 hours <b>after verification</b>)<br>

<h4><u>All items uploaded will go through a verification process where it will have to be accepted by the Manager or Owner.</u></h4>

<br>

<h2>Templates</h2>

<table>
	<tr>
    	<td><img src='/Misc/IMGS/avatar.png'></td>
    	<td><img src='/Misc/IMGS/shirt.png'></td>
    	<td><img src='/Misc/IMGS/pants.png'></td>
	</tr>
    <tr>
    	<td>Full Avatar</td>
    	<td>Shirt</td>
    	<td>Pants</td>
    </tr>
</table>
";

?>