<?php
include("../Misc/connect.php");

if($account['RANK']=='OWNER'){$r=6;}
elseif($account['RANK']=='MANAGER'){$r=5;}
elseif($account['RANK']=='EXECUTIVE'){$r=4;}
elseif($account['RANK']=='ADMIN'){$r=3;}
elseif($account['RANK']=='MODERATOR'){$r=2;}
else{exit();}

$UUID = $account['UUID'];

if(isset($_GET['user'])){
  $usr = "value='" . mysqli_real_escape_string($conn,$_GET['user']) . "'";
}else{
  $usr = '';
}

# Username/id(#n), type{Warn,1h,6h,1d,3d,7d,14d,30d,perm}, reason.

echo"

<h1>Ban user</h1>

<form method='post' enctype='multipart/form-data'>
    <label for='ban_u_$UUID'>Username:</label> <input class='form form1l' placeholder='Username' name='ban_u_$UUID' minlength='1' maxlength='25' $usr required><br><br>
    <textarea class='form form1l' name='ban_r_$UUID' placeholder='Reason' minlength='5' maxlength='255' required></textarea><br><br>
    <select class='form form1l' name='ban_t_$UUID'><option selected disabled>Type</option><option>Warn</option><option>1h</option><option>6h</option><option>1d</option><option>3d</option><option>7d</option><option>14d</option><option>30d</option>
    ";if($r!=2){echo"<option>Termination</option>";}echo"</select><br><br>
    <button class='button3 btn-blue nd hover'>Submit!</button>
</form>
<br>
";

?>