<?php

if(isset($_GET['sender'])||isset($_GET['reciever'])){
  
  
  include("../Misc/gamma-nav.php");
  include("../lgt.php");
  
  if($account['RANK']=='OWNER'){$r=6;}
  else{exit();}
  
  echo"<div class='platform'><div class='platformtitle'><p><u><b>Message Logs</b></u></p></div><br>
  <br>Search: <form method='get' action='/Admin/messages.php'>
	<input type='number' name='sender' placeholder='Sender' value='0' class='form form1l'>
	<input type='number' name='reciever' placeholder='Reciever' value='0' class='form form1l'>
    <button class='button btn-blue nd hover'>Go!</button>
</form><br>";
  
  $sender = 0;$reciever = 0;
  $q = "SELECT * FROM `MESSAGES` WHERE ";
  if(isset($_GET['sender'])){$sender = mysqli_real_escape_string($conn,$_GET['sender']);}
  if(isset($_GET['reciever'])){$reciever = mysqli_real_escape_string($conn,$_GET['reciever']);}
  if($sender != 0 && $reciever != 0){$q .= "`SENDER` = '$sender' AND `RECIEVER` = '$reciever'";}
  elseif($sender != 0){$q .= "`SENDER` = '$sender'";}
  elseif($reciever != 0){$q .= "`RECIEVER` = '$reciever'";}
  $q .= " ORDER BY `ID` DESC";
  
  $MSGS = mysqli_query($conn,$q);
  
  while(($m=mysqli_fetch_array($MSGS))){
    $s = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$m[SENDER]'"));
    $r = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$m[RECIEVER]'"));
    
    if($m['IMPORTANT'] == 1){$ttl = "<a href='/Msg/$m[0]' class='txtcol-red'><i class='fas fa-exclamation-triangle'></i> " . lgt($m['TITLE']) . "</a>";}
    else{$ttl = "<a href='/Msg/$m[0]'>" . lgt($m['TITLE']) . "</a>";}
    echo"

    $ttl "; if($m['VIEWED']=='YES'){echo"<i class='fa fa-eye'></i>";} echo"<br>
    By <a href='/Profile/$s[1]'>$s[1]</a>
    To <a href='/Profile/$r[1]'>$r[1]</a>

    <br><hr><br>

    ";
  }
  
  exit();
  
}else{

include("../Misc/connect.php");
include("../Misc/vars.php");
include("../lgt.php");

if($account['RANK']=='OWNER'){$r=6;}
else{exit();}

}

echo"

<h1>Messages Logs</h1>

<br><form method='get' action='/Admin/messages.php'>
	<input type='number' name='sender' placeholder='Sender' value='0' class='form form1l'>
	<input type='number' name='reciever' placeholder='Reciever' value='0' class='form form1l'>
    <button class='button btn-blue nd hover'>Go!</button>
</form><br>
  
";

$MSGS = mysqli_query($conn,"SELECT * FROM `MESSAGES` WHERE 1 ORDER BY `ID` DESC");

while(($m=mysqli_fetch_array($MSGS))){
  $s = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$m[SENDER]'"));
  $r = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$m[RECIEVER]'"));
    
    if($m['IMPORTANT'] == 1){$ttl = "<a href='/Msg/$m[0]' class='txtcol-red'><i class='fas fa-exclamation-triangle'></i> " . lgt($m['TITLE']) . "</a>";}
    else{$ttl = "<a href='/Msg/$m[0]'>" . lgt($m['TITLE']) . "</a>";}
  echo"
  
  $ttl "; if($m['VIEWED']=='YES'){echo"<i class='fa fa-eye'></i>";} echo"<br>
  By <a href='/Profile/$s[1]'>$s[1]</a>
  To <a href='/Profile/$r[1]'>$r[1]</a>

  <br><hr><br>
  
  ";
}

?>