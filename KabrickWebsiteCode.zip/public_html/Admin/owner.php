<?php
include("../Misc/connect.php");
include("../Misc/vars.php");

if($account['RANK']=='OWNER'){$r=6;}
else{exit();}

$num1 = $account['UUID'];

echo"

<h2>Post Update to Discord</h2>
            
<form method='post'>

  <textarea class='form form1l' name='upd_$num1' placeholder='Description'></textarea>
  
  <select name='upd_type_$num1' class='form form1l'>
  	<option>Update</option>
  	<option>Small Update</option>
  	<option>New Content</option>
  	<option>Hotfix</option>
  	<option>Bug Fix</option>
  </select>

  <button class='button3 btn-blue nd hover'>Post!</button>

</form>

<br><hr>

<h2>Change Update</h2>

<h3>Site Version: $siteVer</h3>
Backend Version: $backendVer<br>
Frontend Version: $frontendVer<br>
Database Version: $sqlVer<br>
            
<form method='post'>

  <input class='form form1l' name='verChange_$num1' placeholder='NewVersion'>
  
  <select name='ver_type_$num1' class='form form1l'>
  	<option>VER_SITE</option>
  	<option>VS_TIME</option>
  	<option>VER_SQL</option>
  	<option>VER_BACK</option>
  	<option>VER_FRONT</option>
  </select>

  <button class='button3 btn-blue nd hover'>Update!</button>

</form>

<br><hr>

<h2>Open Gift</h2>
            
<form method='post'>

  <input class='form form1l' name='giftOpenID_$num1' placeholder='Gift ID' type='number'>
  <input class='form form1l' name='giftItemID_$num1' placeholder='Item ID' type='number'>
  
  <br><input type='checkbox' name='giftChangeGiftName_$num1' id='694200' value='1'>
  <label for='694200'>Change Gift name to Opened ***...</label>
  
  <br><input type='checkbox' name='giftOffsale_$num1' id='6942069' value='1'>
  <label for='6942069'>Offsale the gift</label>

  <button class='button3 btn-blue nd hover'>Open Gift!</button>

</form>

<br><hr>
<a href='/Admin/regcodes.php' class='button2 btn-blue'>Regcode Management <span class='fas fa-external-link-alt'></span></a><br><br>
  
";

?>