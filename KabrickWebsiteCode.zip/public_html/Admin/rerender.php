<?php

include("../Misc/vars.php");

if($account['RANK']=='OWNER'){$r=6;}
elseif($account['RANK']=='MANAGER'){$r=5;}
else{exit();}

if(isset($_GET['id'])){

    $id = mysqli_real_escape_string($conn,$_GET['id']);
    $itemq = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$id'");
    if(mysqli_num_rows($itemq)!=1){
        echo"Invalid item.";
    }else{
        $item = mysqli_fetch_array($itemq);
        $type = $item["TYPE"]; $img_dir_suf = $item["AV_IMG"];
        $img_dir_pre = "/home/lord7302/domains/$meta_blank_url/public_html";
        #echo($img_dir_suf);

        /*if($type == "BACK"){
          $palette_img = imagecreatefrompng($img_dir_pre . $img_dir_suf);
          $av_img = imagecreatefrompng($img_dir_pre."/Misc/IMGS/avatar.png");
          imagesavealpha($palette_img, true);
          imagecopy($palette_img,$av_img,0,0,0,0,121,181);
        }elseif($type == 'BODY'){
          $palette_img = imagecreatefrompng($img_dir_pre.$img_dir_suf);
          imagesavealpha($palette_img, true);
        }else{
          $palette_img = imagecreatefrompng($img_dir_pre."/Misc/IMGS/avatar.png");
          $av_img = imagecreatefrompng($img_dir_pre.$img_dir_suf);
          imagesavealpha($palette_img, true);
          imagecopy($palette_img,$av_img,0,0,0,0,121,181);
        }*/

        $defAvImg = "/Misc/IMGS/avatar.png";

        #exit($img_dir_pre.$defAvImg);

        if($type != "BODY"){
            $palette_img = imagecreatefrompng($img_dir_pre.$defAvImg);
            $av_img = imagecreatefrompng($img_dir_pre.$img_dir_suf);
            #imagesavealpha($palette_img, true);
            #echo($img_dir_pre.$img_dir_suf);

            if($type == "BACK"){
              imagesavealpha($av_img, true);
              imagecopy($av_img,$palette_img,0,0,0,0,108,181);
              imagepng($av_img,$img_dir_pre."/Misc/IMGS/SHOP/R/".$item["ID"].".png");
            }else{
              imagesavealpha($palette_img, true);
              imagecopy($palette_img,$av_img,0,0,0,0,108,181);
              imagepng($palette_img,$img_dir_pre."/Misc/IMGS/SHOP/R/".$item["ID"].".png");
            }
        }else{
            $palette_img = imagecreatefrompng($img_dir_pre.$img_dir_suf);
            imagepng($palette_img,$img_dir_pre."/Misc/IMGS/SHOP/R/".$item["ID"].".png");
        }

        
        echo"Done.<br><img src='/Misc/IMGS/SHOP/R/".$item["ID"].".png'>
                  <br><img src='$img_dir_suf'>
                  <br><img src='$defAvImg'>";
    }
}