<?php
#include("../Misc/connect.php");
include("../Misc/vars.php");
#$CURRENT_ECONOMY = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `CURRENT_ECONOMY` WHERE `ID` = '1'"));

if($account['RANK']=='OWNER'){$r=6;}
else{exit();}

$num1 = $account['UUID'];

// query the users

$q = mysqli_query($conn,"SELECT * FROM `COG` WHERE 1");

$usrs = [];
$cols = ["#f00","#fa0","#ff0","#af0","#0f0","#0ff","#0af","#00f","#a0f","#f0f"];

// [NAME, ID, COINS, BUCKS, TOTB, TOTC]

$tc = 0;
$y = 0;
while(($u = mysqli_fetch_array($q))){
  $tc += 1;
  #array_push($usrs,$u['CTY']);
  if(array_key_exists($u['CTY'], $usrs)){
    $usrs[$u['CTY']] += 1;
  }else{
    $usrs[$u['CTY']] = 1;
  }
}

// Sort array frfr

function coincomp($e1, $e2) {
    return $e2 - $e1;
} 
  
#usort($usrs, 'coincomp');
arsort($usrs);

//pie chart before the table :)

echo"

<h1>Where are kabrick players?</h1><br>

<style>

.picont {display: inline-flex;align-items:center;margin:0 auto;width:auto;}
.pi {border-radius: 50%;width:200px;height:200px;
background: conic-gradient(
";

$tp = $tc/100;

$x = 0;
$ram = 0;
foreach($usrs as $c => $cv){
  if($x>count($usrs)){break;}
  $perc = $ram + (($cv / $tp));
  echo"$cols[$x] $ram% $perc%";
  if($x<count($usrs) - 1){echo", ";}
  $x+=1;
  $ram = $perc;
}

echo");
}

.pilgndbox{margin-left:20px;border:1px solid black;padding:5px;}
.pil-entry{display:flex;align-items:left;}
.pilec{height:10px;width:10px;}
.pilet{margin-left:5px;}

</style>

<div class='picont'>
  <div class='pi'></div>
  <div class='pilgndbox'>
    ";

$x = 0;
foreach($usrs as $c => $cv){
  if(array_key_exists($c, $countries)){$cn = $countries[$c];}else{$cn = $c;}
  if($x>count($usrs)){break;}
  echo"<div class='pil-entry'>
  <div class='pilec' style='background-color:$cols[$x];'></div>
  <div class='pilet'>$cn</div>
  </div>";
  $x+=1;
}

echo"
  </div>
</div><br><br>

";

//display table

echo"

<table>

<tr>
  <th>Country</th>
  <th>Count</th>
</tr>

";

foreach($usrs as $c => $cv){
  if(array_key_exists($c, $countries)){$cn = $countries[$c];}else{$cn = $c;}
    echo"
    
    <tr>
      <td>$cn ($c)</td>
      <td>$cv</td>
    </tr>
    
    ";
}

echo"</table>";

?>