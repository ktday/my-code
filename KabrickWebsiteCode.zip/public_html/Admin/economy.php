<?php
include("../Misc/connect.php");
$CURRENT_ECONOMY = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `CURRENT_ECONOMY` WHERE `ID` = '1'"));

if($account['RANK']=='OWNER'){$r=6;}
elseif($account['RANK']=='MANAGER'){$r=5;}
elseif($account['RANK']=='EXECUTIVE'){$r=4;}
else{exit();}

$num1 = $account['UUID'];

echo"

<h2>Grant Coins or Bucks</h2>
            
<form method='post'>

  <input class='form form1l' name='grant_name_$num1' maxlength='20' placeholder='Username (leave empty for self)'>

  <input type='number' class='form form1l' name='grant_$num1' max='500' value='0'>
  
  <select name='grant_type_$num1' class='form form1l'>
  	<option value='COINS'>Coins</option>
  	<option value='BUCKS'>Bucks</option>
  </select>

  <button class='button3 btn-blue nd hover'>Grant!</button>

</form>
  
";

/*if($r == 6){
  echo"
  
  <h2>Deposit Coins or Bucks</h2>
  
  <form method='post'>
  	<input class='form form2l' name='givecurr' type='number' min='1'>
  
    <select name='gct' class='form form2l'>
      <option value='COINS'>Coins</option>
      <option value='BUCKS'>Bucks</option>
    </select>
    <button class='button3 btn-blue nd hover'>Deposit!</button>
  </form>
  
  ";
}*/

//thats it? no. add more :)

// query the users

$q = mysqli_query($conn,"SELECT * FROM `USERS` WHERE 1 ORDER BY `COINS` + (`BUCKS` * 5) DESC LIMIT 10");

$usrs = [];
#$cols = ["#b41616","#b45016","#b48116","#98b416","#3cb416","#16b45e","#16b4ab","#1640b4","#7616b4","#b4169f"];
$cols = ["#f00","#fa0","#ff0","#af0","#0f0","#0ff","#0af","#00f","#aaf","#f0f"];

// [NAME, ID, COINS, BUCKS, TOTB, TOTC]

$tc = 0;
while(($u = mysqli_fetch_array($q))){
  $totc = $u['COINS'] +      ($u['BUCKS'] * 5);
  $totb = $u['BUCKS'] + floor($u['COINS'] / 5);
  $tc += $totc;
  array_push($usrs,[$u['USERNAME'], $u[0], $u['COINS'], $u['BUCKS'], $totc, $totb]);
  #}
  #echo"$u[USERNAME] $totc| ";
}

// Sort array frfr

/*function coincomp($e1, $e2) {
    return $e2[5] - $e1[5];
} 
  
usort($usrs, 'coincomp');

foreach($usrs as $u){
  if($y > 9){break;}else{$tc+=$u[4];}
  $y += 1;
}*/

#var_dump($tc);

$totalcurrencyq = mysqli_query($conn,"SELECT SUM(USERS.BUCKS) + CURRENT_ECONOMY.BUCKS, SUM(USERS.COINS) + CURRENT_ECONOMY.COINS FROM USERS, CURRENT_ECONOMY WHERE 1");
$totalcurrency = mysqli_fetch_array($totalcurrencyq);
#var_dump(mysqli_fetch_array($totalcurrency));

$totalcoins = $totalcurrency[0] + $totalcurrency[1];

echo"<h1>Total Currency In Circulation</h1>

<h3>Coins: $totalcurrency[1]</h3>
<h3>Bucks: $totalcurrency[0]</h3>
<h3>Total (in coins): $totalcoins</h3>";

//pie chart before the table :)

echo"<h1>Wealth Dispersion</h1><br>

<style>

.picont {display: inline-flex;align-items:center;margin:0 auto;width:auto;}
.pi {border-radius: 50%;width:200px;height:200px;
background: conic-gradient(
";

$tp = $tc/100;

$x = 0;
$ram = 0;
foreach($usrs as $a){
  if($x>9){break;}
  $perc = $ram + (floor(($a[4] / $tp) * 100))/100;
  echo"$cols[$x] $ram% $perc%";
  if($x<9){echo", ";}
  $x+=1;
  $ram = $perc;
}

echo");
}

.pilgndbox{margin-left:20px;border:1px solid white;padding:5px;}
.pil-entry{display:flex;align-items:left;}
.pilec{height:10px;width:10px;}
.pilet{margin-left:5px;}

</style>

<div class='picont'>
  <div class='pi'></div>
  <div class='pilgndbox'>
    ";

$x = 0;
foreach($usrs as $a){
  if($x>9){break;}
  echo"<div class='pil-entry'>
  <div class='pilec' style='background-color:$cols[$x];'></div>
  <div class='pilet'>$a[0]</div>
  </div>";
  $x+=1;
}

echo"
  </div>
</div><br><br>

";

//display table

echo"

<table>

<tr>
  <th>ID</th>
  <th>Username</th>
  <th>Coins</th>
  <th>Bucks</th>
  <th>Total Coins</th>
  <th>Total Bucks</th>
  <th>% (of chart)</th>
</tr>

";

$x = 0;
foreach($usrs as $a){
  $x += 1;
  if($x > 10){break;}else{
    $perc = (floor(($a[4] / $tp) * 100))/100;
    echo"
    
    <tr>
      <td>$x</td>
      <td>$a[0]</td>
      <td>$a[2]</td>
      <td>$a[3]</td>
      <td>$a[4]</td>
      <td>$a[5]</td>
      <td>$perc %</td>
    </tr>
    
    ";
  }
}

echo"</table>";

?>