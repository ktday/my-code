<?php
include("../Misc/connect.php");

if($account['RANK']=='OWNER'){$r=6;}
elseif($account['RANK']=='MANAGER'){$r=5;}
else{exit();}


$num1 = $account['UUID'];

/*$cols = ["red","orange","yellow","green","#255052","lightblue","blue","purple","pink","black"];
$arr = [];
$tot = 0;

$q = mysqli_query($conn,"SELECT `UPLOADER` FROM `MARKET` WHERE `STATUS` = 'AP'");
while(($a = mysqli_fetch_array($q))){
  array_push($arr, $a[0]);
  
}*/

echo"

<h2>Manage Items</h2>

<form method='post'>
	<input name='umang' class='form form1l' placeholder='Item ID' type='number' required>
    <button class='button3 btn-blue'>Go</button>
</form>

<br><hr><br>

<h2> All Items: </h2>
      
<div style='overflow:scroll;'>
    
<table>

<tr>
	<th>ID</th>
    <th>Name</th>
    <th>Price</th>
    <th>Type</th>
    <th>Rarity</th>
    <th>Stock</th>
    <th>Offsale Time</th>
    <th>Status</th>
    <th colspan='2'>Actions</th>
</tr>
      
";

$usrs = mysqli_query($conn,"SELECT * FROM MARKET WHERE 1 ORDER BY ID DESC");
while(($u = mysqli_fetch_array($usrs))){
  
  if($u['ONSALE_TIME']!=0){
    $ot = gmdate("j F Y", $u['ONSALE_TIME']);
  }else{$ot = '0';}
  
  if($u['RARITY']=='EPIC'){$txtc = 'txtcol-gold';}
  elseif($u['RARITY']=='RARE'){$txtc = 'txtcol-purple';}
  elseif($u['RARITY']=='EVENT'){$txtc = 'txtcol-green';}
  elseif($u['RARITY']=='CUSTOM'){$txtc = 'txtcol-blue';}
  elseif($u['RARITY']=='VIP'){$txtc = 'txtcol-red';}
  else{$txtc = 'txtcol-white';}
  
  if($u['STOCK']!=0&&$u['STOCK_REMAINING']==0){
    $txtc2 = 'txtcol-red';
  }elseif($u['STOCK']!=0&&$u['STOCK_REMAINING']!=0){
    $txtc2 = 'txtcol-gold';
  }else{$txtc2 = 'txtcol-white';}
  
  echo"<tr>
  	<td>$u[0]</td>
  	<td>$u[NAME]</td>
  	<td>$u[PRICE] $u[PRICE_TYPE]</td>
  	<td>$u[TYPE]</td>
  	<td class='$txtc'>$u[RARITY]</td>
  	<td class='$txtc2'>$u[STOCK_REMAINING] / $u[STOCK]</td>
  	<td>$ot</td>
  	<td>$u[STATUS]</td>
    <td><a href='/Market/Item/$u[0]' class='fa fa-shopping-cart'></a></td>
    <td><a href='/Market/edit.php?id=$u[0]' class='fa fa-cog'></a></td>
  </tr>";
}

echo"
</table>
<br><br>
</div>
";


?>