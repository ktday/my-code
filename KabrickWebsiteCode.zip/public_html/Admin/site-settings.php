<?php
include("../Misc/connect.php");
$CURRENT_ECONOMY = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `CURRENT_ECONOMY` WHERE `ID` = '1'"));

if($account['RANK']=='OWNER'){$r=6;}
elseif($account['RANK']=='MANAGER'){$r=5;}
elseif($account['RANK']=='EXECUTIVE'){$r=4;}
elseif($account['RANK']=='ADMIN'){$r=3;}
else{exit();}

$num1 = $account['UUID'];

echo"

<h2>Update Noticebar</h2>
            
<form method='post'>

  <textarea class='form form1l' name='notice_bar_$num1' maxlength='200'>$CURRENT_ECONOMY[NAV_TEXT]</textarea>

  <select class='form form1l' name='notice_bar_color_$num1'>
    <option>blue</option>
    <option>green</option>
    <option>red</option>
    <option>gold</option>
    <option>orange</option>
    <option>purple</option>
  </select>
  
  ";

	if($r > 4) /* MANAGER+ */ {echo"<input class='form form1l' name='notice_bar_url_$num1' maxlength='255' placeholder='URL ($CURRENT_ECONOMY[NAV_URL])'>";}

echo"

  <button class='button3 btn-blue nd hover'>Update!</button>

</form>
  
";

?>