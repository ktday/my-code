<?php

include($_SERVER['DOCUMENT_ROOT'] . '/Misc/gamma-nav.php');

function leave() {
  echo"<script>window.location='/'</script>";exit();
}

if(!isset($_COOKIE['KABRICK_U']) || !isset($_COOKIE['KABRICK_P'])){
    leave();
}

if($account['RANK']=='OWNER'){$r=6;}
elseif($account['RANK']=='MANAGER'){$r=5;}
elseif($account['RANK']=='EXECUTIVE'){$r=4;}
elseif($account['RANK']=='ADMIN'){$r=3;}
elseif($account['RANK']=='MODERATOR'){$r=2;}
elseif($account['RANK']=='ASSET_MOD'){leave();}
elseif($account['RANK']=='FORUMS_MOD'){leave();}
elseif($account['RANK']=='ASSET_UPLOADER'){leave();}
else{leave();}

/*

CHECKLIST

R1:
forums only reports +

R1.1:
Asset Uploading +

R2.1:
Asset Accepting

R2:
Tempban
Logs
All reports +

R3:
All Ban

R4:
Manage Memberships

R5:
Grant
Add manage panel +
Manage items page
Manage clans page

R6:
Stats
Accept Assets
Regcode management

*/

//colors

if($r==1.1){
    $c_1 = "red";
    $c_2 = "orange";
    $c_3 = "red";
    $c_4 = "red";
    $c_5 = "red";
    $c_6 = "red";
}elseif($r==1){
    $c_1 = "orange";
    $c_2 = "red";
    $c_3 = "red";
    $c_4 = "red";
    $c_5 = "red";
    $c_6 = "red";
}elseif($r==2.1){
    $c_1 = "red";
    $c_2 = "blue";
    $c_3 = "red";
    $c_4 = "red";
    $c_5 = "red";
    $c_6 = "red";
}elseif($r==2){
    $c_1 = "blue";
    $c_2 = "blue";
    $c_3 = "orange";
    $c_4 = "red";
    $c_5 = "red";
    $c_6 = "red";
}elseif($r==3){
    $c_1 = "blue";
    $c_2 = "blue";
    $c_3 = "blue";
    $c_4 = "red";
    $c_5 = "red";
    $c_6 = "red";
}elseif($r==4){
    $c_1 = "blue";
    $c_2 = "blue";
    $c_3 = "blue";
    $c_4 = "blue";
    $c_5 = "red";
    $c_6 = "red";
}elseif($r==5){
    $c_1 = "blue";
    $c_2 = "blue";
    $c_3 = "blue";
    $c_4 = "blue";
    $c_5 = "blue";
    $c_6 = "red";
}elseif($r==6){
    $c_1 = "blue";
    $c_2 = "blue";
    $c_3 = "blue";
    $c_4 = "blue";
    $c_5 = "blue";
    $c_6 = "gold";
}

echo"
<title>Kabrick.tk Administration Panel</title>

<script>

function makeid(length) {
   var result           = '';
   var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789`¬¦!£$%^&*()|\-_=+[]{};:@#~<>,./?';
   var charactersLength = characters.length;
   for ( var i = 0; i < length; i++ ) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
      pass = 'Randomly Generated Password: ' + result
   }
   
   window.alert(pass);
};

function page1() {
    document.getElementById('page1').style.display = 'block';
    document.getElementById('page2').style.display = 'none';
    document.getElementById('page3').style.display = 'none';
    document.getElementById('page4').style.display = 'none';
    document.getElementById('page5').style.display = 'none';
    document.getElementById('page6').style.display = 'none';
}

function page2() {
    document.getElementById('page1').style.display = 'none';
    document.getElementById('page2').style.display = 'block';
    document.getElementById('page3').style.display = 'none';
    document.getElementById('page4').style.display = 'none';
    document.getElementById('page5').style.display = 'none';
    document.getElementById('page6').style.display = 'none';
}

function page3() {
    document.getElementById('page1').style.display = 'none';
    document.getElementById('page2').style.display = 'none';
    document.getElementById('page3').style.display = 'block';
    document.getElementById('page4').style.display = 'none';
    document.getElementById('page5').style.display = 'none';
    document.getElementById('page6').style.display = 'none';
}

function page4() {
    document.getElementById('page1').style.display = 'none';
    document.getElementById('page2').style.display = 'none';
    document.getElementById('page3').style.display = 'none';
    document.getElementById('page4').style.display = 'block';
    document.getElementById('page5').style.display = 'none';
    document.getElementById('page6').style.display = 'none';
}

function page5() {
    document.getElementById('page1').style.display = 'none';
    document.getElementById('page2').style.display = 'none';
    document.getElementById('page3').style.display = 'none';
    document.getElementById('page4').style.display = 'none';
    document.getElementById('page5').style.display = 'block';
    document.getElementById('page6').style.display = 'none';
}

function page6() {
    document.getElementById('page1').style.display = 'none';
    document.getElementById('page2').style.display = 'none';
    document.getElementById('page3').style.display = 'none';
    document.getElementById('page4').style.display = 'none';
    document.getElementById('page5').style.display = 'none';
    document.getElementById('page6').style.display = 'block';
}

</script>





<div class='doublebox box1'>
    
    <div class='platformtitle'>
        <h2>Admin Panel</h2>
    </div>
    
    <br>
    
    Your rank is: $account[RANK]
    
    <hr><br>
    
    <button onclick='page1()' class='button btn-$c_1 nd hover'>Reports & Logs</button><br>
    <button onclick='page2()' class='button btn-$c_2 nd hover'>Asset Management</button><br>
    <button onclick='page3()' class='button btn-$c_3 nd hover'>Ban & Verify</button><br>
    <button onclick='page4()' class='button btn-$c_4 nd hover'>User Management</button><br>
    <button onclick='page5()' class='button btn-$c_5 nd hover'>Manager Panel</button><br>
    <button onclick='page6()' class='button btn-$c_6 nd hover'>Owner Panel</button><br>
    
</div>

<div class='doublebox box2'>
    
    <div id='page1' style='display:none;'>
    
        <div class='platformtitle'>
            <h2>Reports and Logs</h2>
        </div>
        
        ";
        
        if($c_1=="red"){
            //cannot view
            
            echo"<h1>You Must Be Moderator (LVL3) or Forum Mod (LVL1) to access this section.</h1>";
            
        }else{
            //can view
            
            if($r==1){
                //forums mod
                
                $reports = mysqli_query($conn,"SELECT * FROM `REPORTS` WHERE `TYPE` = 'FORUM' OR `TYPE` = 'REPLY'");
                
                while(($rep=mysqli_fetch_array($reports))){
                    
                    $u = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$rep[REPORTER]'"));
                    
                    if($rep['TYPE']=='FORUM'){
                        $url = "/Forums/post.php?id=$rep[OII]";
                    }elseif($rep['TYPE']=='REPLY'){
                        $url = "/Forums/findreply.php?id=$rep[OII]";
                    }
                    
                    echo"
                    
                    <p>
                        Reporter:
                        <a href='$u[0]'>
                            $u[1]
                        </a>,
                        Offensive Item:
                        <a href='$url'>
                            $rep[OII]
                        </a>,
                        Type: $rep[TYPE]
                    </p>
                    
                    ";
                    
                }
                
            }else{
                //mod+
                
                echo"
                
                <button onclick='logs()' class='button3 btn-blue nd hover'>View Logs</button>
                
                ";
                
                $reports = mysqli_query($conn,"SELECT * FROM `REPORTS` WHERE 1");
                
                while(($rep=mysqli_fetch_array($reports))){
                    
                    $u = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$rep[REPORTER]'"));
                    
                    if($rep['TYPE']=='USER'){
                        $url = "/Users/Profile/?id=$rep[OII]";
                    }elseif($rep['TYPE']=='FORUM'){
                        $url = "/Forums/post.php?id=$rep[OII]";
                    }elseif($rep['TYPE']=='ITEM'){
                        $url = "/Market/item.php?id=$rep[OII]";
                    }elseif($rep['TYPE']=='REPLY'){
                        $url = "/Forums/findreply.php?id=$rep[OII]";
                    }elseif($rep['TYPE']=='CLAN'){
                        $url = "/Clans/clan.php?id=$rep[OII]";
                    }
                    
                    echo"
                    
                    <p>
                        Reporter:
                        <a href='$u[0]'>
                            $u[1]
                        </a>,
                        Offensive Item:
                        <a href='$url'>
                            $rep[OII]
                        </a>,
                        Type: $rep[TYPE]
                    </p>
                    
                    ";
                    
                }
                
                echo"
                
                <script>
                
                function logs() {
                    document.getElementById('logdiv').style.display = 'block';
                    document.getElementById('logdivo').style.display = 'block';
                }
                
                function clogs() {
                    document.getElementById('logdiv').style.display = 'none';
                    document.getElementById('logdivo').style.display = 'none';
                }
                
                </script>
                
                <div id='logdivo' class='logdiv wallet-overlay' style='display:none;'></div>
                
                <div id='logdiv' class='logdiv wallet-alert-overlay' style='display:none;'>
                    
                    <div class='wallet-alert'>
                        
                        <div class='platformtitle border-radius-5px'>
                            <p><u><b>Logs</b></u></p>
                        </div>
                        
                        <br><button onclick='clogs()' class='button3 btn-blue nd hover'>Close</button>
                        
                        <hr>
                        
                        ";
                        
                        $logs = mysqli_query($conn,"SELECT * FROM `LOGS` WHERE 1 ORDER BY `ID` DESC LIMIT 20");
                        
                        while(($l = mysqli_fetch_array($logs))){
                            
                            //select all ones that need the target and categorize
                            //find names based on that
                            //display
                            
                            if($l['TARGET']!=0){
                                if($l['ACTION']=='BANNED'||$l['ACTION']=='WARNED'||$l['ACTION']=='TERMED'||$l['ACTION']=='VERIFIED'||$l['ACTION']=='UNVERIFIED'||$l['ACTION']=='GRANT'||$l['ACTION']=='USERNAME_RESET'||$l['ACTION']=='AVATAR_RESET'||$l['ACTION']=='UNBAN'){
                                    //$l['ACTION']=='BANNED'||
                                    $target="<a href='/Users/Profile/?id=$l[TARGET]'>$l[TARGET]</a>";
                                }elseif($l['ACTION']=='ACCEPTED_ASSET'||$l['ACTION']=='DECLINED_ASSET'||$l['ACTION']=='ITEM_BAN'){
                                    $target="<a href='/Market/item.php?id=$l[TARGET]'>$l[TARGET]</a>";
                                }elseif($l['ACTION']=='CLAN_BAN'||$l['ACTION']=='CLAN_MOD'||$l['ACTION']=='CLAN_RESET'){
                                    $target="<a href='/Clans/clan.php?id=$l[TARGET]'>$l[TARGET]</a>";
                                }elseif($l['ACTION']=='FORUM_BAN'||$l['ACTION']=='FORUM_MOD'||$l['ACTION']=='FORUM_LOCK'||$l['ACTION']=='FORUM_PIN'){
                                    $target="<a href='/Forums/post.php?id=$l[TARGET]'>$l[TARGET]</a>";
                                }else{
                                    $target = "";
                                }
                            }else{
                                $target = "";
                            }
                            
                            if($l['ACTION']=='BANNED'){
                                $action="Banned";
                            }elseif($l['ACTION']=='WARNED'){
                                $action="Warned";
                            }elseif($l['ACTION']=='TERMED'){
                                $action="Terminated";
                            }elseif($l['ACTION']=='ACCEPTED_ASSET'){
                                $action="Accepted Asset";
                            }elseif($l['ACTION']=='DECLINED_ASSET'){
                                $action="Declined Asset";
                            }elseif($l['ACTION']=='VERIFIED'){
                                $action="Verified";
                            }elseif($l['ACTION']=='UNVERIFIED'){
                                $action="Unverified";
                            }elseif($l['ACTION']=='GRANT'){
                                $action="Granted";
                            }elseif($l['ACTION']=='CLAN_BAN'){
                                $action="Banned The Clan";
                            }elseif($l['ACTION']=='CLAN_MOD'){
                                $action="Moderated the clan";
                            }elseif($l['ACTION']=='CLAN_RESET'){
                                $action="Unmoderated/Unbanned the clan";
                            }elseif($l['ACTION']=='ITEM_BAN'){
                                $action="Banned the Item";
                            }elseif($l['ACTION']=='USERNAME_RESET'){
                                $action="Reset the Username of";
                            }elseif($l['ACTION']=='AVATAR_RESET'){
                                $action="Reset the Avatar of";
                            }elseif($l['ACTION']=='FORUM_BAN'){
                                $action="Banned/Deleted the forum post";
                            }elseif($l['ACTION']=='FORUM_MOD'){
                                $action="Moderated the forum post";
                            }elseif($l['ACTION']=='FORUM_LOCK'){
                                $action="Locked the forum post";
                            }elseif($l['ACTION']=='FORUM_PIN'){
                                $action="Pinned the forum post";
                            }elseif($l['ACTION']=='REGISTER'){
                                $action="Registered their account.";
                            }elseif($l['ACTION']=='HACK'){
                                $action="Tried to hack the site.";
                            }elseif($l['ACTION']=='UNBAN'){
                                $action="Unbanned";
                            }else{
                                $action="?";
                            }
                            
                            echo"$l[1] $action $target<br>";
                            
                        }
                        
                        echo"
                        
                    </div>
                    
                </div>
                
                ";
                
            }
            
        }
        
        echo"
    
    </div>
    
    <div id='page2' style='display:none;'>
    
        <div class='platformtitle'>
            <h2>Asset Management</h2>
        </div>
        
        ";
        
        if($c_2=="red"){
            //cannot view
            
            echo"<h1>Forum Moderators (LVL1) cannot access this section.</h1>";
            
        }else{
            
            if($r>=2.1){
                echo"
                
                <br><a class='button btn-blue nd hover' href='/Admin/assets.php'>Accept/Decline assets</a>
                
                ";
            }
            
            if(isset($_POST['itemname'])&&isset($_POST['itemdesc'])&&isset($_POST['itemprice'])&&is_numeric($_POST['itemprice'])&&isset($_POST['itempricetype'])&&isset($_POST['itemtype'])){
            $name=mysqli_real_escape_string($conn,$_POST['itemname']);
            $desc=mysqli_real_escape_string($conn,$_POST['itemdesc']);
            $price=mysqli_real_escape_string($conn,$_POST['itemprice']);
            $ptype=mysqli_real_escape_string($conn,$_POST['itempricetype']);
            $type=mysqli_real_escape_string($conn,$_POST['itemtype']);
            $stock=mysqli_real_escape_string($conn,$_POST['stock']);
            $israre=mysqli_real_escape_string($conn,$_POST['israre']);
            if($ptype=="Price Type"){echo"<script>window.location='/Admin/upload.php'</script>";exit();}if($type=="Item Type"){echo"<script>window.location='/Admin/'</script>";exit();}
            $img = $_FILES['itemimg'];
            if(isset($img)){
                if ($img["error"] > 0){
            		echo "<script>window.alert('Error: " . $img["error"] . "')</script>";echo"<script>window.location='/Admin/'</script>";exit();
            	}else{
            		$info = getimagesize($img['tmp_name']);
            		if($info === FALSE){echo"<script>window.alert('info false');window.location='/Admin/'</script>";exit();}
            		if (($info[2] !== IMAGETYPE_PNG)) {
            		   echo"<script>window.alert('Not A Valid Image file!')</script>";
            		   echo"<script>window.location='/Admin/'</script>";exit();
            		}
            		$ammOfItemQ = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE 1");
            		$ammOfItem = mysqli_num_rows($ammOfItemQ) + 1;
            		$img_dir_pre = "/home/lord7302/domains/definitelynotkabrickbeta.tk/public_html";
            		$img_dir_suf = "/Misc/IMGS/M_ASSETS/$ammOfItem.png";
            		$image_dir = $img_dir_pre.$img_dir_suf;
            		move_uploaded_file($img['tmp_name'], $image_dir);
            		$image_av = $img_dir_suf;
            		
            		if($israre!="EPIC"&&$stock!=0){$stock==0;}
            		if($israre=="EPIC"){if($stock==0){$stock=1;}$st = $stock - 1;}else{$st = 0;}
            		
            		$palette_img = imagecreatefrompng($img_dir_pre."/Misc/IMGS/avatar.png");
        			$av_img = imagecreatefrompng($img_dir_pre.$img_dir_suf);
        			imagesavealpha($palette_img, true);
        			imagecopy($palette_img,$av_img,0,0,0,0,121,181);
        
        		    imagepng($palette_img,$img_dir_pre."/Misc/IMGS/M_ASSETS/".$ammOfItem."p.png");
        		    $image_pre = "/Misc/IMGS/M_ASSETS/".$ammOfItem."p.png";
        		    
        		    $time = time();
        		    
        		    mysqli_query($conn,"INSERT INTO `MARKET` VALUES(NULL,'$name','$desc','$price','$ptype','$type','$stock','$st','$israre','$account[0]','$time','$time','$image_pre','$image_av','$ammOfItem','UAP')");
        		    mysqli_query($conn,"INSERT INTO `INV` VALUES(NULL,'$ammOfItem','$account[0]','$stock')");
        		    echo"<script>window.alert('Item Uploaded! Awaiting approval');window.location='/Market/item.php?id=$ammOfItem'</script>";exit();
            	}
            }else{echo"<script>window.alert('No images selected');window.location='/Admin/'</script>";exit();}
            
        }
            
            echo"
            
            <h1>Upload</h1>
                <form method='post' enctype='multipart/form-data'>
                    <label for='itemname'>Item name:</label> <input class='form form1l' placeholder='Item Name' name='itemname' minlength='4' maxlength='25' required><br><br>
                    <textarea class='form form1l' name='itemdesc' placeholder='Description' minlength='5' maxlength='100' required></textarea><br><br>
                    <label for='itemprice'>Price:</label> <input class='form form1l' type='number' value='0' name='itemprice' max='100000' min='0' required><br><br>
                    <select class='form form1l w10p' name='itempricetype'><option selected disabled>Price Type</option><option>COINS</option><option>BUCKS</option><option>OFFSALE</option><option>FREE</option></select><br><br>
                    <label for='itemtype'>Type:</label> <select class='form form1l w10p' name='itemtype'><option selected disabled>Item Type</option><option>HAT</option><option>FACE</option><option>GEAR</option><option>SHOULDER</option><option>MASK</option><option>BACK</option><option>BODY</option></select><br><br>
                    <input id='itemimg' type='file' name='itemimg' accept='.png'><br><br>
                    <label for='stock'>Stock (0 if not EPIC):</label> <input class='form form1l w10p' type='number' value='0' name='stock' max='100' min='0' required><br><br>
                    <select class='form form1l' name='israre'><option selected disabled>Rarity</option><option>DEF</option><option>RARE</option><option>EPIC</option></select><br><br>
                    <button class='button3 btn-blue nd hover'>Submit!</button>
                </form>
                <br>
            
            ";
            
        }
        
        echo"
    
    </div>
    
    <div id='page3' style='display:none;'>
    
        <div class='platformtitle'>
            <h2>Ban and Verify users</h2>
        </div>
        
        ";
        
        if($c_3=="red"){
            //cannot view
            
            echo"<h1>You Must Be Moderator (LVL3) to access this section.</h1>";
            
        }
        
        echo"
    
    </div>
    
    <div id='page4' style='display:none;'>
    
        <div class='platformtitle'>
            <h2>User Management</h2>
        </div>
        
        ";
        
        if($c_4=="red"){
            //cannot view
            
            echo"<h1>You Must Be Executive (LVL4) to access this section.</h1>";
            
        }else{
          //view alts
          //membership
          //rank
        }
        
        echo"
    
    </div>
    
    <div id='page5' style='display:none;'>
    
        <div class='platformtitle'>
            <h2>Manager Panel</h2>
        </div>
        
        ";
        
        if($c_5=="red"){
            //cannot view
            
            echo"<h1>You Must Be Manager (LVL5) to access this section.</h1>";
            
        }else{
            //manager, owner
            
            $time = time();
            
            if(isset($_POST['amountC'])&&isset($_POST['typeC'])&&isset($_POST['uidC'])&&is_numeric($_POST['uidC'])&&is_numeric($_POST['amountC'])){
                //currency
                $amount = mysqli_real_escape_string($conn,$_POST['amountC']);
                $type = mysqli_real_escape_string($conn,$_POST['typeC']);
                $user = mysqli_real_escape_string($conn,$_POST['uidC']);
                
                $u = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$user'"));
                
                if($type=='BUCKS'){
                    if($amount > $CURRENT_ECONOMY['BUCKS']){
                        echo"<script>window.location='/Admin/'</script>";exit();
                    }else{
                        $oldBucks = $u['BUCKS'];
                        $newBucks = $u['BUCKS'] + $amount;
                        mysqli_query($conn,"UPDATE `USERS` SET `BUCKS` = '$newBucks' WHERE `ID` = '$user'");
                        $newCoins = $CURRENT_ECONOMY['COINS'] - $amount;
                        mysqli_query($conn,"UPDATE `CURRENT_ECONOMY` SET `COINS` = '$newCoins' WHERE `ID` = '1'");
                    }
                }elseif($type=='COINS'){
                    if($amount > $CURRENT_ECONOMY['COINS']){
                        exit();
                    }else{
                        $oldBucks = $u['COINS'];
                        $newBucks = $u['COINS'] + $amount;
                        mysqli_query($conn,"UPDATE `USERS` SET `COINS` = '$newBucks' WHERE `ID` = '$user'");
                        $newCoins = $CURRENT_ECONOMY['COINS'] - $amount;
                        mysqli_query($conn,"UPDATE `CURRENT_ECONOMY` SET `COINS` = '$newCoins' WHERE `ID` = '1'");
                    }
                }else{
                    echo"<script>window.location='/Admin/'</script>";exit();
                }
                
                mysqli_query($conn,"INSERT INTO `LOGS` VALUES(NULL,'$account[0]','GRANT','$user','$amount','$time')");
                mysqli_query($conn,"INSERT INTO `MESSAGES` VALUES(NULL,'1','$user','$username has granted you $amount $type ($oldBucks to $newBucks)! Enjoy your reward!','NO','$time','Free Currency!')");
                echo"<script>window.alert('Successfully granted $amount $type to $user!');window.location='/Admin/'</script>";exit();
                
            }
            
            if(isset($_POST['amountV'])&&isset($_POST['typeV'])&&isset($_POST['uidV'])&&is_numeric($_POST['uidV'])&&is_numeric($_POST['amountV'])){
                //VIP
                $amount = mysqli_real_escape_string($conn,$_POST['amountV']);
                $type = mysqli_real_escape_string($conn,$_POST['typeV']);
                $user = mysqli_real_escape_string($conn,$_POST['uidV']);
                
                $u = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$user'"));
                
                if($type=='BUCKS'){
                    if($amount > 8400000){
                        echo"<script>window.location='/Admin/'</script>";exit();
                    }else{
                        mysqli_query($conn,"UPDATE `USERS` SET `BUCKS` = '$newBucks' WHERE `ID` = '$user'");
                    }
                }elseif($type=='COINS'){
                    if($amount > $CURRENT_ECONOMY['COINS']){
                        exit();
                    }else{
                        mysqli_query($conn,"UPDATE `USERS` SET `COINS` = '$newBucks' WHERE `ID` = '$user'");
                    }
                }elseif($type=='COINS'){
                    if($amount > $CURRENT_ECONOMY['COINS']){
                        exit();
                    }else{
                        mysqli_query($conn,"UPDATE `USERS` SET `COINS` = '$newBucks' WHERE `ID` = '$user'");
                    }
                }else{
                    echo"<script>window.location='/Admin/'</script>";exit();
                }
                
                echo"<script>window.alert('Successfully granted $amount $type to $user!');window.location='/Admin/'</script>";exit();
                
            }
            
            echo"
            
            <h2>Grant</h2>
            
            <h3>Current Economy Availiable:</h3>
            $CURRENT_ECONOMY[BUCKS] <i class='fa fa-money-bill-alt'></i> & $CURRENT_ECONOMY[COINS] <i class='fa fa-coins'></i>
            
            <hr>
            
            <p>Currency</p>
            <form method='post'>
                Amount<br>
                <input name='amountC' type='number' ";if($r!=6){echo"min='1'";}echo" max='1000' class='form form1l'><br><br>
                <select name='typeC' class='form form1l'>
                    <option>BUCKS</option>
                    <option>COINS</option>
                </select><br><br>
                User ID<br>
                <input name='uidC' type='number' class='form form1l'><br>
                <button class='button3 btn-blue nd hover'>Grant!</button>
            </form>
            
            <hr>
            
            <p>VIP</p>
            <form method='post'>
                Seconds (2800000 = 1month, 8400000 = 3 months (max))<br>
                <input name='amountV' type='number' ";if($r!=6){echo"min='1'";}echo" max='8400000' class='form form1l'><br><br>
                <select name='typeV' class='form form1l'>
                    <option>VIP</option>
                    ";if($r!==6){echo"
                    
                    <option>MEGA</option>
                    <option>ULTRA</option>
                    
                    ";}echo"
                </select><br><br>
                User ID<br>
                <input name='uidV' type='number' class='form form1l'><br>
                <button class='button3 btn-blue nd hover'>Grant!</button>
            </form>
            

                <hr>

                <p>Item</p>
                <form method='post'>
                    Which Item?<br>
                    <input name='amountI' type='number' class='form form1l'><br><br>
                    User ID<br>
                    <input name='uidI' type='number' class='form form1l'><br>
                    <button class='button3 btn-blue nd hover'>Grant!</button>
               	</form>

            
            <hr>
            
            <h2>Manage</h2>
            
            <a href='/Admin/manage-user.php' class='button3 btn-blue nd hover'>Manage User</a>
            <a href='/Admin/manage-item.php' class='button3 btn-blue nd hover'>Manage Items</a>
            <a href='/Admin/manage-clan.php' class='button3 btn-blue nd hover'>Manage Clans</a>
            
            <br><br>
            ";
            
        }
        
        echo"
    
    </div>
    
    <div id='page6' style='display:none;'>
    
        <div class='platformtitle'>
            <h2>Owner Panel</h2>
        </div>
        
        ";
        
        if($account[0]!=2){
            //cannot view
            
            echo"<h1>You Must Be Owner (LVL6) to access this section.</h1>";
            
        }else{
            //hi
          
          	$IOTW_UPDATE = date("H:i", $CURRENT_ECONOMY['IOTW_UPDATE']) . ", " . gmdate("j F Y", $CURRENT_ECONOMY['IOTW_UPDATE']);
          	$IOTW_DATE = gmdate("j F Y", $CURRENT_ECONOMY['IOTW_UPDATE']);
            
            //noticebar update
            if(isset($_POST['lv6-noticebartxt'])){
                if($account[0]!=2){
                    //hack
                    mysqli_query($conn,"UPDATE `USERS` SET `STATUS` = 'DISABLED' WHERE `ID` = '$account[0]'");
                    mysqli_query($conn,"INSERT INTO `LOGS` VALUES(NULL,'$account[0]','HACK','0','$curtime')");
                    echo"<script>window.location='/User/logout.php'</script>";
                    exit();
                }else{
                    //it be me :))
                    $txt = mysqli_real_escape_string($conn,$_POST['lv6-noticebartxt']);
                    $col = mysqli_real_escape_string($conn,$_POST['lv6-noticebarcol']);
                    
                    mysqli_query($conn,"UPDATE `CURRENT_ECONOMY` SET `NAV_TEXT` = '$txt' WHERE `ID` = '1'");
                    mysqli_query($conn,"UPDATE `CURRENT_ECONOMY` SET `NAV_COLOR` = '$col' WHERE `ID` = '1'");
                }
            }
          
            //weekly item update
            if(isset($_POST['lv6-updateweeklyitem'])){
                if($account[0]!=2){
                    //hack
                    mysqli_query($conn,"UPDATE `USERS` SET `STATUS` = 'DISABLED' WHERE `ID` = '$account[0]'");
                    mysqli_query($conn,"INSERT INTO `LOGS` VALUES(NULL,'$account[0]','HACK','0','$curtime')");
                    echo"<script>window.location='/User/logout.php'</script>";
                    exit();
                }else{
                    //it be me :))
                    $txt = mysqli_real_escape_string($conn,$_POST['lv6-updateweeklyitem']);
                    
                    mysqli_query($conn,"UPDATE `CURRENT_ECONOMY` SET `ITEM2` = '$txt' WHERE `ID` = '1'");
                }
            }
          
          //weekly item update (TIME)
            if(isset($_POST['lv6-updateweeklyitemtime'])){
                if($account[0]!=2){
                    //hack
                    mysqli_query($conn,"UPDATE `USERS` SET `STATUS` = 'DISABLED' WHERE `ID` = '$account[0]'");
                    mysqli_query($conn,"INSERT INTO `LOGS` VALUES(NULL,'$account[0]','HACK','0','$curtime')");
                    echo"<script>window.location='/User/logout.php'</script>";
                    exit();
                }else{
                    //it be me :))
                    $txt = mysqli_real_escape_string($conn,$_POST['lv6-updateweeklyitemtime']);
                  	$upd_t = strtotime($txt);
                    
                    mysqli_query($conn,"UPDATE `CURRENT_ECONOMY` SET `IOTW_UPDATE` = '$upd_t' WHERE `ID` = '1'");
                }
            }
          
          //update embed
            if(isset($_POST['lv6-update'])){
                if($account[0]!=2){
                    //hack
                    mysqli_query($conn,"UPDATE `USERS` SET `STATUS` = 'DISABLED' WHERE `ID` = '$account[0]'");
                    mysqli_query($conn,"INSERT INTO `LOGS` VALUES(NULL,'$account[0]','HACK','0','$curtime')");
                    echo"<script>window.location='/User/logout.php'</script>";
                    exit();
                }else{
                    //it be me :))
                    $txt = mysqli_real_escape_string($conn,$_POST['lv6-update']);
                    $em = mysqli_real_escape_string($conn,$_POST['lv6-update-em']);
                    
                  if($em=='tag'){
                    $e = ':label:';
                  }elseif($em=='bug'){
                    $e = ':bug:';
                  }elseif($em=='special'){
                    $e = ':sparkles:';
                  }elseif($em=='fire'){
                    $e = ':fire:';
                  }elseif($em=='art'){
                    $e = ':art:';
                  }else{
                    $e = '';
                  }
                  
                  $desc = "[$siteVerRaw] $e $txt";
                  
                  $discordWebhookUrl = "https://discord.com/api/webhooks/907378561680298044/HrYA3awemtAQypAUudhPlTG33gBv1mq4_8kTddSXD_lb-tvGUVUH_cP1eozxoRolnLDb";
                  $discordWebhookData = array(
                      "embeds" => array(
                          array("title"=>"New Update!","description"=>"$desc")#16762880 limiteds
                      ),
                      "content" => ""
                  );
                  $opts = array(
                      "http" => array(
                          "header" => "Content-Type: application/json\r\n",
                          "method" => "POST",
                          "content" => json_encode($discordWebhookData)
                      )
                  );
                  $context = stream_context_create($opts); $result = file_get_contents($discordWebhookUrl, false, $context);
                  
                }
            }
            
            echo"
            
            <br>
            
            <h2>Noticebar</h2>
            
            <form method='post'>
            
                <textarea class='form form1l' name='lv6-noticebartxt' maxlength='200'>$CURRENT_ECONOMY[NAV_TEXT]</textarea>
                
                <select class='form form1l' name='lv6-noticebarcol'>
                    <option>blue</option>
                    <option>green</option>
                    <option>red</option>
                    <option>gold</option>
                    <option>orange</option>
                    <option>purple</option>
                </select>
                
                <button class='button3 btn-blue nd hover'>Update!</button>
            
            </form>
            
            <hr>
            
            <h2>Submit Update</h2>
            
            <form method='post'>
            
                <input class='form form1l' name='lv6-update' maxlength='200'>
                
                <select class='form form1l' name='lv6-update-em'>
                    <option>tag</option>
                    <option>bug</option>
                    <option>special</option>
                    <option>fire</option>
                    <option>art</option>
                    <option>none</option>
                </select>
                
                <button class='button3 btn-blue nd hover'>Submit!</button>
            
            </form>
            
            <hr>
            
            <h2>Next Weekly Item</h2>
            
            <form method='post'>
            
                <input class='form form1l' name='lv6-updateweeklyitem' type='number'>
                
                <button class='button3 btn-blue nd hover'>Update!</button><br><br>
                
                <a href='/Market/item.php?id=$CURRENT_ECONOMY[ITEM]' class='button3 btn-blue nd hover'>Current Weekly Item: $CURRENT_ECONOMY[ITEM]</a>
            	<a href='/Market/item.php?id=$CURRENT_ECONOMY[ITEM2]' class='button3 btn-blue nd hover'>Next Weekly Item: $CURRENT_ECONOMY[ITEM2]</a><br><br><br>
                
                $IOTW_UPDATE
            
            </form>
            
            <h2>Force time</h2>
            
            <form method='post'>
            
            	<input class='form form1l' name='lv6-updateweeklyitemtime' type='text' value='$IOTW_DATE'>
            
            </form>
            
            <hr>
            
            <h2>Manage</h2>
            
            <a href='/Admin/manage-user.php' class='button3 btn-blue nd hover'>Manage User</a>
            <a href='/Admin/manage-item.php' class='button3 btn-blue nd hover'>Manage Items</a>
            <a href='/Admin/manage-clan.php' class='button3 btn-blue nd hover'>Manage Clans</a>
            
            <br><br><br>
            
            <a href='/Admin/execute.php' class='button3 btn-gold nd hover'>EXECUTE</a>
            <a href='/Admin/stats.php' class='button3 btn-blue nd hover'>Stats</a>
            
            <br><br><br>
            <hr>
            <br>
            
            ";
            
        }
        
        echo"
    
    </div>
    
</div>

</div>

";

?>