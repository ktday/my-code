<?php
include("../Misc/connect.php");
$CURRENT_ECONOMY = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `CURRENT_ECONOMY` WHERE `ID` = '1'"));

if($account['RANK']=='OWNER'){$r=6;}
elseif($account['RANK']=='MANAGER'){$r=5;}
elseif($account['RANK']=='EXECUTIVE'){$r=4;}
elseif($account['RANK']=='ADMIN'){$r=3;}
elseif($account['RANK']=='MODERATOR'){$r=2;}
elseif($account['RANK']=='ASSET_UPLOADER'){$r=1;}
else{exit();}

$num1 = $account['UUID'];

$prCs = mysqli_query($conn,"SELECT * FROM `DEVLOG` WHERE 1 ORDER BY ID DESC");

echo"

<div class='platformtitle'>
	<h2>Devlog</h2>
</div>

<table>

<tr>
	<th>ID</th>
	<th>Date</th>
	<th>Time</th>
	<th>Update</th>
	<th>Backend Ver</th>
	<th>Frontend Ver</th>
	<th>Database Ver</th>
	<th>Devlog</th>
</tr>

";

while(($p = mysqli_fetch_array($prCs))){
  
  $t = date("H:i", $p['TIME'] + 18000);# . gmdate("j F Y", $p['TIME_CREATE']);
  
  $verlen = count(explode('.',$p['VER']));
  $veruds = count(explode('_',$p['VER']));
  if($veruds >= 2){$txtcol='bronze';}
  elseif($verlen == 2){$txtcol = 'red';}
  elseif($verlen == 3){$txtcol = 'gold';}
  elseif($verlen == 4){$txtcol='silver';}
  
  echo"
  
  <tr class='txtcol-$txtcol'>
  	<td>$p[0]</td>
  	<td>$p[DATE]</td>
  	<td>$t</td>
  	<td>$p[VER]</td>
  	<td>$p[BVER]</td>
  	<td>$p[FVER]</td>
  	<td>$p[DVER]</td>
  	<td>$p[NOTES]</td>
  </tr>
  
  ";
  
}

echo"

</table>
            

  
";

?>