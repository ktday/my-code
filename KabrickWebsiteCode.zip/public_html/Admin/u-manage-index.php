<?php
include("../Misc/connect.php");

if($account['RANK']=='OWNER'){$r=6;}
elseif($account['RANK']=='MANAGER'){$r=5;}
else{exit();}


$num1 = $account['UUID'];

echo"

<h2>Manage Users</h2>

<form method='post'>
	<input name='umang' class='form form1l' placeholder='Username'>
    <button class='button3 btn-blue'>Go</button>
</form>

<br><hr><br>

<h2> All Users: </h2>

<div style='overflow:scroll;'>
      
<table>

<tr>
	<th>ID</th>
    <th>Userame</th>
    <th>Rank</th>
    <th>Status</th>
    <th>VIP</th>
    <th>Coins</th>
    <th>Bucks</th>
    <th>Can gift</th>
    <th colspan='3'>Actions</th>
</tr>
      
";

$usrs = mysqli_query($conn,"SELECT * FROM USERS WHERE 1");
while(($u = mysqli_fetch_array($usrs))){
  
  if($u['STATUS']=='BANNED'){$tc1 = 'orange';}elseif($u['STATUS']=='DISABLED'){$tc1 = 'red';}else{$tc1 = 'white';}
  if($u['VIP']=='VIP'){$tc2 = 'green';}elseif($u['VIP']=='MEGA'){$tc2 = 'blue';}elseif($u['VIP']=='ULTRA'){$tc2 = 'gold';}else{$tc2 = 'white';}
  /*if($u['RANK']=='ADMIN'){$tc3 = 'red';}
  elseif($u['RANK']=='MODERATOR'||$u['RANK']=='ASSET_UPLOADER'){$tc3 = 'blue';}
  elseif($u['RANK']=='MANAGER'||$u['RANK']=='EXECUTIVE'){$tc3 = 'green';}
  elseif($u['RANK']=='OWNER'){$tc3 = 'gold';}
  else{$tc3 = 'white';}*/
  $urnk = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `ROLES` WHERE `NAME` = '$u[RANK]'"));
  $tc3 = $urnk['COLOR'];
  if($u['CAN_GIFT']=='TRUE'){$tc4 = 'green';}else{$tc4 = 'red';}
  
  echo"<tr>
  	<td>$u[0]</td>
  	<td>$u[USERNAME]</td>
  	<td style='color:$tc3'>$u[RANK]</td>
  	<td class='txtcol-$tc1'>$u[STATUS]</td>
  	<td class='txtcol-$tc2'>$u[VIP]</td>
  	<td>$u[COINS]</td>
  	<td>$u[BUCKS]</td>
  	<td class='txtcol-$tc4'>$u[CAN_GIFT]</td>
    <td><a href='/Profile/$u[USERNAME]' class='fa fa-user'></a></td>
    <td><a href='/Admin/manage.php?id=$u[USERNAME]' class='fa fa-cog'></a></td>
    <td><a href='/Admin/?BAN=$u[USERNAME]' class='fa fa-hammer'></a></td>
  </tr>";
}

echo"
</table>
<br><br>
</div>
";


?>