<?php
include("../Misc/connect.php");
include("../Misc/vars.php");
$CURRENT_ECONOMY = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `CURRENT_ECONOMY` WHERE `ID` = '1'"));

if($account['RANK']=='OWNER'){$r=6;}
elseif($account['RANK']=='MANAGER'){$r=5;}
else{exit();}

$num1 = $account['UUID'];

if(isset($_GET['id'])){
  $id = mysqli_real_escape_string($conn,$_GET['id']);
  if($account['RANK']=='OWNER'){
    $p = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `PROMOCODES` WHERE `ID` = '$id'"));
    if($p['ISACTIVE']==1){
      #disable it
      mysqli_query($conn,"UPDATE `PROMOCODES` SET `ISACTIVE` = '0', `TIME_REMOVE` = '$time' WHERE `ID` = '$id'");
    }else{
      #enable it
      mysqli_query($conn,"UPDATE `PROMOCODES` SET `ISACTIVE` = '1', `TIME_REMOVE` = '0' WHERE `ID` = '$id'");
    }
  }
  echo"<script>window.location='/Admin/'</script>";
  exit();
}

if(isset($_GET['c'])){
  $id = mysqli_real_escape_string($conn,$_GET['c']);
  if($account['RANK']=='OWNER'){
    $p = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `GIFTS` WHERE `ID` = '$id'"));
    if($p['REDEEMED_BY']==0){
      #disable it
      mysqli_query($conn,"UPDATE `CODES` SET `REDEEMED_BY` = '-99' WHERE `ID` = '$id'");
    }else{
      #enable it
      mysqli_query($conn,"UPDATE `CODES` SET `REDEEMED_BY` = '0' WHERE `ID` = '$id'");
    }
  }
  echo"<script>window.location='/Admin/'</script>";
  exit();
}

if(isset($_POST['codeNameKbrk']) && isset($_POST['amountReward']) && isset($_POST['bucksOrItem']) && isset($_POST['maxUsesKbrk'])){
  if($r==6){
    $code = mysqli_real_escape_string($conn,$_POST['codeNameKbrk']);
    $itid = mysqli_real_escape_string($conn,$_POST['amountReward']);
    $bori = mysqli_real_escape_string($conn,$_POST['bucksOrItem']);
    $maxu = mysqli_real_escape_string($conn,$_POST['maxUsesKbrk']);
    
    $p = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM `PROMOCODES` WHERE `CODE` = '$code'"));
    if($p>0){echo"<script>window.alert('That code already exists');window.location='/Admin/'</script>";}
    
    if($bori == "item"){$ic = 0;}
    elseif($bori == "bucks"){$ic = 1;}
    else{exit();}
    $time = time();
    
    $q = $conn->prepare("INSERT INTO `PROMOCODES` VALUES(NULL,?,?,?,'0',?,'0','1',?)");
    $q->bind_param("siiii",$code,$itid,$ic,$time,$maxu);
    $q->execute();
    
  	echo"<script>window.location='/Admin/'</script>";
  	exit();

  }
}

$prCs = mysqli_query($conn,"SELECT * FROM `PROMOCODES` WHERE 1");

echo"

<div class='platformtitle'>
	<h2>Active Promocodes</h2>
</div>

<table>

<tr>
	<th>ID</th>
	<th>Code</th>
	<th>Value</th>
	<th>Uses</th>
	<th>Date Created</th>
	<th>Date Removed</th>
    ";if($r==6){echo"<th></th>";}echo"
</tr>

";

while(($p = mysqli_fetch_array($prCs))){
  
  if($p['ISACTIVE']!=1 || $p['TIME_REMOVE']!=0){ $tr = date("H:i, ", $p['TIME_REMOVE']) . gmdate("j F Y", $p['TIME_REMOVE']); $tx = "red"; } else { $tr = "ACTIVE"; $tx = "green"; }
  
  if($p['ISCASH']==1){
    $v = "<i class='fa fa-money-bill-alt'></i> $p[ITEMID]";
  }else{
    $v = "<a href='/Market/item.php?id=$p[ITEMID]' class='txtcol-$tx'>Item ID $p[ITEMID]</a>";
  }
  
  $t = date("H:i, ", $p['TIME_CREATE']) . gmdate("j F Y", $p['TIME_CREATE']);
  
  echo"
  
  <tr>
  	<td class='txtcol-$tx'>$p[0]</td>
  	<td class='txtcol-$tx'>$p[CODE]</td>
  	<td class='txtcol-$tx'>$v</td>
  	<td class='txtcol-$tx'>$p[USES] / $p[MAXUSES]</td>
  	<td class='txtcol-$tx'>$t</td>
  	<td class='txtcol-$tx'>$tr</td>
    ";if($ar==6){echo"<td><a href='/Admin/codes.php?id=$p[0]' class='nd fas fa-times'></a></td>";}echo"
  </tr>
  
  ";
  
}

echo"</table><br><h3>Create Promocode</h3>";

if($ar == 6){
  echo"
  
  <form method='post' action='/Admin/codes.php'>
  
  	<input name='codeNameKbrk' class='form form1l' placeholder='Code' style='text-transform: uppercase;'><br>
    <input name='amountReward' class='form form1l' placeholder='Item id OR Bucks' type='number'><br>
    <input name='bucksOrItem'  type='radio' value='item' checked> Item
    <input name='bucksOrItem'  type='radio' value='bucks'> Bucks
    <br><br>
    <input name='maxUsesKbrk' class='form form1l' placeholder='Max uses (0=infinite)' type='number' value='0'><br>
    <button class='button3 btn-blue nd hover'>Create!</button>
  
  </form>
  
  ";
}

echo"
            
<br><hr>

<h1>VIP Codes</h1>
<h3>Active:</h3>

<table>

<tr>
	<th>ID</th>
	<th>Code</th>
	<th>Type</th>
	<th>Creator</th>
	<th>Time</th>
	";if($r==6){echo"<th></th>";}echo"
</tr>

";

$AVCs = mysqli_query($conn,"SELECT * FROM `GIFTS` WHERE `REDEEMED_BY` = '0'");
$UVCs = mysqli_query($conn,"SELECT * FROM `GIFTS` WHERE `REDEEMED_BY` != '0'");

while(($c = mysqli_fetch_array($AVCs))){
  if($r==6){$code = $c['CODE'];}else{$code = "<CENSORED>";}
  $t = date("H:i, ", $c['TIME']) . gmdate("j F Y", $c['TIME']);
  $creator = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$c[SENT_BY]'"));
  
  echo"
  
  <tr>
  	<td>$c[0]</td>
  	<td>$code</td>
  	<td>$c[TYPE]</td>
  	<td><a href='/Users/Profile/$creator[1]'>$creator[1]</a></td>
  	<td>$t</td>
	";if($r==6){echo"<td><a href='/Admin/codes.php?c=$c[0]' class='nd fas fa-times'></a></td>";}echo"
  </tr>
  
  ";
}

echo"

</table>
<h3>Used / Inactive:</h3>

<table>

<tr>
	<th>ID</th>
	<th>Code</th>
	<th>Type</th>
	<th>Creator</th>
	<th>Time</th>
</tr>

";

while(($c = mysqli_fetch_array($UVCs))){
  #if($r==6){$code = $c['CODE'];}else{$code = "<CENSORED>";}
  $t = date("H:i, ", $c['TIME']) . gmdate("j F Y", $c['TIME']);
  $creator = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$c[SENT_BY]'"));
  
  echo"
  
  <tr>
  	<td>$c[0]</td>
  	<td>$c[CODE]</td>
  	<td>$c[TYPE]</td>
  	<td><a href='/Users/Profile/$creator[1]'>$creator[1]</a></td>
  	<td>$t</td>
  </tr>
  
  ";
}

echo"

</table>
  
";

?>