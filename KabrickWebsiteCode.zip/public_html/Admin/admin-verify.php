<?php
include("../Misc/connect.php");
$ITEMS = mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `STATUS` = 'UAP'");

if($account['RANK']=='OWNER'){$r=6;}
elseif($account['RANK']=='MANAGER'){$r=5;}
else{exit();}

$UUID = $account['UUID'];

echo"

<h2>Verify Items (LVL2)</h2>
            
";

if(mysqli_num_rows($ITEMS)==0){
  echo"There are no items to verify!";
}else{
  while(($i=mysqli_fetch_array($ITEMS))){
    $u = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$i[UPLOADER]'"));
    
    echo"
    
    <div style='height:181px;'>
    
      <img src='$i[AV_IMG]' class='fl' style='left:1rem;'>
      
      <p><b>$i[NAME] ($i[ID])</b></p>
      
      \"$i[DESCRIPTION]\"<br>
      
      $i[PRICE] $i[PRICE_TYPE]<br>
      
      $i[TYPE]<br>
      
      Stock: $i[STOCK], $i[RARITY], Onsale Time: ". $i['ONSALE_TIME']/3600 ."h<br>
      
      <form method='post'>
      	<button name='a_$UUID' value='$i[0]' class='button3 btn-green nd hover'>Accept</button>
      	<button name='asa_$UUID' value='$i[0]' class='button3 btn-green nd hover'>Accept Without Ping</button>
      	<button name='d_$UUID' value='$i[0]' class='button3 btn-red nd hover'>Decline</button>
      </form>
    
    </div>
    
    ";
    
  }
}

?>