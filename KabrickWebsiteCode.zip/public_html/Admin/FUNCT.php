<?php

include_once($_SERVER['DOCUMENT_ROOT'] . '/Misc/connect.php');
include_once($_SERVER['DOCUMENT_ROOT'] . '/Misc/vars.php');

function formatAction($act){
  $actions = [
    0=>'Hacked',
    1=>'Changed notice bar',
    2=>'Granted currency',
    3=>'Uploaded item',
    4=>'Accepted',
    5=>'Declined',
    6=>'Banned',
    7=>'Accepted (User item)',
    8=>'Declined (User item)',
    9=>'Accepted Clan',
    10=>'Declined Clan',
    50=>'Changed the rank of a user',
    51=>'Granted an item to a user',
    52=>'Granted the E-Ward to a user',
    53=>'Changed the bio of a user',
    54=>'Updated the CAN_GIFT status of a user',
    55=>'Updated the username of a user',
    56=>'Updated the forum banned status of a user',
    99=>'Created a gift',
    150=>'Changed the description of an item',
    151=>'Changed the price of an item',
    152=>'Deleted an item'
  ];
  return $actions[$act];
}

function formatText($act,$user,$det){
  global $conn;
  if($act == 0){
    $text = "";
  }elseif($act==1||$act==3||$act==99||$act==50||$act==51||$act==52||$act==53||$act==54||$act==55||$act==56){
    $text = $det; 
  }elseif($act==2){ //Granted Currency
    $u = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$user'"));
    $text = "$det -> [$user] $u[USERNAME]";
  }elseif($act==6){ //Banned
    $u = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `USERS` WHERE `ID` = '$user'"));
    $text = "$u[USERNAME] ($user) was banned for: $det";
  }elseif($act==4||$act==5||$act==7||$act==8){ //Accepted || Declined
    $i = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `MARKET` WHERE `ID` = '$det'"));
    $text = "[$det] $i[NAME]";
  }elseif($act==150||$act==151){
    $text = "[$user] $det";
  }else{
    $text = $det;
  }
  return $text;
}

function logAction($action,$user,$det = '') {
  global $conn;
  global $account;
  global $curtime;
  $query = mysqli_query($conn,"INSERT INTO `NEWLOGS` VALUES(NULL,'$account[0]','$action','$det','$user','$curtime')");
  $text = formatText($action,$user,$det);
  $discordWebhookUrl = "https://discord.com/api/webhooks/1026936015539163196/sFsdbfdP6q_OahTFgjJOWLOTYKwtZ_tQiNdD5E8gorcGfK7e2ZogxNeZPeeWtqI17ucw";
  $discordWebhookData = array(
    "embeds" => array(
      array("title"=>"$account[1] " . formatAction($action),"description"=>$text)#16762880 limiteds
    )
  );
  $opts = array(
    "http" => array(
      "header" => "Content-Type: application/json\r\n",
      "method" => "POST",
      "content" => json_encode($discordWebhookData)
    )
  );
  $context = stream_context_create($opts); $result = file_get_contents($discordWebhookUrl, false, $context);
  return $query;
}

function iNotif($id) {
  global $conn;
  global $meta_blank_url;
  $title="New Item!";
  $infoQ = mysqli_query($conn, "SELECT * FROM `MARKET` WHERE `ID`='$id'");
  $info = mysqli_fetch_array($infoQ);
  if($info['PRICE_TYPE']=="BUCKS"){$desc = "Details:\nName: $info[NAME]\nPrice: $info[PRICE] Bucks";}
	if($info['PRICE_TYPE']=="COINS"){$desc = "Details:\nName: $info[NAME]\nPrice: $info[PRICE] Coins";}
	if($info['PRICE_TYPE']=="OFFSALE"){$desc = "Details:\nName: $info[NAME]\nPrice: Offsale";}
	if($info['PRICE_TYPE']=="FREE"){$desc = "Details:\nName: $info[NAME]\nPrice: Free!";} //COMP 
  	//<@&790255759878914108>
  
  if($info['RARITY'] == 'EPIC'){$cont = "<@&790255759878914108> <@&1138551783522832416>";}else{$cont = "<@&790255759878914108>";}
  
  if($info['RARITY']=='EPIC'){$col='13806637';}
  elseif($info['RARITY']=='RARE'){$col='6684859';}
  elseif($info['RARITY']=='EVENT'){$col='65365';}
  else{$col='16777215';}
  $discordWebhookUrl = "https://discord.com/api/webhooks/759859645937877052/2Ok1Xt7eja4WhdgRR4lSshe0oSinjhl-wlSdlgPFIXK0LUulKcpBH6Gwu87N_BNBCT4D";
  $discordWebhookData = array(
    "embeds" => array(
      array("title"=>$title,"description"=>$desc,"color"=>$col,"url"=>"http://$meta_blank_url/Market/Item/$id")#16762880 limiteds
    ),
    "content" => $cont
  );
  $opts = array(
    "http" => array(
      "header" => "Content-Type: application/json\r\n",
      "method" => "POST",
      "content" => json_encode($discordWebhookData)
    )
  );
  $context = stream_context_create($opts); $result = file_get_contents($discordWebhookUrl, false, $context);
  return 1;
}

function appUpdate($changelog = ["None"], $version){
  $string = "";
  foreach($changelog as $i){
    $string .= "- " . $i . "\n";
  }
  $discordWebhookUrl = "https://discord.com/api/webhooks/1199647576589340733/qKW6GUl5LATLPnLfZEU-7xndeEjw0Y1BwtEBNulVHUczYzfSMVAnv66z5aVMzZaYQk9d";
  $discordWebhookData = array(
    "embeds" => array(
      array("title"=>"App Version " . $version,"description"=>$string,"color"=>"65365")#16762880 limiteds
    ),
    "content" => $cont
  );
  $opts = array(
    "http" => array(
      "header" => "Content-Type: application/json\r\n",
      "method" => "POST",
      "content" => json_encode($discordWebhookData)
    )
  );
  $context = stream_context_create($opts); $result = file_get_contents($discordWebhookUrl, false, $context);
  return 1;
}

?>