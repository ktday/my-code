<?php
include("../Misc/connect.php");

$UUID = $account['UUID'];

echo"

<h1>Upload Item</h1>

<form method='post' enctype='multipart/form-data'>
    <label for='upl_name_$UUID'>Item name:</label> <input class='form form1l' placeholder='Item Name' name='upl_name_$UUID' minlength='4' maxlength='25' required><br><br>
    <textarea class='form form1l' name='upl_desc_$UUID' placeholder='Description' minlength='5' maxlength='100' required></textarea><br><br>
    <label for='upl_price_$UUID'>Price:</label> <input class='form form1l' type='number' value='0' name='upl_price_$UUID' max='100000' min='0' required><br><br>
    <select class='form form1l w10p' name='upl_pt_$UUID'><option selected disabled value='select'>Price Type</option><option>COINS</option><option>BUCKS</option><option>OFFSALE</option><option>FREE</option></select><br><br>
    <label for='upl_type_$UUID'>Type:</label> <select class='form form1l w10p' name='upl_type_$UUID'><option selected disabled value='select'>Item Type</option><option>HAT</option><option>FACE</option><option>GEAR</option><option>SHOULDER</option><option>MASK</option><option>BACK</option><option>BODY</option><option>PET</option></select><br><br>
    <input id='itemimg' type='file' name='upl_img_$UUID' accept='.png'><br><br>
    <label for='upl_stock_$UUID'>Stock (0 if not EPIC):</label> <input class='form form1l w10p' type='number' value='0' name='upl_stock_$UUID' max='100' min='0' required><br><br>
    <select class='form form1l' name='upl_rarity_$UUID'><option selected disabled value='select'>Rarity</option><option>DEF</option><option>RARE</option><option>EPIC</option></select><br><br>
    <label for='upl_onst_$UUID'>Onsale time in hours (0 if not Timer Item):</label> <input class='form form1l w10p' type='number' value='0' name='upl_onst_$UUID' max='1000' min='0' required><br><br>
    <button class='button3 btn-blue nd hover'>Submit!</button>
</form>

<p class='small1'>For help & more info, visit <u>Staff Info</u></p>
<br>
";

?>