<?php
$number = 1;

function ass(){
  global $number;
  echo($number);
}

ass();