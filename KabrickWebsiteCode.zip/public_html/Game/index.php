<!DOCTYPE html>
<!-- Green to move. Red to stop. Grey for reverse. Click/up arrow to jump -->
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <title>Game</title>
    <link href="index.css" rel="stylesheet" type="text/css" />
    <script src="https://wzrd.repl.it/bundle/p5"></script><script src="https://cdnjs.cloudflare.com/ajax/libs/p5.js/0.6.0/p5.js"></script>
  </head>
  
  <body>
  	
  	<script src="Property.js"></script>
    <script src="index.js"></script>
	<script>
		window.onload = function() {
			var cv = document.getElementById("defaultCanvas0");
			cv.style.position = "absolute";
			cv.style.left = (window.innerWidth/2 - 300) + "px";
			cv.style.top = "50px";
			cv.style.border = "solid 5px green";
		}
	</script>
    
  </body>
</html>