package com.kabrick.radio7302;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements Player.OnCompletionListener {

    ServerConnectionChecker serverConnectionChecker;
    PopupHandler popupHandler;
    Player player;
    Counter counter;
    NotificationHelper notificationHelper;

    SharedPreferences sharedPreferences;
    RequestQueue requestQueue;

    ConstraintLayout loadingOverlay;

    // Panels
    ConstraintLayout pg_home;
    LinearLayout pg_stations;
    ConstraintLayout pg_song;

    // Variables
    String currentStationID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);

        /* Setup popup before connection check, in case of error */
        popupHandler = new PopupHandler(this);
        TextView popup_title = findViewById(R.id.popup_header);
        TextView popup_info = findViewById(R.id.popup_info);
        Button popup_btn1 = findViewById(R.id.popup_btn_1);
        Button popup_btn2 = findViewById(R.id.popup_btn_2);
        ConstraintLayout popup_layout = findViewById(R.id.pg_popup);
        popupHandler.Bind(
                popup_layout,
                popup_title,
                popup_info,
                popup_btn1,
                popup_btn2
        );

        player = new Player(this);
        player.setOnCompletionListener(this);

        loadingOverlay = findViewById(R.id.pg_loading);
        loadingOverlay.setVisibility(View.VISIBLE);

        pg_home = findViewById(R.id.pg_home);
        pg_stations = findViewById(R.id.pg_stations);
        pg_song = findViewById(R.id.pg_song);

        requestQueue = Volley.newRequestQueue(this);

        serverConnectionChecker = new ServerConnectionChecker(this);
        serverConnectionChecker.reset();
        serverConnectionChecker.check();

        notificationHelper = new NotificationHelper(this);

        counter = new Counter(this);

        final Handler handler = new Handler(Looper.getMainLooper());
        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                if(serverConnectionChecker.checked){
                    if(serverConnectionChecker.error){
                        // Error -> show popup
                        popupHandler.createPopup(
                                getString(R.string.popup_connerr_h),
                                getString(R.string.popup_connerr_i),
                                2,
                                0
                        );
                        // Remove loading overlay
                        loadingOverlay.setVisibility(View.GONE);
                    }else{
                        if(!serverConnectionChecker.connected){
                            // Server is down -> show popup
                            popupHandler.createPopup(
                                    getString(R.string.popup_conninv_h),
                                    getString(R.string.popup_conninv_i),
                                    2,
                                    0
                            );
                            // Remove loading overlay
                            loadingOverlay.setVisibility(View.GONE);
                        }else{
                            // Dont setup :) -> Check version shit now :D

                            serverConnectionChecker.getDetails();

                            Runnable runnable1 = new Runnable() {
                                @Override
                                public void run() {
                                    if(serverConnectionChecker.verChecked){
                                        // Remove loading overlay
                                        loadingOverlay.setVisibility(View.GONE);
                                        if(serverConnectionChecker.verError){
                                            // Server is down -> show popup
                                            popupHandler.createPopup(
                                                    getString(R.string.popup_vconninv_h),
                                                    getString(R.string.popup_vconninv_i),
                                                    2,
                                                    0
                                            );
                                        }else{
                                            if(!serverConnectionChecker.Active){
                                                // Radio is inactive -> show popup
                                                popupHandler.createPopup(
                                                        getString(R.string.popup_vnoactiv_h),
                                                        getString(R.string.popup_vnoactiv_i),
                                                        2,
                                                        0
                                                );
                                            }else{
                                                if(serverConnectionChecker.reqUpdate){
                                                    // Server is down -> show popup
                                                    popupHandler.createPopup(
                                                            getString(R.string.popup_vupdate_h),
                                                            getString(R.string.popup_vupdate_i),
                                                            2,
                                                            0
                                                    );
                                                }else{
                                                    // Setup strings, etc
                                                    TextView versionTV = findViewById(R.id.version);
                                                    TextView versionTV1 = findViewById(R.id.song_version);

                                                    versionTV.setText(getString(R.string.pl_version, ServerConnectionChecker.app_version));
                                                    versionTV1.setText(getString(R.string.pl_version, ServerConnectionChecker.app_version));

                                                    if(!ServerConnectionChecker.app_version.equals(serverConnectionChecker.LatestVersion)){
                                                        Log.e("Version is Nonidentical", ServerConnectionChecker.app_version + " - " + serverConnectionChecker.LatestVersion);
                                                        TextView UpdateReq = findViewById(R.id.update_msg);
                                                        UpdateReq.setText(getString(R.string.update, serverConnectionChecker.LatestVersion));
                                                        UpdateReq.setVisibility(View.VISIBLE);

                                                        TextView UpdateReq1 = findViewById(R.id.song_update_msg);
                                                        UpdateReq1.setText(getString(R.string.update, serverConnectionChecker.LatestVersion));
                                                        UpdateReq1.setVisibility(View.VISIBLE);
                                                    }

                                                    // Okay now setup
                                                    setup();
                                                }
                                            }
                                        }
                                    }else{
                                        Log.i("Version Checker", "Waiting for connection");
                                        handler.postDelayed(this, 1000);
                                    }
                                }
                            };

                            handler.postDelayed(runnable1, 1000);
                        }
                    }
                }else{
                    Log.i("Connection Checker", "Waiting for connection");
                    handler.postDelayed(this, 1000);
                }
            }
        };
        handler.postDelayed(runnable, 1000);
    }

    void setup(){
        sharedPreferences = getSharedPreferences("LocalStore", MODE_PRIVATE);

        boolean loggedin = true;//sharedPreferences.getBoolean("LoggedIn", false);
        if(!loggedin){
            Intent intent = new Intent(this, Login.class);
            startActivity(intent);
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS},99);
            }
        }

        Button connectBtn = findViewById(R.id.btn_connect);
        connectBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pg_home.setVisibility(View.GONE);
                pg_stations.setVisibility(View.VISIBLE);
                pg_song.setVisibility(View.GONE);
            }
        });

        ImageButton disconnectBtn = findViewById(R.id.btn_disconnect);
        disconnectBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                player.stop();
                notificationHelper.removeNotification();
                counter.stop();

                pg_home.setVisibility(View.GONE);
                pg_stations.setVisibility(View.VISIBLE);
                pg_song.setVisibility(View.GONE);
            }
        });

        ImageButton homeBtn = findViewById(R.id.btn_home);
        homeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pg_home.setVisibility(View.VISIBLE);
                pg_stations.setVisibility(View.GONE);
                pg_song.setVisibility(View.GONE);
            }
        });

        SeekBar volumeBar = findViewById(R.id.song_volume);
        volumeBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                if (i == 0){
                    player.setVolume(0f);
                }else if(i == 1){
                    player.setVolume(0.1f);
                }else if(i == 2){
                    player.setVolume(0.2f);
                }else if(i == 3){
                    player.setVolume(0.4f);
                }
            }

            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        ImageButton reloadBtn = findViewById(R.id.btn_refresh);
        reloadBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                LinearLayout stationsList = findViewById(R.id.station_list);
                stationsList.removeAllViews();

                String URL = ServerConnectionChecker.urlBase + "/radio/getStations.php";
                StringRequest stringRequest = new StringRequest(URL, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try{
                            JSONArray jsonArray = new JSONArray(response);
                            LayoutInflater layoutInflater = LayoutInflater.from(MainActivity.this);
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject jsonObject = jsonArray.getJSONObject(i);

                                String name = jsonObject.getString("name");
                                String playing = jsonObject.getString("playing");
                                String creator = jsonObject.getString("creator");
                                int priority = jsonObject.getInt("priority");
                                String id = jsonObject.getString("id");

                                View card = layoutInflater.inflate(R.layout.station, stationsList, false);

                                TextView tvName = card.findViewById(R.id.st_title);
                                TextView tvPlaying = card.findViewById(R.id.st_playing);
                                TextView tvCreator = card.findViewById(R.id.st_creator);

                                tvName.setText(name);
                                tvPlaying.setText(playing);
                                tvCreator.setText(creator);

                                ImageButton btn = card.findViewById(R.id.st_play);
                                btn.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        currentStationID = id;
                                        playStation(id);
                                    }
                                });

                                stationsList.addView(card);
                            }
                            Date currentTime = new Date();
                            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm", Locale.getDefault());
                            String formattedTime = sdf.format(currentTime);

                            TextView time = findViewById(R.id.last_load_time);
                            time.setText("Last updated at " + formattedTime);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();
                    }
                });

                requestQueue.add(stringRequest);
            }
        });
    }

    void playStation(String stationID){
        loadingOverlay.setVisibility(View.VISIBLE);

        String URL = ServerConnectionChecker.urlBase + "/radio/getStationSong.php?id=" + stationID;
        StringRequest stringRequest = new StringRequest(URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                if(response.equals("0")) {
                    popupHandler.createPopup(
                            getString(R.string.popup_nosongp_h),
                            getString(R.string.popup_nosongp_i),
                            1, // Close popup
                            0 // Nothing
                    );
                    loadingOverlay.setVisibility(View.GONE);
                    StringRequest stringRequest1 = new StringRequest(ServerConnectionChecker.urlBase + "/radio/genRandomRadio.php?id=" + stationID,
                    new Response.Listener<String>() {@Override public void onResponse(String response) {playStation(stationID);}},
                    new Response.ErrorListener(){@Override public void onErrorResponse(VolleyError error) {error.printStackTrace();}});
                    requestQueue.add(stringRequest1);

                }else if(response.equals("-1")){
                    popupHandler.createPopup(
                            getString(R.string.popup_invstat_h),
                            getString(R.string.popup_invstat_i),
                            1, // Close popup
                            0 // Nothing
                    );
                    loadingOverlay.setVisibility(View.GONE);
                }else{
                    try{
                        JSONObject jsonObject = new JSONObject(response);

                        // calc start offset
                        //long timeNow = System.currentTimeMillis();
                        //long songStart = jsonObject.getInt("start") * 1000L;
                        //long startOffset = timeNow - songStart;
                        long startOffset = jsonObject.getInt("startOffset") * 1000L;

                        // try another way
                        long timeNow = System.currentTimeMillis();
                        long songStart = timeNow - (jsonObject.getInt("startOffset") * 1000L);

                        Log.e("Start", "" + startOffset);
                        Log.e("Rounded", "" + ((startOffset/1000)+1) *1000);

                        // Layout shit
                        TextView song_name = findViewById(R.id.song_name);
                        TextView song_author = findViewById(R.id.song_author);
                        TextView song_author_alt = findViewById(R.id.song_author_alt);
                        TextView song_duration = findViewById(R.id.song_duration);
                        TextView song_times = findViewById(R.id.song_times);

                        // Re-text
                        JSONObject song = jsonObject.getJSONObject("song");
                        song_name.setText(song.getString("name"));
                        song_author.setText(song.getString("author"));
                        song_author_alt.setText(song.getString("author_alt"));
                        song_times.setText("Started " + startOffset + "ms ago");

                        // Song Duration Text
                        counter.start(song_duration, (int)startOffset / 1000, song.getInt("length"));

                        // Icon
                        ImageView image = findViewById(R.id.song_icon);
                        try {
                            Glide.with(MainActivity.this)
                                    .load(song.getString("icon_dir"))
                                    .centerInside()
                                    .into(image);
                        } catch (Exception e){
                            e.printStackTrace();
                        }

                        // Station title
                        TextView station_name = findViewById(R.id.station_name);
                        TextView station_creator = findViewById(R.id.station_creator);

                        JSONObject station = jsonObject.getJSONObject("station");
                        station_name.setText(station.getString("name"));
                        station_creator.setText(station.getString("creator"));

                        // Background color
                        int color1 = Color.parseColor(song.getString("color1"));
                        int color2 = Color.parseColor(song.getString("color2"));

                        GradientDrawable gradientDrawable = (GradientDrawable) getResources().getDrawable(R.drawable.grad);
                        gradientDrawable.setColors(new int[]{color1, color2}); // Change colors dynamically
                        pg_song.setBackground(gradientDrawable);

                        // Start player
                        player.play(song.getString("song_dir"), songStart);

                        // Notification
                        notificationHelper.createNotification(song.getString("name"), song.getString("author"));

                        pg_home.setVisibility(View.GONE);
                        pg_stations.setVisibility(View.GONE);
                        pg_song.setVisibility(View.VISIBLE);
                        loadingOverlay.setVisibility(View.GONE);
                    } catch (JSONException e) {
                        popupHandler.createPopup(
                                getString(R.string.popup_nosongp_h),
                                getString(R.string.popup_nosongp_i),
                                1, // Close popup
                                0 // Nothing
                        );
                        loadingOverlay.setVisibility(View.GONE);
                        e.printStackTrace();
                    }
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });
        requestQueue.add(stringRequest);
    }

    @Override
    public void onCompletion() {
        if (currentStationID != null) {
            counter.stop();
            playStation(currentStationID);
        }else{
            notificationHelper.removeNotification();
            popupHandler.createPopup(
                    getString(R.string.popup_invstat_h),
                    getString(R.string.popup_invstat_i),
                    1, // Close popup
                    0 // Nothing
            );
        }
    }
}