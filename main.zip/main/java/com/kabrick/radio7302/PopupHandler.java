package com.kabrick.radio7302;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.constraintlayout.widget.ConstraintLayout;

public class PopupHandler {
    private ConstraintLayout popup;
    private TextView title;
    private TextView info;
    private Button button1;
    private Button button2;

    private boolean bound = false;

    private int action1 = 0;
    private int action2 = 0;

    private Context context;

    public PopupHandler(Context context){this.context = context;}

    public void Bind(
            ConstraintLayout popup,
            TextView title,
            TextView info,
            Button button1,
            Button button2
    ){
        if(!this.bound) {
            this.popup = popup;
            this.title = title;
            this.info = info;
            this.button1 = button1;
            this.button2 = button2;

            // button onclicks
            button1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    commitAction(1);
                }
            });

            button2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    commitAction(2);
                }
            });

            this.bound = true;
        }else{
            Log.e("Binding error", "Attempted to bind, while bound = true");
        }
    }

    public void commitAction(int actionID){
        int action = 0;
        if(actionID == 1) {
            action = this.action1;
        }else if(actionID == 2){
            action = this.action2;
        }else{
            Log.e("Commit Action Error", "An invalid ID was set when committing a popup action");
        }

        if(action != 0){
            if(action == 1){
                // action 1 => close popup
                popup.setVisibility(View.GONE);
            }else if(action == 2){
                // action 2 => close app
                if (context instanceof Activity) {
                    Activity activity = (Activity) context;
                    activity.finishAffinity(); // Finish all activities
                }else{
                    Log.e("Commit Action Error","Failed to close the app because Context is not an instance of Activity");
                }
            }else{
                Log.e("Commit Action Error","Invalid action was chosen, and cannot be committed");
            }
        }
    }

    private String actionToString(int action){
        if(action == 1){
            return "Close";
        }else if(action == 2){
            return "Close App";
        }else{
            return "Invalid action";
        }
    }

    public void createPopup(
            String title,
            String info,
            int act1,
            int act2
    ){
        if(bound){
            try{
                this.title.setText(title);
                this.info.setText(info);

                this.action1 = act1;
                if (act1 == 0){
                    button1.setVisibility(View.GONE);
                }else{
                    button1.setText(actionToString(act1));
                }
                this.action2 = act2;
                if (act2 == 0){
                    button2.setVisibility(View.GONE);
                }else{
                    button2.setText(actionToString(act2));
                }

                popup.setVisibility(View.VISIBLE);
            }catch (Exception e){
                Log.e("Popup Error","A popup was created, but the necessary components were not bound.");
                e.printStackTrace();
            }
        }else{
            Log.e("Popup Error","A popup was created, but the necessary components were not bound.");
            Toast.makeText(context, "Popup items not bound", Toast.LENGTH_SHORT).show();
        }
    }
}
