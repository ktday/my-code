package com.kabrick.radio7302;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.widget.TextView;

import org.jetbrains.annotations.Nullable;

public class Counter extends Service {
    Context context;

    private boolean isCounting = false;
    private int dur = 0;
    private int len = 0;

    public Counter(Context context){
        this.context = context;
        this.isCounting = false;
    }

    public void start(TextView textView, int duration, int length){
        String d = toTimestamp(duration);
        String l = toTimestamp(length);

        dur = duration;
        len = length;

        isCounting = true;

        textView.setText(d + "/" + l);

        final android.os.Handler handler = new Handler(Looper.getMainLooper());
        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                dur = dur + 1;
                String d = toTimestamp(dur);
                textView.setText(d + "/" + l);
                if(dur < len && isCounting){
                    handler.postDelayed(this, 1000);
                }
            }
        };
        handler.postDelayed(runnable, 1000);
    }

    public void stop(){
        isCounting = false;
    }

    private String toTimestamp(int i){
        if(i < 60){
            String s = i + "";
            if(s.length() == 1){
                s = "0" + s;
            }
            return "00:" + s;
        }else{
            int min = i / 60;
            int sec = i % 60;
            String m = min + "";
            if(m.length() == 1){
                m = "0" + m;
            }
            String s = sec + "";
            if(s.length() == 1){
                s = "0" + s;
            }
            return m + ":" + s;
        }
    }

    //
    // Background
    // Service
    // Code
    //

    private PowerManager.WakeLock wakeLock;

    @Override
    public void onCreate() {
        super.onCreate();
        PowerManager powerManager = (PowerManager) getSystemService(Context.POWER_SERVICE);
        wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,
                "MediaPlaybackService::WakeLock");
        wakeLock.acquire(300*60*1000L /*300 minutes - 5 hours*/);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (wakeLock != null && wakeLock.isHeld()) {
            wakeLock.release();
        }
        stop();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
