package com.kabrick.radio7302;

public class CooldownChecker {
}
