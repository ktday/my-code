package com.kabrick.radio7302;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.IBinder;
import android.os.PowerManager;
import android.util.Log;
import android.widget.Toast;

import org.jetbrains.annotations.Nullable;

import java.io.IOException;

public class Player extends Service {
    private MediaPlayer mediaPlayer;
    private Context context;

    private float volume = 0.2f;
    private boolean isPlaying = false;

    public interface OnCompletionListener {
        void onCompletion();
    }

    private OnCompletionListener onCompletionListener;

    private PowerManager.WakeLock wakeLock;

    @Override
    public void onCreate() {
        super.onCreate();

        // Initialize MediaPlayer and handle media playback

        // Acquire a partial wake lock
        PowerManager powerManager = (PowerManager) getSystemService(Context.POWER_SERVICE);
        wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,
                "MediaPlaybackService::WakeLock");
        wakeLock.acquire(300*60*1000L /*300 minutes - 5 hours*/);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // Start media playback
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        // Release the wake lock
        if (wakeLock != null && wakeLock.isHeld()) {
            wakeLock.release();
        }

        // Stop media playback
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    public Player(Context context) {
        mediaPlayer = new MediaPlayer();
        this.context = context;

        mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                if (onCompletionListener != null) {
                    onCompletionListener.onCompletion();
                }
            }
        });
    }

    public void play(String songUrl, long songStart) {
        if(isPlaying){
            stop();
        }
        Log.w("URL", songUrl);
        Log.w("Start", songStart+"");
        try {
            // Play song
            mediaPlayer.setDataSource(songUrl);
            mediaPlayer.prepare();
            mediaPlayer.setVolume(volume, volume);
            mediaPlayer.start();
            // Find timestamp
            long timeNow = System.currentTimeMillis();
            int songDelay = (int)(timeNow - songStart);
            // Set to timestamp
            if(songStart != 0){ mediaPlayer.seekTo(songDelay); }
            isPlaying = true;
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(context, "Failed to play song", Toast.LENGTH_LONG).show();
        }
    }

    public void stop(){
        isPlaying = false;
        mediaPlayer.stop();
        mediaPlayer.reset();
    }

    public void setVolume(float vol){
        if (vol <= 1){
            volume = vol;
            mediaPlayer.setVolume(vol, vol);
        }else{
            volume = 0;
            mediaPlayer.setVolume(0,0);
        }
    }

    public void setOnCompletionListener(OnCompletionListener listener) {
        this.onCompletionListener = listener;
    }
}
