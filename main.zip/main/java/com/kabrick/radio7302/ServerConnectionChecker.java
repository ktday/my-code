package com.kabrick.radio7302;

import android.content.Context;
import android.util.Log;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class ServerConnectionChecker {
    public boolean checked = false;
    public boolean connected = false;
    public boolean error = false;

    public boolean verChecked = false;
    public boolean verError = false;
    public boolean reqUpdate = false;
    public boolean Active = false;
    public String LatestVersion;
    public String MOTD;
    public String Notice;
    public String Color;

    private RequestQueue requestQueue;

    public static final String app_version = "1.0a";
    public static final int api_version = 1;

    public static String urlBase = "https://server.lord7302.com";//"http://192.168.1.75";

    public ServerConnectionChecker(Context context){
        requestQueue = Volley.newRequestQueue(context);
    }

    public void reset(){
        checked = false;
        connected = false;
        error = false;
    }

    private void update(boolean c, boolean conn, boolean e){
        checked = c;
        connected = conn;
        error = e;
    }

    public void check(){
        String URL = urlBase;
        StringRequest stringRequest = new StringRequest(URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.e("Response", response);
                if(response.equals("alive")){
                    update(true, true, false);
                }else{
                    update(true, false, false);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError Error) {
                Error.printStackTrace();
                //update(true, false, true);

                // Instead of assuming false, check for local ip
                String LocalIP = "http://192.168.1.75";
                StringRequest stringRequest1 = new StringRequest(LocalIP, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.e("Response", response);
                        if (response.equals("alive")) {
                            update(true, true, false);
                            urlBase = LocalIP;
                        } else {
                            update(true, false, false);
                        }
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Error.printStackTrace();
                        update(true, false, true);
                    }
                });
                requestQueue.add(stringRequest1);
            }
        });
        requestQueue.add(stringRequest);
    }

    public void getDetails(){
        String URL = urlBase + "/radio/getAppDetails.php";
        StringRequest stringRequest = new StringRequest(URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try{
                    JSONObject jsonObject = new JSONObject(response);

                    int active = jsonObject.getInt("ACTIVE");
                    if (active == 1){
                        Active = true;

                        int verReq = jsonObject.getInt("VER_REQ");
                        if (verReq > api_version){
                            // Out of date
                            reqUpdate = true;
                            verError = false;
                            Active = true;
                            verChecked = true;
                        }else{
                            // In date :)

                            LatestVersion = jsonObject.getString("VER_LATEST");
                            MOTD = jsonObject.getString("MOTD");
                            JSONObject notice = jsonObject.getJSONObject("NOTICE");
                            Notice = notice.getString("TXT");
                            Color = notice.getString("COL");

                            reqUpdate = false;
                            verError = false;
                            Active = true;
                            verChecked = true;
                        }
                    }else{
                        reqUpdate = false;
                        verError = false;
                        Active = false;
                        verChecked = true;
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                reqUpdate = false;
                verError = true;
                Active = false;
                verChecked = true;
                Log.e("ERROR", "Cannot contact version check");
            }
        });
        requestQueue.add(stringRequest);
    }
}
