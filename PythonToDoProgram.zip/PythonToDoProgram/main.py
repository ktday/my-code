import tkinter as tk
import tkinter.messagebox as msg

# Configs

cols = [
    '#ccc',
    '#fa0'
    ]

title = "To-Do"
w = '300'
h = '400'
geo = w + "x" + h
filenam = "list"
ffilenam = "pin"

# Create Window

root = tk.Tk()

root.title(title)
root.geometry(geo)
root.attributes('-topmost', True)

# Top frame -> add item

text = tk.StringVar(root)

frame = tk.Frame(root, width=w, highlightbackground='#000',highlightthickness=1)
frame.pack_propagate(False)
frame.columnconfigure(0,weight=4)
frame.columnconfigure(1,weight=1)
frame.pack()

wid = int( (int(w) - 50) / 5 )
label = tk.Entry(frame, width=wid, textvariable=text).grid(column=0,row=0)
btn1 = tk.Button(frame, text="Add", width=5, fg='#f00', command=lambda:add()).grid(column=1,row=0)

xframe = tk.Frame(root)
xframe.pack()


# Functions

def add():
    global text
    f = open(filenam, 'a')
    f.write("\n" + text.get())
    f.close()

    load()

def pin(i): # send item to pins
    t = ""
    ae = ""
    x = 0
    f = open(filenam, 'r')
    for l in f:
        if int(i) == x:
            if l[-1] == "\n":
                l = l[:-1]
            ae = l
        else:
            if l[-1] == "\n":
                l = l[:-1]
            t = t + '\n' + l
        x = x + 1
    f.close()

    w = open(filenam, 'w')
    w.write(t[1:])
    w.close()

    a = open(ffilenam, 'a')
    a.write("\n" + ae)
    a.close()

    load()

def unpin(i): # remove item from pins
    t = ""
    ae = ""
    x = 0
    f = open(ffilenam, 'r')
    for l in f:
        if int(i) == x:
            if l[-1] == "\n":
                l = l[:-1]
            ae = l
        else:
            if l[-1] == "\n":
                l = l[:-1]
            t = t + '\n' + l
        x = x + 1
    f.close()

    w = open(ffilenam, 'w')
    w.write(t[1:])
    w.close()

    a = open(filenam, 'a')
    a.write("\n" + ae)
    a.close()

    load()

def edel(i): # delete from list
    t = ""
    ae = ""
    x = 0
    f = open(filenam, 'r')
    for l in f:
        if int(i) != x:
            if l[-1] == "\n":
                l = l[:-1]
            t = t + '\n' + l
        x = x + 1
    f.close()

    w = open(filenam, 'w')
    w.write(t[1:])
    w.close()

    load()

def pdel(i): # delete from pins
    t = ""
    ae = ""
    x = 0
    f = open(ffilenam, 'r')
    for l in f:
        if int(i) != x:
            if l[-1] == "\n":
                l = l[:-1]
            t = t + '\n' + l
        x = x + 1
    f.close()

    w = open(ffilenam, 'w')
    w.write(t[1:])
    w.close()

    load()

# Load the list

def load():
    global xframe
    global w
    global h
    global cols
    for i in xframe.winfo_children():
        i.destroy()

    f = open(ffilenam, 'r')
    x = 0
    for i in f:
        if i[:-1] != '':
            frame = tk.Frame(xframe, width=w, highlightbackground='#000',highlightthickness=1, bg=cols[1])
            frame.pack_propagate(False)
            frame.columnconfigure(0,weight=4)
            frame.columnconfigure(1,weight=1)
            frame.columnconfigure(2,weight=1)
            frame.pack()

            if i[-1] == "\n":
                i = i[:-1]
            wid = int( (int(w) - 50) / 2 )
            label = tk.Label(frame, text=i, width=wid, bg=cols[1]).grid(column=0,row=0)
            btn1 = tk.Button(frame, text="X", width=25, fg='#f00', command=lambda a=x:pdel(a)).grid(column=1,row=0)
            btn2 = tk.Button(frame, text="-", width=25, fg='#fa0', command=lambda a=x:unpin(a)).grid(column=2,row=0)
        x = x + 1
    f.close()

    f = open(filenam, 'r')
    x = 0
    for i in f:
        if i[:-1] != '':
            frame = tk.Frame(xframe, width=w, highlightbackground='#000',highlightthickness=1, bg=cols[0])
            frame.pack_propagate(False)
            frame.columnconfigure(0,weight=4)
            frame.columnconfigure(1,weight=1)
            frame.columnconfigure(2,weight=1)
            frame.pack()

            if i[-1] == "\n":
                i = i[:-1]
            wid = int( (int(w) - 50) / 2 )
            label = tk.Label(frame, text=i, width=wid, bg=cols[0]).grid(column=0,row=0)
            btn1 = tk.Button(frame, text="X", width=25, fg='#f00', command=lambda a=x:edel(a)).grid(column=1,row=0)
            btn2 = tk.Button(frame, text="+", width=25, fg='#fa0', command=lambda a=x:pin(a)).grid(column=2,row=0)
        x = x + 1
    f.close()

load()
