<?php

session_start();

include_once("header.php");

if (empty($_SESSION['bb_login_token'])) {
    echo"<script>window.location='.'</script>";exit();
}

$account = get_account($_SESSION['bb_login_token']);

if($account == 100){
    unset($_SESSION['bb_login_token']);
    echo"<script>window.location='.'</script>";exit();
}

include_scripts("Book a table - Bean & Brew");
display_navbar();

if(
    isset($_POST['location']) &&
    isset($_POST['date']) &&
    isset($_POST['time']) &&
    isset($_POST['table']) &&
    isset($_POST['people'])
    ){
        $location = mysqli_real_escape_string($conn,$_POST['location']);

        if($location == "KnaresboroughCastle" || $location == "Leeds" || $location == "Harrogate"){

            $date = mysqli_real_escape_string($conn,$_POST['date']);
            $time = mysqli_real_escape_string($conn,$_POST['time']);
            $table = mysqli_real_escape_string($conn,$_POST['table']);
            $people = mysqli_real_escape_string($conn,$_POST['people']);

            $datetime = $date . " " . $time;
            $timestamp = strtotime($datetime);
            $datestamp = gmdate('j/m/Y', $timestamp);

            if($timestamp === false){
                echo"<script>window.location='..'</script>";exit();
            }else{

                $query = mysqli_query(
                    $conn,
                    "INSERT INTO `bb_bookings` VALUES(
                            NULL,
                            '$timestamp',
                            '$datestamp',
                            '$location',
                            '$account[id]',
                            '$table'
                        )"
                );

                echo"<script>window.location='../thankyou'</script>";exit();

            }

        }else{
            echo"<script>window.location='..'</script>";exit();
        }
    }

if(isset($_GET['loc'])){
    
    $location = mysqli_real_escape_string($conn,$_GET['loc']);

    if($location == "KnaresboroughCastle" || $location == "Leeds" || $location == "Harrogate"){

        echo"
        
        <section class='hero is-fullheight'>
            <div class='hero-body'>
                <div class='container'>
                    <div class='box'>
                        <p class='title'>Book a table now!</p>
                        <p class='subtitle'>Location: $location <br><a href='book' class='button is-primary is-light'>Change</a></p>
                        

                        <form method='post'>

                            <input type='hidden' name='location' value='$location' id='location'>
                            <input type='hidden' name='checkedavailability' value='false'>

                            <div class='field'>
                                <label class='label'>Select Date</label>
                                <div class='control has-icons-left'>
                                    <input class='input' type='date' name='date' required id='date'>
                                    <span class='icon is-small is-left'>
                                        <i class='fas fa-calendar-alt'></i>
                                    </span>
                                </div>
                            </div>

                            <div class='field'>
                                <label class='label'>Select Time</label>
                                <div class='control has-icons-left'>
                                    <input class='input' type='time' name='time' required>
                                    <span class='icon is-small is-left'>
                                        <i class='fas fa-clock'></i>
                                    </span>
                                </div>
                            </div>

                            <div class='field'>
                                <label class='label'>Select Number of People</label>
                                <div class='control has-icons-left'>
                                    <div class='select'>
                                        <select name='people'>
                                            ";

                                            $numberOfTables = 6;

                                            for($i = 1; $i <= $numberOfTables; $i++){
                                                echo"<option value='$i'>$i People</option>";
                                            }

                                            echo"
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class='field'>
                                <label class='label'>Select Table Number</label>
                                <div class='control has-icons-left'>
                                    <div class='select'>
                                        <select name='table' id='table'>
                                            ";

                                            /*$numberOfTables = 25;

                                            $invalidTables = [];

                                            $date = gmdate('j/m/Y', time());
                                            $query = mysqli_query($conn,"SELECT * FROM `bb_bookings` WHERE `date` = '$date' AND `location` = '$location'");
                                            if(mysqli_num_rows($query) > 0){
                                                $array = mysqli_fetch_array($query);
                                                $invalidTables[$array["table"]] = true;
                                            }

                                            for($i = 1; $i <= $numberOfTables; $i++){
                                                if(array_key_exists($i, $invalidTables)){
                                                    echo"<option value='$i' disabled>Table $i (Taken)</option>";
                                                }else{
                                                    echo"<option value='$i'>Table $i</option>";
                                                }
                                            }*/

                                            echo"
                                            <option disabled>Select a date first</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <button class='button is-success is-light'>Book now</button>

                            <script src='../scripts/book.js'></script>

                        </form>
                    </div>
                </div>
            </div>
        </selection>
        
        ";

    }else{
        echo"<script>window.location='../book'</script>";exit();
    }

}else{

    echo"
    
    <section class='hero is-fullheight'>
        <div class='hero-body'>
            <div class='container has-text-centered'>
                <h1 class='title is-1'>Please select a location</h1>
                <div class='columns'>
                <div class='column is-one-third'>
                    <div class='card'>
                        <br><p class='title'>Harrogate</p>
                        <a href='book/Harrogate' class='button is-primary is-light'>Select</a><br><br>
                    </div>
                </div>
                <div class='column is-one-third'>
                    <div class='card'>
                        <br><p class='title'>Leeds</p>
                        <a href='book/Leeds' class='button is-primary is-light'>Select</a><br><br>
                    </div>
                </div>
                <div class='column is-one-third'>
                    <div class='card'>
                        <br><p class='title'>Knaresborough Castle</p>
                        <a href='book/KnaresboroughCastle' class='button is-primary is-light'>Select</a><br><br>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </selection>
    
    ";

}

?>