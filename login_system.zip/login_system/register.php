<?php

session_start();

include_once("header.php");

$login_attempts = 3;

if(empty($_SESSION['login_attempts_remaining'])){
    $_SESSION['login_attempts_remaining'] = $login_attempts + 1;
}

if(empty($_SESSION['login_attempts_refresh'])){
    $_SESSION['login_attempts_refresh'] = time() + 300;
}else{
    if($_SESSION['login_attempts_refresh'] < time()){
        $_SESSION['login_attempts_refresh'] = time() + 300;
        $_SESSION['login_attempts_remaining'] = $login_attempts + 1;
    }
}

#var_dump($_SESSION);

if (empty($_SESSION['bb_login_token'])) {
    include_scripts("Register - Bean & Brew");

    if(isset($_POST["bb_register-name"]) && isset($_POST["bb_register-pass"]) && isset($_POST["bb_register-pass2"])){

        if($_SESSION['login_attempts_remaining'] < 2){
            exit("No more login attempts remaining");
        }
        
        $username = mysqli_real_escape_string($conn, $_POST['bb_register-name']);
        $email = mysqli_real_escape_string($conn, $_POST['bb_register-email']);
        $password = mysqli_real_escape_string($conn, $_POST['bb_register-pass']);
        $password2 = mysqli_real_escape_string($conn, $_POST['bb_register-pass2']);
        $accq = mysqli_query($conn,"SELECT * FROM bb_users WHERE `name` = '$username'");
        if(mysqli_num_rows($accq) != 1){
            if($password == $password2){
                $hash = password_hash($password, PASSWORD_DEFAULT);
                include("../randomstring.php");
                $session = janix(128);
                $time = time();

                mysqli_query($conn,"
                    INSERT INTO `bb_users` VALUES(NULL, '$username', '$hash', '$email', '$session', '0')
                ");

                $_SESSION["login_token"] = $session;
                unset($_SESSION["login_attempts_remaining"]);
            }else{
                $_SESSION['login_error_password'] = 1;
            }
        }else{
            $_SESSION['login_error_username'] = 1;
        }

        echo"<script>window.location='". $_SERVER["REQUEST_URI"] ."'</script>";exit();

    }

    else{

        echo"
        
        <section class='hero is-fullheight'>
            <div class='hero-body'>
            <div class='container has-text-centered'>
            <div class='column is-4 is-offset-4'>

                <div class='card'>

                    <header class='card-header'>
                        <p class='card-header-title'>Login</p>

                    </header>

                    <div class='card-content'>

                        <form method='post'>

                            <div class='field'>
                                <label class='label'>Username</label>
                                ";

                                if(empty($_SESSION['login_error_username'])){
                                    echo"
                                    
                                    <div class='control has-icons-left'>
                                        <input class='input' type='text' name='bb_register-name' placeholder='Enter username here' required>
                                        <span class='icon is-small is-left'>
                                            <i class='fas fa-user'></i>
                                        </span>
                                    </div>
                                    
                                    ";
                                }else{
                                    echo"
                                    
                                    <div class='control has-icons-left'>
                                        <input class='input is-danger' type='text' name='bb_register-name' placeholder='Enter username here' required>
                                        <span class='icon is-small is-left'>
                                            <i class='fas fa-user'></i>
                                        </span>
                                    </div>
                                    <p class='help is-danger'>That username is already taken.</p>
                                    
                                    ";
                                    unset($_SESSION['login_error_username']);
                                }

                                echo"

                            </div>

                            <div class='field'>
                                <label class='label'>Email</label>
                                <div class='control has-icons-left'>
                                    <input class='input' type='email' name='bb_register-email' placeholder='Enter email here' required>
                                    <span class='icon is-small is-left'>
                                        <i class='fas fa-envelope'></i>
                                    </span>
                                </div>
                            </div>

                            <div class='field'>
                                <label class='label'>Enter a Secure Password</label>
                                <div class='control has-icons-left'>
                                    <input class='input' type='password' name='bb_register-pass' placeholder='Enter password here' required>
                                    <span class='icon is-small is-left'>
                                        <i class='fas fa-key'></i>
                                    </span>
                                </div>
                            </div>

                            <div class='field'>
                                <label class='label'>Repeat Password</label>
                                ";

                                if(empty($_SESSION['login_error_password'])){
                                    echo"
                                    
                                    <div class='control has-icons-left'>
                                        <input class='input' type='password' name='bb_register-pass2' placeholder='Enter password here' required>
                                        <span class='icon is-small is-left'>
                                            <i class='fas fa-key'></i>
                                        </span>
                                    </div>
                                    
                                    ";
                                }else{
                                    echo"
                                    
                                    <div class='control has-icons-left'>
                                        <input class='input is-danger' type='password' name='bb_register-pass2' placeholder='Enter password here' required>
                                        <span class='icon is-small is-left'>
                                            <i class='fas fa-user'></i>
                                        </span>
                                    </div>
                                    <p class='help is-danger'>These passwords do not match.</p>
                                    
                                    ";
                                    unset($_SESSION['login_error_password']);
                                }

                                echo"

                                <br>
                                ";
                                if($_SESSION['login_attempts_remaining'] <= 1){
                                    echo"<button class='button is-grey is-light' disabled>Log in</button>
                                    <p class='help is-danger'>You have no more login attempts remaining. Please try again later.</p>";
                                }else{
                                    echo"<button class='button is-success is-light'>Register</button>
                                    <p class='is-link help'><a href='.'>Log into an account here.</a></p>";
                                }
                                
                                echo"
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </selection>
        
        ";

    }
}else{
    echo"<script>window.location='dashboard'</script>";exit();
}