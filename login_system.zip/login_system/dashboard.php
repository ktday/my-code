<?php

session_start();

include_once("header.php");

if (empty($_SESSION['bb_login_token'])) {
    echo"<script>window.location='.'</script>";exit();
}

$account = get_account($_SESSION['bb_login_token']);

if($account == 100){
    unset($_SESSION['bb_login_token']);
    echo"<script>window.location='.'</script>";exit();
}

include_scripts("Dashboard - Bean & Brew");
display_navbar();

?>