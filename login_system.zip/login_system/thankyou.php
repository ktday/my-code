<?php

session_start();

include_once("header.php");

if (empty($_SESSION['bb_login_token'])) {
    echo"<script>window.location='.'</script>";exit();
}

$account = get_account($_SESSION['bb_login_token']);

if($account == 100){
    unset($_SESSION['bb_login_token']);
    echo"<script>window.location='.'</script>";exit();
}

include_scripts("Thank you - Bean & Brew");
display_navbar();

$query = mysqli_query($conn,"SELECT * FROM `bb_bookings` WHERE `user` = '$account[id]' ORDER BY `id` DESC LIMIT 1");
if(mysqli_num_rows($query) < 1){
    echo"<script>window.location='.'</script>";exit();
}else{

    $booking = mysqli_fetch_array($query);

    $time = gmdate('H:i', $booking['time']);

    echo"
    
    <section class='hero is-fullheight'>
        <div class='hero-body'>
            <div class='container'>
                <div class='box'>
                    <p class='title has-text-success'>Thank you for booking!</p>
                    <p class='subtitle'>Here's some information about your booking</p>
                    <p>Booking location: <b>$booking[location]</b></p>
                    <p>Time and Date: <b>$booking[date] at $time</b></p>
                    <p>Booking ID: <b>$booking[id]</b></p>
                </div>
            </div>
        </div>
    </section>

    ";

}