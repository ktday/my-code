<?php

$conn = mysqli_connect("localhost","root","","database");
if(!$conn){
    echo("Invalid database connection.");exit();
}

function include_scripts($title){
    echo"
    
    <meta charset='utf-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bulma@1.0.0/css/bulma.min.css'>
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css' />
    <link rel='icon' href='/website/login_system/favicon.png' type='image/x-icon'/>
    <script src='https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>

    <title>$title</title>
    
    ";
}

function get_account($session){
    global $conn;
    $accountQuery = mysqli_query($conn,"SELECT * FROM `bb_users` WHERE `session` = '$session'");
    if(mysqli_num_rows($accountQuery) != 1){
        return 100;
    }

    $account = mysqli_fetch_array($accountQuery);

    return $account;
}

function display_navbar(){
    echo'
    
    <nav class="navbar is-light" role="navigation" aria-label="main navigation">
        <div class="navbar-brand">
            <!--<a class="navbar-item" href=".">
                <img src="favicon.png" alt="site logo"/>
            </a>-->

            <a role="button" class="navbar-burger" aria-label="menu" aria-expanded="false" data-target="navbarBasicExample">
                <span aria-hidden="true"></span>
                <span aria-hidden="true"></span>
                <span aria-hidden="true"></span>
                <span aria-hidden="true"></span>
            </a>
        </div>

        <div id="navbarBasicExample" class="navbar-menu">
            <div class="navbar-start">
                <a class="navbar-item" href=".">
                    <i class="fas fa-home"></i>
                    &nbsp;Dashboard
                </a>
                
                <a class="navbar-item" href="book">
                    <i class="fas fa-book"></i>
                    &nbsp;Book a table
                </a>

                <div class="navbar-item has-dropdown is-hoverable">
                    <a class="navbar-link" href=".">
                        <i class="fas fa-coffee"></i>
                        &nbsp;Order for collection
                    </a>
                    <div class="navbar-dropdown">
                        <a class="navbar-item" href=".">
                            <i class="fas fa-coffee"></i>
                            &nbsp;Coffee
                        </a>
                        <a class="navbar-item" href=".">
                            <i class="fas fa-bread-slice"></i>
                            &nbsp;Baked goods
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </nav>
    
    ';
}

?>