<?php

session_start();
unset($_SESSION["bb_login_token"]);

echo"<script>window.location='.'</script>";exit();

?>