<?php

header('Content-Type: application/json');

include_once("../header.php");

if (isset($_GET['location']) && isset($_GET['date'])) {
    $location = mysqli_real_escape_string($conn,$_GET['location']);
    $date1 = mysqli_real_escape_string($conn,$_GET['date']);
    $date2 = strtotime($date1);
    $date = gmdate('j/m/Y', $date2 + 43200);

    $numOfTables = 25;
    $tables = [];
    for($i = 1; $i <= $numOfTables; $i++){
        $tables[$i] = 1;
    }

    $query = mysqli_query($conn,"SELECT * FROM `bb_bookings` WHERE `date` = '$date' AND `location` = '$location'");
    if(mysqli_num_rows($query) > 0){
        while(($table = mysqli_fetch_array($query))){
            $tables[$table["table"]] = 0;
        }
    }

    echo(json_encode($tables));
}

?>