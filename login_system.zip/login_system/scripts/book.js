window.addEventListener("DOMContentLoaded", (event) => {
    const bdate = document.getElementById("date");
    const btable = document.getElementById("table");
    const blocation = document.getElementById("location");

    bdate.addEventListener('change', function(){
        const d = bdate.value;
        const l = blocation.value;

        console.log("checked");

        /*fetch(`check_tables.php?location=${l}&date=${d}`)
            .then(response => response.json())
            .then(data => updateTableOptions(data))
            .catch(error => console.error('Error fetching data: ', error));*/
        fetch(`../scripts/check_tables.php?location=${l}&date=${d}`)
            .then(res => res.json())
            .then(out => updateTableOptions(out))
            .catch(err => { throw err });
    })

    function updateTableOptions(tables){
        while (btable.firstChild) {
            btable.removeChild(btable.lastChild);
        }

        console.log("checked");

        /*tables.forEach(table => {
            const option = document.createElement('option');
            option.value = table.number;
            option.textContent = `Table ${table.number}`;
            newSelect.appendChild(option);
        });*/

        for (const tnum in tables){
                const isValid = tables[tnum];

                const option = document.createElement('option');
                option.value = tnum;
                if(isValid == 1){
                    option.textContent = `Table ${tnum}`;
                }else{
                    option.textContent = `Table ${tnum} (Taken)`;
                    option.disabled = "true";
                }
                
                btable.appendChild(option);
        }
    }
});