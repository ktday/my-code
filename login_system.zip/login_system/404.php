<?php

include_once("header.php");
include_scripts("404 - Page not found");

?>

<section class='hero is-fullheight'>
    <div class='hero-body'>
        <div class='container has-text-centered'>
            <div class='column is-4 is-offset-4'>

                <div class='card'>

                    <header class='card-header'>
                        <p class='card-header-title'>Error 404</p>
                    </header>

                    <div class='card-content'>
                        <p>The page you have requested does not exist.</p>
                        <i><?php echo"$_SERVER[REQUEST_URI]"; ?></i><br><br>
                        <a class='button is-success is-light' href='.'>Return to homepage</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>