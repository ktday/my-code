import tkinter as tk
import random
import time
from tkinter import messagebox

root = tk.Tk()
root.geometry("200x200")
root.title("Noughts and Crosses")

grid = [0,0,0, 0,0,0, 0,0,0]
moves_left = [9]

#load data
savef = open("save",'r')
s = savef.read()
vals = eval(s)
pw, bw = vals[0], vals[1]
savef.close()

mb = tk.Menu(root)
root.config(menu=mb)

frame = tk.Frame(root,height=200,width=200)
frame.pack()

def save():
    global pw
    global bw
    arr = [pw,bw]
    savef = open("save",'w')
    savef.write(str(arr))
    savef.close()
    messagebox.showinfo(title="Game Saved!", message="Save successful!")

def e():
    global root
    save()
    root.destroy()

def startBtn():
    global pw
    global bw
    tk.Button(frame,text="Start Game!",command=placeBtn).pack()
    tk.Label(frame,text=f"Wins: {pw} | Loses: {bw}").pack()
    tk.Label(frame,text="").pack()
    tk.Button(frame,text="Save data",command=save).pack()
    tk.Button(frame,text="Exit",command=e).pack()

def clearFrame():
    for i in frame.winfo_children():
        i.destroy()

def btn(i):
    if i == 0:
        return tk.Button(frame, text=' -- ')
    elif i == 1:
        return tk.Button(frame, text=' O ', state="disabled")
    elif i == 2:
        return tk.Button(frame, text=' X ', state="disabled")

def placeBtn():
    pos = [[0,0],[1,0],[2,0],
           [0,1],[1,1],[2,1],
           [0,2],[1,2],[2,2]]

    clearFrame()

    x = 0
    for i in grid:
        p = pos[x]
        pp = (x)

        b = btn(i)
        b["command"] = lambda pos=x:place(pos)
        b.grid(row=p[1], column=p[0])
        
        #time.sleep(0.1)
        x += 1

def restart():
    global grid
    global moves_left
    clearFrame()
    moves_left[0] = 9
    grid = [0,0,0, 0,0,0, 0,0,0]
    startBtn()

def anncWinner(x):
    global pw
    global bw
    #print("WON")
    if x == 1:
        #player won
        pw += 1
        messagebox.showinfo(title="We have a winner!", message="You have won the game!")
    else:
        bw += 1
        messagebox.showinfo(title="We have a winner!", message="You have LOST the game!")
    #print(str(pw) + " " + str(bw))

def checkWin(x):
    if grid[0] == x and grid[1] == x and grid[2] == x:
        anncWinner(x)
        return True
    elif grid[3] == x and grid[4] == x and grid[5] == x:
        anncWinner(x)
        return True
    elif grid[6] == x and grid[7] == x and grid[8] == x:
        anncWinner(x)
        return True
        
    elif grid[0] == x and grid[3] == x and grid[6] == x:
        anncWinner(x)
        return True
    elif grid[1] == x and grid[4] == x and grid[7] == x:
        anncWinner(x)
        return True
    elif grid[2] == x and grid[5] == x and grid[8] == x:
        anncWinner(x)
        return True
        
    elif grid[0] == x and grid[4] == x and grid[8] == x:
        anncWinner(x)
        return True
    elif grid[2] == x and grid[4] == x and grid[6] == x:
        anncWinner(x)
        return True
    else:
        return False

def botPlace():
    i = random.randint(0,1)
    #print(i)
    i = 1
    if i == 1:
        arr = [
            [0, 1, 2],
            [3, 4, 5],
            [6, 7, 8],
            [0, 3, 6],
            [1, 4, 7],
            [2, 5, 8],
            [0, 4, 8],
            [2, 4, 6]
            ]

        random.shuffle(arr)

        a = False
        for i in arr:
            if a == False:
                if grid[i[0]] != 0 and grid[i[1]] != 0 and grid[i[2]] == 0:
                    grid[i[2]] = 2
                    a = True
                elif grid[i[0]] != 0 and grid[i[1]] == 0 and grid[i[2]] != 0:
                    grid[i[1]] = 2
                    a = True
                elif grid[i[0]] == 0 and grid[i[1]] != 0 and grid[i[2]] != 0:
                    grid[i[0]] = 2
                    a = True
            
        

        if a == False:
            b = []
            x = 0
            for i in grid:
                if i == 0:
                    b.append(x)
                x += 1
            random.shuffle(b)
            #print(b)
            grid[b[0]] = 2

def place(pos):
    global grid
    #print(grid)
    if grid[pos] == 0:
        grid[pos] = 1
        placeBtn()
        w = checkWin(1)

        if w == True:
            # player has won
            clearFrame()
            moves_left[0] = 9
            grid = [0,0,0, 0,0,0, 0,0,0]
            startBtn()
        else:

            #print(moves_left[0])
            moves_left[0] = moves_left[0] - 1
            if moves_left[0] == 0:

                messagebox.showerror(title="We have a winner!",message="There was a tie! No one has won this round.")
                clearFrame()
                moves_left[0] = 9
                grid = [0,0,0, 0,0,0, 0,0,0]
                startBtn()
                
            else:
                time.sleep(1)
                botPlace()
                placeBtn()
                w = checkWin(2)

                if w == True:
                    # bot has won
                    clearFrame()
                    moves_left[0] = 9
                    grid = [0,0,0, 0,0,0, 0,0,0]
                    startBtn()
                else:
                    moves_left[0] = moves_left[0] - 1

menu = tk.Menu(mb)
menu.add_command(label='Save',command=save)
menu.add_command(label='To Menu',command=restart)
menu.add_command(label='Exit',command=e)
mb.add_cascade(label='File', menu=menu)

startBtn()

tk.mainloop()
