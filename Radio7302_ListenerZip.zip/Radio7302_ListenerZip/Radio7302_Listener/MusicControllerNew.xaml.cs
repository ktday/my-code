﻿using NAudio.Dsp;
using NAudio.Wave.SampleProviders;
using NAudio.Wave;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;
using Newtonsoft.Json;
using System.Net.Http;

namespace Radio7302_Listener
{
    /// <summary>
    /// Interaction logic for MusicControllerNew.xaml
    /// </summary>
    public partial class MusicControllerNew : Window
    {
        string baseurl = "http://server.lord7302.com";

        string stationId = string.Empty;

        private IWavePlayer wavePlayer;
        private MediaFoundationReader mediaReader;
        private MeteringSampleProvider meteringProvider;

        /*public MusicControllerNew()
        {
            InitializeComponent();
            //InitializeEqualizer("http://example.com/your-audio-file.mp3"); // Replace with your URL
        }*/
        public MusicControllerNew(string title, string station)
        {
            InitializeComponent();
            this.Title = title;
            this.Topmost = true;
            stationId = station;
        }

        private void Window_PreviewLostKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e)
        {
            var window = (Window)sender;
            window.Topmost = true;
        }

        // Gradient

        public Color ConvertHexToColor(string hex)
        {
            // Ensure the hex string starts with a #
            if (!hex.StartsWith("#"))
            {
                hex = "#" + hex;
            }

            return (Color)ColorConverter.ConvertFromString(hex);
        }

        public void ChangeGradientColors(string hex1, string hex2)
        {
            Color col1 = ConvertHexToColor(hex1);
            Color col2 = ConvertHexToColor(hex2);

            LinearGradientBrush gradientBrush = BackgroundGradient;

            gradientBrush.GradientStops[0].Color = col1;
            gradientBrush.GradientStops[1].Color = col2;
        }

        // Equaliser

        public void InitializeEqualizer(string url, int startSeconds)
        {
            wavePlayer = new WaveOutEvent();
            mediaReader = new MediaFoundationReader(url);

            long startPositionInBytes = (long)(startSeconds * mediaReader.WaveFormat.SampleRate *
                                                           mediaReader.WaveFormat.BitsPerSample / 8 *
                                                           mediaReader.WaveFormat.Channels);
            mediaReader.Position = startPositionInBytes;

            var sampleChannel = new SampleChannel(mediaReader, true);
            meteringProvider = new MeteringSampleProvider(sampleChannel);

            meteringProvider.StreamVolume += OnStreamVolume;

            wavePlayer.Init(meteringProvider);
            wavePlayer.Play();

            wavePlayer.PlaybackStopped += OnPlaybackStopped;

            DispatcherTimer timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromMilliseconds(100);
            timer.Tick += Timer_Tick;
            timer.Start();
        }

        private void OnStreamVolume(object sender, StreamVolumeEventArgs e)
        {
            // Average of left and right channels
            float volume = (e.MaxSampleValues[0] + e.MaxSampleValues[1]) / 2.0f;
            float vol1 = e.MaxSampleValues[0];
            float vol2 = e.MaxSampleValues[1];

            Dispatcher.Invoke(() =>
            {
                Bar1.Value = vol1 * 100;
                Bar2.Value = vol2 * 100;
            });
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            // The StreamVolume event will handle the UI update
            // Update the duration text
            if (mediaReader != null && wavePlayer.PlaybackState == PlaybackState.Playing)
            {
                try
                {
                    TimeSpan currentTime = mediaReader.CurrentTime;
                    TimeSpan totalTime = mediaReader.TotalTime;

                    SongDuration.Text = $"{currentTime.ToString(@"mm\:ss")} / {totalTime.ToString(@"mm\:ss")}";

                    // Update the progress bar
                    double currentSeconds = currentTime.TotalSeconds;
                    double totalSeconds = totalTime.TotalSeconds;

                    if (totalSeconds > 0)
                    {
                        double progress = (currentSeconds / totalSeconds) * 100;
                        SongDurationBar.Value = progress;
                    }
                }
                catch (Exception ex)
                {
                    // Handle the exception or log it
                    Console.WriteLine($"Error updating time: {ex.Message}");
                }
            }
        }

        // Destroy audio

        private void destroyAll()
        {
            wavePlayer?.Stop();
            wavePlayer?.Dispose();
            wavePlayer = null;
            mediaReader.Position = 0;
            mediaReader?.Dispose();
            mediaReader = null;
        }

        private void OnPlaybackStopped(object sender, StoppedEventArgs e)
        {
            //Console.WriteLine($"Ended. Lengths -> {mediaReader.Position} - {mediaReader.Length}");
            if (mediaReader != null)
            {
                PlayNextSong();
            }
        }

        private async void PlayNextSong()
        {
            // Dispose the current player and reader
            destroyAll();

            if (string.IsNullOrEmpty(stationId))
            {
                MessageBox.Show("Invalid station selected.");
                return;
            }

            // Get next song
            string url = baseurl + "/radio/getStationSong.php?id=" + stationId;

            using (HttpClient client = new HttpClient())
            {
                try
                {
                    HttpResponseMessage response = await client.GetAsync(url);
                    response.EnsureSuccessStatusCode();

                    string responseBody = await response.Content.ReadAsStringAsync();

                    if (responseBody == "-1")
                    {
                        MessageBox.Show("Cannot play: Radio station has an invalid ID");
                    }
                    else if (responseBody == "0")
                    {
                        MessageBox.Show("Cannot play: Radio station does not exist");
                    }
                    else
                    {
                        dynamic jsonData = JsonConvert.DeserializeObject<dynamic>(responseBody);

                        // Fill out panel

                        dynamic station = jsonData.station;

                        //controller.SetID(station.id.ToString());

                        // Fill out song playing

                        dynamic song = jsonData.song;

                        if (song.name == "0")
                        {
                            SongName.Text = "No song playing.";
                            SongAuthor.Text = string.Empty;

                            SongIcon.Visibility = Visibility.Collapsed;
                        }
                        else
                        {
                            SongName.Text = song.name;
                            SongAuthor.Text = song.author;

                            ChangeGradientColors(
                                song.color1.ToString(),
                                song.color2.ToString()
                            );

                            try
                            {

                                BitmapImage bitmap = new BitmapImage();
                                bitmap.BeginInit();
                                bitmap.UriSource = new Uri(song.icon_dir.ToString(), UriKind.Absolute);
                                bitmap.EndInit();

                                // Set the Image control's Source property to the new BitmapImage
                                SongIcon.Source = bitmap;
                                SongIcon.Visibility = Visibility.Visible;
                            }
                            catch
                            {
                                SongIcon.Visibility = Visibility.Collapsed;

                                MessageBox.Show("Can't load song image");
                            }
                        }

                        // Play the song
                        int start = jsonData.startOffset;
                        InitializeEqualizer(song.song_dir.ToString(), start);

                    }
                }
                catch (HttpRequestException ex)
                {
                    MessageBox.Show("HTTP Request Error");
                }
                catch (JsonException ex)
                {
                    MessageBox.Show("JSON Error");
                }
            }
        }

        protected override void OnClosed(EventArgs e)
        {
            base.OnClosed(e);
            destroyAll();
        }

    }
}
