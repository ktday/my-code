﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Net.Http;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static System.Collections.Specialized.BitVector32;
using static System.Net.Mime.MediaTypeNames;

namespace Radio7302_Listener
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        string baseurl = "http://server.lord7302.com";

        string stationClicked = string.Empty;
        string stationSelected = string.Empty;

        bool songPlaying = false;

        private MusicControllerNew controller;

        public class RadioStation
        {
            public string Name { get; set; }
            public string Creator { get; set; }
            public string Playing { get; set; }
            public string Id { get; set; }
            public bool IsSelected { get; set; }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        public ObservableCollection<RadioStation> Stations { get; set; }

        public MainWindow()
        {
            InitializeComponent();

            Stations = new ObservableCollection<RadioStation>();

            DataContext = this;

            Load_Stations();
        }

        private async void Load_Stations() 
        {
            string url = baseurl + "/radio/getStations.php";

            using (HttpClient client = new HttpClient())
            {
                try
                {
                    HttpResponseMessage response = await client.GetAsync(url);
                    response.EnsureSuccessStatusCode();

                    string responseBody = await response.Content.ReadAsStringAsync();
                    dynamic jsonData = JsonConvert.DeserializeObject<dynamic>(responseBody);

                    itemsControl.ItemsSource = null;
                    var itemsList = new ObservableCollection<RadioStation>();

                    foreach (var item in jsonData)
                    {
                        itemsList.Add(new RadioStation
                        {
                            Name = item.name,
                            Creator = item.creator,
                            Playing = item.playing,
                            Id = item.id,
                            IsSelected = false
                        });
                    }

                    itemsControl.Items.Clear();
                    itemsControl.ItemsSource = itemsList;

                    Stations = itemsList;

                    // Reset to defaults

                    stationClicked = string.Empty;
                    stationSelected = string.Empty;
                    songPlaying = false;

                    StationDetailsPane.Visibility = Visibility.Collapsed;

                    RadioSelectorText.Text = "Select a radio station";
                    RadioSelectorText.Foreground = Brushes.Black;
                }
                catch (HttpRequestException ex)
                {
                    Console.WriteLine($"HTTP Request Error: {ex.Message}");
                    RadioSelectorText.Text = "HTTP Request Error";
                    RadioSelectorText.Foreground = Brushes.Red;
                }
                catch (JsonException ex)
                {
                    Console.WriteLine($"JSON Error: {ex.Message}");
                    RadioSelectorText.Text = "JSON Error";
                    RadioSelectorText.Foreground = Brushes.Red;
                }
            }
        }

        private async void Click_Select(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(stationClicked))
            {
                RadioSelectorText.Text = "Select a radio station";
                RadioSelectorText.Foreground = Brushes.Red;
            }
            else
            {
                string url = baseurl + "/radio/getStationSong.php?id=" + stationClicked;

                using (HttpClient client = new HttpClient())
                {
                    try
                    {
                        HttpResponseMessage response = await client.GetAsync(url);
                        response.EnsureSuccessStatusCode();

                        string responseBody = await response.Content.ReadAsStringAsync();

                        if (responseBody == "-1")
                        {
                            RadioSelectorText.Text = "Radio station has an invalid ID";
                            RadioSelectorText.Foreground = Brushes.Red;
                        }else if (responseBody == "0")
                        {
                            RadioSelectorText.Text = "Radio station does not exist";
                            RadioSelectorText.Foreground = Brushes.Red;
                        }
                        else
                        {
                            dynamic jsonData = JsonConvert.DeserializeObject<dynamic>(responseBody);

                            bool textUpdated = false;

                            // Fill out panel

                            dynamic station = jsonData.station;

                            StationDetailsName.Text = station.name;
                            StationDetailsCreator.Text = station.creator;

                            stationSelected = station.id;

                            // Fill out song playing

                            dynamic song = jsonData.song;

                            if (song.name == "0")
                            {
                                StationDetailsNowPlaying.Text = "No song playing.";
                                StationDetailsNowPlayingAuthor.Text = string.Empty;

                                StationDetailsImage.Visibility = Visibility.Collapsed;

                                songPlaying = false;
                            }
                            else
                            {
                                songPlaying = true;

                                StationDetailsNowPlaying.Text = song.name;
                                StationDetailsNowPlayingAuthor.Text = song.author;

                                try
                                {

                                    BitmapImage bitmap = new BitmapImage();
                                    bitmap.BeginInit();
                                    bitmap.UriSource = new Uri(song.icon_dir.ToString(), UriKind.Absolute);
                                    bitmap.EndInit();

                                    // Set the Image control's Source property to the new BitmapImage
                                    StationDetailsImage.Source = bitmap;
                                    StationDetailsImage.Visibility = Visibility.Visible;
                                }
                                catch
                                {
                                    StationDetailsImage.Visibility = Visibility.Collapsed;

                                    textUpdated = true;
                                    RadioSelectorText.Text = "Can't load song image";
                                    RadioSelectorText.Foreground = Brushes.Red;
                                }
                            }

                            StationDetailsPane.Visibility = Visibility.Visible;

                            if (!textUpdated)
                            {
                                RadioSelectorText.Text = "Select a radio station";
                                RadioSelectorText.Foreground = Brushes.Black;
                            }
                            
                        }
                    }
                    catch (HttpRequestException ex)
                    {
                        Console.WriteLine($"HTTP Request Error: {ex.Message}");
                        RadioSelectorText.Text = "HTTP Request Error";
                        RadioSelectorText.Foreground = Brushes.Red;
                    }
                    catch (JsonException ex)
                    {
                        Console.WriteLine($"JSON Error: {ex.Message}");
                        RadioSelectorText.Text = "JSON Error";
                        RadioSelectorText.Foreground = Brushes.Red;
                    }
                }
            }
        }

        private async void Click_Play(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(stationSelected) || !songPlaying)
            {
                RadioSelectorText.Text = "Cannot play station";
                RadioSelectorText.Foreground = Brushes.Red;
            }
            else
            {
                string url = baseurl + "/radio/getStationSong.php?id=" + stationSelected;

                using (HttpClient client = new HttpClient())
                {
                    try
                    {
                        HttpResponseMessage response = await client.GetAsync(url);
                        response.EnsureSuccessStatusCode();

                        string responseBody = await response.Content.ReadAsStringAsync();

                        if (responseBody == "-1")
                        {
                            RadioSelectorText.Text = "Cannot play: Radio station has an invalid ID";
                            RadioSelectorText.Foreground = Brushes.Red;
                        }
                        else if (responseBody == "0")
                        {
                            RadioSelectorText.Text = "Cannot play: Radio station does not exist";
                            RadioSelectorText.Foreground = Brushes.Red;
                        }
                        else
                        {
                            dynamic jsonData = JsonConvert.DeserializeObject<dynamic>(responseBody);

                            bool textUpdated = false;

                            // Fill out panel

                            dynamic station = jsonData.station;

                            if (controller != null)
                            {
                                controller.Close();
                            }

                            controller = new MusicControllerNew(station.name.ToString(), stationSelected);
                            controller.Show();

                            //controller.SetID(station.id.ToString());

                            // Fill out song playing

                            dynamic song = jsonData.song;

                            if (song.name == "0")
                            {
                                controller.SongName.Text = "No song playing.";
                                controller.SongAuthor.Text = string.Empty;

                                controller.SongIcon.Visibility = Visibility.Collapsed;
                            }
                            else
                            {
                                controller.SongName.Text = song.name;
                                controller.SongAuthor.Text = song.author;

                                controller.ChangeGradientColors(
                                    song.color1.ToString(),
                                    song.color2.ToString()
                                );

                                try
                                {

                                    BitmapImage bitmap = new BitmapImage();
                                    bitmap.BeginInit();
                                    bitmap.UriSource = new Uri(song.icon_dir.ToString(), UriKind.Absolute);
                                    bitmap.EndInit();

                                    // Set the Image control's Source property to the new BitmapImage
                                    controller.SongIcon.Source = bitmap;
                                    controller.SongIcon.Visibility = Visibility.Visible;
                                }
                                catch
                                {
                                    controller.SongIcon.Visibility = Visibility.Collapsed;

                                    textUpdated = true;
                                    RadioSelectorText.Text = "Can't load song image";
                                    RadioSelectorText.Foreground = Brushes.Red;
                                }
                            }

                            // Play the song
                            int start = jsonData.startOffset;
                            //controller.PlayMediaAsync(song.song_dir.ToString(), start);
                            controller.InitializeEqualizer(song.song_dir.ToString(), start);

                            if (!textUpdated)
                            {
                                RadioSelectorText.Text = "Select a radio station";
                                RadioSelectorText.Foreground = Brushes.Black;
                            }

                        }
                    }
                    catch (HttpRequestException ex)
                    {
                        Console.WriteLine($"HTTP Request Error: {ex.Message}");
                        RadioSelectorText.Text = "HTTP Request Error";
                        RadioSelectorText.Foreground = Brushes.Red;
                    }
                    catch (JsonException ex)
                    {
                        Console.WriteLine($"JSON Error: {ex.Message}");
                        RadioSelectorText.Text = "JSON Error";
                        RadioSelectorText.Foreground = Brushes.Red;
                    }
                }
            }
        }

        private void Click_Exit(object sender, RoutedEventArgs e)
        {
            System.Windows.Application.Current.Shutdown();
        }

        private void Click_Reload(object sender, RoutedEventArgs e)
        {
            Load_Stations();
        }

        private void MouseLeftButtonDown_Station(object sender, MouseButtonEventArgs e)
        {
            Border border = sender as Border;

            if (border != null)
            {
                RadioStation clickedItem = border.DataContext as RadioStation;

                if (clickedItem != null)
                {
                    foreach (var station in Stations)
                    {
                        station.IsSelected = false;
                        Console.WriteLine(station.Name + " reset");
                    }

                    clickedItem.IsSelected = true;
                    Console.WriteLine(clickedItem.Name + " added");

                    stationClicked = clickedItem.Id.ToString();

                    itemsControl.Items.Refresh();
                }
                else
                {
                    RadioSelectorText.Text = "TextBlock is null";
                    RadioSelectorText.Foreground = Brushes.Red;
                }
            }
            else
            {
                RadioSelectorText.Text = "Border is null";
                RadioSelectorText.Foreground = Brushes.Red;
            }
        }
    }
}
