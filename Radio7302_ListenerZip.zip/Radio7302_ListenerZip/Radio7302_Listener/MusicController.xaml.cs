﻿using NAudio.Dsp;
using NAudio.Wave;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Radio7302_Listener
{
    /// <summary>
    /// Interaction logic for MusicController.xaml
    /// </summary>
    public partial class MusicController : Window
    {
        private string id;

        static bool isAudioPlaying = false;
        private WaveOutEvent outputDevice;
        private MediaFoundationReader audioFile;

        public MusicController(string title)
        {
            InitializeComponent();
            InitializeEqualizer();
            this.Title = title;
        }

        protected override void OnClosed(EventArgs e)
        {
            base.OnClosed(e);
            if (isAudioPlaying)
            {
                // Stop
                outputDevice?.Stop();

                try
                {
                    // Dispose
                    outputDevice.Dispose();
                    outputDevice = null;
                    audioFile.Position = 0;
                    audioFile.Dispose();
                    audioFile = null;
                }
                catch 
                {
                    MessageBox.Show("This song cannot be disposed right now.");
                }

                // Reset bool
                isAudioPlaying = false;
            }
        }

        private void Window_PreviewLostKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e)
        {
            var window = (Window)sender;
            window.Topmost = true;
        }

        //
        // Play
        //

        public void PlayMediaAsync(string audioUrl, int startSeconds)
        {
            try
            {
                outputDevice = new WaveOutEvent();
                audioFile = new MediaFoundationReader(audioUrl);
                long startPositionInBytes = (long)(startSeconds * audioFile.WaveFormat.SampleRate *
                                                           audioFile.WaveFormat.BitsPerSample / 8 *
                                                           audioFile.WaveFormat.Channels);
                audioFile.Position = startPositionInBytes;

                outputDevice.Init(audioFile);
                outputDevice.Play();

                // Update bool
                isAudioPlaying = true;
            }
            catch
            {
                MessageBox.Show("This song cannot be played.");
                isAudioPlaying = false;
            }
        }

        public Color ConvertHexToColor(string hex)
        {
            // Ensure the hex string starts with a #
            if (!hex.StartsWith("#"))
            {
                hex = "#" + hex;
            }

            return (Color)ColorConverter.ConvertFromString(hex);
        }

        public void ChangeGradientColors(string hex1, string hex2)
        {
            Color col1 = ConvertHexToColor(hex1);
            Color col2 = ConvertHexToColor(hex2);

            LinearGradientBrush gradientBrush = BackgroundGradient;

            gradientBrush.GradientStops[0].Color = col1;
            gradientBrush.GradientStops[1].Color = col2;
        }

        public void SetID(string sid)
        {
            id = sid;
        }

        //
        //
        // E
        //
        // Q
        //
        // U
        //
        // A
        //
        // L
        //
        // I
        // 
        // S
        //
        // E
        //
        // R
        //
        //

        private WaveInEvent waveIn;
        private DispatcherTimer timer;
        private float[] fftBuffer = new float[1024];
        private Complex[] fftComplexBuffer = new Complex[1024];
        private int fftPos;
        private bool fftBufferFilled;

        private void InitializeEqualizer()
        {
            waveIn = new WaveInEvent();
            waveIn.WaveFormat = new WaveFormat(44100, 1); // 44.1kHz mono
            waveIn.DataAvailable += OnDataAvailable;
            waveIn.StartRecording();

            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromMilliseconds(100); // Update every 100 milliseconds
            timer.Tick += Timer_Tick;
            timer.Start();
        }

        private void OnDataAvailable(object sender, WaveInEventArgs e)
        {
            for (int i = 0; i < e.BytesRecorded; i += 2)
            {
                short sample = (short)((e.Buffer[i + 1] << 8) | e.Buffer[i + 0]);
                float sample32 = sample / 32768f;
                fftBuffer[fftPos] = sample32;
                fftComplexBuffer[fftPos].X = (float)(sample32 * FastFourierTransform.HannWindow(fftPos, fftBuffer.Length));
                fftComplexBuffer[fftPos].Y = 0;
                fftPos++;
                if (fftPos >= fftBuffer.Length)
                {
                    fftPos = 0;
                    fftBufferFilled = true;
                    FastFourierTransform.FFT(true, (int)Math.Log(fftBuffer.Length, 2.0), fftComplexBuffer);
                }
            }
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            if (fftBufferFilled)
            {
                float lowFreq = 0, midFreq = 0, highFreq = 0;
                int lowCount = 0, midCount = 0, highCount = 0;

                for (int i = 0; i < fftComplexBuffer.Length / 2; i++)
                {
                    float magnitude = fftComplexBuffer[i].X * fftComplexBuffer[i].X + fftComplexBuffer[i].Y * fftComplexBuffer[i].Y;
                    if (i < fftComplexBuffer.Length / 6)
                    {
                        lowFreq += magnitude;
                        lowCount++;
                    }
                    else if (i < fftComplexBuffer.Length / 3)
                    {
                        midFreq += magnitude;
                        midCount++;
                    }
                    else
                    {
                        highFreq += magnitude;
                        highCount++;
                    }
                }

                Bar1.Value = lowFreq / lowCount * 100;
                Bar2.Value = midFreq / midCount * 100;
                Bar3.Value = highFreq / highCount * 100;
            }
        }
    }
}
